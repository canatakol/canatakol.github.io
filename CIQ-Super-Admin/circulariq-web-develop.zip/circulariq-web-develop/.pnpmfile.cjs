function readPackage(pkg) {
  // Allow chromedriver to run its install scripts
  if (pkg.name === 'chromedriver') {
    pkg.scripts = pkg.scripts || {};
  }
  return pkg;
}

module.exports = {
  hooks: {
    readPackage,
  },
};
