# Current User Information Usage Guide

Bu dokümantasyon, uygulamada aktif kullanıcının bilgilerine nasıl erişileceğini açıklar.

## SessionStorage'dan Kullanıcı Bilgilerine Erişim

Uygulamada kullanıcı bilgileri `sessionStorage`'da `credentials` anahtarı altında saklanır. Bu bilgiler şu şekilde erişilebilir:

### 1. CurrentUserService Kullanımı (Önerilen)

```typescript
import { CurrentUserService } from '@app/core/services/current-user.service';

constructor(private currentUserService: CurrentUserService) {}

// Kullanıcı email'ini al
const userEmail = this.currentUserService.getCurrentUserEmail();

// Kullanıcı adını al
const userName = this.currentUserService.getCurrentUserName();

// Kullanıcı ID'sini al
const userId = this.currentUserService.getCurrentUserId();

// Kullanıcının kimlik doğrulama token'ını al
const authToken = this.currentUserService.getCurrentUserToken();

// Kullanıcının tam bilgilerini al
const credentials = this.currentUserService.getCurrentUserCredentials();

// Kullanıcının kimlik doğrulandığını kontrol et
const isAuthenticated = this.currentUserService.isAuthenticated();

// Kullanıcının belirli bir özelliğe sahip olup olmadığını kontrol et
const hasE5Feature = this.currentUserService.hasFeature('e5');
const isProUser = this.currentUserService.isProUser();
const isCIQUser = this.currentUserService.isCIQUser();

// Kullanıcının email'inin doğrulanıp doğrulanmadığını kontrol et
const isEmailVerified = this.currentUserService.isEmailVerified();
```

### 2. Doğrudan SessionStorage Erişimi

```typescript
// Kullanıcı bilgilerini doğrudan sessionStorage'dan al
const credentials = sessionStorage.getItem('credentials');
if (credentials) {
  const userData = JSON.parse(credentials);
  const userEmail = userData.email;
  const userName = userData.name;
  const userId = userData.userId;
  const authToken = userData.authToken;
}
```

## Kullanım Örnekleri

### Component'te Kullanım

```typescript
import { Component, OnInit } from '@angular/core';
import { CurrentUserService } from '@app/core/services/current-user.service';

@Component({
  selector: 'app-example',
  template: `
    <div *ngIf="isAuthenticated">
      <p>Hoş geldin, {{ currentUserName }}!</p>
      <p>Email: {{ currentUserEmail }}</p>
      <p *ngIf="isProUser">Pro kullanıcısınız</p>
    </div>
  `,
})
export class ExampleComponent implements OnInit {
  currentUserEmail: string = '';
  currentUserName: string = '';
  isAuthenticated: boolean = false;
  isProUser: boolean = false;

  constructor(private currentUserService: CurrentUserService) {}

  ngOnInit(): void {
    this.currentUserEmail = this.currentUserService.getCurrentUserEmail();
    this.currentUserName = this.currentUserService.getCurrentUserName();
    this.isAuthenticated = this.currentUserService.isAuthenticated();
    this.isProUser = this.currentUserService.isProUser();
  }
}
```

### Mentions Filtreleme Örneği

```typescript
// Kullanıcının kendisine yapılan mention'ları filtrele
filterMentionsForCurrentUser(notifications: any[]): any[] {
  const currentUserCredentials = this.currentUserService.getCurrentUserCredentials();

  return notifications.filter(notification => {
    if (!notification.mentions || notification.mentions.length === 0) {
      return false;
    }

    return notification.mentions.some(mention =>
      mention.userId === currentUserCredentials.userId ||
      mention.username === currentUserCredentials.email
    );
  });
}
```

### Koşullu İçerik Gösterme

```typescript
// Template'te koşullu içerik gösterme
<div *ngIf="currentUserService.isCIQUser()">
  <!-- CIQ kullanıcılarına özel içerik -->
</div>

<div *ngIf="currentUserService.isProUser()">
  <!-- Pro kullanıcılarına özel içerik -->
</div>

<div *ngIf="!currentUserService.isEmailVerified()">
  <!-- Email doğrulanmamış kullanıcılara uyarı -->
  <p>Lütfen email adresinizi doğrulayın.</p>
</div>
```

## Credentials Objesi Yapısı

SessionStorage'da saklanan credentials objesi şu yapıya sahiptir:

```typescript
interface UserCredentials {
  authToken: string; // Kimlik doğrulama token'ı
  userId: string; // Kullanıcı ID'si
  email: string; // Kullanıcı email'i
  name: string; // Kullanıcı adı
  organisation?: any; // Organizasyon bilgileri
  memberships?: any[]; // Üyelik bilgileri
  features?: string[]; // Kullanıcının sahip olduğu özellikler
  emailVerified?: boolean; // Email doğrulama durumu
  show2025Terms?: boolean; // 2025 şartları gösterilip gösterilmediği
  [key: string]: any; // Diğer ek özellikler
}
```

## Güvenlik Notları

1. **SessionStorage Güvenliği**: Kullanıcı bilgileri sessionStorage'da saklanır ve tarayıcı kapatıldığında temizlenir.
2. **Token Güvenliği**: Auth token'ı güvenli bir şekilde saklanır ve HTTP isteklerinde kullanılır.
3. **Hata Yönetimi**: Service'te try-catch blokları kullanılarak hata durumları yönetilir.

## Debug ve Test

Uygulamada debug bilgilerini görmek için `CommentCenterComponent`'te debug bölümü eklenmiştir. Bu bölümü production'da kaldırmayı unutmayın.

```html
<!-- Debug Section - Remove this in production -->
<div class="debug-info"><strong>Current User:</strong> {{ getCurrentUserName() }} ({{ getCurrentUserEmail() }})</div>
```

## Örnek Component

`UserInfoExampleComponent` tam bir kullanım örneği sağlar. Bu component'i referans olarak kullanabilirsiniz.
