// npx nightwatch test/e2e/basic/create_business_level_and_assessmet_then_delete.js
describe('Create Business Level and Assessment Test then Remove', function () {
  this.tags = ['Create Business Level and Assessment Test then Remove'];

  before(function (browser) {
    browser.setWindowSize(1920, 1080).setWindowPosition(0, 0);
  });

  it('Create Business Level and Assessment Test then Remove', function (browser) {
    browser
      // login test
      .url('https://accept-cti.circular-iq.com/login')
      .waitForElementPresent('body', 10000)
      .waitForElementVisible('input[formcontrolname="email"]', 10000)
      .setValue('input[formcontrolname="email"]', 'ecagiral@gmail.com')
      .setValue('input[formcontrolname="password"]', 'Welcome01')
      .click('#login-button')
      .waitForElementPresent('.box ul li', 20000)
      .assert.urlContains('/cti/select-organisation')
      .waitForElementVisible('.box ul li:nth-child(1)', 10000)
      .click('.box ul li:nth-child(1)')
      .assert.urlContains('/cti/pro-business')
      .waitForElementPresent('body', 10000)
      .execute(function () {
        console.log('Current URL:', window.location.href);
        console.log('Available elements:', document.body.innerHTML);
      })

      // Create business level
      .waitForElementVisible('#addBusiness', 10000)
      .click('#addBusiness')
      .waitForElementPresent('#dialog-wrapper input[formcontrolname="name"]', 10000)
      .setValue('#dialog-wrapper input[formcontrolname="name"]', 'aaaaa new business level')
      .waitForElementPresent('#dialog-wrapper select[formcontrolname="type"]', 10000)
      .click('#dialog-wrapper select[formcontrolname="type"] option:nth-child(2)')
      .waitForElementPresent('#dialog-wrapper .btn-circular.bg-shamrock', 10000)
      .click('#dialog-wrapper .btn-circular.bg-shamrock')
      .waitForElementPresent('.table-box tr:nth-child(1)', 10000)

      // Create assessment
      .waitForElementPresent('.table-box', 10000)
      .waitForElementPresent('.table-box .btn-circular', 10000)
      .click('.table-box .btn-circular')
      .waitForElementPresent('#dialog-wrapper input[formcontrolname="name"]', 10000)
      .setValue('#dialog-wrapper input[formcontrolname="name"]', 'aaaa new assessment')
      .waitForElementPresent('#dialog-wrapper .btn-circular.bg-shamrock', 10000)
      .click('#dialog-wrapper .btn-circular.bg-shamrock')
      .waitForElementPresent('.btn-circular', 10000)

      // Delete assessment
      .waitForElementPresent('.table-box:nth-child(2) tbody tr:nth-child(1) .settings', 10000)
      .waitForElementVisible('.table-box:nth-child(2) tbody tr:nth-child(1) .settings', 10000)
      .click('.table-box:nth-child(2) tbody tr:nth-child(1) .settings')
      .waitForElementPresent('.action', 10000)
      .waitForElementVisible('.action', 10000)
      .waitForElementPresent('.action .delete', 10000)
      .waitForElementVisible('.action .delete', 10000)
      .execute(function () {
        document.querySelector('.action .delete').click();
      })
      .waitForElementPresent('#dialog-wrapper', 10000)
      .waitForElementVisible('#dialog-wrapper', 10000)
      .waitForElementPresent('#dialog-wrapper .bg-watermelon', 10000)
      .waitForElementVisible('#dialog-wrapper .bg-watermelon', 10000)
      .execute(function () {
        document.querySelector('#dialog-wrapper .bg-watermelon').click();
      })
      .waitForElementPresent('.success-snackBar', 10000)

      // Delete business level
      .waitForElementPresent('.table-box:nth-child(2) .settingsBussines', 10000)
      .waitForElementVisible('.table-box:nth-child(2) .settingsBussines', 10000)
      .click('.table-box:nth-child(2) .settingsBussines')
      .waitForElementPresent('.action', 10000)
      .waitForElementVisible('.action', 10000)
      .waitForElementPresent('.action .delete', 10000)
      .waitForElementVisible('.action .delete', 10000)
      .execute(function () {
        document.querySelector('.action .delete').click();
      })
      .waitForElementPresent('#dialog-wrapper', 10000)
      .waitForElementVisible('#dialog-wrapper', 10000)
      .waitForElementPresent('#dialog-wrapper .bg-watermelon', 10000)
      .waitForElementVisible('#dialog-wrapper .bg-watermelon', 10000)
      .execute(function () {
        document.querySelector('#dialog-wrapper .bg-watermelon').click();
      })
      .waitForElementPresent('.success-snackBar', 10000);
  });

  after(function (browser) {
    console.log('Test completed. Closing down...');
  });

  afterEach(function (browser, done) {
    browser.pause(1000);
    done();
  });
});
