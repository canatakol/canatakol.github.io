// npx nightwatch test/e2e/basic/report.js
describe('Ecosia', function () {
  this.tags = ['Report'];
  it('Successful Report Test', function (browser) {
    browser
      .url('https://accept-cti.circular-iq.com/login/')
      .waitForElementPresent('body', 1000)
      .setValue(element({ selector: '.login-box input', index: 0 }), 'kadir-pro@accept.com')
      .setValue(element({ selector: '.login-box input', index: 1 }), 'Welcome01')
      .click('.login-box button')
      .pause(2000)
      .assert.urlContains('/cti/select-organisation')
      .pause(2000)
      .click('.box ul li:nth-child(1)')
      .pause(10000)
      .url('https://accept-cti.circular-iq.com/cti/pro-business')
      .pause(3000)
      // Wait for the page to load and check if there are assessments
      .waitForElementPresent('.table', 10000)
      .execute(
        function () {
          // Check if there are any assessment rows in the table
          const assessmentRows = document.querySelectorAll('.table tbody tr');
          return assessmentRows.length > 0;
        },
        [],
        function (result) {
          if (result.value) {
            // If assessments exist, continue with the test
            browser
              .waitForElementPresent('.table tbody tr:first-child .settings span.material-icons', 5000)
              .click('.table tbody tr:first-child .settings span.material-icons')
              .pause(2000)
              // Try multiple selectors for the action menu
              .execute(
                function () {
                  // Check if any action menu is visible
                  const actionMenus = document.querySelectorAll('.action');
                  const visibleMenus = Array.from(actionMenus).filter(
                    (menu) => menu.style.display !== 'none' && menu.offsetParent !== null
                  );

                  if (visibleMenus.length > 0) {
                    // Find the first visible action menu with data-uuid
                    const actionElement = visibleMenus[0].querySelector('span[data-uuid]');
                    if (actionElement) {
                      return { found: true, unitId: actionElement.getAttribute('data-uuid') };
                    }
                  }

                  // If no visible menu, try to find any span with data-uuid
                  const allDataUuidElements = document.querySelectorAll('span[data-uuid]');
                  if (allDataUuidElements.length > 0) {
                    return { found: true, unitId: allDataUuidElements[0].getAttribute('data-uuid') };
                  }

                  return { found: false, unitId: null };
                },
                [],
                function (result) {
                  if (result.value && result.value.found && result.value.unitId) {
                    // We found the unitId, now get the authToken and proceed
                    browser.execute(
                      function () {
                        try {
                          const credentials = JSON.parse(sessionStorage.getItem('credentials'));
                          const authToken = credentials ? credentials.authToken : null;
                          return { authToken, unitId: arguments[0] };
                        } catch (error) {
                          console.error('Error in execute script:', error);
                          return { authToken: null, unitId: null };
                        }
                      },
                      [result.value.unitId],
                      function (result) {
                        if (result.value && result.value.authToken && result.value.unitId) {
                          const { authToken, unitId } = result.value;
                          browser
                            .url(`https://accept-cti.circular-iq.com/cti/${unitId}/${authToken}/report`)
                            .pause(1000)
                            .end();
                        } else {
                          console.error('Failed to get authToken or unitId:', result.value);
                          browser.end();
                        }
                      }
                    );
                  } else {
                    // Try clicking on the first action menu item if it exists
                    browser.execute(
                      function () {
                        // Try to find and click on any action menu item
                        const actionSpans = document.querySelectorAll('.action span');
                        if (actionSpans.length > 0) {
                          // Click on the first action span (Download Report)
                          actionSpans[0].click();
                          return { clicked: true };
                        }
                        return { clicked: false };
                      },
                      [],
                      function (result) {
                        if (result.value && result.value.clicked) {
                          // Wait a bit and then try to get the unitId
                          browser.pause(1000).execute(
                            function () {
                              try {
                                const credentials = JSON.parse(sessionStorage.getItem('credentials'));
                                const authToken = credentials ? credentials.authToken : null;

                                // Try to get unitId from any element with data-uuid
                                const dataUuidElement = document.querySelector('[data-uuid]');
                                const unitId = dataUuidElement ? dataUuidElement.getAttribute('data-uuid') : null;

                                return { authToken, unitId };
                              } catch (error) {
                                console.error('Error in execute script:', error);
                                return { authToken: null, unitId: null };
                              }
                            },
                            [],
                            function (result) {
                              if (result.value && result.value.authToken && result.value.unitId) {
                                const { authToken, unitId } = result.value;
                                browser
                                  .url(`https://accept-cti.circular-iq.com/cti/${unitId}/${authToken}/report`)
                                  .pause(1000)
                                  .end();
                              } else {
                                console.error('Failed to get authToken or unitId:', result.value);
                                browser.end();
                              }
                            }
                          );
                        } else {
                          console.error('Could not find or click action menu');
                          browser.end();
                        }
                      }
                    );
                  }
                }
              );
          } else {
            console.log('No assessments found in the table');
            browser.end();
          }
        }
      );
  });
  after(function (browser) {
    console.log('Closing down...');
  }),
    afterEach(function (browser, done) {
      browser.pause(10);
      done();
    });
});
