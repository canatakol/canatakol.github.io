// npx nightwatch test/e2e/basic/step3-outflow-question.js
describe('Step3 inflow quetsion test', function () {
  this.tags = ['Step3 inflow quetsion test'];

  it('Step3 inflow quetsion test', function (browser) {
    browser
      // login test
      .url('https://accept-cti.circular-iq.com/login/')
      .waitForElementPresent('body', 1000)
      .setValue(element({ selector: '.login-box input', index: 0 }), 'kadir-pro@accept.com')
      .setValue(element({ selector: '.login-box input', index: 1 }), 'Welcome01')
      .pause(2000)
      .click('.login-box button')
      .pause(2000)
      .assert.urlContains('/cti/select-organisation')
      .pause(2000)
      .click('.box ul li:nth-child(1)')
      .pause(2000)

      // // created bussines level test

      .waitForElementVisible('#addBusiness')
      .pause(5000)
      .click('#addBusiness ')

      .setValue(
        element({ selector: '#dialog-wrapper input', index: 0 }),
        'aaaa Automatic test created this bussines level'
      )
      .waitForElementVisible('#dialog-wrapper .defult-select')
      .click('#dialog-wrapper .defult-select')
      .click('#business-level-1')
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bottom-box .btn-circular')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(3000)
      // created assesesment test
      .click('.no-ass .btn-circular')
      .pause(1000)
      .setValue(
        element({ selector: '#dialog-wrapper input', index: 0 }),
        'aaaa Automatic test created this assesesment'
      )
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bottom-box .btn-circular')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(5000)

      // select assment test
      .waitForElementVisible('.table-box')
      .pause(1000)
      .click('.table-box .settings:nth-child(1)')
      .click('.action span:nth-child(2)')
      .waitForElementVisible('#step3')
      .click('#step3')
      // add new Outflow
      .waitForElementVisible('#add-outflow')
      .click('#add-outflow')
      .waitForElementVisible('#flow-name')
      .setValue(element({ selector: '#flow-name' }), 'Automatic Test Flow')
      .pause(1000)
      .click('#add-btn')
      // answer inflow question
      .pause(5000)
      .setValue(element({ selector: '#M18' }), 'Automatic Test')
      .setValue(element({ selector: '#kg' }), '10')
      .setValue(element({ selector: '#TI10' }), 'material')
      .setValue(element({ selector: '#TI4' }), '50')
      .setValue(element({ selector: '#TI12' }), 'biological')
      .setValue(element({ selector: '#TI5' }), '100')
      .pause(1000)
      .click('#submit')
      .pause(1000)
      // check sankey info
      .click('#step4')
      .pause(3000)
      .assert.textEquals('#potentialRecoveryWeight', '5.00 Kg')
      .assert.textEquals('#nonPotentialRecoveryWeight', '5.00 Kg')
      .assert.textEquals('#outflowCircularWeight', '5.00 Kg')
      .assert.textEquals('#outflowLinearWeight', '5.00 Kg')
      .click('#leftNavPro')
      .pause(3000)
      // remove assesesment test
      .click('.pro .settings:nth-child(1)')
      .click('.action span:nth-child(4)')
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bg-watermelon')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(3000)
      // remove bussines level test
      .click('.table-box .table-head-line .settingsBussines')
      .click('.table-box .table-head-line .settingsBussines .delete')
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .pause(1000)
      .click('#dialog-wrapper .bg-watermelon')
      .pause(3000)
      .assert.visible('.success-snackBar');
  }),
    after(function (browser) {
      console.log('Closing down...');
    }),
    afterEach(function (browser, done) {
      browser.pause(10);
      done();
      // }
    });
});
