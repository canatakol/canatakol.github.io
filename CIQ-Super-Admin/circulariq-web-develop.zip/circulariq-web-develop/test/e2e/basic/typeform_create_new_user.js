// npx nightwatch test/e2e/basic/typeform_create_new_user.js

describe(' Typeform create new user', function () {
  this.tags = ['Typeform create new user'];

  it.skip('Successful Typeform create new user', function (browser) {
    browser
      .url('https://circulariq.typeform.com/to/YZYiFY86')
      // dev .url('https://circulariq.typeform.com/to/mz3O4oeL')
      // prod .url('https://circulariq.typeform.com/to/YZYiFY86')
      .waitForElementVisible('body', 10000)
      .pause(2000)
      .waitForElementVisible('[role="button"], button', 15000)
      .click(element({ selector: '[role="button"], button', index: 0 }))
      .waitForElementVisible('.renderer-in', 10000)
      .waitForElementVisible('input[type="text"]', 15000)
      .setValue(element({ selector: 'input[type="text"]', index: 0 }), 'Kadir')
      .setValue(element({ selector: 'input[type="text"]', index: 1 }), 'Erbakar')
      .setValue(
        element({ selector: 'input[type="text"]', index: 2 }),
        `kadir+${(Math.random() + 1).toString(36).substring(7)}@circular-iq.com`
      )
      .setValue(element({ selector: 'input[type="text"]', index: 3 }), 'Automatic Test')
      .waitForElementVisible('[data-qa="submit-button"], button[type="submit"], [role="button"]', 15000)
      .click(element({ selector: '[data-qa="submit-button"], button[type="submit"], [role="button"]', index: 0 }))
      .waitForElementVisible('body', 10000)
      .pause(5000) // Increased pause time for redirect

      // Wait for redirect and check if we're on the login page
      .waitForElementPresent('.set-password', 20000)
      .waitForElementVisible('input[type="password"]', 10000)
      .setValue('input[type="password"]', 'Welcome01')
      .waitForElementVisible('input[type="password"]', 10000)
      .setValue('input[type="password"]', 'Welcome01')
      .pause(1000)
      .click('.check_terms_of_agreement')
      .pause(1000)
      .submitForm('.set-password')
      .waitForElementPresent('.form form', 15000)
      .assert.urlContains('/cti/guide/new-user')
      .pause(3000)
      .submitForm('.form form')
      .end();
  });

  after(function (browser) {
    console.log('Closing down...');
  });

  afterEach(function (browser, done) {
    browser.pause(10);
    done();
  });
});
