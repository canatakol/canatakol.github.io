// npx nightwatch test/e2e/basic/step3-inflow-question.js
describe('Step3 inflow quetsion test', function () {
  this.tags = ['Step3 inflow quetsion test'];

  it('Step3 inflow quetsion test', function (browser) {
    browser
      // // create user test
      // .url('https://circulariq.typeform.com/to/YZYiFY86')
      // .pause(1000)
      // .assert.visible('.ButtonWrapper-sc-__sc-1qu8p4z-0')
      // .click('.ButtonWrapper-sc-__sc-1qu8p4z-0')
      // .pause(3000)
      // .assert.visible('.renderer-in')
      // .setValue(element({ selector: '.SpacerWrapper-sc-__sc-4rs8xl-0 input', index: 0 }), 'Kadir')
      // .setValue(element({ selector: '.SpacerWrapper-sc-__sc-4rs8xl-0 input', index: 1 }), 'Erbakar')
      // .setValue(
      //   element({ selector: '.SpacerWrapper-sc-__sc-4rs8xl-0 input', index: 2 }),
      //   `kadir+${(Math.random() + 1).toString(36).substring(7)}@circular-iq.com`
      // )
      // .setValue(element({ selector: '.SpacerWrapper-sc-__sc-4rs8xl-0 input', index: 3 }), 'Automatic Test')
      // .click('.ButtonWrapper-sc-__sc-1qu8p4z-0')
      // .waitForElementVisible('.login-box', 20000)
      // .assert.visible('.login-box')
      // .setValue(element({ selector: '.set-password  input', index: 0 }), 'Welcome01')
      // .setValue(element({ selector: '.set-password  input', index: 1 }), 'Welcome01')
      // .click('.mat-checkbox-inner-container')
      // .click('.btn-circular')
      // .assert.urlContains('/cti/guide/new-user')
      // .pause(2000)
      // .click('.bg-shamrock')

      // .assert.urlContains('/cti/pro')

      // kadi3wrrewfrwe@circular-iq.com

      // login test
      .url('https://accept-cti.circular-iq.com/login/')
      .waitForElementPresent('body', 1000)
      .setValue(element({ selector: '.login-box input', index: 0 }), 'kadir-pro@accept.com')
      .setValue(element({ selector: '.login-box input', index: 1 }), 'Welcome01')
      .pause(2000)
      .click('.login-box button')
      .pause(2000)
      .assert.urlContains('/cti/select-organisation')
      .pause(2000)
      .click('.box ul li:nth-child(1)')
      .pause(2000)

      // // created bussines level test

      .waitForElementVisible('#addBusiness')
      .pause(5000)
      .click('#addBusiness ')

      .setValue(
        element({ selector: '#dialog-wrapper input', index: 0 }),
        'aaaa Automatic test created this bussines level'
      )
      .waitForElementVisible('#dialog-wrapper .defult-select')
      .click('#dialog-wrapper .defult-select')
      .click('#business-level-1')
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bottom-box .btn-circular')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(3000)
      // created assesesment test
      .click('.no-ass .btn-circular')
      .pause(1000)
      .setValue(
        element({ selector: '#dialog-wrapper input', index: 0 }),
        'aaaa Automatic test created this assesesment'
      )
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bottom-box .btn-circular')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(5000)

      // select assment test
      .waitForElementVisible('.table-box')
      .pause(1000)
      .click('.table-box .settings:nth-child(1)')
      .click('.action span:nth-child(2)')
      .waitForElementVisible('#step3')
      .click('#step3')
      // add new inflow
      .waitForElementVisible('#add-inflow')
      .click('#add-inflow')
      .waitForElementVisible('#flow-name')
      .setValue(element({ selector: '#flow-name' }), 'Automatic Test Flow')
      .click('#our-organization')
      .pause(1000)
      .click('#me')
      .pause(1000)
      .click('#add-btn')
      // answer inflow question
      .pause(5000)
      .setValue(element({ selector: '#M18' }), 'Automatic Test')
      .setValue(element({ selector: '#kg' }), '10')
      .setValue(element({ selector: '#TI17' }), '10')
      .setValue(element({ selector: '#TI2' }), '20')
      .setValue(element({ selector: '#TI1' }), '30')
      .setValue(element({ selector: '#TI10' }), 'material')
      .pause(1000)
      .click('#submit')
      .pause(1000)
      // check sankey info
      .click('#step4')
      .pause(3000)
      .assert.textEquals('#circularInflowkg', '6.00 Kg')
      .assert.textEquals('#linearInflowkg', '4.00 Kg')
      .assert.textEquals('#circularOutflow', '50.00%')
      .assert.textEquals('#linearOutflow', '50.00%')
      .click('#leftNavPro')
      .pause(3000)
      // remove assesesment test
      .click('.pro .settings:nth-child(1)')
      .click('.action span:nth-child(4)')
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .click('#dialog-wrapper .bg-watermelon')
      .pause(1000)
      .assert.visible('.success-snackBar')
      .pause(3000)
      // remove bussines level test
      .click('.table-box .table-head-line .settingsBussines')
      .click('.table-box .table-head-line .settingsBussines .delete')
      .pause(1000)
      .assert.visible('#dialog-wrapper')
      .pause(1000)
      .click('#dialog-wrapper .bg-watermelon')
      .pause(3000)
      .assert.visible('.success-snackBar');
  }),
    after(function (browser) {
      console.log('Closing down...');
    }),
    afterEach(function (browser, done) {
      browser.pause(10);
      done();
      // }
    });
});
