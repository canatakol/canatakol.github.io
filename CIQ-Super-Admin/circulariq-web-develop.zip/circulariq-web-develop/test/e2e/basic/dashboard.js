// npx nightwatch test/e2e/basic/dashboard.js

describe('Login Workflow', function () {
  this.tags = ['login'];

  it('Successful Login Test', function (browser) {
    browser
      .url('https://accept-cti.circular-iq.com/login/')
      .waitForElementPresent('body', 1000)
      .setValue(element({ selector: '.login-box input', index: 0 }), 'kadir-pro@accept.com')
      .setValue(element({ selector: '.login-box input', index: 1 }), 'Welcome01')
      .pause(2000)
      .submitForm('.loginForm form')
      .waitForElementVisible('body', 5000)
      .assert.urlContains('/cti/select-organisation')
      .end();
  }),
    it('Failed Login Test', function (browser) {
      browser
        .url('https://accept-cti.circular-iq.com/login/')
        .waitForElementPresent('body', 1000)
        .setValue(element({ selector: '.login-box input', index: 0 }), 'kadir-pro@accept.com')
        .setValue(element({ selector: '.login-box input', index: 1 }), 'Welcome')
        .submitForm('.loginForm form')
        .pause(1000)
        .assert.urlContains('/login')
        .end();
    }),
    after(function (browser) {
      console.log('Closing down...');
    }),
    afterEach(function (browser, done) {
      browser.pause(10);
      done();
    });
});
