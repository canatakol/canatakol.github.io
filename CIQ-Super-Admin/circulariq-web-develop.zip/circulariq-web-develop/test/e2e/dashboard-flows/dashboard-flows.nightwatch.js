/**
 * Nightwatch E2E to cover dashboard flows (replace + improve + create scenario)
 * Preconditions (set as env vars):
 *  - NIGHTWATCH_FLOWS_URL: full URL of the dashboard flows screen (inflows or outflows)
 *  - NIGHTWATCH_EMAIL / NIGHTWATCH_PASSWORD: credentials used on the login form
 *
 * The test:
 *  - loads the flows page and logs in if needed
 *  - spies on XHR to assert the preview/save payloads only contain changed items
 *  - performs a replace action on the first row
 *  - performs an improve action on the second row
 *  - validates on-screen calculations (total mass / circular mass)
 *  - creates a new scenario and confirms the improvements payload is sent
 */

const flowsUrl =
  process.env.NIGHTWATCH_FLOWS_URL ||
  'https://accept-cti.circular-iq.com/cti/dashboard/d1c29fb5-8e42-4385-8dfb-1ec923f464e7/sustainability';
const loginEmail = process.env.NIGHTWATCH_EMAIL || 'kadir-pro@accept.com';
const loginPassword = process.env.NIGHTWATCH_PASSWORD || 'Welcome01';
const loginUrl = 'https://accept-cti.circular-iq.com/login/';

const replaceMass = Number(process.env.NIGHTWATCH_REPLACE_MASS || 120);
const replaceLinear = Number(process.env.NIGHTWATCH_REPLACE_LINEAR || 35);
const improveMass = Number(process.env.NIGHTWATCH_IMPROVE_MASS || 150);
const improveLinear = Number(process.env.NIGHTWATCH_IMPROVE_LINEAR || 25);

const FIRST_ROW = '.flow-row:nth-of-type(1)';
const SECOND_ROW = '.flow-row:nth-of-type(2)';

function toNumber(text) {
  if (!text) return 0;
  let clean = String(text).replace(/[^0-9.,-]/g, '');
  const lastDot = clean.lastIndexOf('.');
  const lastComma = clean.lastIndexOf(',');
  if (lastComma > lastDot) {
    clean = clean.replace(/\./g, '').replace(',', '.');
  } else if (lastDot > lastComma) {
    clean = clean.replace(/,/g, '');
  } else if (lastDot !== -1 || lastComma !== -1) {
    clean = clean.replace(/[,.]/, '.');
  }
  const parsed = parseFloat(clean);
  return Number.isFinite(parsed) ? parsed : 0;
}

function installRequestSpy(browser) {
  return browser.execute(function () {
    // Store captured requests on window for later assertions
    window.__capturedRequests = [];

    const serializeBody = (body) => {
      if (!body) return null;
      if (typeof body === 'string') return body;
      try {
        return JSON.stringify(body);
      } catch (e) {
        return body && body.toString ? body.toString() : null;
      }
    };

    const originalOpen = XMLHttpRequest.prototype.open;
    const originalSend = XMLHttpRequest.prototype.send;

    XMLHttpRequest.prototype.open = function (method, url) {
      this.__reqInfo = { method, url };
      return originalOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
      const reqInfo = this.__reqInfo || {};
      reqInfo.body = serializeBody(body);
      const start = Date.now();

      this.addEventListener('loadend', function () {
        try {
          window.__capturedRequests.push({
            url: reqInfo.url,
            method: reqInfo.method,
            body: reqInfo.body,
            status: this.status,
            duration: Date.now() - start,
            responseText: this.responseText || '',
          });
        } catch (e) {
          // swallow errors in the spy to avoid impacting the app
        }
      });

      return originalSend.apply(this, arguments);
    };
    return true;
  });
}

describe('Dashboard flows replace / improve / scenario', function () {
  this.tags = ['dashboard-flows'];

  it('replaces, improves, and saves scenario with correct payloads', function (browser) {
    browser.assert.equal(!!flowsUrl, true, 'NIGHTWATCH_FLOWS_URL must be provided');

    // First go to login page
    browser.url(loginUrl).waitForElementVisible('body', 10000);

    browser
      .waitForElementVisible('.login-box', 10000)
      .setValue('.login-box input[type="text"]', loginEmail)
      .setValue('.login-box input[type="password"]', loginPassword)
      .click('.loginForm form button[type="submit"]')
      .waitForElementNotPresent('.loginForm form', 15000);

    // After login, navigate to the specific dashboard sustainability tab
    browser.url(flowsUrl).waitForElementVisible('body', 10000);

    installRequestSpy(browser);

    browser.waitForElementVisible('.flow-row', 20000);

    // --- Replace first row
    browser.execute(
      function (selector) {
        const el = document.querySelector(selector);
        if (el) el.scrollIntoView({ block: 'center' });
      },
      [`${FIRST_ROW} .line-action-buttons.replace`]
    );
    browser.pause(1000);
    browser.click(`${FIRST_ROW} .line-action-buttons.replace`);
    browser.waitForElementVisible('#dialog-wrapper', 5000);
    browser
      .clearValue('input[formcontrolname="flowName"]')
      .setValue('input[formcontrolname="flowName"]', 'Nightwatch Replace');
    browser
      .clearValue('input[formcontrolname="totalMass"]')
      .setValue('input[formcontrolname="totalMass"]', String(replaceMass));
    browser
      .clearValue('input[formcontrolname="linearPercentage"]')
      .setValue('input[formcontrolname="linearPercentage"]', String(replaceLinear));
    browser.click('#dialog-wrapper button.btn-save');
    browser.waitForElementNotPresent('#dialog-wrapper', 10000);
    browser.pause(2000); // Wait for animations/rerender
    browser.waitForElementVisible(`${FIRST_ROW} .badge`, 5000);
    browser.expect.element(`${FIRST_ROW} .badge`).text.contains('REPLACED');

    // --- Improve second row
    browser.execute(
      function (selector) {
        const el = document.querySelector(selector);
        if (el) el.scrollIntoView({ block: 'center' });
      },
      [`${SECOND_ROW} .line-action-buttons.improve`]
    );
    browser.pause(1000);
    browser.click(`${SECOND_ROW} .line-action-buttons.improve`);
    browser.waitForElementVisible('#dialog-wrapper', 5000);
    browser
      .clearValue('input[formcontrolname="totalMass"]')
      .setValue('input[formcontrolname="totalMass"]', String(improveMass));
    browser
      .clearValue('input[formcontrolname="linearPercentage"]')
      .setValue('input[formcontrolname="linearPercentage"]', String(improveLinear));
    browser.click('#dialog-wrapper button.btn-save');
    browser.pause(1000);
    browser.waitForElementNotPresent('#dialog-wrapper', 10000);
    browser.waitForElementVisible(`${SECOND_ROW} .badge`, 5000);
    browser.expect.element(`${SECOND_ROW} .badge`).text.contains('IMPROVED');

    // --- Validate recalculated masses on improved row
    browser.execute(
      function (selector) {
        const el = document.querySelector(selector);
        if (!el) return '';
        // Clone to avoid mutation, remove temporary-value span
        const clone = el.cloneNode(true);
        const temp = clone.querySelector('.temporary-value');
        if (temp) temp.remove();
        return (clone.innerText || clone.textContent).trim();
      },
      [`${SECOND_ROW} .improve-column-1 .text`],
      function (massRes) {
        const displayedMass = toNumber(massRes.value);
        browser.assert.equal(Math.abs(displayedMass - improveMass) < 0.01, true, 'Total mass updated after improve');
      }
    );

    browser.execute(
      function (selector) {
        const el = document.querySelector(selector);
        if (!el) return '';
        const clone = el.cloneNode(true);
        const temp = clone.querySelector('.temporary-value');
        if (temp) temp.remove();
        return clone.innerText || clone.textContent;
      },
      [`${SECOND_ROW} .improve-column-3 .text`],
      function (circularRes) {
        const expectedCircularMass = (improveMass * (100 - improveLinear)) / 100;
        const displayedCircular = toNumber(circularRes.value);
        browser.assert.equal(
          Math.abs(displayedCircular - expectedCircularMass) < 0.5,
          true,
          'Circular mass recalculated'
        );
      }
    );

    // --- Create scenario with current draft changes
    const scenarioName = `Nightwatch Scenario ${Date.now()}`;
    browser.click('.action-island .btn-create-scenario');
    browser.waitForElementVisible('input#scenarioName', 10000);
    browser.clearValue('input#scenarioName').setValue('input#scenarioName', scenarioName);
    browser.click('.scenario-dialog .btn-primary');
    browser.waitForElementNotPresent('.scenario-dialog', 15000);
    browser.pause(2000); // Allow time for POST create -> then PUT improvements to complete

    // --- Assert requests/payloads captured by spy
    browser.perform(function (done) {
      browser.execute(
        function () {
          return (window.__capturedRequests || []).map(function (r) {
            return {
              url: r.url,
              method: r.method,
              status: r.status,
              body: r.body,
            };
          });
        },
        [],
        function (res) {
          const requests = res.value || [];

          const previewRequests = requests.filter((r) => (r.url || '').includes('/preview-improvements/'));
          browser.assert.equal(previewRequests.length > 0, true, 'Preview improvements request(s) sent');

          if (previewRequests.length > 0) {
            // Check the last preview request as it should contain all changes
            const lastPreview = previewRequests[previewRequests.length - 1];
            try {
              const payload = JSON.parse(lastPreview.body);
              browser.assert.equal(
                Array.isArray(payload.replacedFlows) && payload.replacedFlows.length > 0,
                true,
                'Replaced flows payload sent in last preview'
              );
              browser.assert.equal(
                Array.isArray(payload.improvedFlows) && payload.improvedFlows.length > 0,
                true,
                'Improved flows payload sent in last preview'
              );
            } catch (e) {
              browser.assert.fail('Preview payload is not valid JSON');
            }
          }

          const saveReq = requests.find(
            (r) => (r.url || '').includes('/cti/scenarios/') && r.method && r.method.toUpperCase() === 'PUT'
          );
          browser.assert.equal(!!saveReq, true, 'Scenario save PUT sent with draft changes');

          done();
        }
      );
    });

    browser.end();
  });
});
