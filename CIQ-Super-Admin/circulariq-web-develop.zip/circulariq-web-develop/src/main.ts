/*
 * Entry point of the application.
 * Only platform bootstrapping code should be here.
 * For app-specific initialization, use `app/app.component.ts`.
 */

import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule } from '@app/app.module';
import { environment } from '@env/environment';
import posthog from 'posthog-js';

const posthogConfig = (
  environment as {
    posthog: { apiKey: string; apiHost: string; defaults?: string };
  }
).posthog;

posthog.init(posthogConfig.apiKey, {
  api_host: posthogConfig.apiHost,
  defaults: posthogConfig.defaults,
} as any);

if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic()
  .bootstrapModule(AppModule)
  .catch((err) => {
    // Error handled silently in production
  });
