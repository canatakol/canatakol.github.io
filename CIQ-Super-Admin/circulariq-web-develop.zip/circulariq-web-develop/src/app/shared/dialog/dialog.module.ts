import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatStepperModule } from '@angular/material/stepper';
import { MatTableModule } from '@angular/material/table';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FilePondModule } from 'ngx-filepond';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { GuidanceComponent } from '@app/shared-components/guidance/guidance';
import { LabelManagmentComponent } from '@app/pro/label-managment/label-managment.component';

// Import all dialog components
import { InviteColleagueDialog } from './invite-colleague/invite-colleague.component';
import { DeleteConfirmDialog } from './delete-confirm/delete-confirm-dialog.component';
import { UpdateNameDialog } from './update-name/update-name-dialog.component';
import { TFAConfirmDialog } from './tfa-confirm/tfa-confirm-dialog.component';
import { DupplicateAssessmentDialog } from './duplicate_assesment/duplicate_assesment_dialog.component';
import { SetOrganisationGoalAssessmentDialog } from './set-organisation-goal/set_organisation_goal_dialog.component';
import { SetMeetingEventDialog } from './set-meeting-event/set-meeting-event-dialog.component';
import { ImportAssessmentDialog } from './import_assessment/import_assessment_dialog.component';
import { ImportAssessmentErrorDialog } from './import-assessment-error/import_assessment_error_dialog.component';
import { ConfirmDialog } from './confirm-dialog/confirm-dialog.component';
import { PublishConfirmDialog } from './publish-confirm/publish-confirm-dialog.component';
import { IsReadyConfirmDialog } from './isReady-confirm/isReady-confirm-dialog.component';
import { ReportStatusDialog } from './report-status/report-status-dialog.component';
import { NewUserDialogComponent } from './new-user/new-user.component';
import { NewSupplierDialogComponent } from './new-supplier/new-supplier.component';
import { Step7DownloadReportDialog } from './step7-download-report/step7-download-report-dialog.component';
import { ActualRecoveryRatetDialog } from './actual-recovery-rate/actual-recovery-rate-dialog.component';
import { AddAssessmentDialog } from './add-assessment/add-assessment.component';
import { AddLabelDialog } from './add-label/add-label.component';
import { WatchvideoConfirmDialog } from './watch-video/watch-video-dialog.component';
import { ManageMembersDialog } from './manage-members/manage-members-dialog.component';
import { AddBusinessLevelDialog } from './add-business-level/add-business-level.component';
import { MoveAssessmentDialog } from './move-assessment/move-assessment.component';
import { EditBusinessLevelDialog } from './edit-business-level/edit-business-level.component';
import { InviteNewMemberDialog } from './invite-new-member/invite-new-member.component';
import { MergeAssessmentsConfirmDialog } from './merge-assessments-confirm/merge-assessments-confirm.component';
import { ImportAssessmentE5Dialog } from './import_assessment_e5/import_assessment_e5_dialog.component';
import { LabelManagmentDialog } from './label-managment/label-managment.component';
import { E5ReportDialog } from './e5-report/e5-report.component';

// Import pipes
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatStepperModule,
    MatTableModule,
    NgbModule,
    FilePondModule,
    CurrencyMaskModule,
    CiqNumberPipe,
    TruncatePipe,
    LabelManagmentComponent,
    GuidanceComponent,
  ],
  declarations: [
    InviteColleagueDialog,
    DeleteConfirmDialog,
    UpdateNameDialog,
    TFAConfirmDialog,
    DupplicateAssessmentDialog,
    SetOrganisationGoalAssessmentDialog,
    SetMeetingEventDialog,
    ImportAssessmentDialog,
    ImportAssessmentErrorDialog,
    ConfirmDialog,
    PublishConfirmDialog,
    IsReadyConfirmDialog,
    ReportStatusDialog,
    NewUserDialogComponent,
    NewSupplierDialogComponent,
    Step7DownloadReportDialog,
    ActualRecoveryRatetDialog,
    AddAssessmentDialog,
    AddLabelDialog,
    WatchvideoConfirmDialog,
    ManageMembersDialog,
    AddBusinessLevelDialog,
    MoveAssessmentDialog,
    EditBusinessLevelDialog,
    InviteNewMemberDialog,
    MergeAssessmentsConfirmDialog,
    ImportAssessmentE5Dialog,
    LabelManagmentDialog,
    E5ReportDialog,
  ],
  exports: [
    InviteColleagueDialog,
    DeleteConfirmDialog,
    UpdateNameDialog,
    TFAConfirmDialog,
    DupplicateAssessmentDialog,
    SetOrganisationGoalAssessmentDialog,
    SetMeetingEventDialog,
    ImportAssessmentDialog,
    ImportAssessmentErrorDialog,
    ConfirmDialog,
    PublishConfirmDialog,
    IsReadyConfirmDialog,
    ReportStatusDialog,
    NewUserDialogComponent,
    NewSupplierDialogComponent,
    Step7DownloadReportDialog,
    ActualRecoveryRatetDialog,
    AddAssessmentDialog,
    AddLabelDialog,
    WatchvideoConfirmDialog,
    ManageMembersDialog,
    AddBusinessLevelDialog,
    MoveAssessmentDialog,
    EditBusinessLevelDialog,
    InviteNewMemberDialog,
    MergeAssessmentsConfirmDialog,
    ImportAssessmentE5Dialog,
    LabelManagmentDialog,
    E5ReportDialog,
  ],
})
export class DialogModule {}
