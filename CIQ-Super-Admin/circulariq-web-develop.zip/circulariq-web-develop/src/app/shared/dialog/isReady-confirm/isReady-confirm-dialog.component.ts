import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'isReady-confirm-dialog',
  templateUrl: './isReady-confirm-dialog.component.html',
  styleUrls: ['./isReady-confirm-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class IsReadyConfirmDialog {
  // tslint:disable-next-line:typedef
  constructor(public dialogRef: MatDialogRef<IsReadyConfirmDialog>, @Inject(MAT_DIALOG_DATA) public data) {}

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
    location.reload();
  }
}
