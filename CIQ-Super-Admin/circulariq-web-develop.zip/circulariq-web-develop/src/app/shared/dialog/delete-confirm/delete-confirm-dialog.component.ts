import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'delete-confirm-dialog',
  templateUrl: './delete-confirm-dialog.component.html',
  styleUrls: ['./delete-confirm-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class DeleteConfirmDialog {
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<DeleteConfirmDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'delete');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
