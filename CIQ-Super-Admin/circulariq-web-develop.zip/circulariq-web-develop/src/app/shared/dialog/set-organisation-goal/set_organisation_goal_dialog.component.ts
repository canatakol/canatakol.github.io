import { Component, Inject, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'set_organisation_goal_dialog',
  templateUrl: './set_organisation_goal_dialog.component.html',
  styleUrls: ['./set_organisation_goal_dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class SetOrganisationGoalAssessmentDialog implements OnInit {
  // tslint:disable-next-line:typedef
  goalForm: FormGroup;
  selectedMonth;
  selectedYear;
  mounthList = environment.services.mounthList;
  yearList = Array.from({ length: 10 }, (v, i) => new Date().getFullYear() - 1 + i + 1);
  actualRecoveryShow = false;
  circularInflowShow = false;
  circularOutflowShow = false;
  materialCircularityShow = false;
  potentialRecoveryShow = false;
  materialCircularityWarning = false;
  circularInflowWarning = false;
  circularOutflowWarning = false;
  potentialRecoveryWarning = false;
  targetDateWarning = false;
  actualRecoveryWarning = false;
  actualRecovery;
  circularInflow;
  circularOutflow;
  materialCircularity;
  potentialRecovery;
  targetDate;
  description;
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    private commonService: CommonService,
    public dialogRef: MatDialogRef<SetOrganisationGoalAssessmentDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    public storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'set-organizational-goals');
      this.storyblok = story[0].content;
    });
    if (this.data) {
      this.actualRecovery = this.data.actualRecovery ? this.data.actualRecovery : null;
      this.circularInflow = this.data.circularInflow ? this.data.circularInflow : null;
      this.circularOutflow = this.data.circularOutflow ? this.data.circularOutflow : null;
      this.materialCircularity = this.data.materialCircularity ? this.data.materialCircularity : null;
      this.potentialRecovery = this.data.potentialRecovery ? this.data.potentialRecovery : null;
      this.description = this.data.description ? this.data.description : null;
      this.actualRecoveryShow = this.data.actualRecovery ? true : false;
      this.circularInflowShow = this.data.circularInflow ? true : false;
      this.circularOutflowShow = this.data.circularOutflow ? true : false;
      this.materialCircularityShow = this.data.materialCircularity ? true : false;
      this.potentialRecoveryShow = this.data.potentialRecovery ? true : false;
      if (this.data.targetDate) {
        this.selectedMonth = String(this.data.targetDate.split('-')[1]);
        this.selectedYear = Number(this.data.targetDate.split('-')[0]);
      } else {
        const dateObj = new Date();
        const month = dateObj.getUTCMonth() + 1;
        const year = dateObj.getUTCFullYear() + 1;
        this.selectedMonth = String(month < 10 ? '0' + month : month);
        this.selectedYear = year;
      }
    }
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onSubmit(): void {
    if (this.materialCircularityShow && this.materialCircularity === null) {
      this.materialCircularityWarning = true;
    } else {
      this.materialCircularityWarning = false;
    }
    if (this.circularInflowShow && this.circularInflow === null) {
      this.circularInflowWarning = true;
    } else {
      this.circularInflowWarning = false;
    }
    if (this.circularOutflowShow && this.circularOutflow === null) {
      this.circularOutflowWarning = true;
    } else {
      this.circularOutflowWarning = false;
    }
    if (this.potentialRecoveryShow && this.potentialRecovery === null) {
      this.potentialRecoveryWarning = true;
    } else {
      this.potentialRecoveryWarning = false;
    }
    if (this.actualRecoveryShow && this.actualRecovery === null) {
      this.actualRecoveryWarning = true;
    } else {
      this.actualRecoveryWarning = false;
    }
    if (this.goalForm.value.targetDate === null) {
      this.targetDateWarning = true;
    } else {
      this.targetDateWarning = false;
    }
    if (
      !this.materialCircularityWarning &&
      !this.circularInflowWarning &&
      !this.circularOutflowWarning &&
      !this.potentialRecoveryWarning &&
      !this.targetDateWarning &&
      !this.actualRecoveryWarning
    ) {
      this.goalForm.value.targetDate = `${this.goalForm.value.year}-${this.goalForm.value.mounth}-01T00:00:00`;
      delete this.goalForm.value.year;
      delete this.goalForm.value.mounth;
      this.commonService.organisationGoalData.next(this.goalForm.value);
      this.dialogRef.close(this.goalForm.value);
    }
  }
  ngOnInit() {
    this.createForm();
  }

  changeCheckEvent(target: string) {
    switch (target) {
      case 'actualRecoveryShow':
        this.actualRecoveryShow = !this.actualRecoveryShow;
        this.actualRecovery = this.actualRecoveryShow ? this.data.actualRecovery : null;
        break;
      case 'circularInflowShow':
        this.circularInflowShow = !this.circularInflowShow;
        this.circularInflow = this.circularInflowShow ? this.data.circularInflow : null;
        break;
      case 'circularOutflowShow':
        this.circularOutflowShow = !this.circularOutflowShow;
        this.circularOutflow = this.circularOutflowShow ? this.data.circularOutflow : null;
        break;
      case 'materialCircularityShow':
        this.materialCircularityShow = !this.materialCircularityShow;
        this.materialCircularity = this.materialCircularityShow ? this.data.materialCircularity : null;
        break;
      case 'potentialRecoveryShow':
        this.potentialRecoveryShow = !this.potentialRecoveryShow;
        this.potentialRecovery = this.potentialRecoveryShow ? this.data.potentialRecovery : null;
        break;
      default:
        break;
    }
  }

  clickCheckEvent(target: string) {
    switch (target) {
      case 'actualRecoveryShow':
        this.actualRecoveryShow = true;
        this.actualRecovery = this.actualRecoveryShow ? this.data.actualRecovery : null;
        break;
      case 'circularInflowShow':
        this.circularInflowShow = true;
        this.circularInflow = this.circularInflowShow ? this.data.circularInflow : null;
        break;
      case 'circularOutflowShow':
        this.circularOutflowShow = true;
        this.circularOutflow = this.circularOutflowShow ? this.data.circularOutflow : null;
        break;
      case 'materialCircularityShow':
        this.materialCircularityShow = true;
        this.materialCircularity = this.materialCircularityShow ? this.data.materialCircularity : null;
        break;
      case 'potentialRecoveryShow':
        this.potentialRecoveryShow = true;
        this.potentialRecovery = this.potentialRecoveryShow ? this.data.potentialRecovery : null;
        break;
      default:
        break;
    }
  }

  maxValue(item: any, max: any, target: any) {
    switch (target) {
      case 'actualRecovery':
        this.actualRecoveryShow = true;
        if (item.replace(/[^\d.d]+/g, '') > max) {
          this.actualRecovery = max;
        }
        if (item.replace(/[^\d.d]+/g, '') < 0) {
          this.actualRecovery = 0;
        }
        break;
      case 'circularInflow':
        this.circularInflowShow = true;
        if (item.replace(/[^\d.d]+/g, '') > max) {
          this.circularInflow = max;
        }
        if (item.replace(/[^\d.d]+/g, '') < 0) {
          this.circularInflow = 0;
        }
        break;
      case 'circularOutflow':
        this.circularOutflowShow = true;
        if (item.replace(/[^\d.d]+/g, '') > max) {
          this.circularOutflow = max;
        }
        if (item.replace(/[^\d.d]+/g, '') < 0) {
          this.circularOutflow = 0;
        }
        break;
      case 'materialCircularity':
        this.materialCircularityShow = true;
        if (item.replace(/[^\d.d]+/g, '') > max) {
          this.materialCircularity = max;
        }
        if (item.replace(/[^\d.d]+/g, '') < 0) {
          this.materialCircularity = 0;
        }
        break;
      case 'potentialRecovery':
        this.potentialRecoveryShow = true;
        if (item.replace(/[^\d.d]+/g, '') > max) {
          this.potentialRecovery = max;
        }
        if (item.replace(/[^\d.d]+/g, '') < 0) {
          this.potentialRecovery = 0;
        }
        break;
      default:
        break;
    }
  }
  private createForm() {
    this.goalForm = new FormGroup({
      actualRecovery: new FormControl(this.data ? this.data.actualRecovery : null, [Validators.required]),
      circularInflow: new FormControl(this.data ? this.data.circularInflow : null, [Validators.required]),
      circularOutflow: new FormControl(this.data ? this.data.circularOutflow : null, [Validators.required]),
      materialCircularity: new FormControl(this.data ? this.data.materialCircularity : null, [Validators.required]),
      potentialRecovery: new FormControl(this.data ? this.data.potentialRecovery : null, [Validators.required]),
      mounth: new FormControl(this.data ? this.selectedMonth : null, [Validators.required]),
      year: new FormControl(this.data ? this.selectedYear : null, [Validators.required]),
      targetDate: new FormControl([Validators.required]),
      description: new FormControl(this.data ? this.data.description : null, [Validators.required]),
    });
  }
}
