import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'add-label.dialog',
  templateUrl: './add-label.component.html',
  styleUrls: ['./add-label.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class AddLabelDialog {
  storyblok;
  selectedItem;
  showOptions = false;
  nestedOptions;
  currentLine = 0;
  businessForm: FormGroup;
  apiService: any;
  constructor(
    public dialogRef: MatDialogRef<AddLabelDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    public router: Router,
    private formBuilder: FormBuilder,
    private http: ApiRequestService
  ) {
    this.storyblok = this.data.storyblok;

    this.createForm();
    if (this.data.labelData.length > 0) {
      this.nestedOptions = this.data.labelData;
    } else {
      this.fetchLabels();
    }
  }

  fetchLabels() {
    this.http.callService(new Method(environment.services.label(), '', 'get')).subscribe((res) => {
      this.nestedOptions = res;
    });
  }

  selectedParrent(item: any, line: number) {
    if (line > this.currentLine) {
      this.selectedItem = item;
      this.currentLine = line;
      this.showOptions = false;
    }
    setTimeout(() => {
      this.currentLine = 0;
    }, 100);
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    const data = {
      name: this.businessForm.value.name,
      parentId: this.selectedItem ? this.selectedItem.id : null,
    };
    this.http.callService(new Method(environment.services.label(), data, 'post')).subscribe((res) => {
      this.dialogRef.close(res);
    });
  }
  private createForm() {
    this.businessForm = this.formBuilder.group({
      name: [this.data?.text, Validators.required],
    });
  }
}
