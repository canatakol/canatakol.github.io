import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'set-meeting-event-dialog.component',
  templateUrl: './set-meeting-event-dialog.component.html',
  styleUrls: ['./set-meeting-event-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class SetMeetingEventDialog {
  constructor(public dialogRef: MatDialogRef<SetMeetingEventDialog>, public router: Router) {}
  onNoClick(): void {
    this.dialogRef.close(false);
  }
}
