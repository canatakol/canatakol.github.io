import {
  Component,
  Inject,
  Input,
  OnInit,
  ViewChild,
  AfterViewChecked,
  ElementRef,
  ChangeDetectorRef,
} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { E5LabelBaseComponent } from '@app/e5/label-base/label-base.component';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'import_assessment_e5_dialog',
  templateUrl: './import_assessment_e5_dialog.component.html',
  styleUrls: ['./import_assessment_e5_dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class ImportAssessmentE5Dialog implements OnInit, AfterViewChecked {
  @ViewChild('childRef') labelBaseComponent: E5LabelBaseComponent;
  @ViewChild('errorBox') errorBox: ElementRef;
  @ViewChild('dialogWrapper') dialogWrapper: ElementRef;
  displayedColumns: string[] = ['sheet', 'cellAddress', 'message'];
  responseData;
  fileType;
  fileName;
  progressStatus = 0;
  openText = false;
  labelManagmentContentShow = false;
  showCreateLabel = false;
  selectedLabelforLabelManagment: any[] = [];
  labels: any[] = [];
  labelManagmentShow = false;
  pondOptions;
  storyblok;
  E5storyblok;
  businessForm: FormGroup;
  private hasScrolledToError = false;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<ImportAssessmentE5Dialog>,
    private storyblokService: StoryblokService,
    private formBuilder: FormBuilder,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private router: Router,
    private cdr: ChangeDetectorRef,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private http: ApiRequestService
  ) {
    this.createForm();
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'import-assessment');
      this.storyblok = story[0].content;
      const e5story = res.filter((item) => item.slug === 'pro-dashboard');
      this.E5storyblok = e5story[0].content;
    });
  }

  setSelectedLabelArray(selectedData: any): void {
    this.labels = selectedData;
    this.selectedLabelforLabelManagment = selectedData.filter((item) => item.selected).map((item) => item.id);
    this.labelManagmentContentShow = false;
  }

  deleteLabel(label: any): void {
    this.labels = this.labels.filter((item) => item.id !== label.id);
    this.selectedLabelforLabelManagment = this.selectedLabelforLabelManagment.filter((item) => item !== label.id);
    this.data = this.data.filter((item) => item.id !== label.id);
  }

  ngOnInit(): void {
    this.selectedLabelforLabelManagment = [];
  }

  ngAfterViewChecked(): void {
    // This will be triggered automatically when view updates, ensuring scroll happens after DOM is ready
    if (this.progressStatus === 400 && !this.hasScrolledToError) {
      this.scrollToError();
    }
    // Reset flag when progress changes away from error state
    if (this.progressStatus !== 400) {
      this.hasScrolledToError = false;
    }
  }

  private scrollToError(): void {
    setTimeout(() => {
      if (this.errorBox && this.errorBox.nativeElement) {
        const errorElement = this.errorBox.nativeElement;
        const dialogWrapper = this.dialogWrapper?.nativeElement || document.querySelector('#dialog-wrapper');

        if (dialogWrapper && errorElement) {
          const errorTop = errorElement.offsetTop;
          dialogWrapper.scrollTo({
            top: errorTop - 20,
            behavior: 'smooth',
          });
          this.hasScrolledToError = true;
        } else if (errorElement) {
          // Fallback to scrollIntoView if dialog wrapper not found
          errorElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
          this.hasScrolledToError = true;
        }
      }
    }, 300);
  }

  isLastPath(label: any, index: number): boolean {
    return label.path.length === index + 1;
  }
  changeFileType(type: string) {
    this.responseData = null;
    this.progressStatus = null;
    this.pondOptions = {
      class: 'my-filepond',
      multiple: false,
      labelIdle: this.storyblok.upload_file,
      acceptedFileTypes:
        type === 'json'
          ? ['application/json', 'text/csv']
          : 'text/xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      server: {
        url: environment.serverUrl,
        process: async (fieldName, file, metadata, load, error, progress, abort) => {
          const formData = new FormData();
          const self = this;
          self.responseData = null;
          self.progressStatus = 0;
          formData.append('file', file, file.name);
          const request = new XMLHttpRequest();
          request.open('POST', environment.serverUrl + environment.services.uploadPermanent());
          request.upload.onprogress = (e) => {
            progress(e.lengthComputable, e.loaded, e.total);
          };
          request.onload = () => {
            if (request.status >= 200 && request.status < 300) {
              load(request.responseText);
              const url = `${environment.serverUrl}/assets/download/${JSON.parse(request.response)[0].fileName}`;
              const requestBody = { url: url, labelIds: this.selectedLabelforLabelManagment };
              if (type === 'json') {
                self.callAssesmentServiceJSON(requestBody);
              } else {
                self.callAssesmentService(requestBody);
              }
            } else {
              self.progressStatus = 9;
            }
          };
          request.send(formData);
          return {
            abort: () => {
              request.abort();
              abort();
            },
          };
        },
        revert: (uniqueFileId, load, error) => {
          load();
        },
        load: (uniqueFileId, load, error) => {
          fetch(uniqueFileId)
            .then((res) => res.blob())
            .then((res) => {
              load(new File([res], '', { type: 'image' }));
            })
            .catch(error);
        },
      },
    };
  }
  callAssesmentServiceJSON(data: any) {
    fetch(environment.serverUrl + environment.services.parsingServiceJSON(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': JSON.parse(sessionStorage.getItem('credentials')).authToken,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.status === 200) {
          this.hasScrolledToError = false;
          return (this.progressStatus = 200);
        } else {
          this.hasScrolledToError = false;
          this.progressStatus = 400;
          const json = response.json();
          return json;
        }
      })
      // tslint:disable-next-line:no-shadowed-variable
      .then((data) => {
        if (data) {
          this.responseData = data;
          this.cdr.detectChanges();
          if (this.progressStatus === 400) {
            this.scrollToError();
          }
          //    window.location.reload();
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }

  callAssesmentService(data: any) {
    fetch(environment.serverUrl + environment.services.parsingServiceExcel(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': JSON.parse(sessionStorage.getItem('credentials')).authToken,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.status === 200) {
          this.hasScrolledToError = false;
          return (this.progressStatus = 200);
        } else {
          this.hasScrolledToError = false;
          this.progressStatus = 400;
          const json = response.json();
          return json;
        }
      })
      // tslint:disable-next-line:no-shadowed-variable
      .then((data) => {
        if (data) {
          this.responseData = data;
          this.cdr.detectChanges();
          //  window.location.reload();
        }
      })
      .catch((error) => {
        console.error('Error:', error);
      });
  }

  pondHandleInit() {
    // FilePond has initialised
  }

  pondHandleAddFile(event: any) {
    // A file was added
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }

  get errorResponse() {
    return this.responseData;
  }

  get progress() {
    return this.progressStatus;
  }

  getTemplateFilePath(fileType: string): string {
    const currentUrl = this.router.url;
    if (currentUrl.includes('/cti/pro-label')) {
      return `../../../../assets/sample_assessment_import.${fileType}`;
    } else {
      return `../../../../assets/sample_e5_assessment_import.${fileType}`;
    }
  }

  private createForm() {
    this.businessForm = this.formBuilder.group({
      name: [this.data?.text, Validators.required],
    });
  }
}
