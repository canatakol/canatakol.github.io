import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, EmailValidator } from '@angular/forms';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'add-business-level.dialog',
  templateUrl: './add-business-level.component.html',
  styleUrls: ['./add-business-level.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class AddBusinessLevelDialog implements OnInit {
  businessLevels = [
    'Select business level',
    'Company level',
    'Business unit',
    'Product line',
    'Site location',
    'Other',
  ];
  name;
  active = 1;
  businessForm: FormGroup;
  assessmentForm: FormGroup;
  storyblok;
  assessment_storyblok;
  constructor(
    public dialogRef: MatDialogRef<AddBusinessLevelDialog>,
    public router: Router,
    private snackBar: MatSnackBar,
    private http: ApiRequestService,
    private formBuilder: FormBuilder,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'add-business-level');
      const assessment = res.filter((item) => item.slug === 'add-assessment');
      this.storyblok = story[0].content;
      this.assessment_storyblok = assessment[0].content;
    });
    this.createForm();
  }
  ngOnInit() {}

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    const data = {
      name: this.businessForm.value.name,
      type: this.businessForm.value.type,
      otherType: this.businessForm.value.otherType,
    };
    this.dialogRef.close(data);
  }

  private createForm() {
    this.businessForm = this.formBuilder.group({
      name: ['', Validators.required],
      type: ['', Validators.required],
      otherType: [''],
    });
    this.assessmentForm = this.formBuilder.group({
      assessmentName: ['', Validators.required],
    });
  }
}
