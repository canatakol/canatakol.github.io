import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { environment } from '../../../../environments/environment';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  standalone: false,
})
export class NewUserDialogComponent {
  createUserFrom: FormGroup;
  firstNameReadonly = false;
  activeStep = 'first';
  businessLevelsToInviteList = [];
  environment = environment;
  mainData;
  allChecked = false;
  isPro;
  showLevelSelectBox = false;
  levelList;
  availableUser;
  userData;
  lastNameReadonly = false;
  storyblok;
  project = environment.project;
  constructor(
    private http: ApiRequestService,
    public commonService: CommonService,
    private formBuilder: FormBuilder,
    public router: Router,
    public storyblokService: StoryblokService,
    public dialogRef: MatDialogRef<NewUserDialogComponent>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'invite-new-organization-member');
      this.storyblok = story[0].content;
    });
    this.mainData = data;
    this.createUserFrom = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email]],
      firstName: [null, [Validators.required]],
      lastName: [null, []],
      role: [this.project === 'CIQ' ? 'Company admin' : '', Validators.required],
    });
    this.isPro = this.commonService.isPro;
    if (this.isPro) {
      this.getBusinessLevel();
    }
  }

  // deleteSpaces(email: string) {
  //   // this.createUserFrom.controls.email.value = email.trim();

  // }

  async getBusinessLevel() {
    this.http.callService(new Method(environment.services.getCTIProDashboard(), '', 'get')).subscribe((res) => {
      this.levelList = res;
    });
  }

  selectedAllbussinesAssesment(event: any) {
    this.levelList.forEach((level) => {
      if (event.checked) {
        if (!level.added) {
          this.addAssests(event, level);
        }
      }
      if (!event.checked) {
        if (level.added) {
          this.addAssests(event, level);
        }
      }
    });
  }

  async addAssests(event: any, level: any) {
    const index = this.businessLevelsToInviteList.indexOf(level.id);
    if (index === -1) {
      this.businessLevelsToInviteList.push(level.id);
      level.added = true;
    } else {
      this.businessLevelsToInviteList.splice(index, 1);
      level.added = false;
    }
    this.allChecked = this.businessLevelsToInviteList.length === this.levelList.length;
  }

  openLevelSelectBox() {
    this.showLevelSelectBox = true;
  }

  donesLevelSelect() {
    this.showLevelSelectBox = false;
    this.commonService.businessLevelsToInviteList = [];
    this.businessLevelsToInviteList.forEach((id) => {
      this.commonService.businessLevelsToInviteList.push(id);
    });
  }

  async backsLevelSelect() {
    this.businessLevelsToInviteList = [];
    await this.levelList.forEach((level) => {
      level.added = false;
      this.commonService.businessLevelsToInviteList.forEach((id) => {
        if (id === level.id) {
          level.added = true;
        }
      });
    });
    this.showLevelSelectBox = false;
    await this.levelList.forEach((level) => {
      if (level.added) {
        this.businessLevelsToInviteList.push(level.id);
      }
    });

    this.allChecked = this.businessLevelsToInviteList.length === this.levelList.length;
  }

  onNoClick() {
    this.dialogRef.close(false);
  }
  onYesClick() {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (!credentials || !credentials.organisation || !credentials.organisation.id) {
      return;
    }
    const organisationId = credentials.organisation.id;
    this.userData = {
      email: this.createUserFrom.controls.email.value,
      firstName: this.createUserFrom.controls.firstName.value,
      lastName: this.createUserFrom.controls.lastName.value,
      roles: {
        roleNames:
          this.createUserFrom.controls.role.value === 'Company admin'
            ? ['Company admin', 'Product manager']
            : [this.createUserFrom.controls.role.value],
      },
      businessLevels: {
        businessLevels: this.businessLevelsToInviteList,
      },
      organisationId: organisationId,
      project: this.project,
    };
    this.http
      .callService(new Method(environment.services.membership(organisationId), this.userData, 'put'))
      .subscribe((res) => {
        const materialData = { userId: res['id'], email: res['email'] };
        this.dialogRef.close(materialData);
      });
  }
  addMemberPut(userId: string) {
    const setData = {
      businessLevels: this.businessLevelsToInviteList,
    };
    this.http.callService(new Method(environment.services.BusinessLevelsOfuser(userId), setData, 'put'));
  }
}
