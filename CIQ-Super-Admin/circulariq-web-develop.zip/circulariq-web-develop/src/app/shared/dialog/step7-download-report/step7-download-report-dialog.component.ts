import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'step7-download-report-dialog.component',
  templateUrl: './step7-download-report-dialog.component.html',
  styleUrls: ['./step7-download-report-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class Step7DownloadReportDialog {
  storyblok;
  constructor(
    public dialogRef: MatDialogRef<Step7DownloadReportDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    public storyblokService: StoryblokService,
    public router: Router
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'step-7-download-report-dialogue');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.router.navigate([`/cti/${this.data}/assessment/step4`]);
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
