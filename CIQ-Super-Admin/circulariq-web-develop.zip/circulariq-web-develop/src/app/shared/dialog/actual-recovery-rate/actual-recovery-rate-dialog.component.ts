import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'actual-recovery-rate-dialog.component',
  templateUrl: './actual-recovery-rate-dialog.component.html',
  styleUrls: ['./actual-recovery-rate-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class ActualRecoveryRatetDialog {
  public data = [];

  public subdata = [];
  storyblok;
  public selelctedParrentId = '0';
  constructor(
    public dialogRef: MatDialogRef<ActualRecoveryRatetDialog>,
    public router: Router,
    private http: ApiRequestService,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'actual_recovery_rate');
      this.storyblok = story[0].content;
      this.storyblok.data.tbody.forEach((item) => {
        this.data.push({ id: item.body[0].value, name: item.body[1].value });
      });
      this.storyblok.subdata.tbody.forEach((item) => {
        this.subdata.push({ id: item.body[0].value, name: item.body[1].value, percentage: item.body[2].value });
      });
    });
  }

  setParrentData(id: string) {
    this.selelctedParrentId = id;
  }

  onYesClick(item: string): void {
    this.dialogRef.close(item);
  }
}
