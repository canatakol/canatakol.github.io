import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
declare var $: any;

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'import_assessment_error_dialog',
  templateUrl: './import_assessment_error_dialog.component.html',
  styleUrls: ['./import_assessment_error_dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class ImportAssessmentErrorDialog {
  displayedColumns: string[] = ['sheet', 'rowIndex', 'message'];
  numericSeparator = '.';
  fileName;
  erorrData;
  progressStatus = 0;
  openText = false;
  pondOptions;
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    private http: ApiRequestService,
    public dialogRef: MatDialogRef<ImportAssessmentErrorDialog>,
    private storyblokService: StoryblokService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'duplicate-and-import-assessment-error');
      this.storyblok = story[0].content;
    });
    if (data) {
      this.http
        .callService(new Method(environment.services.assessmentImportErrorDetail(data.assessmentId), '', 'get'))
        .subscribe({
          next: (res) => {
            this.erorrData = res;
          },
          error: (error) => {
            console.error('Failed to load assessment import error details:', error);
            this.erorrData = [];
          },
        });
    }
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
