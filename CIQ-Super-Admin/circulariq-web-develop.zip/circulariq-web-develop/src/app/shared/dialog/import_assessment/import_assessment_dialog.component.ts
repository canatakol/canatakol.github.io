import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'import_assessment_dialog',
  templateUrl: './import_assessment_dialog.component.html',
  styleUrls: ['./import_assessment_dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class ImportAssessmentDialog {
  displayedColumns: string[] = ['sheet', 'cellAddress', 'message'];
  responseData;
  fileType;
  fileName;
  progressStatus = 0;
  openText = false;
  pondOptions;
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    private httpClient: HttpClient,
    public dialogRef: MatDialogRef<ImportAssessmentDialog>,
    private storyblokService: StoryblokService,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private http: ApiRequestService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'import-assessment');
      this.storyblok = story[0].content;
    });
  }

  changeFileType(type: string) {
    this.responseData = null;
    this.progressStatus = null;
    this.pondOptions = {
      class: 'my-filepond',
      multiple: false,
      labelIdle: this.storyblok.upload_file,
      acceptedFileTypes:
        type === 'json'
          ? ['application/json', 'text/csv']
          : 'text/xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      server: {
        url: environment.serverUrl,
        process: async (fieldName, file, metadata, load, error, progress, abort) => {
          const formData = new FormData();
          const self = this;
          self.responseData = null;
          self.progressStatus = 0;
          formData.append('file', file, file.name);
          const request = new XMLHttpRequest();
          request.open('POST', environment.serverUrl + environment.services.uploadPermanent());
          request.upload.onprogress = (e) => {
            progress(e.lengthComputable, e.loaded, e.total);
          };
          request.onload = function () {
            if (request.status >= 200 && request.status < 300) {
              load(request.responseText);
              const url = `${environment.serverUrl}/assets/download/${JSON.parse(request.response)[0].fileName}`;
              const requestBody = { url: url, businessLevelUuid: self.data.id };
              if (type === 'json') {
                self.callAssesmentServiceJSON(requestBody);
              } else {
                self.callAssesmentService(requestBody);
              }
            } else {
              self.progressStatus = 9;
            }
          };
          request.send(formData);
          return {
            abort: () => {
              request.abort();
              abort();
            },
          };
        },
        revert: (uniqueFileId, load, error) => {
          load();
        },
        load: (uniqueFileId, load, error) => {
          fetch(uniqueFileId)
            .then((res) => res.blob())
            .then((res) => {
              load(new File([res], '', { type: 'image' }));
            })
            .catch(error);
        },
      },
    };
  }
  callAssesmentServiceJSON(data: any) {
    fetch(environment.serverUrl + environment.services.parsingServiceJSON(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': JSON.parse(sessionStorage.getItem('credentials')).authToken,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.status === 200) {
          return (this.progressStatus = 200);
        } else {
          this.progressStatus = 400;
          const json = response.json();
          return json;
        }
      })
      // tslint:disable-next-line:no-shadowed-variable
      .then((data) => {
        if (data) {
          this.responseData = data;
        }
      })
      .catch((error) => {
        // Error occurred
      });
  }

  callAssesmentService(data: any) {
    fetch(environment.serverUrl + environment.services.parsingServiceExcel(), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-auth-token': JSON.parse(sessionStorage.getItem('credentials')).authToken,
      },
      body: JSON.stringify(data),
    })
      .then((response) => {
        if (response.status === 200) {
          return (this.progressStatus = 200);
        } else {
          this.progressStatus = 400;
          const json = response.json();
          return json;
        }
      })
      // tslint:disable-next-line:no-shadowed-variable
      .then((data) => {
        if (data) {
          this.responseData = data;
        }
      })
      .catch((error) => {
        // Error occurred
      });
  }

  pondHandleInit() {
    // FilePond has initialised
  }

  pondHandleAddFile(event: any) {
    // A file was added
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }

  get errorResponse() {
    return this.responseData;
  }

  get progress() {
    return this.progressStatus;
  }
}
