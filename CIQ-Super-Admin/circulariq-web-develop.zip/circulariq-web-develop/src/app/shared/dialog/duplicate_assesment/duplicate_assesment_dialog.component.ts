import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'duplicate_assesment_dialog',
  templateUrl: './duplicate_assesment_dialog.component.html',
  styleUrls: ['./duplicate_assesment_dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class DupplicateAssessmentDialog {
  // tslint:disable-next-line:typedef
  assessmentNameLength;
  storyblok;
  constructor(
    public dialogRef: MatDialogRef<DupplicateAssessmentDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'duplicate-assessment');
      this.storyblok = story[0].content;
    });
  }

  assesmentTitleChange() {
    this.assessmentNameLength = this.data.assessmentName.replace(/\s/g, '').length;
  }
  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    const returnData = {
      copyAssessmentName: this.data.assessmentName,
      step5: this.data.step5,
      step6: this.data.step6,
      step7: this.data.step7,
    };
    this.dialogRef.close(returnData);
  }
}
