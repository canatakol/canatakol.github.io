import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-merge-assessments-confirm',
  templateUrl: './merge-assessments-confirm.component.html',
  styleUrls: ['./merge-assessments-confirm.component.scss'],
  standalone: false,
})

// tslint:disable-next-line:component-class-suffix
export class MergeAssessmentsConfirmDialog {
  storyblok;
  mergeNameLength = 0;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<MergeAssessmentsConfirmDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'merge-assessments-confirm');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
  mergeNameChange() {
    if (this.data.mergeName) {
      this.mergeNameLength = this.data.mergeName.replace(/\s/g, '').length;
    }
  }

  onYesClick(): void {
    this.dialogRef.close(this.data);
  }
}
