import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'e5-report.dialog',
  templateUrl: './e5-report.component.html',
  styleUrls: ['./e5-report.component.scss'],
  standalone: false,
})
export class E5ReportDialog {
  storyblok;
  selectedItem;
  showOptions = false;
  nestedOptions;
  currentLine = 0;
  mounthList = environment.services.mounthList;
  startMounth;
  endMounth;
  yearList = Array.from({ length: 20 }, (v, i) => new Date().getFullYear() - 10 + i + 1);
  startYear;
  endYear;
  businessForm: FormGroup;

  constructor(
    public dialogRef: MatDialogRef<E5ReportDialog>,
    @Inject(MAT_DIALOG_DATA) public data,
    public router: Router,
    private snackBar: MatSnackBar,
    private formBuilder: FormBuilder,
    private http: ApiRequestService
  ) {
    this.storyblok = this.data.storyblok;
    this.createForm();
    this.nestedOptions = this.data.labelData;
  }

  selectedParrent(item: any, line: number) {
    if (line > this.currentLine) {
      this.selectedItem = item;
      this.currentLine = line;
      this.showOptions = false;
    }
    setTimeout(() => {
      this.currentLine = 0;
    }, 100);
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    if (this.businessForm.value.name !== '') {
      if (this.businessForm.status === 'INVALID') {
        this.snackBar.open(this.storyblok.date_range_error_message, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
        return;
      }
    }

    const data = {
      name: this.businessForm.value.name,
      startDate: this.businessForm.value.startMounth + '/' + this.businessForm.value.startYear,
      endDate: this.businessForm.value.endMounth + '/' + this.businessForm.value.endYear,
      assessmentList: this.data.selectAssetList,
    };
    this.http.callService(new Method(environment.services.createESRSReport(), data, 'post')).subscribe((res) => {
      this.dialogRef.close(res);
    });
  }

  private createForm() {
    this.businessForm = this.formBuilder.group(
      {
        name: ['', Validators.required],
        startMounth: ['', Validators.required],
        startYear: ['', Validators.required],
        endMounth: ['', Validators.required],
        endYear: ['', Validators.required],
      },
      {
        validator: this.dateRangeValidator('startMounth', 'startYear', 'endMounth', 'endYear'),
      }
    );
  }

  // Tarihlerin doğru aralıkta olup olmadığını ve aynı olmadığını kontrol eden validator
  private dateRangeValidator(startMonthKey: string, startYearKey: string, endMonthKey: string, endYearKey: string) {
    return (formGroup: FormGroup) => {
      const startMonth = formGroup.controls[startMonthKey].value;
      const startYear = formGroup.controls[startYearKey].value;
      const endMonth = formGroup.controls[endMonthKey].value;
      const endYear = formGroup.controls[endYearKey].value;

      if (startYear && endYear && startMonth && endMonth) {
        const startDate = new Date(startYear, startMonth - 1);
        const endDate = new Date(endYear, endMonth - 1);

        if (startDate > endDate) {
          formGroup.controls[endMonthKey].setErrors({ dateRangeInvalid: true });
          formGroup.controls[endYearKey].setErrors({ dateRangeInvalid: true });
        } else if (startDate.getTime() === endDate.getTime()) {
          // Eğer tarihler aynıysa
          formGroup.controls[endMonthKey].setErrors({ sameDateInvalid: true });
          formGroup.controls[endYearKey].setErrors({ sameDateInvalid: true });
        } else {
          formGroup.controls[endMonthKey].setErrors(null);
          formGroup.controls[endYearKey].setErrors(null);
        }
      }
    };
  }
}
