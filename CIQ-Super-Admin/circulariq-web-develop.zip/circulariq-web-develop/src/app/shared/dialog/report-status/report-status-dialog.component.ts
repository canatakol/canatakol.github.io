import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'report-status-dialog',
  templateUrl: './report-status-dialog.component.html',
  styleUrls: ['./report-status-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class ReportStatusDialog {
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<ReportStatusDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'report-status');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
