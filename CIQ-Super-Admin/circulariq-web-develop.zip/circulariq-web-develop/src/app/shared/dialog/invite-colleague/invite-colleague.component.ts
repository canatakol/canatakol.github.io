import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { environment } from '../../../../environments/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { NewUserDialogComponent } from '../new-user/new-user.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'invite-colleague.component-dialog',
  templateUrl: './invite-colleague.component.html',
  styleUrls: ['./invite-colleague.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class InviteColleagueDialog {
  get searchTerm(): string {
    return this._searchTerm;
  }
  set searchTerm(value: string) {
    this._searchTerm = value;
    this.filterItems = this.filtering(value);
  }
  selectedProduct;
  message;
  resObj = {};
  resObj2 = {};
  resObj3 = {};
  items = [];
  filterItems;
  supplierData;
  isNewUser = true;
  isDisabled = true;
  isShowOtherFields = false;
  companyName;
  selectColleague;
  email;
  searchMember;
  selectItems = [];
  storyblok;
  private _searchTerm: string;
  constructor(
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private storyblokService: StoryblokService,
    public dialogRef: MatDialogRef<InviteColleagueDialog>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.selectedProduct = data;
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (credentials && credentials['organisation'] && credentials['organisation']['name']) {
      this.companyName = credentials['organisation']['name'];
    }

    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'assign-a-colleague');
      this.storyblok = story[0].content;
      this.message = `${this.storyblok?.hello} ${this.selectColleague ? this.selectColleague.firstname : ''}, ${
        this.storyblok?.message_line_1
      } ${this.selectedProduct ? this.selectedProduct.tradeName : ''} ${this.storyblok?.message_line_2} ${
        this.selectColleague ? this.selectColleague.firstname : ''
      }.`;
    });

    this.getUser();
  }

  getUser() {
    this.http.callService(new Method(environment.services.user() + '?size=999', '', 'get')).subscribe((res) => {
      const userListWithoutMyUser = [];
      res['results'].forEach((element) => {
        if (element.email !== localStorage.getItem('user-email')) {
          userListWithoutMyUser.push(element);
        }
        element.roles.forEach((role) => {
          if (role.name === 'Company admin') {
            element.admin = true;
          }
        });
      });
      this.items = userListWithoutMyUser;
      this.filterItems = this.items;
    });
  }

  filtering(searchString: string) {
    return this.items.filter(
      (item) =>
        item.fullname.toLowerCase().indexOf(searchString.toLowerCase()) !== -1 ||
        item.email.toLowerCase().indexOf(searchString.toLowerCase()) !== -1
    );
  }

  selectItem(item: any) {
    this.selectColleague = item;
    this.message = `Hello ${
      this.selectColleague ? this.selectColleague.firstname : ''
    }, We are currently updating information in our ${
      this.selectedProduct ? this.selectedProduct.tradeName : ''
    } product. We kindly ask that you support us by providing data about this specific  ${
      this.selectColleague ? this.selectColleague.firstname : ''
    }.`;
    this.items.forEach((element) => {
      element.selected = false;
      this.isDisabled = false;
      if (element.id === item.id) {
        element.selected = true;
      }
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  addUser(): void {
    const dialogRef = this.dialog.open(NewUserDialogComponent, {
      width: '80%',
      maxWidth: '640px',
      panelClass: 'centered-dialog',
      data: this.selectedProduct,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const data = { userId: result.userId, text: '' };
        this.http
          .callService(new Method(environment.services.responsible(this.selectedProduct.flowId), data, 'post'))
          .subscribe((res) => {
            if (res === null) {
              this.snackBar.open('Invitation sent successfully!', '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
            }
          });
      } catch (error) {}
    });
    this.dialogRef.close(false);
  }

  onYesClick(message: any): void {
    const data = { userId: this.selectColleague['id'], text: message };
    this.http
      .callService(new Method(environment.services.responsible(this.selectedProduct.flowId), data, 'post'))
      .subscribe((res) => {
        if (res === null) {
          this.snackBar.open('Invitation sent successfully!', '', {
            duration: 5000,
            panelClass: ['success-snackBar'],
          });
        }
      });
    this.dialogRef.close(true);
  }
}
