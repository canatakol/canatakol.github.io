import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'tfa-confirm-dialog',
  templateUrl: './tfa-confirm-dialog.component.html',
  styleUrls: ['./tfa-confirm-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class TFAConfirmDialog {
  storyblok;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<TFAConfirmDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'two-factor-authentication');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(true);
  }
}
