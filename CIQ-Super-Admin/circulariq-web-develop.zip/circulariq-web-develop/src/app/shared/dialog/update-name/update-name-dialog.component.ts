import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'update-name-dialog',
  templateUrl: './update-name-dialog.component.html',
  styleUrls: ['./update-name-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class UpdateNameDialog {
  storyblok;
  name;
  // tslint:disable-next-line:typedef
  constructor(
    public dialogRef: MatDialogRef<UpdateNameDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    private storyblokService: StoryblokService
  ) {
    this.name = data.title;
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'update-name');
      this.storyblok = story[0].content;
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(this.name);
  }
}
