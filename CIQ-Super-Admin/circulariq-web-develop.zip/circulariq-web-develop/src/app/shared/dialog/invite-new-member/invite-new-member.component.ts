import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'invite-new-member.component-dialog',
  templateUrl: './invite-new-member.component.html',
  styleUrls: ['./invite-new-member.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class InviteNewMemberDialog {
  createUserFrom: FormGroup;
  level;
  userData;
  storyblok;
  project = environment.project;
  constructor(
    private http: ApiRequestService,
    private formBuilder: FormBuilder,
    private storyblokService: StoryblokService,
    public dialogRef: MatDialogRef<InviteNewMemberDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'invite-new-member');
      this.storyblok = story[0].content;
    });
    this.level = data;
    this.createUserFrom = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email]],
      firstName: [null, [Validators.required]],
      lastName: [null, [Validators.required]],
      message: [null, []],
    });
  }
  onNoClick(): void {
    this.dialogRef.close(false);
  }

  async addMemberPut(userId: string) {
    const setData = {
      businessLevels: [this.level.id],
    };
    await this.http.callService(new Method(environment.services.BusinessLevelsOfuser(userId), setData, 'put'));
  }

  onYesClick(): void {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (!credentials || !credentials.organisation || !credentials.organisation.id) {
      return;
    }
    const organisationId = credentials.organisation.id;
    this.userData = {
      email: this.createUserFrom.controls.email.value,
      firstName: this.createUserFrom.controls.firstName.value,
      lastName: this.createUserFrom.controls.lastName.value,
      roles: {
        roleNames: ['Product manager'],
      },
      businessLevels: {
        businessLevels: [this.level.id],
      },
      organisationId: organisationId,
      project: this.project,
    };

    this.http
      .callService(new Method(environment.services.membership(organisationId), this.userData, 'put'))
      .subscribe((res) => {
        this.dialogRef.close(res);
      });
  }
}
