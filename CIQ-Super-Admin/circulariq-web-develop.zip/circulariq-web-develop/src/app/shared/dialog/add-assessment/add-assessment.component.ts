import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { environment } from '@env/environment';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
declare var $: any;
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'add-assessment.dialog',
  templateUrl: './add-assessment.component.html',
  styleUrls: ['./add-assessment.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class AddAssessmentDialog implements OnInit {
  name;
  businessForm: FormGroup;
  labelManagmentContentShow = false;
  storyblok;
  nameAvailable = false;
  labelList = [];
  selectedLabelArray: any[] = [];
  labels: any[] = [];
  updateLabelShow = false;
  showCreateLabel = false;
  constructor(
    public dialogRef: MatDialogRef<AddAssessmentDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    public router: Router,
    private formBuilder: FormBuilder,
    private storyblokService: StoryblokService,
    private http: ApiRequestService,
    private commonService: CommonService
  ) {
    this.commonService.addLabel.subscribe((res) => {
      this.onNoClick();
    });
  }
  ngOnInit(): void {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'add-assessment');
      this.storyblok = story[0].content;
    });
    this.createForm();

    this.labelList = this.data.labelList;
  }
  buttonDisabled(value: boolean): void {
    this.showCreateLabel = value;
  }

  setSelectedLabelArray(selectedData: any): void {
    this.labels = selectedData;
    this.selectedLabelArray = selectedData.filter((item) => item.selected).map((item) => item.id);
    this.labelManagmentContentShow = false;
  }

  deleteLabel(label: any): void {
    this.labels = this.labels.filter((item) => item.id !== label.id);
    this.selectedLabelArray = this.selectedLabelArray.filter((item) => item !== label.id);
    this.labelList = this.labelList.filter((item) => item.id !== label.id);
  }
  isLastPath(label: any, index: number): boolean {
    return label.path.length === index + 1;
  }
  onNoClick(): void {
    this.selectedLabelArray = [];
    this.labelList?.forEach((label) => {
      label.selected = false;
    });
    this.dialogRef.close(false);
  }
  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.assessmentNameCheck(), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
        });
    } else {
      this.nameAvailable = false;
    }
  }

  onYesClick(): void {
    if (this.businessForm.value) {
      if (this.labelList?.length > 0) {
        this.dialogRef.close({ assessmentName: this.businessForm.value.name, labelList: this.selectedLabelArray });
        this.selectedLabelArray = [];
        this.labelList?.forEach((label) => {
          label.selected = false;
        });
      } else {
        this.dialogRef.close(this.businessForm.value.name);
      }
    }
  }
  private createForm() {
    this.businessForm = this.formBuilder.group({
      name: ['', Validators.required],
    });
  }
}
