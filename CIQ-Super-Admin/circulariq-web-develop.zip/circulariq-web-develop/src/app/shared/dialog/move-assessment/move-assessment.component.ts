import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'move-assessment.dialog',
  templateUrl: './move-assessment.component.html',
  styleUrls: ['./move-assessment.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class MoveAssessmentDialog implements OnInit {
  active = 1;
  firstTabData;
  secondTabData;
  selectedMoveToItem;
  storyblok;
  constructor(
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data,
    public dialogRef: MatDialogRef<MoveAssessmentDialog>,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'move-assessments');
      this.storyblok = story[0].content;
    });
  }
  ngOnInit() {
    this.firstTabData = this.data;
    const noAdded = this.firstTabData.filter((b, index) => {
      return !b.assessments.find((a) => a.added);
    });
    this.firstTabData = noAdded;

    this.secondTabData = this.data;
    const added = this.secondTabData.filter((b, index) => {
      return b.assessments.find((a) => a.added);
    });
    this.secondTabData = added;
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  onYesClick(): void {
    this.dialogRef.close(this.selectedMoveToItem.id);
  }

  onNextClick(selectedMoveToItem: any): void {
    this.active = 2;
    this.selectedMoveToItem = selectedMoveToItem;
  }
  onBackClick(): void {
    this.active = 1;
  }
}
