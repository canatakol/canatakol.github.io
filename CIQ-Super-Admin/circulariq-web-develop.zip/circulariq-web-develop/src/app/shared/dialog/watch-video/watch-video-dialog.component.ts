import { Component, Inject } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DomSanitizer } from '@angular/platform-browser';
declare var $: any;
@Component({
  // tslint:disable-next-line:component-selector
  selector: 'watch-video-dialog',
  templateUrl: './watch-video-dialog.component.html',
  styleUrls: ['./watch-video-dialog.component.scss'],
  standalone: false,
})
// tslint:disable-next-line:component-class-suffix
export class WatchvideoConfirmDialog {
  // tslint:disable-next-line:typedef
  constructor(
    private sanitizer: DomSanitizer,
    public dialogRef: MatDialogRef<WatchvideoConfirmDialog>,
    // tslint:disable-next-line:typedef
    @Inject(MAT_DIALOG_DATA) public data
  ) {
    $(document).ready(function () {
      const width = Math.floor($('#dialog-wrapper').width());
      const height = Math.floor((width / 16) * 9);
      $('iframe').width(width);
      $('iframe').height(height);
    });

    $(window).on('resize', function () {
      const width = Math.floor($('#dialog-wrapper').width());
      const height = Math.floor((width / 16) * 9);
      $('iframe').width(width);
      $('iframe').height(height);
    });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }
}
