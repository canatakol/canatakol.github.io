import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LoginService } from '@app/login/login.service';
import { E5LabelBaseComponent } from './label-base/label-base.component';
import { AddAssessmentDialog } from '@app/shared/dialog/add-assessment/add-assessment.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { DupplicateAssessmentDialog } from '@app/shared/dialog/duplicate_assesment/duplicate_assesment_dialog.component';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { ImportAssessmentE5Dialog } from '@app/shared/dialog/import_assessment_e5/import_assessment_e5_dialog.component';
import { E5ReportDialog } from '@app/shared/dialog/e5-report/e5-report.component';

import { map, mergeMap } from 'rxjs/operators';
import { ManageHazardousComponent } from './manage-hazardous/manage-hazardous.component';
import { VERSION } from '@env/version';
import { LabelManagmentDialog } from '@app/shared/dialog/label-managment/label-managment.component';
import { MergeAssessmentsConfirmDialog } from '@app/shared/dialog/merge-assessments-confirm/merge-assessments-confirm.component';
import { DashboardPreferenceService } from '@app/core/dashboard-preference.service';
import { Subscription } from 'rxjs';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { LocalStorageService } from '@app/core/services/local-storage.service';

declare var $: any;
@Component({
  selector: 'e5-pro',
  templateUrl: './e5.component.html',
  styleUrls: ['./e5.component.scss'],
  standalone: false,
})
export class E5Component implements OnInit, OnDestroy {
  @ViewChild('childRef') labelBaseComponent: E5LabelBaseComponent;
  version = VERSION;
  data: any;
  storyblok: any;
  authToken;
  E5storyblok: any;
  credentials: any;
  isLoading = false;
  isLoadingLabel = false;
  isLoadingLabelbig = false;
  isLoadingLabelSmall = false;
  private previousLabelIdsLength: number = 0;
  private isLoadingLabelSmallSub: Subscription;
  relatedLabelData: any;
  initialRelatedLabelData: any;
  searchText = '';
  language = localStorage.getItem('lang') || 'en';
  selectAssetList = JSON.parse(sessionStorage.getItem('selectAssetList')) || [];
  labelList: any[] = [];
  labelListPureData: any[] = [];
  selectedLabelArray: any[] = [];
  selectedLabelforLabelManagment: any[] = [];
  labelManagmentShow = false;
  labelManagmentContentShow = false;
  selectAssetListShow = false;
  updateLabelShow = false;
  checkDisabled = false;
  noLabelTextShow = false;
  sortedData: any[] = [];
  initialData: any[] = [];
  duplicateAssessmentId: string = '';
  dropLabelList: any[] = [];
  private maxSelectedSize = 2500;
  private selectedIndex = 0;
  totalAssessments = 0;
  navigationMode;
  showCreateLabel = false;
  labelViewQuikTipsShow = localStorage.getItem('labelViewQuikTipsShow') === 'false' ? false : true;
  project = window.location.href.split('/')[3] === 'cti' ? 'cti' : 'ciq';
  isProLabel = window.location.href.includes('pro-label');
  environment = environment;
  searchKeyword: string = '';
  private searchSubject = new Subject<string>();
  private searchSubscription: Subscription;
  showSnapshot = false;
  snapshotOpenAccordion = false;
  snapshotData = { name: 'Snapshots', assessments: [] };
  initialSnapshotData;
  snapShotWarning = false;
  showLoadigIconAggregate = false;
  showLoadigIconCompare = false;
  compareData;
  lastSnapshottId;
  mergeWarning = false;
  openGuidance = false;
  showToggle = false;
  copyAssessmentName: null;
  // Warning properties for tooltips
  warningAggregateShow = false;
  warningSnapshotShow = false;
  warningLabelShow = false;
  warningCompareShow = false;
  warningDeleteShow = false;
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private dashboardPreferenceService: DashboardPreferenceService,
    private loginService: LoginService,
    private localStorageService: LocalStorageService
  ) {
    this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
    this.authToken = this.credentials.authToken;
    this.showToggle = this.credentials?.organisation?.features.includes('bl_view');
    this.initializeUI();
    this.loadInitialData();
    this.commonService.addLabel.subscribe((res) => {
      this.close();
    });

    // Setup search debounce
    this.searchSubscription = this.searchSubject
      .pipe(
        debounceTime(500), // Wait 500ms after user stops typing
        distinctUntilChanged() // Only emit if the value has changed
      )
      .subscribe((searchTerm: string) => {
        if (this.labelBaseComponent) {
          this.labelBaseComponent.setKeyword(searchTerm);
          // Only trigger search if 3 or more characters, or empty (to clear results)
          if (searchTerm.length >= 3 || searchTerm.length === 0) {
            this.labelBaseComponent.searchAssessments();
          }
        }
      });
  }

  deleteSame = (arr) => {
    return arr.filter(function (elem: any, index: any, self: string | any[]) {
      return index === self.indexOf(elem);
    });
  };

  createSnapshot() {
    const returnData = this.returnSelectData();
    if (returnData.snapshotList.length > 0) {
      this.mergeWarning = true;
      setTimeout(() => {
        this.mergeWarning = false;
      }, 3000);
    } else {
      this.mergeWarning = false;
      const dialogRef = this.dialog.open(MergeAssessmentsConfirmDialog, {
        width: '80%',
        maxWidth: '620px',
        panelClass: 'centered-dialog',
        data: {
          selectAssetList: this.selectAssetList,
        },
      });
      dialogRef.afterClosed().subscribe(async (result) => {
        if (!result) {
          return;
        }
        try {
          const data = {
            name: result.mergeName,
            organisationUnitList: result.selectAssetList.map((item) => item.unitId),
          };
          this.http
            .callService(new Method(environment.services.assessmentSnapshot(), data, 'post'))
            .subscribe((res) => {
              this.lastSnapshottId = res['unitId'];
              this.showSnapshot = true;
              this.getSnapshot(true);
            });
        } catch (error) {}
      });
    }
  }
  isButtonDisabled(): boolean {
    return (this.selectAssetList?.length ?? 0) < 2 || this.selectAssetList?.some((item) => item.type === 'snapshot');
  }

  hasSnapshotSelected(): boolean {
    return this.selectAssetList?.some((item) => item.type === 'snapshot') ?? false;
  }

  getSnapshot(event: any) {
    this.snapshotOpenAccordion = event;
    this.showSnapshot = event;
    this.http.callService(new Method(environment.services.assessmentSnapshot(), '', 'get')).subscribe((res: []) => {
      this.snapshotData.assessments = res['assessments'];
      this.snapshotData.assessments.map;
      this.initialSnapshotData = res;
      this.snapshotData.assessments.forEach((assessment) => {
        this.selectAssetList.forEach((element) => {
          if (element.unitId === assessment.unitId) {
            assessment.added = true;
          }
        });
        if (assessment.name) {
          assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
        }
      });
    });
  }

  showSnapshotevent() {
    if (!this.showSnapshot) {
      // Snapshot'ları göster ve yükle
      this.getSnapshot(true);
    } else {
      // Snapshot'ları gizle ve seçimleri temizle
      this.showSnapshot = false;
      this.selectedAllbussinesAssesment({ checked: false }, this.snapshotData);
    }
  }
  removeSelectedAssessment(assessment: any): void {
    const index = this.selectAssetList.findIndex((item) => item.unitId === assessment.unitId);

    if (index !== -1) {
      this.selectAssetList.splice(index, 1);
    }
    this.relatedLabelData.assessments.forEach((element) => {
      if (element.unitId === assessment.unitId) {
        element.added = false;
      }
    });
    sessionStorage.setItem('selectAssetList', JSON.stringify(this.selectAssetList));
    this.selectAssetList.sort((a, b) => a.name.localeCompare(b.name));
  }

  selectAssest(event: any, assessment: any, level: any): void {
    if (this.selectAssetList.length >= this.maxSelectedSize) {
      if (event.checked) {
        assessment.added = false;
        this.checkDisabled = true;
      } else {
        this.checkDisabled = false;
        this.toggleSelectedAssessment(assessment, level);
      }
    } else {
      this.checkDisabled = false;
      this.toggleSelectedAssessment(assessment, level);
    }
    sessionStorage.setItem('selectAssetList', JSON.stringify(this.selectAssetList));
    this.selectAssetList.sort((a, b) => a.name.localeCompare(b.name));
  }

  // returnSelectData() {
  //   let organisationUnitList = [];
  //   let snapshotList = [];
  //   organisationUnitList = this.selectAssetList.filter(
  //     (a) => !this.snapshotData.assessments.map((b) => b.unitId).includes(a)
  //   );
  //   snapshotList = this.selectAssetList
  //     .filter((g) => this.selectAssetList.includes(g.unitId))
  //     .map((g) => g.unitId);
  //   return {
  //     organisationUnitList: this.deleteSame(organisationUnitList),
  //     snapshotList: this.deleteSame(snapshotList),
  //   };
  // }
  returnSelectData() {
    const organisationUnitList = this.selectAssetList.filter((item) => item.type === 'assessment');
    const snapshotList = this.selectAssetList.filter((item) => item.type === 'snapshot');

    return {
      organisationUnitList: this.deleteSame(organisationUnitList),
      snapshotList: this.deleteSame(snapshotList),
    };
  }

  private toggleSelectedAssessment(assessment: any, level: any): void {
    const index = this.selectAssetList.findIndex((item) => item.unitId === assessment.unitId);
    if (index === -1) {
      this.selectAssetList.push({
        name: assessment.name,
        unitId: assessment.unitId,
        type: level?.name === 'Snapshots' ? 'snapshot' : 'assessment',
      });
      assessment.added = true;
    } else {
      this.selectAssetList.splice(index, 1);
      assessment.added = false;
      level.added = false;
    }
  }
  goToAggregate() {
    const returnData = this.returnSelectData();
    const setData = {
      memberList: returnData.organisationUnitList.map((item) => item.unitId),
    };
    if (this.selectAssetList.length > 1) {
      if (returnData.snapshotList.length > 0) {
        this.snapShotWarning = true;
        setTimeout(() => {
          this.snapShotWarning = false;
        }, 3000);
      } else {
        this.showLoadigIconAggregate = true;
        this.snapShotWarning = false;
        this.http.callService(new Method(environment.services.aggregateBusiness(), setData, 'put')).subscribe((res) => {
          this.localStorageService.setCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY, res);
          this.router.navigate(['cti/pro/aggregate']);
          this.showLoadigIconAggregate = false;
        });
      }
    }
  }
  async goToCompare() {
    const returnData = this.returnSelectData();
    const setData = {
      organisationUnitList: returnData.organisationUnitList.map((item) => item.unitId),
      snapshotList: returnData.snapshotList.map((item) => item.unitId),
    };

    if (this.selectAssetList.length > 1) {
      this.showLoadigIconCompare = true;
      this.http.callService(new Method(environment.services.compareBusiness(), setData, 'put')).subscribe((res) => {
        this.compareData = res;
        this.compareData.forEach((item) => {
          item.namesort = `${item.businessLevelName.toUpperCase()}-${item.assessmentName.toUpperCase()}`;
        });
        this.showLoadigIconCompare = false;
        this.localStorageService.setCompressedItem(this.localStorageService.COMPARE_DATA_KEY, res);
        this.router.navigate(['cti/pro/compare']);
      });
    }
  }

  async bulkDelete() {
    const returnData = this.returnSelectData();
    const data = [...returnData.organisationUnitList.map((item) => item.unitId)];
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `Delete ${data.length} assessments`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.bulkDelete(), { assessmentList: data }, 'put'))
          .subscribe(async (res: []) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            await this.getBusinessLevel();
            this.refreshSelectedAssessment();
            if (this.snapshotData) {
              this.getSnapshot(false);
            }
            if (this.labelBaseComponent) {
              this.labelBaseComponent.getAssessmentaccordingToLabel();
            }
          });
      } catch (error) {}
    });
  }

  private initializeUI(): void {
    const headerElement = document.getElementById('header');
    if (headerElement) {
      headerElement.style.display = 'none';
    }
    this.checkUserRolesAndFeatures();
  }

  private checkUserRolesAndFeatures(): void {
    if (this.credentials) {
      this.labelManagmentShow = this.credentials?.organisation?.features.includes('label');
      this.updateLabelShow = this.credentials['roles'].some((role) => role.name === 'Company admin');
    }
  }

  quikTipsClose() {
    this.labelViewQuikTipsShow = false;
    localStorage.setItem('labelViewQuikTipsShow', JSON.stringify(this.labelViewQuikTipsShow));
  }
  dashboardChange() {
    this.http
      .callService(
        new Method(
          environment.services.userJourney(),
          [
            {
              question: 'SHOW_BL_VIEW',
              value: true,
            },
          ],
          'put'
        )
      )
      .subscribe((res) => {
        this.dashboardPreferenceService.setShowBLDashboard(true);
        this.router.navigate(['/cti/pro-business']);
      });
  }
  private loadInitialData(): void {
    if (this.labelManagmentShow) {
      this.setLabel();
    }
    if (!sessionStorage.getItem('onboardingAlwaysOn')) {
      this.http.callService(new Method(environment.services.ctiGuidance(), '', 'get')).subscribe((ctiGuidanceData) => {
        sessionStorage.setItem('ctiGuidance', JSON.stringify(ctiGuidanceData));
        sessionStorage.setItem('onboardingAlwaysOn', JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']));
        this.commonService.onboardingAlwaysOn = JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']);
      });
    }
    if (this.localStorageService.getCompressedSessionItem('questionList') === null) {
      this.loginService.getQuestionList();
    }
  }

  get shouldShowLoader(): boolean {
    return !this.data || !this.storyblok || this.isLoading || !this.E5storyblok || this.isLoadingLabelbig;
  }

  get isDataLoaded(): boolean {
    return !!this.data && !!this.storyblok && !!this.E5storyblok;
  }

  get shouldShowSearchBox(): boolean {
    return !this.noLabelTextShow;
  }

  get shouldShowSearchClose(): boolean {
    return this.searchText?.length >= 2;
  }

  get shouldShowLabelLoader(): boolean {
    return !this.relatedLabelData && this.isLoadingLabel && !this.noLabelTextShow;
  }

  get shouldShowLabelManagementMask(): boolean {
    return this.labelManagmentContentShow;
  }

  get showAlert(): boolean {
    return this.credentials?.remainingDaysToVerify > 0 && !this.credentials?.emailVerified;
  }

  hazardousManagment(selectAssetList: any) {
    const dialogRef = this.dialog.open(ManageHazardousComponent, {
      width: '80%',
      maxWidth: '850px',
      panelClass: 'centered-dialog',
      data: { storyblok: this.storyblok, assessmentList: selectAssetList.map((item) => item.unitId) },
    });
  }

  gotoAssessment(assessment: any) {
    if (this.project === 'cti') {
      if (this.relatedLabelData) {
        localStorage.setItem('selectedBusiness', JSON.stringify(this.relatedLabelData));
      } else {
        localStorage.setItem('selectedBusiness', JSON.stringify({ assessments: [assessment] }));
      }
      sessionStorage.setItem('selectedAssessment', JSON.stringify(assessment));
      this.commonService.selectedUnit = assessment;
      this.router.navigate([`/cti/${assessment.unitId}/assessment/step1`]);
    } else {
      this.router.navigate([`/e5/${assessment.unitId}/e5-materials/true`], {
        queryParams: {
          name: assessment.name,
          inflowMass: assessment?.inflowMass,
          outflowMass: assessment?.outflowMass,
        },
      });
    }
  }

  ngOnInit(): void {
    delete sessionStorage.indicators;
    this.isLoadingLabelSmallSub = this.commonService.isLoadingLabelSmall.subscribe((res) => {
      this.isLoadingLabelSmall = res;

      const labelIds = JSON.parse(localStorage.getItem('dashboardSelectedLabelIds') || '[]');
      const currentLength = labelIds.length;

      if (currentLength <= 1 && this.previousLabelIdsLength !== 2) {
        this.isLoadingLabelbig = res;
      }
      this.previousLabelIdsLength = currentLength;
    });
    if (JSON.parse(localStorage.getItem('dashboardSelectedLabelIds') || '[]').length > 1) {
      this.isLoadingLabelbig = true;
    }
    if (this.project === 'cti') {
      $('#main-content').addClass('darkBG');
    } else {
      $('#main-content').addClass('darkGreenBG');
    }
    if (this.isProLabel) {
      $('#header').show();
    } else {
      $('#header').hide();
    }
    this.getBusinessLevel();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'pro-dashboard');
      this.storyblok = story[0].content;
      const e5story = data.filter((item) => item.slug === 'e5-dashboard');
      this.E5storyblok = e5story[0].content;
    });
  }

  ngOnDestroy(): void {
    $('#main-content').removeClass('darkBG');
    $('#main-content').removeClass('darkGreenBG');
    const headerElement = document.getElementById('header');
    if (headerElement) {
      headerElement.style.display = '';
    }
    if (this.isLoadingLabelSmallSub) {
      this.isLoadingLabelSmallSub.unsubscribe();
    }
    if (this.searchSubscription) {
      this.searchSubscription.unsubscribe();
    }
  }
  selectedAllbussinesAssesment(event: any, level: any) {
    level.added = event.checked;
    level.assessments.forEach((assessment) => {
      if (event.checked) {
        if (!assessment.added) {
          this.selectAssest(event, assessment, level);
        }
      }
      if (!event.checked) {
        if (assessment.added) {
          this.selectAssest(event, assessment, level);
        }
      }
    });
  }
  addLabelEvent() {
    this.setLabel();
    setTimeout(() => {
      const searchLabel = $('#searchLabel').val() as string;
      this.labelBaseComponent.addLabel(searchLabel);
    }, 500);
  }
  navigationModeEvent(val: boolean) {
    this.navigationMode = val;
  }

  deleteLabel(label: any) {
    if (this.relatedLabelData && this.relatedLabelData.labels) {
      this.relatedLabelData.labels = this.relatedLabelData.labels.filter((l) => l.id !== label.id);
    }
    this.labelBaseComponent.selectLabel(label.id, false, true);
  }
  setRelatedLabelData(data: any): void {
    this.isLoadingLabelbig = false;
    if (data) {
      const selectedSet = new Set(this.selectAssetList.map((asset) => asset.unitId));
      data.assessments.forEach((assessment) => {
        if (selectedSet.has(assessment.unitId)) {
          assessment.added = true;
        }
        if (assessment.id === this.duplicateAssessmentId) {
          assessment.isDuplicated = true;
        }
      });

      data.assessments.sort((a, b) => {
        if (a.isDuplicated) return -1;
        if (b.isDuplicated) return 1;
        return 0;
      });
    }
    this.relatedLabelData = null;
    this.noLabelTextShow = false;
    if (!data) {
      this.noLabelTextShow = true;
      return;
    }
    this.relatedLabelData = data;
    this.initialRelatedLabelData = data;
    if (this.relatedLabelData && this.relatedLabelData.assessments) {
      this.noLabelTextShow = false;
    }
  }

  setLabel(): void {
    this.http
      .callService(new Method(environment.services.labelSearch(), { keyword: '' }, 'put'))
      .subscribe((res: any[]) => {
        this.labelList = res.map((label) => ({
          ...label,
          selected: false,
          labelPahtWithTrim: label.path.join('').toLowerCase().replace(/\s/g, ''),
        }));
        this.labelListPureData = this.labelList;
        this.labelList.sort((a, b) => a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim));
      });
  }

  goToReport(): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(E5ReportDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: { storyblok: this.E5storyblok, selectAssetList: this.selectAssetList.map((item) => item.unitId) },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.router.navigate([`e5/${result.uuid}/e5-report`]);
      }
    });
  }

  toggleExpand(assessment: any): void {
    assessment.expendActive = !assessment.expendActive;
  }

  isLastPath(label: any, index: number): boolean {
    return label.path.length === index + 1;
  }

  isDuplicateAssessment(assessment: any): boolean {
    return this.duplicateAssessmentId === assessment.id;
  }

  buttonDisabled(value: boolean): void {
    this.showCreateLabel = value;
  }
  close(): void {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${this.E5storyblok.delete_assessment_list_modal_title}`,
        message: `${this.E5storyblok.delete_assessment_list_modal_text}`,
        yesButtonText2: 'CLEAR',
        noButtonText: 'KEEP SELECTION ',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.refreshSelectedAssessment();
      }
    });
  }

  refreshSelectedAssessment() {
    sessionStorage.removeItem('selectAssetList');
    this.selectAssetListShow = false;
    this.selectAssetList = [];
    this.labelManagmentShow = false;
    this.labelManagmentContentShow = false;
    this.labelList.forEach((label) => (label.selected = false));
    if (this.snapshotData.assessments) {
      this.snapshotData.assessments['added'] = false;
      this.snapshotData.assessments.forEach((assessment) => (assessment.added = false));
    }
    if (this.relatedLabelData) {
      this.relatedLabelData.added = false;
      this.relatedLabelData.assessments.forEach((assessment) => (assessment.added = false));
    }
  }

  searchAssessment(event: any): void {
    const initialRelatedLabelData = [];

    if (event !== null) {
      const searchText = event.target.value.trim().toLowerCase().replace(/\s/g, '');
      this.searchText = searchText;
    } else {
      this.searchText = '';
      $('#searchInput').val('');
    }
    if (this.searchText.length > 2 && this.searchText !== null) {
      this.initialRelatedLabelData?.assessments.forEach((assessment) => {
        assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
        if (assessment.assessmentNameWithTrim.includes(this.searchText)) {
          initialRelatedLabelData.push(assessment);
        }
      });
      this.relatedLabelData = { assessments: initialRelatedLabelData };
    } else {
      this.relatedLabelData = this.initialRelatedLabelData;
    }
  }

  sortData(sort: Sort, assessmentList: any): void {
    if (!sort.active || sort.direction === '') {
      this.sortedData = assessmentList;
      return;
    }
    this.sortedData = this.sortAssessments(sort, assessmentList);
  }

  private sortAssessments(sort: Sort, assessments: any[]): any[] {
    const isAsc = sort.direction === 'asc';
    return assessments.sort((a, b) => this.compare(a[sort.active], b[sort.active], isAsc));
  }

  private compare(a: number | string, b: number | string, isAsc: boolean): number {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  settingsClicked(assessment: any, value: any[]): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    value.forEach((item) => {
      if (item.unitId === assessment.unitId) {
        item.isSettingsVisible = !item.isSettingsVisible;
      } else {
        item.isSettingsVisible = false;
      }
    });
  }

  importAssessment(level: object, index: number): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(ImportAssessmentE5Dialog, {
      width: '80%',
      maxWidth: '640px',
      panelClass: 'centered-dialog',
      data: this.labelList,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getBusinessLevel();
      }
    });
  }

  reportStatus(assessment: any, level: any) {
    this.http
      .callService(new Method(environment.services.reportStatus(assessment.unitId), '', 'get'))
      .subscribe((res) => {
        if (res['canDownload']) {
          if (res['warningMessage']) {
            const dialogRef = this.dialog.open(ReportStatusDialog, {
              width: '80%',
              maxWidth: '430px',
              panelClass: 'centered-dialog',
              data: {
                message: res['warningMessage'],
              },
            });
            dialogRef.afterClosed().subscribe(async (result) => {
              if (!result) {
                return;
              }
              try {
                window.open(`/cti/${assessment.unitId}/${this.authToken}/report`);
              } catch (error) {}
            });
          } else {
            window.open(`/cti/${assessment.unitId}/${this.authToken}/report`);
          }
        } else {
          this.snackBar.open(res['warningMessage'], '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        }
      });
  }

  async duplicateAssessment(assessment: object, level: object, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(DupplicateAssessmentDialog, {
      width: '80%',
      maxWidth: '660px',
      panelClass: 'centered-dialog',
      data: {
        name: `${level['name']}`,
        assessmentName: `${assessment['name']}`,
        step5: false,
        step6: false,
        step7: false,
      },
    });
    this.settingsClicked(assessment, level['assessments']);
    dialogRef.afterClosed().subscribe(async (result) => {
      this.copyAssessmentName = result.copyAssessmentName;
      if (!result) {
        return;
      }
      try {
        await this.http
          .callService(new Method(environment.services.duplicateAssessment(assessment['id']), result, 'post'))
          .subscribe(async (res) => {
            this.isLoadingLabelbig = true;
            this.duplicateAssessmentId = res['id'];
            await this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });

            let isPolling = true;

            const pollData = () => {
              if (!isPolling) return;

              this.http
                .callService(new Method(environment.services.getAssessmentaccordingToLabel(), { labelIds: [] }, 'put'))
                .subscribe((res: any) => {
                  const hasDuplicatedAssessment = res?.assessments?.some(
                    (assessment) => assessment.name === this.copyAssessmentName
                  );
                  if (!hasDuplicatedAssessment) {
                    setTimeout(pollData, 2000);
                  } else {
                    this.labelBaseComponent.setNoLabelSelected(true);
                    isPolling = false;
                  }
                });
            };
            pollData();
          });
      } catch (error) {}
    });
  }

  getAssessmentaccordingToLabel() {
    const initialCount = this.relatedLabelData?.assessments?.length || 0;

    const pollData = () => {
      this.http
        .callService(new Method(environment.services.getAssessmentaccordingToLabel(), { labelIds: [] }, 'put'))
        .subscribe((res: any) => {
          const currentCount = res?.assessments?.length || 0;
          this.setRelatedLabelData(res);
          if (currentCount <= initialCount) {
            setTimeout(pollData, 1000);
          }
        });
    };
    pollData();
  }

  removeAssessment(assessment: object): void {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${assessment['name']}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.http
          .callService(new Method(environment.services.getAssessment(assessment['id']), '', 'delete'))
          .subscribe(() => {
            this.getBusinessLevel();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.relatedLabelData.assessments.forEach((item) => {
              if (item.id === assessment['id']) {
                item.removed = true;
              }
            });
          });
      }
    });
  }
  removeSnapshot(item: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${item.name}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.assessmentSnapshotRemove(item.unitId), '', 'delete'))
          .subscribe(async (res: []) => {
            this.getSnapshot(item.unitId);
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }
  renameSnapshot(item: any) {
    this.snapshotData.assessments.forEach((snapshotItem) => {
      if (snapshotItem.unitId === item.unitId) {
        snapshotItem.edit = true;
      } else {
        snapshotItem.edit = false;
      }
    });
  }

  snapshotNameChange(item: any) {
    this.http
      .callService(new Method(environment.services.assessmentSnapshotEdit(item.unitId), { name: item.name }, 'put'))
      .subscribe(async (res) => {
        item.edit = false;
        item.isSettingsVisible = false;
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }
  async getBusinessLevel(): Promise<void> {
    this.isLoading = true;
    const businessLevels = await this.fetchBusinessLevels();

    this.totalAssessments = await this.fetchBusinessLevels();
    this.processBusinessLevels(businessLevels);

    this.isLoading = false;
  }

  get formattedLabel(): string {
    return this.E5storyblok?.add_label.replace('#COUNT', Number(this.totalAssessments));
  }

  private async fetchBusinessLevels(): Promise<any> {
    return this.http
      .callService(new Method(environment.services.businessLevelStats(), '', 'get'))
      .toPromise()
      .then((res: any) => res.assessmentCount);
  }

  private processBusinessLevels(levels: any[]): void {
    this.data = levels;
    this.initialData = levels;
    if (this.data.length) {
      this.data.forEach((level) =>
        level.assessments.forEach((assessment) => {
          assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
        })
      );
      this.data.forEach((level, index) => (level.openAccordion = index === this.selectedIndex));
    }
  }

  openGuidanceEvent() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'label' });
  }

  openGuidanceEventQickTips() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'label', slug: 'slug' });
  }

  async labelManagment(selectAssetList: any): Promise<void> {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    await this.setLabel();
    await this.labelList.forEach((label) => {
      label.selected = false;
    });
    const selectedAssessments = this.findSameAssessment(
      selectAssetList.map((item) => item.unitId),
      this.relatedLabelData.assessments
    );
    const commonLabels = this.findCommonLabels(selectedAssessments);
    await this.labelList.forEach((label) => {
      label.selected = commonLabels.includes(label.id);
    });
    await this.labelList.sort(this.sortBySelected);
    const dialogRef = this.dialog.open(LabelManagmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { selectAssetList: this.selectAssetList.map((item) => item.unitId), labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      this.labelManagmentShow = false;
      this.labelManagmentContentShow = false;
      if (result) {
        await this.labelBaseComponent.getAssessmentaccordingToLabel();
        await this.labelBaseComponent.fetchLabels();
        await this.setLabel();
      }
    });
  }
  private findCommonLabels(assessments: any): string[] {
    const labelIds = assessments.flatMap((assessment) => assessment.labels.map((label) => label.id));
    const size = assessments.length;

    return labelIds.filter((id) => labelIds.filter((labelId) => labelId === id).length === size);
  }

  private sortBySelected(a: any, b: any): number {
    return a.selected === b.selected ? 0 : a.selected ? -1 : 1;
  }

  findSameAssessment(selectAssetList: any[], relatedLabelData: any[]): any[] {
    return relatedLabelData.filter((element) => selectAssetList.includes(element.unitId));
  }

  searchLabel(val: any) {
    const selectedItems = this.labelList.filter((item) => item.selected);
    this.labelList = this.labelListPureData;

    if (val === null) {
      $('#searchLabel').val('');
    }

    const searchText = $('#searchLabel').val()?.toLowerCase().replace(/\s/g, '');

    if (searchText) {
      const filteredItems = this.labelList.filter((item) => {
        return item.labelPahtWithTrim.includes(searchText) && !item.selected;
      });

      this.labelList = [...selectedItems, ...filteredItems];
    } else {
      this.labelList = [...selectedItems, ...this.labelList.filter((item) => !item.selected)];
    }

    this.moveSelectedItemsToTop();
  }

  addToSelectedLabel(label: { id: number; selected: boolean }): void {
    this.updateLabelShow = true;

    if (label.selected) {
      this.selectedLabelArray.push(label.id);
    } else {
      const index = this.selectedLabelArray.indexOf(label.id);
      if (index > -1) {
        this.selectedLabelArray.splice(index, 1);
      }
    }

    this.moveSelectedItemsToTop();
  }

  moveSelectedItemsToTop(): void {
    this.labelList.sort((a, b) => {
      const aSelected = this.selectedLabelArray.includes(a.id);
      const bSelected = this.selectedLabelArray.includes(b.id);
      return aSelected === bSelected ? 0 : aSelected ? -1 : 1;
    });
  }

  addLabel(): void {
    const searchLabel = $('#searchLabel').val() as string;
    this.labelBaseComponent.addLabel(searchLabel);
  }

  addAssessment(): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(AddAssessmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { data: { name: this.project }, type: 'assessment', labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (result) {
        this.isLoading = true;
        await this.http
          .callService(
            new Method(
              environment.services.addAssessmentDefault(),
              { name: result.assessmentName ? result.assessmentName : result },
              'post'
            )
          )
          .subscribe(async (res) => {
            let unitIds = [];
            const labelIds = result.labelList;
            unitIds.push(res['unitId']);
            if (labelIds) {
              await this.http.callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'));
            }
            this.isLoading = false;
            this.gotoAssessment(res);
          });
      }
    });
  }

  onSearchKeywordChange(event: any): void {
    this.searchKeyword = event.target.value || '';
    this.searchSubject.next(this.searchKeyword);
  }

  clearSearch(): void {
    this.searchKeyword = '';
    this.searchSubject.next('');
  }
}
