import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  AfterViewChecked,
  OnInit,
  EventEmitter,
  Output,
} from '@angular/core';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ActualRecoveryRatetDialog } from '@app/shared/dialog/actual-recovery-rate/actual-recovery-rate-dialog.component';
import { ChangeDetectorRef } from '@angular/core';
import { E5MaterialsComponent } from '../e5-materials.component';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';

declare var $: any;

@Component({
  selector: 'app-e5-outflow-question',
  templateUrl: './e5-outflow-question.component.html',
  styleUrls: ['./e5-question.component.scss'],
  standalone: false,
})
export class E5OutflowQuestionComponent implements OnChanges, AfterViewChecked, OnInit {
  @Input() public selectedFlow: string;
  @Input() public storyblok: any;
  @Input() public E5storyblok: any;
  @Input() public isEditable: any;
  @Input() public selectedAssessmentData: any;
  @Input() public blockNavigation: boolean;
  @Output() public showBoxResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  totalMassArray = [0, 0, 0, 0, 0, 0];
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  questions = [];
  technical = [];
  biological = [];
  foodAndFeed = [];
  possibleRecoveryTypes = [];
  selectPotential;
  isEmptyTI5;
  unitId = this.route.snapshot.params.unitId;
  kgValue;
  gramValue;
  storyblokGuidance;
  totalValue;
  selectedFlowId;
  indicators;
  isGHGShow;
  selectedPercentage;
  SelectApplication = 'Select Recovery rate source application';
  questionnaireId;
  controls;
  showForm = false;
  nameAvailable = true;
  currentName;
  materialType;
  flowId;
  form: FormGroup;
  showTest;
  answers;
  baseQuestionList = [];
  actualRecoveryRates = environment.services.actualRecoveryRates;
  isLoading = false;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private cdRef: ChangeDetectorRef,
    public storyblokService: StoryblokService,
    public e5materialsComponent: E5MaterialsComponent,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokGuidance = {
        name: data.filter((item) => item.uuid === '6dd82a43-54e6-4fb7-a5fa-a85b7195bb3e')[0].content,
        mass: data.filter((item) => item.uuid === '7cc9dc10-93f1-42f1-b143-cdf5af3f350e')[0].content,
        recoveryPotentia: data.filter((item) => item.uuid === 'cd0b107c-0fe0-473a-8c41-e5c32e24b37c')[0].content,
        flowType: data.filter((item) => item.uuid === 'bb75293e-2537-4326-a59e-b011df53eb7b')[0].content,
        actualRecovery: data.filter((item) => item.uuid === '4fcfe341-f256-4af3-aed2-78be7f89b663')[0].content,
        ghgOutflowImpact: data.filter((item) => item.uuid === '1908847c-617f-4350-80c6-b397b22fa10b')[0].content,
      };
    });
  }
  changeData(value: boolean) {
    if (this.isEditable) {
      this.dirtyData = value;
      this.showBoxResponse.emit(value);
    }
  }
  openGuidanceEvent(slug: any) {
    this.commonService.mainGuidanceData.next({ show: true, active: 'datapoint', slug: slug });
  }
  async reset() {
    this.changeData(false);
    await this.e5materialsComponent.closeDetail();
    await this.delay(1);
    await this.e5materialsComponent.showDetail(this.selectedFlow, 'OUTFLOW');
  }
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  baseQuestion() {
    const outflowQuestions = ['M18', 'TI6', 'TI10', 'TI39', 'TI42', 'TI47', 'TI45', 'TI60', 'TI58', 'TI61', 'ESRS1'];
    const questionList = this.localStorageService.getCompressedSessionItem('questionList');
    questionList.forEach((question) => {
      outflowQuestions.forEach((code) => {
        if (question.code === code) {
          this.baseQuestionList.push(question);
        }
      });
    });
  }

  public ngOnChanges(changes: SimpleChanges) {
    if (changes.selectedFlow) {
      if (changes.selectedFlow.currentValue.flowId !== this.flowId) {
        this.showForm = false;
        const id = changes.selectedFlow.currentValue.id;
        this.flowId = changes.selectedFlow.currentValue.flowId;
        this.materialType = this.commonService.materialType;
        this.isGHGShow = this.commonService.isGHGShow;
        this.selectedFlowId = changes.selectedFlow.currentValue.id;
        if (this.isEditable) {
          this.getSummary(this.flowId);
        } else {
          this.getESRSQuestion();
        }
      }
    }
  }
  getESRSQuestion() {
    this.http
      .callService(
        new Method(
          environment.services.esrsQuestionData(this.selectedAssessmentData.reportId, this.unitId, this.selectedFlowId),
          '',
          'get'
        )
      )
      .subscribe((res) => {
        this.flowId = this.selectedFlowId;
        this.answers = [];
        this.answers = res;
        this.filterQuestion();
      });
  }
  getSummary(flowId: any) {
    this.http.callService(new Method(environment.services.flowSummary(flowId), '', 'get')).subscribe((res) => {
      this.questionnaireId = res['questionnaire']['questionnaireId'];
      this.getAnswers(this.questionnaireId);
    });
  }

  getAnswers(id: string) {
    localStorage.setItem('questionId', id);
    this.http.callService(new Method(environment.services.answers(id), '', 'get')).subscribe((res) => {
      this.answers = [];
      this.answers = res;
      this.filterQuestion();
    });
  }
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  ngOnInit(): void {
    this.baseQuestion();
  }

  filterQuestion() {
    this.questions = [];
    this.controls = {};
    this.baseQuestionList.forEach((b) => {
      b.value = [''];
      this.questions.push(b);
    });
    this.answers.forEach((a) => {
      this.questions.forEach((q) => {
        if (a.code === q.code) {
          q.value = a.value;
        }
        if (q.code === 'TI6') {
          q.massValue = ['', ''];
          q.massValue = q.value[0].split('.', 2);
          if (q.massValue[1]) {
            if (q.massValue[1].length === 1) {
              q.massValue[1] = q.massValue[1] + '00';
            }
            if (q.massValue[1].length === 2) {
              q.massValue[1] = q.massValue[1] + '0';
            }
            if (q.massValue[1].length > 2) {
              q.massValue[1] = q.massValue[1].substring(0, 3);
            }
          }
        }
      });
    });
    this.questions = this.questions.reduce((acc, item) => {
      acc[item.code] = {
        ...item,
      };
      return acc;
    }, {});
    this.generateForm();
  }
  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.flowNameCheck(this.unitId, 'OUTFLOW'), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
          this.nameAvailable =
            this.currentName.trim().toLowerCase() === name.trim().toLowerCase() ? true : this.nameAvailable;
          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }
  async generateForm() {
    this.showForm = false;

    this.calaculateTotalMass();
    this.controls['kg'] = new FormControl();
    this.controls['gram'] = new FormControl();
    for (const [key, q] of Object.entries(this.questions)) {
      this.currentName = this.questions['M18'].value[0];
      if (q.code === 'ESRS1') {
        if (q.value[0] !== 'Yes') {
          q.realValue = false;
        } else {
          q.realValue = true;
        }
      }
      this.controls[q.code] = new FormControl(false);
    }
    this.form = this.fb.group({
      questionnaire: this.fb.group(this.controls),
    });

    this.showForm = true;

    await setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        if (this.isEditable) {
          this.dirtyData = true;
          this.showBoxResponse.emit(true);
        }
      });
    }, 1000);
  }

  openModel(item: string) {
    const dialogRef = this.dialog.open(ActualRecoveryRatetDialog, {
      width: '80%',
      maxWidth: '700px',
      height: '500px',
      panelClass: 'centered-dialog',
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.changeData(true);
        this.selectedPercentage = result.percentage;
        this.SelectApplication = result.name;
      } catch (error) {}
    });
  }

  calaculateTotalMass() {
    const calculateArray = ['TI39', 'TI42', 'TI45', 'TI47', 'TI58', 'TI60'];
    calculateArray.forEach((code, index) => {
      this.totalMassArray[index] = 0;
      const question = this.questions[code];
      if (question && question.value?.[0]) {
        this.totalMassArray[index] = Number(question.value[0]) || 0;
      } else {
        console.warn(`Question with code ${code} not found or value is undefined.`);
      }
    });
    calculateArray.forEach((element, index) => {
      this.maxValueWithTotal(this.questions[element], index, false);
    });
  }

  maxValueWithTotal(item: any, index: any, changeData: boolean) {
    this.totalMassArray[index] = Number(item.value[0] > 0 ? item.value[0] : 0);
    const totalSum: number = this.totalMassArray.reduce((a, b) => a + b, 0);
    const allowedPercentage = 100;
    if (totalSum > allowedPercentage) {
      this.totalMassArray[index] = allowedPercentage - (totalSum - this.totalMassArray[index]);
    }
    if (this.totalMassArray[index] < 0) {
      this.totalMassArray[index] = 0;
    }
    item.value[0] = this.totalMassArray[index];
    this.questions['TI61'].value[0] = 100 - totalSum < 0 ? 0 : 100 - totalSum;
    if (changeData) {
      this.changeData(true);
    }
  }

  maxValue(item: any, max: any) {
    if (item.value[0] > max) {
      item.value[0] = max;
    }
    if (item.value[0] < 0) {
      item.value[0] = 0;
    }
    this.changeData(true);
  }

  maxValueFake(item: any, max: any) {
    if (item.massValue[1] > max) {
      item.massValue[1] = max;
    }
  }

  nameChangeEvent(q: any) {
    this.changeData(true);
  }

  resetTableData() {
    this.form.value.questionnaire.TI39 = '';
    this.form.value.questionnaire.TI42 = '';
    this.form.value.questionnaire.TI45 = '';
    this.form.value.questionnaire.TI47 = '';
    this.form.value.questionnaire.TI58 = '';
    this.form.value.questionnaire.TI60 = '';
    this.form.value.questionnaire.TI61 = '';

    this.questions['TI39'].value[0] = '';
    this.questions['TI42'].value[0] = '';
    this.questions['TI45'].value[0] = '';
    this.questions['TI47'].value[0] = '';
    this.questions['TI58'].value[0] = '';
    this.questions['TI60'].value[0] = '';
    this.questions['TI61'].value[0] = '';
  }

  saveForm(isPublish: boolean) {
    this.changeData(false);
    this.blockNavigation = false;
    const data = {};
    this.totalValue = null;
    this.kgValue = 0;
    this.gramValue = 0;
    for (const [key, value] of Object.entries(this.form.getRawValue().questionnaire)) {
      if (
        key.indexOf('verification') === -1 &&
        value !== undefined &&
        value !== 'false' &&
        value !== null &&
        value !== ''
      ) {
        if (key === 'TI21') {
          data[key] = [{ [key]: String(value ? 'Yes' : 'No') }];
        }
        if ($('#TI5').val() === '') {
          data['TI5'] = [{ ['TI5']: null }];
        }
        if ($('#TI4').val() === '') {
          data['TI4'] = [{ ['TI4']: null }];
        }
        if (key === 'kg' || key === 'gram') {
          if (key === 'kg' || key === 'gram') {
            if (key === 'kg') {
              this.kgValue = value;
            }
            if (key === 'gram') {
              if (String(value).length === 1) {
                this.gramValue = `00${value}`;
              } else if (String(value).length === 2) {
                this.gramValue = `0${value}`;
              } else {
                this.gramValue = String(value).substr(String(value).length - 3);
              }
            }
            this.totalValue = this.kgValue + '.' + this.gramValue;
            data['TI6'] = [{ ['TI6']: this.totalValue }];
          }
        }
        if (key !== 'TI21' && key !== 'TI6' && key !== 'kg' && key !== 'gram') {
          data[key] = [{ [key]: String(value) }];
        }
        if (key === 'TI30') {
          data[key] = [
            {
              [key]: String(
                this.form.value.questionnaire.TI12 === 'technical' ? this.form.value.questionnaire.TI30 : ''
              ),
            },
          ];
        }
      }
      if (key === 'ESRS1') {
        data[key] = [{ [key]: String(value ? 'Yes' : 'No') }];
      }
      if (key === 'TI62') {
        data[key] = [{ [key]: String(this.questions['TI62'].value[0] ? this.questions['TI62'].value[0] : '') }];
      }
      if (key === 'TI67') {
        data[key] = [{ [key]: String(this.questions['TI67'].value[0] ? this.questions['TI67'].value[0] : '') }];
      }
      if (key === 'TI72') {
        data[key] = [{ [key]: String(this.questions['TI72'].value[0] ? this.questions['TI72'].value[0] : '') }];
      }
      if (key === 'TI77') {
        data[key] = [{ [key]: String(this.questions['TI77'].value[0] ? this.questions['TI77'].value[0] : '') }];
      }
    }
    data['TI38'] = [{ ['TI38']: String('Yes') }];
    if (this.form.controls.questionnaire.value.TI10 !== 'product') {
      delete data['TI24'];
      delete data['TI25'];
      delete data['TI26'];
    }
    this.http
      .callService(
        new Method(environment.services.ctiFlowQuestionsSave(this.flowId), { 'Product Details': data }, 'put')
      )
      .subscribe(async (res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        if (isPublish) {
          this.http
            .callService(
              new Method(
                environment.services.ctiQuestionsPublish(this.questionnaireId),
                { questionnaireId: this.questionnaireId },
                'post'
              )
            )
            .subscribe(async (res2) => {
              await this.e5materialsComponent.initData(true);
              await this.e5materialsComponent.closeDetail();
              this.isLoading = false;
            });
        } else {
          await this.e5materialsComponent.initData();
        }
      });
  }

  saveAndPublishForm() {
    this.isLoading = true;
    this.saveForm(true);
  }
}
