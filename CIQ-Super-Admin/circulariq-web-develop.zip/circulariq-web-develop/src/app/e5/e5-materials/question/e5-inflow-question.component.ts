import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { E5MaterialsComponent } from '../e5-materials.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { ActivatedRoute } from '@angular/router';

declare var $: any;

@Component({
  selector: 'app-e5-inflow-question',
  templateUrl: './e5-inflow-question.component.html',
  styleUrls: ['./e5-question.component.scss'],
  standalone: false,
})
export class E5InflowQuestionComponent implements OnChanges {
  @Input() public selectedFlow: string;
  @Input() public storyblok: any;
  @Input() public E5storyblok: any;
  @Input() public isEditable: any;
  @Input() public selectedAssessmentData: any;
  @Input() public blockNavigation: boolean;
  @Output() public showBoxResponse: EventEmitter<any> = new EventEmitter();

  dirtyData = false;
  unitId = this.route.snapshot.params.unitId;
  kgValue;
  gramValue;
  freeOrganization;
  showCriticalMaterial = true;
  storyblokGuidance;
  selectedFlowId;
  totalValue;
  flowId;
  questionnaireId;
  controls;
  showForm = false;
  criticalBoxShow = false;
  materialType;
  maxPercentage;
  TI2ValidValue = 0;
  TI1ValidValue = 0;
  form: FormGroup;
  answers;
  baseQuestionList = [];
  indicators;
  isGHGShow;
  questions = [];
  displayGuidance = '';
  isLoading = false;
  nameAvailable = true;
  currentName;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    public e5materialsComponent: E5MaterialsComponent,
    public storyblokService: StoryblokService,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService
  ) {
    const questionList = this.localStorageService.getCompressedSessionItem('questionList');
    const inflowQuestions = ['M18', 'TI3', 'TI1', 'TI2', 'TI9'];
    questionList.forEach((question) => {
      inflowQuestions.forEach((code) => {
        if (question.code === code) {
          this.baseQuestionList.push(question);
        }
      });
    });
    const user = JSON.parse(sessionStorage.getItem('credentials'));
    this.freeOrganization = user?.organisation?.licenseType === 'Free' || false;
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokGuidance = {
        name: data.filter((item) => item.uuid === 'ca4d328c-0d1b-4fa5-85c3-d6f1579d0eb9')[0].content,
        mass: data.filter((item) => item.uuid === 'a32e7763-fb01-4926-b3e2-ec359e162f5c')[0].content,
        materialSourceType: data.filter((item) => item.uuid === '5886a6ac-4b5e-440c-b5ac-5bb3aeea8c53')[0].content,
        flowType: data.filter((item) => item.uuid === '8a09eeda-9dee-4304-8fe0-6629a12c5694')[0].content,
        criticalMaterial: data.filter((item) => item.uuid === 'dac529a4-d4ac-4385-aee9-ad7861871482')[0].content,
        ghgMaterialReference: data.filter((item) => item.uuid === '4542a983-faaf-436b-8045-9039b4af9758')[0].content,
      };
    });
  }
  openGuidanceEvent() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'started' });
  }
  changeData(value: boolean) {
    if (this.isEditable) {
      this.dirtyData = value;
      this.showBoxResponse.emit(value);
    }
  }

  async reset() {
    this.changeData(false);
    await this.e5materialsComponent.closeDetail();
    await this.delay(1);
    await this.e5materialsComponent.showDetail(this.selectedFlow, 'INFLOW');
  }
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  public ngOnChanges(changes: SimpleChanges) {
    if (changes.selectedFlow) {
      if (this.selectedFlowId !== changes.selectedFlow.currentValue.id) {
        this.isGHGShow = this.commonService.isGHGShow;
        this.showForm = false;
        const id = changes.selectedFlow.currentValue.id;
        this.flowId = changes.selectedFlow.currentValue.flowId;
        this.materialType = this.commonService.materialType;
        this.selectedFlowId = changes.selectedFlow.currentValue.id;
        if (this.isEditable) {
          this.getSummary(this.flowId);
        } else {
          this.getESRSQuestion();
        }
      }
    }
  }
  getESRSQuestion() {
    this.http
      .callService(
        new Method(
          environment.services.esrsQuestionData(this.selectedAssessmentData.reportId, this.unitId, this.selectedFlowId),
          '',
          'get'
        )
      )
      .subscribe((res) => {
        this.flowId = this.selectedFlowId;
        this.answers = [];
        this.answers = res;
        this.filterQuestion();
      });
  }

  getSummary(flowId: any) {
    this.http.callService(new Method(environment.services.flowSummary(flowId), '', 'get')).subscribe((res) => {
      this.questionnaireId = res['questionnaire']['questionnaireId'];
      this.getAnswers(this.questionnaireId);
    });
  }
  getAnswers(id: string) {
    localStorage.setItem('questionId', id);
    this.http.callService(new Method(environment.services.answers(id), '', 'get')).subscribe((res) => {
      this.answers = [];
      this.answers = res;
      this.filterQuestion();
    });
  }

  filterQuestion() {
    this.questions = [];
    this.controls = {};
    this.baseQuestionList.forEach((b) => {
      b.value = [''];
      b.evidenceFiles = [''];
      this.questions.push(b);
    });

    this.answers.forEach((a) => {
      this.questions.forEach((q) => {
        if (a.code === q.code) {
          q.value = a.value;
          q.evidenceFiles = a.evidenceFiles;
          if (q.evidenceFiles.length > 0) {
            if (q.evidenceFiles[0].fileName) {
              q.imgpath = `${environment.serverUrl}/assets/download/${q.evidenceFiles[0].fileName}`;
              q.fileType = q.evidenceFiles[0].fileName.split('.')[1];
            }
          }
        }
        if (q.code === 'TI3') {
          q.massValue = ['', ''];
          if (q.value[0]) {
            q.massValue = q.value[0].split('.', 2);
          }
          if (q.massValue[1]) {
            if (q.massValue[1].length === 1) {
              q.massValue[1] = q.massValue[1] + '00';
            }
            if (q.massValue[1].length === 2) {
              q.massValue[1] = q.massValue[1] + '0';
            }
            if (q.massValue[1].length > 2) {
              q.massValue[1] = q.massValue[1].substring(0, 3);
            }
          }
        }
      });
    });
    this.questions = this.questions.reduce((acc, item) => {
      acc[item.code] = {
        ...item,
      };
      return acc;
    }, {});
    this.generateForm();
  }

  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.flowNameCheck(this.unitId, 'INFLOW'), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
          this.nameAvailable =
            this.currentName.trim().toLowerCase() === name.trim().toLowerCase() ? true : this.nameAvailable;
          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }
  async generateForm() {
    this.showForm = false;
    this.controls['kg'] = new FormControl();
    this.controls['gram'] = new FormControl();
    for (const [key, q] of Object.entries(this.questions)) {
      this.currentName = this.questions['M18'].value[0];
      if (q.code === 'TI2' || q.code === 'TI1') {
        const totalValue = Number(this.questions['TI2'].value) + Number(this.questions['TI1'].value);
        if (totalValue === 0) {
          this.questions['TI9'].value[0] = 100;
        }
      }
      this.controls[q.code] = new FormControl();
    }
    this.form = this.fb.group({
      questionnaire: this.fb.group(this.controls),
    });
    this.showForm = true;
    await setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        if (this.isEditable) {
          this.dirtyData = true;
          this.showBoxResponse.emit(true);
        }
      });
    }, 1000);
  }

  inputKeyUp() {
    this.changeData(true);
    this.maxPercentage = 100;
    for (const [key, element] of Object.entries(this.questions)) {
      if (element.code === 'TI2') {
        if (element.value > 100) {
          element.value = 100;
        }
        if (element.value < 0) {
          element.value = 0;
        }
        this.TI2ValidValue = element.value;
      }
      if (element.code === 'TI1') {
        if (element.value > this.maxPercentage - this.TI2ValidValue) {
          element.value = this.maxPercentage - this.TI2ValidValue;
        }
        if (element.value < 0) {
          element.value = 0;
        }
        this.TI1ValidValue = element.value;
      }
      if (element.code === 'TI9') {
        element.value = this.maxPercentage - this.TI2ValidValue - this.TI1ValidValue;
        if (element.value < 0) {
          element.value = 0;
        }
      }
    }
  }
  maxValueFake(item: any, max: any) {
    if (item.massValue[1] > max) {
      item.massValue[1] = max;
    }
  }

  saveForm(isPublish: boolean) {
    this.changeData(false);
    this.blockNavigation = false;
    const data = {};
    this.totalValue = null;
    this.kgValue = 0;
    this.gramValue = 0;
    for (const [key, value] of Object.entries(this.form.getRawValue().questionnaire)) {
      if (
        key.indexOf('verification') === -1 &&
        value !== undefined &&
        value !== 'false' &&
        value !== null &&
        value !== ''
      ) {
        if (key === 'kg' || key === 'gram') {
          if (key === 'kg') {
            this.kgValue = value;
          }
          if (key === 'gram') {
            if (String(value).length === 1) {
              this.gramValue = `00${value}`;
            } else if (String(value).length === 2) {
              this.gramValue = `0${value}`;
            } else {
              this.gramValue = String(value).substr(String(value).length - 3);
            }
          }
          this.totalValue = this.kgValue + '.' + this.gramValue;
          data['TI3'] = [{ ['TI3']: this.totalValue }];
        } else {
          data[key] = [{ [key]: String(value) }];
        }
      }
    }
    delete data['showCriticalMaterial'];
    this.http
      .callService(
        new Method(environment.services.ctiFlowQuestionsSave(this.flowId), { 'Product Details': data }, 'put')
      )
      .subscribe(async (res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        if (isPublish) {
          this.http
            .callService(
              new Method(
                environment.services.ctiQuestionsPublish(this.questionnaireId),
                { questionnaireId: this.questionnaireId },
                'post'
              )
            )
            .subscribe(async (res2) => {
              await this.e5materialsComponent.initData(true);
              await this.e5materialsComponent.closeDetail();
              this.isLoading = false;
            });
        } else {
          await this.e5materialsComponent.initData();
        }
      });
  }

  saveAndPublishForm() {
    this.isLoading = true;
    this.saveForm(true);
  }
  setProof(event: any) {
    this.getSummary(this.flowId);
  }

  toggleDisplayGuidance(code: string) {
    if (this.displayGuidance === code) {
      this.displayGuidance = null;
    } else {
      this.displayGuidance = code;
    }
  }
}
