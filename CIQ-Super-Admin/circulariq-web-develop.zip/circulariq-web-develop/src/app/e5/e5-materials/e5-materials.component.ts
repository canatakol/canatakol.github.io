import { Component, OnInit, EventEmitter, Output, OnDestroy } from '@angular/core';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { NavigationExtras, NavigationStart, ActivatedRoute, Router, Event } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LabelManagmentDialog } from '@app/shared/dialog/label-managment/label-managment.component';
declare var $: any;
@Component({
  selector: 'app-materials',
  templateUrl: './e5-materials.component.html',
  styleUrls: ['./e5-materials.component.scss'],
  standalone: false,
})
export class E5MaterialsComponent implements OnInit, OnDestroy {
  @Output() public myOutput = new EventEmitter();
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  productDetailData;
  isAdvanced = false;
  redirectUrl;
  dirtyData = false;
  storyblok;
  E5storyblok;
  proStoryblok;
  category;
  criticalBoxShow = false;
  energyBoxShow = false;
  isShowPatica = false;
  inflows;
  inflowResults;
  supplierResults = [];
  inflowRemoveFlowList = [];
  outflowRemoveFlowList = [];
  labelList: any[] = [];
  labelListPureData: any[] = [];
  environment = environment;
  questions;
  showModal = false;
  showCriticalMaterial = false;
  showFileUpload = false;
  steps;
  showAddFlow;
  outflows;
  outflowResults;
  invitedFlows;
  activePageDetail = false;
  unitId = this.route.snapshot.params.unitId;
  isEditable = this.route.snapshot.params.iseditable === 'true' ? true : false;
  selectedAssessmentData;
  selectedMaterial = {
    id: '0',
    tradeName: '',
    type: '',
    responsibleSupplierInitals: '',
    responsibleSupplierInitalsFull: '',
    responsibleSupplierInitalsEmail: '',
    displayName: '',
    tradeNumber: '',
    status: '',
    owner: '',
    transitionDate: '',
    weight: null,
    responsibleUsers: [
      {
        email: '',
        organisation: {
          licenseType: '',
          name: '',
          id: '',
        },
        fullName: '',
        id: '0',
      },
    ],
    draft: null,
    critical: null,
    priority: null,
    buyer: {
      licenseType: '',
      name: '',
      id: '0',
    },

    virginNonRenewablePercentage: null,
    actualRecovery: null,
    potentialRecovery: null,
    wip: null,
    flowId: null,
    responsibleOwnerInitalsFull: '',
    responsibleOwnerInitalsEmail: '',
    responsibleOwnerInitals: '',
  };
  pageInfoInflowValue = 'CREATIONDESCENDING';
  pageInfoOutflowValue = 'CREATIONDESCENDING';
  pageInfoInvitedFlowValue = 'CREATIONDESCENDING';
  pageInfoInflow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  pageInfoOutflow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  pageInfoInvitedFlow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  materiaNavShow = false;
  lastCreateMaterial = {};
  user;
  freeOrganization;
  pondOptions;
  labels;
  loaderShow = false;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private route: ActivatedRoute,
    public router: Router,
    private storyblokService: StoryblokService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar
  ) {
    this.user = JSON.parse(sessionStorage.getItem('credentials'));
    this.freeOrganization = this.user?.organisation?.licenseType === 'Free' || false;
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
    this.getAssmentLabel();
    this.getProductLineDetails();
  }

  getProductLineDetails() {
    this.http
      .callService(new Method(environment.services.productLineDetails(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.productDetailData = res;
        this.productDetailData.amount = res['amount'] ? res['amount'] : 1;
      });
  }
  setProductLineDetails() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const data = { amount: this.productDetailData.amount };
    this.http
      .callService(new Method(environment.services.productLineDetails(this.unitId), data, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }

  getAssmentLabel() {
    this.http.callService(new Method(environment.services.assementLabel(this.unitId), '', 'get')).subscribe((res) => {
      this.labels = res;
    });
  }

  async labelManagment(): Promise<void> {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }

    await this.labelList.forEach((label) => {
      label.selected = false;
    });
    const selectedAssessments = [{ unitId: this.unitId, labels: this.labels }];
    const commonLabels = this.findCommonLabels(selectedAssessments);
    await this.labelList.forEach((label) => {
      label.selected = commonLabels.includes(label.id);
    });
    await this.labelList.sort(this.sortBySelected);
    const dialogRef = this.dialog.open(LabelManagmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { selectAssetList: [this.unitId], labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (result) {
        await this.getAssmentLabel();
      }
    });
  }

  setLabel(): void {
    this.http
      .callService(new Method(environment.services.labelSearch(), { keyword: '' }, 'put'))
      .subscribe(async (res: any[]) => {
        this.labelList = res.map((label) => ({
          ...label,
          selected: false,
          labelPahtWithTrim: label.path.join('').toLowerCase().replace(/\s/g, ''),
        }));
        this.labelListPureData = this.labelList;
        await this.labelList.sort((a, b) => a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim));
        await this.labelManagment();
      });
  }

  private findCommonLabels(assessments: any): string[] {
    const labelIds = assessments.flatMap((assessment) => assessment.labels.map((label) => label.id));
    const size = assessments.length;

    return labelIds.filter((id) => labelIds.filter((labelId) => labelId === id).length === size);
  }

  private sortBySelected(a: any, b: any): number {
    return a.selected === b.selected ? 0 : a.selected ? -1 : 1;
  }

  findSameAssessment(selectAssetList: any[], relatedLabelData: any[]): any[] {
    return relatedLabelData.filter((element) => selectAssetList.includes(element.unitId));
  }

  deleteLabel(label: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const result = label.path.join(' / ');

    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${result}`,
        message: this.E5storyblok.delete_label_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.http
          .callService(
            new Method(environment.services.labelDrop(), { labelIds: [label.id], unitIds: [this.unitId] }, 'put')
          )
          .subscribe((res) => {
            this.getAssmentLabel();
          });
      }
    });
  }

  isLastPath(label: any, index: number): boolean {
    return label.path.length === index + 1;
  }

  addRemoveList(value: any, id: any, type: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      this.close();
      return;
    }
    if (type === 'inflow') {
      if (value) {
        this.inflowRemoveFlowList.push(id);
      } else {
        this.inflowRemoveFlowList = this.inflowRemoveFlowList.filter((item) => item !== id);
      }
    } else {
      if (value) {
        this.outflowRemoveFlowList.push(id);
      } else {
        this.outflowRemoveFlowList = this.outflowRemoveFlowList.filter((item) => item !== id);
      }
    }
  }

  removeFlow() {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${this.inflowRemoveFlowList.length + this.outflowRemoveFlowList.length} ${
          this.inflowRemoveFlowList.length + this.outflowRemoveFlowList.length > 1
            ? this.storyblok?.flows
            : this.storyblok?.flow
        } ${this.storyblok.selected}`,
        message: this.E5storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        if (this.inflowRemoveFlowList.length) {
          this.http
            .callService(
              new Method(
                environment.services.removeFlow(this.unitId, 'INFLOW'),
                { productIds: this.inflowRemoveFlowList },
                'put'
              )
            )
            .subscribe((res) => {
              if (!this.outflowRemoveFlowList.length) {
                this.initData(true);
                this.close();
              }
            });
        }
        if (this.outflowRemoveFlowList.length) {
          this.http
            .callService(
              new Method(
                environment.services.removeFlow(this.unitId, 'OUTFLOW'),
                { productIds: this.outflowRemoveFlowList },
                'put'
              )
            )
            .subscribe((res) => {
              this.initData(true);
              this.close();
            });
        }
      }
    });
  }

  setSelectedFlow() {
    this.inflows?.results?.forEach((item) => {
      const isInRemoveList = this.inflowRemoveFlowList.some((removeItem) => removeItem === item.id);
      if (isInRemoveList) {
        item.selected = true;
      }
    });
    this.inflows?.results?.forEach((item) => {
      const isInRemoveList = this.outflowRemoveFlowList.some((removeItem) => removeItem === item.id);
      if (isInRemoveList) {
        item.selected = true;
      }
    });
  }

  close() {
    this.inflowRemoveFlowList = [];
    this.outflowRemoveFlowList = [];
    this.inflows.results.forEach((item) => {
      if (item.selected) {
        item.selected = false;
      }
    });
    this.outflows.results.forEach((item) => {
      if (item.selected) {
        item.selected = false;
      }
    });
  }

  ngOnDestroy() {
    $('#main-content').removeClass('lightGreenBG');
    this.routerEventsSubscription.unsubscribe();
  }

  sortChange(selectedOption: string, flow: string) {
    this.lastCreateMaterial = {};
    this.inflows = [];
    this.outflows = [];

    const sortOptions = {
      NAMEASCENDING: { sort: 'NAME', order: 'ASCENDING' },
      NAMEDESCENDING: { sort: 'NAME', order: 'DESCENDING' },
      WEIGHTASCENDING: { sort: 'WEIGHT', order: 'ASCENDING' },
      WEIGHTDESCENDING: { sort: 'WEIGHT', order: 'DESCENDING' },
      UPDATEDESCENDING: { sort: 'UPDATE', order: 'DESCENDING' },
      UPDATEASCENDING: { sort: 'UPDATE', order: 'ASCENDING' },
      CREATIONASCENDING: { sort: 'CREATION', order: 'ASCENDING' },
      CREATIONDESCENDING: { sort: 'CREATION', order: 'DESCENDING' },
    };

    const pageInfo = flow === 'INFLOW' ? this.pageInfoInflow : this.pageInfoOutflow;
    const { sort, order } = sortOptions[selectedOption] || sortOptions.CREATIONDESCENDING;

    pageInfo.sort = sort;
    pageInfo.order = order;

    if (flow === 'INFLOW') {
      this.getInflows(this.unitId, 'INFLOW', 1, pageInfo.pageSize, sort, order);
    } else {
      this.getOutflows(this.unitId, 'OUTFLOW', 1, pageInfo.pageSize, sort, order);
    }
  }

  selectEvent(item: any, category?: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.showModal = true;
    switch (item) {
      case 'INFLOW':
        this.showAddFlow = true;
        this.commonService.addmaterialType = 'INFLOW';
        break;
      case 'OUTFLOW':
        this.showAddFlow = true;
        this.commonService.addmaterialType = 'OUTFLOW';
        break;
      default:
        return;
        break;
    }
  }

  public hideModal() {
    this.showModal = false;
    this.showCriticalMaterial = false;
    this.showAddFlow = false;
    this.showFileUpload = false;
    this.lastCreateMaterial = this.commonService.lastCreateMaterial;
    this.initData();
  }
  goBack() {
    if (this.isEditable) {
      this.router.navigate(['/e5']);
    } else {
      this.router.navigate(['/e5/' + this.selectedAssessmentData.reportId + '/e5-report']);
    }
  }
  async ngOnInit() {
    $('#main-content').addClass('lightGreenBG');
    await this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'step3')[0].content;
      this.proStoryblok = data.filter((item) => item.slug === 'pro-dashboard')[0].content;
      this.E5storyblok = data.filter((item) => item.slug === 'material-page')[0].content;
    });
    await this.route.queryParams.subscribe((params) => {
      this.selectedAssessmentData = params;
    });
    if (!this.isEditable) {
      this.snackBar.open(this.storyblok.noneditable_message, '', {
        duration: 8000,
        panelClass: ['info-snackBar'],
      });
    }
    await this.initData();
  }

  public initData(dontOpen?: boolean) {
    if (this.unitId) {
      this.getInflows(
        this.unitId,
        'INFLOW',
        this.pageInfoInflow.pageIndex + 1,
        this.pageInfoInflow.pageSize,
        this.pageInfoInflow.sort,
        this.pageInfoInflow.order,
        dontOpen ? dontOpen : false
      );
      this.getOutflows(
        this.unitId,
        'OUTFLOW',
        this.pageInfoOutflow.pageIndex + 1,
        this.pageInfoOutflow.pageSize,
        this.pageInfoOutflow.sort,
        this.pageInfoOutflow.order,
        dontOpen ? dontOpen : false
      );
    }
  }
  pageEventInflow(pageInfo: any) {
    this.pageInfoInflow.pageIndex = pageInfo.pageIndex;
    this.pageInfoInflow.pageSize = pageInfo.pageSize;
    this.getInflows(
      this.unitId,
      'INFLOW',
      pageInfo.pageIndex + 1,
      pageInfo.pageSize,
      this.pageInfoInflow.sort,
      this.pageInfoInflow.order
    );
  }
  getInflows(
    unitId: string,
    type: string,
    page: number,
    size: number,
    order: string,
    sort: string,
    dontOpen?: boolean
  ) {
    this.loaderShow = true;
    if (this.isEditable) {
      this.http
        .callService(
          new Method(environment.services.inflowsandOutflofList(unitId, type, page, size, order, sort), '', 'get')
        )
        .subscribe((res) => {
          this.inflows = res;
          this.inflows.results.forEach((element) => {
            if (!Array.isArray(element.listOfTypes)) {
              element.listOfTypes = [];
            }
            if (!element.listOfTypes.includes(element.type)) {
              if (element.type === 'product' || element.type === 'packaging') {
                element.listOfTypes.push({ class: element.type, name: element.type });
              }
              if (element.priority) {
                element.listOfTypes.push({ class: 'priority', name: this.storyblok?.focus_flow_label });
              }
              if (element.critical) {
                element.listOfTypes.push({ class: 'critical', name: this.storyblok?.critical_label });
              }
              if (element.draft) {
                element.listOfTypes.push({ class: 'draft', name: this.storyblok?.darft_label });
              }
              if (element.waste) {
                element.listOfTypes.push({ class: 'waste', name: this.storyblok?.waste });
              }
            }
          });

          this.inflowResults = this.inflows.results;
          this.inflowResults.forEach((element) => {
            element.class = element.type;
            if (element.id === this.lastCreateMaterial['id']) {
              if (dontOpen !== true) {
                this.showDetail(element, 'INFLOW');
              }
            }
          });
          this.setSelectedFlow();
          this.loaderShow = false;
        });
    } else {
      this.http
        .callService(
          new Method(
            environment.services.esrsInflowsandOutflofList(
              this.selectedAssessmentData.reportId,
              unitId,
              type,
              page,
              size,
              order,
              sort
            ),
            '',
            'get'
          )
        )
        .subscribe((res) => {
          this.inflows = res;
          this.inflowResults = this.inflows.results;
          this.inflowResults.forEach((element) => {
            element.class = element.type;
            if (element.id === this.lastCreateMaterial['id']) {
              if (dontOpen !== true) {
                this.showDetail(element, 'INFLOW');
              }
            }
          });
          this.setSelectedFlow();
          this.loaderShow = false;
        });
    }
  }
  pageEventOutflow(pageInfo: any) {
    this.pageInfoOutflow.pageIndex = pageInfo.pageIndex;
    this.pageInfoOutflow.pageSize = pageInfo.pageSize;
    this.getOutflows(
      this.unitId,
      'OUTFLOW',
      pageInfo.pageIndex + 1,
      pageInfo.pageSize,
      this.pageInfoOutflow.sort,
      this.pageInfoOutflow.order
    );
  }
  getOutflows(
    unitId: string,
    type: string,
    page: number,
    size: number,
    order: string,
    sort: string,
    dontOpen?: boolean
  ) {
    this.loaderShow = true;
    if (this.isEditable) {
      this.http
        .callService(
          new Method(environment.services.inflowsandOutflofList(unitId, type, page, size, order, sort), '', 'get')
        )
        .subscribe((res) => {
          this.outflows = res;
          this.outflowResults = this.outflows.results;
          this.outflowResults.forEach((element) => {
            if (!Array.isArray(element.listOfTypes)) {
              element.listOfTypes = [];
            }
            if (!element.listOfTypes.includes(element.type)) {
              if (element.type === 'product' || element.type === 'packaging') {
                element.listOfTypes.push({ class: element.type, name: element.type });
              }
              if (element.priority) {
                element.listOfTypes.push({ class: 'priority', name: this.storyblok?.focus_flow_label });
              }
              if (element.critical) {
                element.listOfTypes.push({ class: 'critical', name: this.storyblok?.critical_label });
              }
              if (element.draft) {
                element.listOfTypes.push({ class: 'draft', name: this.storyblok?.darft_label });
              }
              if (element.waste) {
                element.listOfTypes.push({ class: 'waste', name: this.storyblok?.waste });
              }
            }
            if (element.id === this.lastCreateMaterial['id']) {
              if (dontOpen !== true) {
                this.showDetail(element, 'OUTFLOW');
              }
            }
          });
          this.setSelectedFlow();
          this.loaderShow = false;
        });
    } else {
      this.http
        .callService(
          new Method(
            environment.services.esrsInflowsandOutflofList(
              this.selectedAssessmentData.reportId,
              unitId,
              type,
              page,
              size,
              order,
              sort
            ),
            '',
            'get'
          )
        )
        .subscribe((res) => {
          this.outflows = res;
          this.outflowResults = this.outflows.results;
          this.outflowResults.forEach((element) => {
            element.class = element.type;
            if (element.id === this.lastCreateMaterial['id']) {
              if (dontOpen !== true) {
                this.showDetail(element, 'OUTFLOW');
              }
            }
          });
          this.setSelectedFlow();
          this.loaderShow = false;
        });
    }
  }

  getNameInitials(fullName: string) {
    const a = fullName.split(' ').slice(0, -1).join(' ').charAt(0).toUpperCase();
    const b = fullName.split(' ').slice(-1).join(' ').charAt(0).toUpperCase();
    return a + b;
  }

  showDetail(material: any, type: string) {
    this.blockNavigation = this.dirtyData;
    if (!this.blockNavigation) {
      this.materiaNavShow = false;
      this.selectedMaterial = material;
      this.selectedMaterial['type'] = type;
      this.commonService.materialType = type;
      this.myOutput.emit(material.id);
      this.activePageDetail = true;
    }
  }
  showBoxResponse(value: boolean) {
    this.dirtyData = value;
  }
  closeDetail() {
    this.blockNavigation = this.dirtyData;
    if (!this.blockNavigation) {
      this.activePageDetail = false;
    }
  }
}
