import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
@Component({
  selector: 'app-manage-hazardous',
  templateUrl: './manage-hazardous.component.html',
  styleUrls: ['./manage-hazardous.component.scss'],
  animations: [
    trigger('smoothFade', [
      state(
        'void',
        style({
          opacity: 0,
        })
      ),
      transition(':enter', [animate('800ms ease-in', style({ opacity: 1 }))]),
      transition(':leave', [animate('800ms ease-out', style({ opacity: 0 }))]),
    ]),
  ],
  standalone: false,
})
export class ManageHazardousComponent {
  storyblok;
  showElement = false;
  environment = environment;
  hazardousData;

  constructor(
    public dialogRef: MatDialogRef<ManageHazardousComponent>,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    @Inject(MAT_DIALOG_DATA) public injectedData: any,
    private http: ApiRequestService
  ) {
    this.storyblok = this.injectedData.storyblok;

    this.http
      .callService(
        new Method(environment.services.getHazardous(), { assessmentList: injectedData.assessmentList }, 'put')
      )
      .subscribe((res) => {
        this.hazardousData = res['assessmentList'];
      });
  }

  onNoClick(): void {
    this.dialogRef.close(false);
  }

  setHazardous(flow: any) {
    const data = {
      flowList: [
        {
          flowId: flow.id,
          hazardous: flow.hazardous,
        },
      ],
    };
    this.http.callService(new Method(environment.services.setHazardous(), data, 'put')).subscribe((res) => {
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 1000,
        panelClass: ['success-snackBar'],
      });
    });
  }
}
