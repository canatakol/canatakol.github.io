import { Component, OnDestroy, OnInit } from '@angular/core';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { Sort } from '@angular/material/sort';
declare var $: any;
@Component({
  selector: 'app-e5-report',
  templateUrl: './e5-report.component.html',
  styleUrls: [
    '../../shared/dialog/e5-report/e5-report.component.scss',
    '../e5.component.scss',
    './e5-report.component.scss',
  ],
  standalone: false,
})
export class E5ReportComponent implements OnInit, OnDestroy {
  storyblok;
  isShow = false;
  showReportOptionsBox = false;
  selectedOption;
  count = 0;
  reportId = this.route.snapshot.params.reportId;
  E5storyblok;
  data = {};
  mounthList = environment.services.mounthList;
  startMounth;
  endMounth;
  yearList = Array.from({ length: 20 }, (v, i) => new Date().getFullYear() - 10 + i + 1);
  startYear;
  endYear;
  businessForm: FormGroup;
  environment = environment;
  ESRSReportDetailData;
  sortedData;
  constructor(
    private storyblokService: StoryblokService,
    private formBuilder: FormBuilder,
    private router: Router,
    private commonService: CommonService,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    public route: ActivatedRoute
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'pro-dashboard');
      this.storyblok = story[0].content;
      const e5story = data.filter((item) => item.slug === 'e5-dashboard');
      this.E5storyblok = e5story[0].content;
    });

    this.getESRSReportDetail();
  }
  ngOnInit(): void {
    $('#main-content').addClass('greenBG');
  }

  ngOnDestroy(): void {
    $('#main-content').removeClass('greenBG');
  }
  getESRSReportDetail() {
    this.http
      .callService(new Method(environment.services.getESRSReportDetail(this.reportId), '', 'get'))
      .subscribe((res) => {
        this.ESRSReportDetailData = res;
        this.createForm();
      });
  }
  sortData(event: Sort, data: any[]) {
    const { active, direction } = event;
    if (!direction) {
      // Varsayılan sıralama
      this.sortedData = data;
      return;
    }

    this.sortedData = data.sort((a, b) => {
      const isAsc = direction === 'asc';
      switch (active) {
        case 'name':
          return this.compare(a.name, b.name, isAsc);
        case 'materialCircularity':
          return this.compare(a.materialCircularity, b.materialCircularity, isAsc);
        case 'inflowMass':
          return this.compare(a.inflowMass, b.inflowMass, isAsc);
        case 'outflowMass':
          return this.compare(a.outflowMass, b.outflowMass, isAsc);
        default:
          return 0;
      }
    });
  }

  compare(a: any, b: any, isAsc: boolean): number {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  updateReport(report: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const data = {
      name: report.name,
      startDate: `01/${report.startMounth}/${report.startYear}`,
      endDate: `28/${report.endMounth}/${report.endYear}`,
    };
    this.http
      .callService(new Method(environment.services.updateReport(this.reportId), data, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        this.count = 7;
      });
  }

  private dateRangeValidator(startMonthKey: string, startYearKey: string, endMonthKey: string, endYearKey: string) {
    return (formGroup: FormGroup) => {
      const startMonth = formGroup.controls[startMonthKey].value;
      const startYear = formGroup.controls[startYearKey].value;
      const endMonth = formGroup.controls[endMonthKey].value;
      const endYear = formGroup.controls[endYearKey].value;
      this.count++;
      if (startYear && endYear && startMonth && endMonth) {
        const startDate = new Date(startYear, startMonth - 1);
        const endDate = new Date(endYear, endMonth - 1);

        if (startDate > endDate) {
          formGroup.controls[endMonthKey].setErrors({ dateRangeInvalid: true });
          formGroup.controls[endYearKey].setErrors({ dateRangeInvalid: true });
        } else if (startDate.getTime() === endDate.getTime()) {
          // Eğer tarihler aynıysa
          formGroup.controls[endMonthKey].setErrors({ sameDateInvalid: true });
          formGroup.controls[endYearKey].setErrors({ sameDateInvalid: true });
        } else {
          formGroup.controls[endMonthKey].setErrors(null);
          formGroup.controls[endYearKey].setErrors(null);
        }
      }
    };
  }

  discardReport() {
    this.createForm();
    this.count = 6;
  }

  private createForm() {
    this.businessForm = this.formBuilder.group(
      {
        name: [this.ESRSReportDetailData.name, Validators.required],
        startMounth: [
          this.ESRSReportDetailData.startDate.length === 7
            ? this.ESRSReportDetailData.startDate.split('/')[0]
            : this.ESRSReportDetailData.startDate.split('/')[1],
          Validators.required,
        ],
        startYear: [this.ESRSReportDetailData.startDate.split('/').pop(), Validators.required],
        endMounth: [
          this.ESRSReportDetailData.endDate.length === 7
            ? this.ESRSReportDetailData.endDate.split('/')[0]
            : this.ESRSReportDetailData.endDate.split('/')[1],
          Validators.required,
        ],
        endYear: [this.ESRSReportDetailData.endDate.split('/').pop(), Validators.required],
      },
      {
        validator: this.dateRangeValidator('startMounth', 'startYear', 'endMounth', 'endYear'),
      }
    );
    this.isShow = true;
  }

  gotoReport(selectedOption: string) {
    window.open(`/e5/${this.reportId}/report?unit=${selectedOption ? selectedOption : 'kg'}`, '_blank');
  }

  gotoAssessment(assessment: any) {
    this.router.navigate([`e5/${assessment.uuid}/e5-materials/false`], {
      queryParams: {
        name: assessment.name,
        inflowMass: assessment.inflowMass,
        outflowMass: assessment.outflowMass,
        reportId: this.reportId,
      },
    });

    // this.router.navigate([`e5/b905334c-070c-4056-a75a-cb29cd07beb9/e5-materials/false`]);
  }
  goToBack() {
    // this.router
    //   .navigate(['/e5'], {
    //     queryParams: {
    //       labelIds: ['55a8000e-00f8-479b-a3b2-5c60b15be5aa', '41f9937a-43a6-4844-a4bf-f3fbb5de5567'],
    //       selectAssetList: [
    //         'a381222b-610f-4154-bea7-38ec4238f806',
    //         '8a0b4f82-bfb2-4d52-be93-37b562c78898',
    //         'a2d91325-f0ce-4ee7-9c73-2907a8f5105b',
    //       ],
    //     },
    //   })
    //   .then(() => {
    //     window.location.reload();
    //   });
    this.router.navigate(['/e5']);
  }
}
