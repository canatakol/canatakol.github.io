import { AfterViewInit, Component, EventEmitter, Input, Output } from '@angular/core';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { of as observableOf } from 'rxjs';
import { FlatTreeControl } from '@angular/cdk/tree';
import { AddLabelDialog } from '@app/shared/dialog/add-label/add-label.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UpdateNameDialog } from '@app/shared/dialog/update-name/update-name-dialog.component';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-E5label-base',
  templateUrl: './label-base.component.html',
  styleUrls: ['./label-base.component.scss'],
  standalone: false,
})
export class E5LabelBaseComponent implements AfterViewInit {
  @Output() setRelatedLabelData = new EventEmitter<any>();
  @Output() snapShotEvent = new EventEmitter<any>();
  @Output() addLabelEvent = new EventEmitter<any>();
  @Output() navigationMode = new EventEmitter<any>();
  @Input() public storyblok: any;
  @Input() public E5storyblok: any;
  @Input() public totalAssessments: any;
  @Input() public searchKeyword: string = '';

  environment = environment;
  labelData;
  labelIds: string[] = [];
  deselectedItems = [];
  selectedLabelId: string;
  selectedNodes;
  isLoading = false;
  noLabelSelected = false;
  allLabelSelected = false;
  snapshotsSelected = false;
  ESRSReportData: any[] = [];
  treeControl: FlatTreeControl<any>;
  treeFlattener: MatTreeFlattener<any, any>;
  dataSource: MatTreeFlatDataSource<any, any>;
  project = window.location.href.split('/')[3] === 'cti' ? 'cti' : 'ciq';
  labelViewQuikTipsShowLeftSide = localStorage.getItem('labelViewQuikTipsShowLeftSide') === 'false' ? false : true;
  keyword: string = '';

  constructor(
    private apiService: ApiRequestService,
    private dialog: MatDialog,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private activatedRoute: ActivatedRoute,
    public router: Router
  ) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<any>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    this.fetchLabels();
    this.getESRSReport();
    this.commonService.addLabel.subscribe((res) => {
      this.addLabel(res);
    });
  }

  quikTipsClose() {
    this.labelViewQuikTipsShowLeftSide = false;
    localStorage.setItem('labelViewQuikTipsShowLeftSide', JSON.stringify(this.labelViewQuikTipsShowLeftSide));
  }

  getESRSReport() {
    this.apiService.callService(new Method(environment.services.getESRSReport(), '', 'get')).subscribe((res: any[]) => {
      this.ESRSReportData = res;
    });
  }
  openGuidanceEventQickTips() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'label', slug: 'slug' });
  }

  parseContent(): string {
    return this.E5storyblok?.label_description.content
      .map((para) => para.content.map((item) => (item.marks ? `<b>${item.text}</b>` : item.text)).join(''))
      .join('<br>');
  }

  goToReport(reportId: string) {
    this.router.navigate([`e5/${reportId}/e5-report`]);
  }

  fetchLabels() {
    this.apiService.callService(new Method(environment.services.label(), '', 'get')).subscribe((res) => {
      this.labelData = res;
      this.dataSource.data = this.labelData;
      if (this.labelData) {
        this.activatedRoute.queryParams.subscribe((params) => {
          this.handleLabelSelection(params.labelIds);
        });
      }
    });
  }

  handleLabelSelection(labelIds) {
    if (typeof labelIds === 'string') {
      this.selectLabel(labelIds, true, true);
    } else {
      this.labelIds = Array.isArray(labelIds) ? labelIds : [labelIds];
      this.labelIds.forEach((labelId, index) => {
        this.selectLabel(labelId, true, index === this.labelIds.length);
      });
    }
  }

  getAssessmentaccordingToLabel() {
    this.commonService.isLoadingLabelSmall.next(true);

    if (
      this.keyword &&
      this.keyword.length > 0 &&
      this.keyword.length < 3 &&
      this.labelIds.length === 0 &&
      !this.noLabelSelected
    ) {
      this.setRelatedLabelData.emit(null);
      this.commonService.isLoadingLabelSmall.next(false);
      return;
    }

    this.isLoading = false;
    const data = {
      labelIds: this.labelIds,
      keyword: this.keyword,
      noLabel: this.noLabelSelected,
    };
    this.apiService
      .callService(new Method(environment.services.getAssessmentaccordingToLabel(), data, 'put'))
      .subscribe((res) => {
        this.setRelatedLabelData.emit(res);
        this.commonService.isLoadingLabelSmall.next(false);
      });
    this.isLoading = false;
  }

  articleSelect() {
    alert('Archive coming soon');
  }

  handleNavigationMode(id: string) {
    this.selectedLabelId = id;
    this.navigationMode.emit(true);
    this.fetchRelatedLabelData(id);
    this.clearSelection();
  }
  navigationModeEvent(id: string) {
    this.selectedLabelId = id;
    this.commonService.isLoadingLabelSmall.next(true);
    this.navigationMode.emit(true);
    const data = {
      labelIds: [id],
      keyword: this.keyword,
      noLabel: this.noLabelSelected,
    };
    this.apiService
      .callService(new Method(environment.services.getAssessmentaccordingToLabel(), data, 'put'))
      .subscribe((res) => {
        this.setRelatedLabelData.emit(res);
        this.commonService.isLoadingLabelSmall.next(false);
      });
    this.treeControl.dataNodes.forEach((item) => {
      item.selected = false;
    });
  }

  setNoLabelSelected(value: boolean) {
    this.noLabelSelected = value;
    this.allLabelSelected = false;
    this.navigationMode.emit(false);
    this.selectedLabelId = null;
    this.clearSelection();
    this.labelIds = [];
    localStorage.setItem('dashboardSelectedLabelIds', JSON.stringify(this.labelIds));
    localStorage.setItem('noLabelSelected', JSON.stringify(value));
    this.getAssessmentaccordingToLabel();
  }
  setAllLabelSelected(value: boolean) {
    this.allLabelSelected = value;
    this.noLabelSelected = false;
  }
  setSnapshotsSelected(value: boolean) {
    this.snapShotEvent.emit(value);
    this.snapshotsSelected = value;
    localStorage.setItem('snapshotsSelected', JSON.stringify(value));
  }

  setKeyword(keyword: string) {
    this.keyword = keyword;
  }

  searchAssessments() {
    this.getAssessmentaccordingToLabel();
  }

  selectLabel(id: string, isSelected: boolean, fetchAssessment: boolean) {
    this.navigationMode.emit(false);
    this.selectedLabelId = null;
    this.noLabelSelected = false;
    this.updateSelection(id, isSelected);
    if (fetchAssessment) {
      this.getAssessmentaccordingToLabel();
    }
  }

  updateSelection(id: string, isSelected: boolean) {
    this.labelIds = [];
    this.treeControl.dataNodes.forEach((item) => {
      if (item.id === id && isSelected) {
        item.selected = true;
      }
      if (item.id === id && !isSelected) {
        item.selected = false;
      }
      if (item.selected) {
        this.labelIds.push(item.id);
        if (item.parentId) {
          const parentNode = this.treeControl.dataNodes.find((parent) => parent.id === item.parentId);
          if (parentNode) {
            parentNode.expandable = true;
            this.treeControl.expand(parentNode);
          }
        }
      }
    });
    localStorage.setItem('dashboardSelectedLabelIds', JSON.stringify(this.labelIds));
  }
  ngAfterViewInit() {
    const storedLabelIds = JSON.parse(localStorage.getItem('dashboardSelectedLabelIds'));
    if (storedLabelIds && Array.isArray(storedLabelIds) && storedLabelIds.length > 0) {
      const interval = setInterval(() => {
        if (this.treeControl?.dataNodes?.length) {
          clearInterval(interval);
          storedLabelIds.forEach((item, index) => {
            const isLast = index === storedLabelIds.length - 1;
            this.selectLabel(item, true, isLast);
          });
        }
      }, 100);
    }
    setTimeout(() => {
      const noLabelSelected = JSON.parse(localStorage.getItem('noLabelSelected'));
      if (noLabelSelected === true) {
        this.setNoLabelSelected(true);
      }
    }, 1000);

    setTimeout(() => {
      const snapshotsSelected = JSON.parse(localStorage.getItem('snapshotsSelected'));
      if (snapshotsSelected === true) {
        this.setSnapshotsSelected(true);
      }
    }, 500);
  }

  fetchRelatedLabelData(id: string) {
    const data = {
      labelIds: [id],
      keyword: this.keyword,
      noLabel: this.noLabelSelected,
    };
    this.apiService
      .callService(new Method(environment.services.getAssessmentaccordingToLabel(), data, 'put'))
      .subscribe((res) => this.setRelatedLabelData.emit(res));
  }

  clearSelection() {
    this.treeControl?.dataNodes?.forEach((item) => (item.selected = false));
  }

  addLabel(text: string) {
    if (text === undefined) {
      return;
    }
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(AddLabelDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: { storyblok: this.storyblok, labelData: this.labelData, text: text },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.fetchLabels();
        this.addLabelEvent.emit(true);
      } catch (error) {}
    });
  }

  settingsReport(report: any, isOpen: boolean) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    if (isOpen) {
      report.isSettingsVisible = false;
    } else {
      this.clearAllSettingsVisibility();
      report.isSettingsVisible = true;
    }
  }
  settingsLabel(node: any, isOpen: boolean) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    if (isOpen) {
      node.isSettingsVisible = false;
    } else {
      this.clearAllSettingsVisibility();
      node.isSettingsVisible = true;
    }
  }

  clearAllSettingsVisibility() {
    this.treeControl.dataNodes.forEach((item) => (item.isSettingsVisible = false));
  }

  updateLabel(node: any) {
    const dialogRef = this.dialog.open(UpdateNameDialog, {
      width: '80%',
      maxWidth: '500px',
      panelClass: 'centered-dialog',
      data: {
        title: node.name,
        message: this.storyblok.updat_label_name_modal_text,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.apiService
          .callService(new Method(environment.services.labelaction(node.id), { name: result }, 'put'))
          .subscribe(() => {
            this.showSnackBar(this.commonService.storyblok?.success_message, 'success-snackBar');
            this.fetchLabels();
          });
      }
    });
  }

  deleteReport(report: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: report.name,
        message: this.storyblok.delete_label_modal_text,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.apiService
          .callService(new Method(environment.services.deleteReport(report.uuid), '', 'delete'))
          .subscribe(() => {
            this.showSnackBar(this.commonService.storyblok?.success_message, 'success-snackBar');
            this.getESRSReport();
          });
      }
    });
  }

  deleteLabel(node: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: node.name,
        message: this.storyblok.delete_label_modal_text,
      },
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.apiService
          .callService(new Method(environment.services.labelaction(node.id), '', 'delete'))
          .subscribe(() => {
            this.showSnackBar(this.commonService.storyblok?.success_message, 'success-snackBar');
            this.fetchLabels();
          });
      }
    });
  }

  showSnackBar(message: string, panelClass: string) {
    this.snackBar.open(message, '', {
      duration: 5000,
      panelClass: [panelClass],
    });
  }

  transformer(node: any, level: number) {
    return {
      name: node.name,
      id: node.id,
      parentId: node.parentId,
      selected: node.selected,
      level: level,
      expandable: !!node.children,
    };
  }

  getLevel(node: any) {
    return node.level;
  }

  isExpandable(node: any) {
    return node.expandable;
  }

  getChildren(node: any) {
    return observableOf(node.children);
  }

  hasChild(index: number, node: any) {
    return node.expandable;
  }
}
