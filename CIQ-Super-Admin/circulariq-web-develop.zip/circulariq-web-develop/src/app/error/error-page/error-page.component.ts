import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { filter } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { environment } from '@env/environment';
import { AuthenticationService } from '@app/core/authentication/authentication.service';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.scss'],
  standalone: false,
})
export class ErrorPageComponent implements OnInit, OnDestroy {
  count = 6;
  isPro = false;
  interval;
  storyblok;
  credentials;
  routerSubscription: Subscription;
  project = environment.project;
  constructor(
    private router: Router,
    private storyblokService: StoryblokService,
    private authenticationService: AuthenticationService
  ) {
    this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (this.credentials && this.credentials['organisation'] && this.credentials['organisation'].features) {
      this.credentials['organisation'].features.forEach((element) => {
        if (element === 'unlimited_unit') {
          this.isPro = true;
        }
      });
    }

    this.routerSubscription = this.router.events
      .pipe(filter((event: any) => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        if (this.router.url === '/error-page') {
          console.error('wrong url : ', event.url);
        }
      });
  }

  ngOnInit(): void {
    this.startCountdown();
    this.loadStoryblokContent();
  }

  ngOnDestroy(): void {
    if (this.interval) {
      clearInterval(this.interval);
    }
    if (this.routerSubscription) {
      this.routerSubscription.unsubscribe();
    }
  }

  startCountdown(): void {
    this.interval = setInterval(() => {
      this.count--;
      if (this.count === 0) {
        clearInterval(this.interval);
        this.gotoDashboard();
      }
    }, 1000);
  }

  loadStoryblokContent(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'error-page');
      this.storyblok = story[0]?.content;
    });
  }

  gotoDashboard(): void {
    if (!this.credentials) {
      this.router.navigate(['/login']);
    } else {
      if (this.project === 'CTI') {
        if (this.isPro) {
          const credentials = JSON.parse(sessionStorage.getItem('credentials'));
          if (credentials && credentials['showBLDashboard']) {
            this.router.navigate(['/cti/pro-business']).then(() => {
              location.reload();
            });
          } else {
            this.router.navigate(['/cti/pro-label']).then(() => {
              location.reload();
            });
          }
        } else {
          this.router.navigate(['/cti/none/assessment/step1'], { replaceUrl: true });
        }
      } else if (this.project === 'CIQ') {
        if (this.credentials?.organisation?.features?.includes('e5')) {
          window.location.assign('/e5');
        } else {
          this.authenticationService.logout();
          window.location.assign('/login');
        }
      }

      setTimeout(() => {
        location.reload();
      }, 2000);
    }
  }
}
