import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { environment } from '@env/environment';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';

@Component({
  selector: 'app-most-linear-inflow',
  templateUrl: './most-linear-inflow.component.html',
  styleUrls: ['./most-linear-inflow.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe, TruncatePipe, CommentBadgeComponent],
})
export class MostLinearInflowComponent implements OnInit {
  @Input() public report: boolean;
  @Input() public data: boolean;
  storyblok;
  environment = environment;
  selectedItemData;
  detailshow = false;
  dashboardPage = false;
  constructor(private storyblokService: StoryblokService) {}

  close() {
    this.detailshow = false;
  }

  getDetail(item: any) {
    this.selectedItemData = item;
    this.detailshow = true;
  }

  ngOnInit(): void {
    console.log('data', this.data);
    this.dashboardPage = window.location.href.includes('dashboard');
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'aggregate');
      this.storyblok = story.length > 0 ? story[0].content : {};
    });
  }
}
