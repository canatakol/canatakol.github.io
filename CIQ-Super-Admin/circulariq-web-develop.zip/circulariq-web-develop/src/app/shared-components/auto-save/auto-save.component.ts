import { Component, EventEmitter, Input, OnChanges, Output } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-auto-save',
  templateUrl: './auto-save.component.html',
  styleUrls: ['./auto-save.component.scss'],
  standalone: false,
})
export class AutoSaveComponent implements OnChanges {
  @Input() public blockNavigation: boolean;
  @Input() public dirtyData: boolean;
  @Input() public saveAndNext: boolean;
  @Output() showBoxResponse: EventEmitter<any> = new EventEmitter();
  storyblok;
  constructor(private storyblokService: StoryblokService, private commonService: CommonService) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'auto-save-box');
      this.storyblok = story[0].content;
    });
  }

  ngOnChanges(): void {
    this.blockNavigation = this.blockNavigation;
    this.dirtyData = this.dirtyData;
    this.saveAndNext = this.saveAndNext;
  }
  saveBoxResponse(value: boolean) {
    if (value) {
      if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
        return;
      }
    }
    this.showBoxResponse.emit(value);
  }
}
