import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  HostListener,
  ElementRef,
  ViewChild,
  AfterViewChecked,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { forkJoin } from 'rxjs';
import { MentionsDropdownComponent, User } from './mentions-dropdown.component';
import { CommentData, CommentMention, CommentService } from '@app/core/services/comment.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

export interface Comment {
  id: string;
  dashboardId: string;
  dashboardName: string;
  subLevel: string;
  section: string;
  text: string;
  authorId: string;
  authorName: string;
  creationDate: string;
  lastModifiedDate: string;
  isRead: boolean;
  mentions: {
    userId: string;
    username: string;
    startIndex: number;
    endIndex: number;
  }[];
}

@Component({
  selector: 'app-comment-badge',
  templateUrl: './comment-badge.component.html',
  styleUrls: ['./comment-badge.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, MentionsDropdownComponent],
})
export class CommentBadgeComponent implements OnInit, AfterViewChecked {
  @Input() showAddButton: boolean = true;
  @Input() position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' = 'top-right';
  @Input() size: 'small' | 'medium' | 'large' = 'medium';
  @Input() breadcrumb: string = '';
  @Input() dashboardName: string = '';
  @Input() componentName: string = '';
  @Input() componentNameForBreadcrumb: string = '';
  @Input() mentions: string[] = [];
  @Input() componentId: string = '';
  dashboardId: string = '';
  tabName: string = '';
  tabNameLower: string = '';
  componentNameLower: string = '';
  private originalComponentName: string = '';
  @Output() commentAdded = new EventEmitter<{ componentId: string; comment: Comment }>();
  @Output() commentViewed = new EventEmitter<{ componentId: string; comments: Comment[] }>();

  @ViewChild(MentionsDropdownComponent) mentionsDropdown!: MentionsDropdownComponent;
  @ViewChild('commentList', { static: false }) commentList!: ElementRef;

  comments: Comment[] = [];
  showCommentModal: boolean = false;
  modalData = {
    breadcrumb: '',
    mentions: [],
    initialText: '',
  };

  private shouldScrollToBottom = false;

  showMentionsDropdown: boolean = false;
  mentionsSearchTerm: string = '';
  mentionsPosition: { x: number; y: number } = { x: 0, y: 0 };
  currentMentionStart: number = -1;

  isDragging: boolean = false;
  popupPosition = { x: 0, y: 0 };
  dragOffset = { x: 0, y: 0 };

  storyblok: any;
  constructor(
    private snackBar: MatSnackBar,
    private elementRef: ElementRef,
    private http: ApiRequestService,
    private route: ActivatedRoute,
    private commentService: CommentService,
    private storyblokService: StoryblokService
  ) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'dashboard')[0].content;
    });
    this.modalData.mentions = this.mentions;
    this.dashboardId = this.route.snapshot.params['dashboardId'];
    this.tabName = this.route.snapshot.params['tab']?.toUpperCase();
    this.tabNameLower = this.route.snapshot.params['tab'];

    // Store the original componentName before setting default
    this.originalComponentName = this.componentName;

    // Set default componentName to 'SUSTAINABILITY' if not provided
    if (!this.componentName) {
      this.componentName = 'SUSTAINABILITY';
    }
    this.componentNameLower = this.componentName.toLowerCase();

    // Load comments from backend instead of localStorage
    this.loadCommentsFromBackend();
  }

  ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom && this.commentList && this.commentList.nativeElement) {
      // Use requestAnimationFrame to ensure DOM is fully updated
      requestAnimationFrame(() => {
        this.scrollToBottom();
        this.shouldScrollToBottom = false;
      });
    }
  }

  get commentCount(): number {
    return this.comments ? this.comments.length : 0;
  }

  get unreadCount(): number {
    return this.comments ? this.comments.filter((comment) => !comment.isRead).length : 0;
  }

  get hasComments(): boolean {
    return this.commentCount > 0;
  }

  get isDashboardLevel(): boolean {
    return !this.originalComponentName;
  }

  get hasDashboardId(): boolean {
    return !!this.dashboardId;
  }

  onAddComment(): void {
    this.showCommentModal = true;
    this.modalData = {
      initialText: '',
      breadcrumb: this.getCurrentBreadcrumb(),
      mentions: this.mentions,
    };

    // Position popup after it's rendered
    setTimeout(() => {
      this.positionPopupBelowButton();
    }, 0);
  }

  onViewComments(): void {
    this.showCommentModal = true;
    this.modalData = {
      initialText: '',
      breadcrumb: this.getCurrentBreadcrumb(),
      mentions: this.mentions,
    };

    // Mark unread comments as read when viewing
    this.markUnreadCommentsAsRead();

    // Position popup after it's rendered
    setTimeout(() => {
      this.positionPopupBelowButton();
      // Scroll to bottom when viewing comments
      if (this.comments.length > 0) {
        this.shouldScrollToBottom = true;
      }
    }, 100); // Increased timeout to ensure DOM is ready
  }

  onCommentSubmitted(commentText: string): void {
    if (commentText.trim()) {
      const mentions: CommentMention[] = this.extractMentions(commentText);

      const commentData: CommentData = {
        subLevel: this.tabName || 'DESIGN',
        section: this.componentName || 'INFLOW_BREAKDOWN',
        text: commentText,
        mentions: mentions,
      };

      // Post comment using the comment service
      if (this.dashboardId) {
        this.commentService.postComment(this.dashboardId, commentData).subscribe({
          next: (response) => {
            // After successful post, refresh comments from service
            this.commentService.refreshComments(this.dashboardId);

            // Also refresh header unread count to show new comment
            this.commentService.refreshHeaderUnreadCount();

            // Ensure scroll to bottom after new comment is added
            setTimeout(() => {
              this.shouldScrollToBottom = true;
            }, 100);

            this.snackBar.open('Comment added successfully!', '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          },
          error: (error) => {
            this.snackBar.open('Error posting comment. Please try again.', '', {
              duration: 5000,
              panelClass: ['error-snackBar'],
            });
          },
        });
      } else {
        this.snackBar.open('Error: No dashboard ID provided', '', {
          duration: 3000,
          panelClass: ['error-snackBar'],
        });
      }

      this.modalData.initialText = '';
      this.showCommentModal = false;
    }
  }

  onCloseModal(): void {
    this.showCommentModal = false;
    this.modalData.initialText = '';
    if (this.mentionsDropdown?.visible) {
      this.hideMentionsDropdown();
    }
  }

  private markUnreadCommentsAsRead(): void {
    const unreadComments = this.comments.filter((comment) => !comment.isRead);

    if (unreadComments.length > 0) {
      const markAsReadObservables = unreadComments.map((comment) => this.commentService.markCommentRead(comment.id));

      forkJoin(markAsReadObservables).subscribe({
        next: () => {
          this.commentService.refreshComments(this.dashboardId);
          this.commentService.refreshHeaderUnreadCount();
        },
        error: (error) => {
          console.error('Error marking comments as read:', error);
        },
      });
    }
  }

  getBadgeText(): string {
    if (this.unreadCount > 0) {
      return this.unreadCount.toString();
    }
    return this.commentCount.toString();
  }

  // Comment formatting methods
  formatCommentText(text: string): string {
    // Highlight mentions with @ symbol
    return text.replace(/@(\w+)/g, '<span class="mention-highlight">@$1</span>');
  }

  trackByPart(index: number, part: { type: 'text' | 'mention'; content: string }): string {
    return `${part.type}-${index}-${part.content}`;
  }

  trackByComment(index: number, comment: Comment): string {
    return comment.id;
  }

  getTimeAgo(timestamp: string): string {
    const now = new Date();
    const commentDate = new Date(timestamp);
    const diffInMs = now.getTime() - commentDate.getTime();
    const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));
    const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));

    if (diffInDays > 0) {
      return `${diffInDays}d`;
    } else if (diffInHours > 0) {
      return `${diffInHours}h`;
    } else if (diffInMinutes > 0) {
      return `${diffInMinutes}m`;
    } else {
      return 'now';
    }
  }

  getCurrentBreadcrumb(): string {
    // If breadcrumb is provided directly, use it
    if (this.breadcrumb) {
      return this.breadcrumb;
    }

    // Otherwise, build breadcrumb from individual parts
    const parts: string[] = [];

    if (this.dashboardName) {
      parts.push(this.dashboardName);
    }

    if (this.tabName) {
      parts.push(this.tabName);
    }

    // Use componentNameForBreadcrumb if provided, otherwise use componentName
    const componentNameToUse = this.componentNameForBreadcrumb || this.componentName;
    if (componentNameToUse) {
      parts.push(componentNameToUse);
    }

    // If no parts are provided, fall back to componentId
    if (parts.length === 0) {
      return this.componentId || 'Component';
    }

    return parts.join(' > ');
  }

  // Load comments from service
  private loadCommentsFromBackend(): void {
    if (!this.dashboardId) {
      console.warn('No dashboard ID available for loading comments');
      return;
    }

    this.commentService.getComments(this.dashboardId).subscribe({
      next: (serviceComments) => {
        if (serviceComments && Array.isArray(serviceComments)) {
          // Filter comments by current tab (subLevel) and component (section)
          const filteredComments = serviceComments.filter((comment) => {
            // Filter by tab (subLevel)
            const tabMatches = !this.tabName || comment.subLevel === this.tabName;

            // Filter by component (section) if componentName is provided
            const componentMatches = !this.componentName || comment.section === this.componentName;

            return tabMatches && componentMatches;
          });

          // Convert service comments to component comments format
          this.comments = filteredComments
            .map((comment) => ({
              id: comment.id,
              dashboardId: comment.dashboardId,
              dashboardName: comment.dashboardName,
              subLevel: comment.subLevel,
              section: comment.section,
              text: comment.text,
              authorId: comment.authorId,
              authorName: comment.authorName,
              creationDate: comment.creationDate,
              lastModifiedDate: comment.lastModifiedDate,
              isRead: comment.isRead,
              mentions: comment.mentions.map((mention) => ({
                userId: mention.userId,
                username: mention.fullname || mention.userId, // Use fullname if available, otherwise fallback to userId
                startIndex: mention.startIndex,
                endIndex: mention.endIndex,
              })),
            }))
            .sort((a, b) => {
              const dateA = new Date(a.creationDate);
              const dateB = new Date(b.creationDate);
              return dateA.getTime() - dateB.getTime();
            });
          this.shouldScrollToBottom = true;
        } else {
          this.comments = [];
        }
      },
      error: (error) => {
        console.error('Error loading comments:', error);
        this.comments = [];
        this.snackBar.open('Error loading comments. Please try again.', '', {
          duration: 3000,
          panelClass: ['error-snackBar'],
        });
      },
    });
  }

  // Popup positioning
  private positionPopupBelowButton(): void {
    const badgeElement = this.elementRef.nativeElement.querySelector('.comment-badge');
    if (!badgeElement) return;

    const rect = badgeElement.getBoundingClientRect();
    const popupElement = this.elementRef.nativeElement.querySelector('.comment-popup');

    if (!popupElement) return;

    const popupRect = popupElement.getBoundingClientRect();
    const popupWidth = popupRect.width;
    const popupHeight = popupRect.height;

    // Get viewport dimensions
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Calculate initial position (below button)
    let initialX = rect.left;
    let initialY = rect.bottom + 5;

    // Adjust X position if popup would go outside right edge
    if (initialX + popupWidth > viewportWidth) {
      initialX = viewportWidth - popupWidth - 100; // 100px margin from right edge
    }

    // Adjust X position if popup would go outside left edge
    if (initialX < 0) {
      initialX = 10; // 10px margin from left edge
    }

    // Adjust Y position if popup would go outside bottom edge
    if (initialY + popupHeight > viewportHeight) {
      initialY = rect.top - popupHeight - 5; // Position above button instead
    }

    // Ensure popup doesn't go above top edge
    if (initialY < 0) {
      initialY = 10; // 10px margin from top edge
    }

    this.popupPosition = {
      x: initialX,
      y: initialY,
    };

    console.log('Popup positioned at:', this.popupPosition);
  }

  // Drag & drop methods
  onPopupMouseDown(event: MouseEvent): void {
    if (event.target instanceof HTMLElement) {
      const target = event.target as HTMLElement;
      // Only allow dragging from the header
      if (target.closest('.popup-header')) {
        this.isDragging = true;
        this.dragOffset = {
          x: event.clientX - this.popupPosition.x,
          y: event.clientY - this.popupPosition.y,
        };
        event.preventDefault();
      }
    }
  }

  @HostListener('document:mousemove', ['$event'])
  onMouseMove(event: MouseEvent): void {
    if (!this.isDragging) return;

    const newX = event.clientX - this.dragOffset.x;
    const newY = event.clientY - this.dragOffset.y;

    // Get popup dimensions
    const popupElement = this.elementRef.nativeElement.querySelector('.comment-popup');
    if (!popupElement) return;

    const popupRect = popupElement.getBoundingClientRect();
    const popupWidth = popupRect.width;
    const popupHeight = popupRect.height;

    // Get viewport dimensions
    const viewportWidth = window.innerWidth;
    const viewportHeight = window.innerHeight;

    // Calculate boundaries
    const minX = 0;
    const maxX = viewportWidth - popupWidth - 100; // 100px margin from right edge
    const minY = 0;
    const maxY = viewportHeight - popupHeight;

    // Constrain position within viewport
    const constrainedX = Math.max(minX, Math.min(maxX, newX));
    const constrainedY = Math.max(minY, Math.min(maxY, newY));

    this.popupPosition = {
      x: constrainedX,
      y: constrainedY,
    };
  }

  @HostListener('document:mouseup')
  onMouseUp(): void {
    this.isDragging = false;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent): void {
    // Close popup when clicking outside
    if (this.showCommentModal && !this.elementRef.nativeElement.contains(event.target)) {
      // Check if click is on mentions dropdown (which might be outside the main element)
      const target = event.target as HTMLElement;
      const isMentionsDropdown = target.closest('.mentions-dropdown');

      if (!isMentionsDropdown) {
        this.onCloseModal();
      }
    }
  }

  // Mentions functionality methods

  onTextareaInput(event: Event): void {
    const textarea = event.target as HTMLTextAreaElement;
    const text = textarea.value;
    const cursorPosition = textarea.selectionStart;

    this.checkForMentions(text, cursorPosition, textarea);
  }

  onTextareaKeydown(event: KeyboardEvent): void {
    if (this.showMentionsDropdown) {
      // Let the dropdown handle arrow keys, enter, escape
      if (['ArrowUp', 'ArrowDown', 'Enter', 'Escape'].includes(event.key)) {
        return;
      }
    }

    // Handle Ctrl+Enter for sending
    if (event.ctrlKey && event.key === 'Enter') {
      event.preventDefault();
      this.onCommentSubmitted(this.modalData.initialText);
    }
  }

  private checkForMentions(text: string, cursorPosition: number, textarea: HTMLTextAreaElement): void {
    // Find the word being typed (from cursor position backwards)
    const beforeCursor = text.substring(0, cursorPosition);

    // Simple regex to match @ followed by any characters
    const mentionMatch = beforeCursor.match(/@([^@\s]*)$/);
    if (mentionMatch) {
      this.currentMentionStart = mentionMatch.index!;
      this.mentionsSearchTerm = mentionMatch[1];
      this.showMentionsDropdown = true;
      this.positionMentionsDropdown(textarea);
    } else {
      this.hideMentionsDropdown();
    }
  }

  private positionMentionsDropdown(textarea: HTMLTextAreaElement): void {
    // Simple positioning - just below the textarea
    const textareaRect = textarea.getBoundingClientRect();

    let x = textareaRect.left;
    let y = textareaRect.bottom + 5; // 5px below textarea

    // Ensure dropdown doesn't go outside viewport
    const dropdownWidth = 250; // Approximate width of dropdown
    const dropdownHeight = 200; // Approximate height

    if (x + dropdownWidth > window.innerWidth) {
      x = window.innerWidth - dropdownWidth - 10;
    }

    if (y + dropdownHeight > window.innerHeight) {
      y = textareaRect.top - dropdownHeight - 10;
    }

    if (x < 0) x = 10;
    if (y < 0) y = 10;

    this.mentionsPosition = { x, y };
  }

  onUserSelected(user: User): void {
    const text = this.modalData.initialText;
    const beforeMention = text.substring(0, this.currentMentionStart);
    const afterMention = text.substring(this.currentMentionStart + this.mentionsSearchTerm.length + 1); // +1 for @

    this.modalData.initialText = beforeMention + '@' + user.fullname + ' ' + afterMention;

    // Hide dropdown first
    this.hideMentionsDropdown();

    // Set cursor position after the mention and focus textarea
    setTimeout(() => {
      const textarea = this.elementRef.nativeElement.querySelector('.comment-textarea') as HTMLTextAreaElement;
      if (textarea) {
        const newPosition = beforeMention.length + user.fullname.length + 2; // +2 for @ and space
        textarea.setSelectionRange(newPosition, newPosition);
        textarea.focus();

        // Trigger input event to update any bindings
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
      }
    }, 10);
  }

  onMentionsDropdownClose(): void {
    this.hideMentionsDropdown();
  }

  onTextareaBlur(): void {
    // Delay hiding dropdown to allow for clicks on dropdown items
    // But don't hide if user is clicking on dropdown
    setTimeout(() => {
      const activeElement = document.activeElement;
      const isDropdownActive = activeElement?.closest('.mentions-dropdown');

      if (!isDropdownActive) {
        this.hideMentionsDropdown();
      }
    }, 200);
  }

  private hideMentionsDropdown(): void {
    this.showMentionsDropdown = false;
    this.mentionsSearchTerm = '';
    this.currentMentionStart = -1;
  }

  // Override the existing renderMessageWithMentions method to handle the new mentions structure
  renderMessageWithMentions(
    message: string,
    mentions: string[] = []
  ): Array<{ type: 'text' | 'mention'; content: string }> {
    const parts: Array<{ type: 'text' | 'mention'; content: string }> = [];
    const mentionRegex = /@([^@\s]+)/g;
    let lastIndex = 0;
    let match;

    while ((match = mentionRegex.exec(message)) !== null) {
      // Add text before mention
      if (match.index > lastIndex) {
        parts.push({
          type: 'text',
          content: message.substring(lastIndex, match.index),
        });
      }

      // Add mention
      parts.push({
        type: 'mention',
        content: match[1],
      });

      lastIndex = match.index + match[0].length;
    }

    // Add remaining text
    if (lastIndex < message.length) {
      parts.push({
        type: 'text',
        content: message.substring(lastIndex),
      });
    }

    return parts;
  }

  /**
   * Render message with mentions using backend mentions array with startIndex and endIndex
   * @param message - The comment text
   * @param mentions - Array of mentions from backend with startIndex and endIndex
   * @returns Array of text and mention parts
   */
  renderMessageWithBackendMentions(
    message: string,
    mentions: { userId: string; username: string; startIndex: number; endIndex: number }[] = []
  ): Array<{ type: 'text' | 'mention'; content: string; userId?: string }> {
    const parts: Array<{ type: 'text' | 'mention'; content: string; userId?: string }> = [];

    // Handle null or undefined mentions
    if (!mentions || mentions.length === 0) {
      // No mentions, return entire message as text
      parts.push({
        type: 'text',
        content: message,
      });
      return parts;
    }

    // Sort mentions by startIndex to process them in order
    const sortedMentions = [...mentions].sort((a, b) => a.startIndex - b.startIndex);
    let lastIndex = 0;

    sortedMentions.forEach((mention) => {
      // Add text before mention
      if (mention.startIndex > lastIndex) {
        parts.push({
          type: 'text',
          content: message.substring(lastIndex, mention.startIndex),
        });
      }

      // Add mention
      const mentionText = message.substring(mention.startIndex, mention.endIndex);
      parts.push({
        type: 'mention',
        content: mentionText,
        userId: mention.userId,
      });

      lastIndex = mention.endIndex;
    });

    // Add remaining text after last mention
    if (lastIndex < message.length) {
      parts.push({
        type: 'text',
        content: message.substring(lastIndex),
      });
    }

    return parts;
  }

  /**
   * Extract mentions from comment text and convert to CommentMention format
   * @param text - The comment text
   * @returns Array of CommentMention objects
   */
  private extractMentions(text: string): CommentMention[] {
    const mentions: CommentMention[] = [];
    const mentionRegex = /@([^@\s]+)/g; // Changed to capture everything after @ until space or @
    let match;

    while ((match = mentionRegex.exec(text)) !== null) {
      const username = match[1];
      const user = this.getUserFromUsername(username);

      // Only add mention if we found a valid user
      if (user) {
        const fullMentionText = '@' + user.fullname;
        const mention = {
          userId: user.id,
          startIndex: match.index,
          endIndex: match.index + fullMentionText.length,
        };
        mentions.push(mention);
      }
    }

    return mentions;
  }

  /**
   * Get user from username using userData from localStorage
   * @param username - The username
   * @returns The user object or null if not found
   */
  private getUserFromUsername(username: string): User | null {
    try {
      // Get userData from localStorage
      const userDataString = localStorage.getItem('userData');
      if (!userDataString) {
        return null;
      }

      const userData: User[] = JSON.parse(userDataString);

      // Try multiple matching strategies
      let user = null;

      // 1. Exact match (case-insensitive)
      user = userData.find((u) => u.fullname.toLowerCase() === username.toLowerCase());
      if (user) {
        return user;
      }

      // 2. Email match (case-insensitive)
      user = userData.find((u) => u.email.toLowerCase() === username.toLowerCase());
      if (user) {
        return user;
      }

      // 3. Partial match in fullname
      user = userData.find((u) => u.fullname.toLowerCase().includes(username.toLowerCase()));
      if (user) {
        return user;
      }

      // 4. Partial match in email
      user = userData.find((u) => u.email.toLowerCase().includes(username.toLowerCase()));
      if (user) {
        return user;
      }

      return null;
    } catch (error) {
      return null;
    }
  }

  /**
   * Get user ID from username using userData from localStorage
   * @param username - The username
   * @returns The user ID
   */
  private getUserIdFromUsername(username: string): string {
    const user = this.getUserFromUsername(username);
    return user ? user.id : '';
  }

  private scrollToBottom(): void {
    if (this.commentList && this.commentList.nativeElement) {
      const element = this.commentList.nativeElement;

      // Smooth scroll to bottom
      element.scrollTo({
        top: element.scrollHeight,
        behavior: 'smooth',
      });

      // Fallback for older browsers
      if (!element.scrollTo) {
        element.scrollTop = element.scrollHeight;
      }
    }
  }
}
