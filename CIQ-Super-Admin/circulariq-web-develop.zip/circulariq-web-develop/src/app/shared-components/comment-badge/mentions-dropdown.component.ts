import {
  Component,
  Input,
  Output,
  EventEmitter,
  OnInit,
  OnChanges,
  SimpleChanges,
  ChangeDetectionStrategy,
} from '@angular/core';
import { CommonModule } from '@angular/common';

export interface User {
  id: string;
  fullname: string;
  email: string;
}

@Component({
  selector: 'app-mentions-dropdown',
  templateUrl: './mentions-dropdown.component.html',
  styleUrls: ['./mentions-dropdown.component.scss'],
  standalone: true,
  imports: [CommonModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MentionsDropdownComponent implements OnInit, OnChanges {
  // Define users directly in the component
  users: User[] = JSON.parse(localStorage.getItem('userData') || '[]');

  @Input() searchTerm: string = '';
  @Input() visible: boolean = false;
  @Input() position: { x: number; y: number } = { x: 0, y: 0 };

  @Output() userSelected = new EventEmitter<User>();
  @Output() closeDropdown = new EventEmitter<void>();

  filteredUsers: User[] = [];
  selectedIndex: number = 0;

  ngOnInit(): void {
    this.filterUsers();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['searchTerm']) {
      this.filterUsers();
      this.selectedIndex = 0;
    }
    // Only update if relevant properties changed
    if (changes['visible']) {
      if (this.visible) {
        this.filterUsers();
      }
    }
  }

  filterUsers(): void {
    if (!this.searchTerm) {
      this.filteredUsers = this.users.slice(0, 10); // Limit to first 10 users
    } else {
      this.filteredUsers = this.users
        .filter(
          (user) =>
            user.fullname.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(this.searchTerm.toLowerCase())
        )
        .slice(0, 10); // Limit to first 10 matches
    }
  }

  onUserClick(user: User): void {
    this.userSelected.emit(user);
  }

  onKeyDown(event: KeyboardEvent): void {
    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        this.selectedIndex = Math.min(this.selectedIndex + 1, this.filteredUsers.length - 1);
        break;
      case 'ArrowUp':
        event.preventDefault();
        this.selectedIndex = Math.max(this.selectedIndex - 1, 0);
        break;
      case 'Enter':
        event.preventDefault();
        if (this.filteredUsers[this.selectedIndex]) {
          this.userSelected.emit(this.filteredUsers[this.selectedIndex]);
        }
        break;
      case 'Escape':
        event.preventDefault();
        this.closeDropdown.emit();
        break;
    }
  }

  isSelected(index: number): boolean {
    return index === this.selectedIndex;
  }
}
