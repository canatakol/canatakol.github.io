import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface Label {
  id: string | number;
  path: string[];
  [key: string]: any;
}

@Component({
  selector: 'app-label-logic-display',
  templateUrl: './label-logic-display.component.html',
  styleUrls: ['./label-logic-display.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class LabelLogicDisplayComponent {
  @Input() labels: Label[] = [];
  @Input() showRemoveButton: boolean = true;
  @Input() customClass: string = '';
  @Output() labelRemoved = new EventEmitter<Label>();

  getLabelGroups(labels: Label[] = []): Label[][] {
    if (!Array.isArray(labels) || labels.length === 0) return [];
    const groupMap = new Map<string, Label[]>();
    labels.forEach((label) => {
      const key = label.path[0] || '';
      if (!groupMap.has(key)) groupMap.set(key, []);
      groupMap.get(key)!.push(label);
    });
    return Array.from(groupMap.values());
  }

  onLabelRemove(label: Label): void {
    this.labelRemoved.emit(label);
  }
}
