import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CurrentUserService } from '@app/core/services/current-user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardStateService } from '@app/core/services/dashboard-state.service';
import { Subscription, interval } from 'rxjs';
import { CommentService, FormattedHeaderComment, HeaderCommentMention } from '@app/core/services/comment.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-header-comment-center',
  templateUrl: './header-comment-center.component.html',
  styleUrls: ['./header-comment-center.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class HeaderCommentCenterComponent implements OnInit, OnDestroy {
  @Input() isHeaderDropdown: boolean = true;
  @Input() defaultActiveTab: string = 'unread';
  @Output() closeDropdown = new EventEmitter<void>();

  dashboardId: string = '';
  currentUserEmail: string = '';
  currentSubLevel: string = '';
  storyblok: any;

  activeTab: string = 'unread';

  notifications: FormattedHeaderComment[] = [];

  private dashboardStateSubscription: Subscription;
  private commentUpdateSubscription: Subscription;
  private headerCommentsSubscription: Subscription;

  constructor(
    private currentUserService: CurrentUserService,
    public router: Router,
    private dashboardStateService: DashboardStateService,
    private commentService: CommentService,
    private storyblokService: StoryblokService
  ) {
    this.currentUserEmail = this.currentUserService.getCurrentUserEmail();
    this.currentSubLevel = this.dashboardStateService.getCurrentSubLevel();
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'dashboard')[0].content;
    });
    this.activeTab = this.defaultActiveTab;

    // Subscribe to header comments from service
    this.headerCommentsSubscription = this.commentService.getHeaderComments().subscribe((comments) => {
      this.notifications = comments;
      this.updateActiveTabBasedOnUnreadComments();
    });

    // Load initial comments
    this.commentService.loadHeaderCommentsFromService();

    // Start timer to check for new comments every 30 seconds
    this.commentUpdateSubscription = interval(30000).subscribe(() => {
      this.commentService.loadHeaderCommentsFromService();
    });

    this.dashboardStateSubscription = this.dashboardStateService.currentState$.subscribe((state) => {
      this.currentSubLevel = state.subLevel;
    });
  }

  ngOnDestroy(): void {
    if (this.dashboardStateSubscription) {
      this.dashboardStateSubscription.unsubscribe();
    }
    if (this.commentUpdateSubscription) {
      this.commentUpdateSubscription.unsubscribe();
    }
    if (this.headerCommentsSubscription) {
      this.headerCommentsSubscription.unsubscribe();
    }
  }

  getCurrentUserEmail(): string {
    return this.currentUserService.getCurrentUserEmail();
  }

  getCurrentUserCredentials(): any {
    return this.currentUserService.getCurrentUserCredentials();
  }

  isCurrentUserMentioned(notification: FormattedHeaderComment): boolean {
    if (!notification.originalData.mentions || notification.originalData.mentions.length === 0) {
      return false;
    }

    const currentUserCredentials = this.currentUserService.getCurrentUserCredentials();
    if (!currentUserCredentials) {
      return false;
    }

    return notification.originalData.mentions.some(
      (mention) => mention.userId === currentUserCredentials.userId || mention.username === currentUserCredentials.email
    );
  }

  getCurrentUserName(): string {
    return this.currentUserService.getCurrentUserName();
  }

  capitalizeText(text: string): string {
    if (!text) return '';
    const textWithSpaces = text.replace(/_/g, ' ');
    return textWithSpaces.charAt(0).toUpperCase() + textWithSpaces.slice(1).toLowerCase();
  }

  get filteredNotifications(): FormattedHeaderComment[] {
    const currentUserCredentials = this.getCurrentUserCredentials();
    return this.commentService.getFilteredHeaderComments(
      this.notifications,
      this.activeTab,
      this.currentSubLevel,
      this.currentUserEmail,
      currentUserCredentials
    );
  }

  getTabCount(tab: string): number {
    const currentUserCredentials = this.getCurrentUserCredentials();
    return this.commentService.getHeaderCommentTabCount(
      this.notifications,
      tab,
      this.currentSubLevel,
      this.currentUserEmail,
      currentUserCredentials
    );
  }

  trackByNotification(index: number, notification: FormattedHeaderComment): string {
    return notification.id;
  }

  trackByPart(index: number, part: any): string {
    return `${part.type}-${index}-${part.content}`;
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  navigateToContent(notification: FormattedHeaderComment): void {
    const navigationData = {
      dashboardID: notification.originalData.dashboardId,
      dashboardName: notification.originalData.dashboardName,
      tabName: notification.originalData.subLevel,
      componentName: notification.originalData.section,
    };

    this.closeDropdown.emit();

    if (notification.originalData.dashboardId && notification.originalData.subLevel) {
      try {
        const tabName = notification.originalData.subLevel.toLowerCase();

        this.router
          .navigate(['cti/dashboard', notification.originalData.dashboardId, tabName])
          .then(() => {
            this.dashboardStateService.updateState({
              selectedTab: notification.originalData.subLevel.toUpperCase(),
              dashboardId: notification.originalData.dashboardId,
              subLevel: notification.originalData.subLevel,
            });

            setTimeout(() => {
              this.scrollToComponent(notification.originalData.section);
            }, 1500);

            setTimeout(() => {
              this.scrollToComponent(notification.originalData.section);
            }, 3000);
          })
          .catch((error) => {
            this.router.navigate(['cti/dashboard', notification.originalData.dashboardId]);
          });

        this.commentService
          .markCommentReadAndRefresh(notification.originalData.id, notification.originalData.dashboardId)
          .subscribe({
            next: (response) => {
              // Refresh comments after marking as read
              this.commentService.loadHeaderCommentsFromService();
            },
            error: (error) => {
              console.error('Error marking comment as read:', error);
            },
          });
      } catch (error) {
        this.router.navigate(['cti/dashboard', notification.originalData.dashboardId]);
      }
    }
  }

  private scrollToComponent(sectionName: string): void {
    if (!sectionName) {
      return;
    }

    const componentId = this.getComponentIdForSection(sectionName);

    if (componentId) {
      const element = document.getElementById(componentId);

      if (element) {
        const elementRect = element.getBoundingClientRect();
        const offsetTop = elementRect.top + window.pageYOffset - 100;

        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth',
        });

        this.highlightElement(element);
      } else {
        this.tryAlternativeScrollMethods(componentId, sectionName);
      }
    }
  }

  private tryAlternativeScrollMethods(componentId: string, sectionName: string): void {
    const commentBadge = document.querySelector(`app-comment-badge[componentId="${componentId}"]`);

    if (commentBadge) {
      const elementRect = commentBadge.getBoundingClientRect();
      const offsetTop = elementRect.top + window.pageYOffset - 100;

      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });

      this.highlightElement(commentBadge);
      return;
    }

    const dataComponent = document.querySelector(`[data-component-id="${componentId}"]`);

    if (dataComponent) {
      const elementRect = dataComponent.getBoundingClientRect();
      const offsetTop = elementRect.top + window.pageYOffset - 100;

      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });

      this.highlightElement(dataComponent);
      return;
    }

    const elements = Array.from(document.querySelectorAll('*'));
    for (const element of elements) {
      if (element.textContent && element.textContent.toLowerCase().includes(sectionName.toLowerCase())) {
        if (
          element.tagName === 'H1' ||
          element.tagName === 'H2' ||
          element.tagName === 'H3' ||
          element.tagName === 'H4' ||
          element.tagName === 'H5' ||
          element.tagName === 'H6' ||
          element.classList.contains('title') ||
          element.classList.contains('header')
        ) {
          const elementRect = element.getBoundingClientRect();
          const offsetTop = elementRect.top + window.pageYOffset - 100;

          window.scrollTo({
            top: offsetTop,
            behavior: 'smooth',
          });

          this.highlightElement(element);
          return;
        }
      }
    }
  }

  private getComponentIdForSection(sectionName: string): string | null {
    const componentNameMappings: { [key: string]: string } = {
      PACKAGING: 'packaging-component',
      GHG_IMPACT: 'ghg-component',
      CRITICAL_INFLOW: 'critical-inflow-component',
      MOST_LINEAR_INFLOWS: 'most-linear-inflow-component',
      SANKEY: 'sankey-info-inflow-component',
      RECOVERY: 'recovery-breakdown-component',
      MASS_BREAKDOWN: 'breakdown-of-mass-component',
      PRODUCTIVITY: 'circular-material-productivity-component',
      REVENUE: 'cti-revenue-component',
      ON_SITE_WATER: 'onsite-water-circulation-component',
      ENERGY: 'renewable-energy-component',
      WATER: 'water-circularity-component',
    };

    if (componentNameMappings[sectionName]) {
      return componentNameMappings[sectionName];
    }

    const normalizedMappings: { [key: string]: string } = {
      packaging: 'packaging-component',
      ghg: 'ghg-component',
      'critical-inflow': 'critical-inflow-component',
      'most-linear-inflow': 'most-linear-inflow-component',
      'sankey-info': 'sankey-info-inflow-component',
      'recovery-breakdown': 'recovery-breakdown-component',
      'breakdown-of-mass': 'breakdown-of-mass-component',
      'circular-material-productivity': 'circular-material-productivity-component',
      'cti-revenue': 'cti-revenue-component',
      'onsite-water-circulation': 'onsite-water-circulation-component',
      'critical-inflow-optimize': 'critical-inflow-optimize-component',
      'renewable-energy': 'renewable-energy-component',
      'water-circularity': 'water-circularity-component',
    };

    const normalizedSectionName = sectionName.toLowerCase().replace(/[^a-z0-9]/g, '-');
    return normalizedMappings[normalizedSectionName] || null;
  }

  private highlightElement(element: Element): void {
    element.classList.add('scroll-highlight');

    setTimeout(() => {
      element.classList.remove('scroll-highlight');
    }, 1000);
  }

  getMentions(notification: FormattedHeaderComment): HeaderCommentMention[] {
    return notification.originalData.mentions;
  }

  renderMessageWithMentions(message: string, mentions: HeaderCommentMention[]): any[] {
    return this.commentService.renderMessageWithMentions(message, mentions);
  }

  private updateActiveTabBasedOnUnreadComments(): void {
    // Check if there are any unread comments
    const hasUnreadComments = this.notifications.some((notification) => !notification.originalData.isRead);

    if (hasUnreadComments) {
      this.activeTab = 'unread';
    } else {
      this.activeTab = 'all';
    }
  }
}
