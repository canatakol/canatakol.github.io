import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-guidance',
  templateUrl: './guidance.html',
  styleUrls: ['./guidance.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class GuidanceComponent implements OnInit, AfterViewInit {
  @Input('style') guidanceStyle = '';
  @Input() guidance = '';
  public story: any = {
    blocks: [],
    content: {},
    showBlocksDirectly: false,
    title: '',
    hasLoaded: false,
    mainContent: {},
  };
  private shownIds = [];
  private currentContent;
  private parentItem = null;

  constructor(private sbService: StoryblokService, private changeDetector: ChangeDetectorRef) {}

  ngAfterViewInit() {
    this.changeDetector.detach();
  }

  async ngOnInit() {
    const response: any = await this.sbService.getStoryGuidance(this.guidance);
    if (response && response.content) {
      switch (this.guidanceStyle) {
        case 'component-based':
          this.currentContent = response.content;
          this.currentContent.uuid = response.uuid;
          this.story.hasLoaded = true;
          break;
        default:
          this.story = {
            blocks: response.content.blocks,
            content: response.content.content,
            showBlocksDirectly: response.content.show_blocks_directly,
            hasLoaded: true,
            mainContent: {},
            title: response.content.title,
          };

          if (typeof response.content.main_content === 'string' && response.content.main_content !== '') {
            const mainContentResponse: any = await this.sbService.getStoryGuidance(
              '/' + response.content.main_content,
              {
                findBy: 'uuid',
              }
            );
            this.story.mainContent = mainContentResponse.content;
          }
          this.changeDetector.detectChanges();
          break;
      }
    } else {
      switch (this.guidanceStyle) {
        case 'component-based':
          this.currentContent = {
            notFound: true,
          };
          this.story.hasLoaded = true;
          this.changeDetector.detectChanges();
          break;
      }
    }
  }

  toggleAccordion(uid: string) {
    const index = this.shownIds.indexOf(uid);
    if (index === -1) {
      this.shownIds.push(uid);
    } else {
      delete this.shownIds[index];
    }
    this.changeDetector.detectChanges();
  }

  async openSubContent(uid: string, parent: any = {}) {
    if (Object.keys(parent).length === 0) {
      this.parentItem = {};
    } else {
      this.parentItem = parent;
    }

    const story: any = await this.sbService.getStoryGuidance('/' + uid, { findBy: 'uuid' });
    this.currentContent = story?.content;
    this.currentContent.uuid = story.uuid;
    this.changeDetector.detectChanges();
  }

  goBack() {
    if (this.parentItem.id) {
      this.openSubContent(this.parentItem.id);
    } else {
      this.currentContent = null;
    }
    this.changeDetector.detectChanges();
  }

  getGuidanceType() {
    if (this.currentContent) {
      return 'single-detail';
    }

    if (this.story.mainContent.title !== undefined) {
      return 'single-content';
    }

    if (this.story.mainContent.title === undefined && this.story.blocks.length > 0) {
      return 'block-listing';
    }
  }
}
