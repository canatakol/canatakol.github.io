import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { environment } from '@env/environment';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';
@Component({
  selector: 'app-critical-inflow',
  templateUrl: './critical-inflow.component.html',
  styleUrls: ['../../../assets/bootstrap.min.css', './critical-inflow.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe, TruncatePipe, CommentBadgeComponent],
})
export class CriticalInflowComponent {
  @Input() public data: string;
  @Input() public lifetimeExtension: string;
  @Input() public report: boolean;
  @Input() public storyblok: string;
  unitId = this.route.snapshot.params.unitId;
  environment = environment;
  constructor(private storyblokService: StoryblokService, private router: Router, private route: ActivatedRoute) {
    // Component initialized
  }
}
