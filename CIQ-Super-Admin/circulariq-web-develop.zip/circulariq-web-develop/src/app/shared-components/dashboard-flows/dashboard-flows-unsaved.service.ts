import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export const DASHBOARD_FLOW_UNSAVED_MESSAGE = 'If you leave this page, you will lose any unsaved changes.';

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsUnsavedService {
  private readonly hasUnsavedSubject = new BehaviorSubject<boolean>(false);

  setHasUnsavedChanges(hasChanges: boolean): void {
    this.hasUnsavedSubject.next(hasChanges);
  }

  hasUnsavedChanges(): boolean {
    return this.hasUnsavedSubject.value;
  }
}
