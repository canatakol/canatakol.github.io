import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';
import { FlexDecimalModule } from '@app/directives/flex-decimal.module';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-replace-flow-dialog',
  templateUrl: './replace-flow-dialog.component.html',
  styleUrls: ['./replace-flow-dialog.component.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FlexDecimalModule, TruncatePipe, CiqNumberPipe],
})
export class ReplaceFlowDialogComponent implements OnDestroy, OnInit {
  storyblok: any;
  storyblokAggregate: any;
  storyblokDashboardFlow: any;
  displayedData: any[] = [];
  materialForm!: FormGroup;
  type = 'INFLOWS';
  selectedButton = 'NEW FLOW';
  private materialFormSubscription?: Subscription;

  // Summary Card Properties
  originalValues: any = {};
  summary = {
    circularInflow: { change: 0, new: 0 },
    materialCircularity: { change: 0, new: 0 },
    linearMass: { change: 0, new: 0 },
    totalMass: { change: 0, new: 0 },
  };

  constructor(
    public dialogRef: MatDialogRef<ReplaceFlowDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private storyblokService: StoryblokService,
    private fb: FormBuilder
  ) {
    this.storyblokService.getStoryService().then((stories) => {
      if (Array.isArray(stories)) {
        const stepStory = stories.find((item) => item.slug === 'step3');
        this.storyblok = stepStory?.content;
        this.storyblokService.getStoryService().then((data) => {
          this.storyblokAggregate = data.filter((item) => item.slug === 'aggregate')[0].content;
        });
        const dashboardFlowStory = stories.find((item) => item.slug === 'dashboard-flows');
        this.storyblokDashboardFlow = dashboardFlowStory?.content || {};
      } else {
        this.storyblok = undefined;
        this.storyblokDashboardFlow = {};
      }
    });
  }

  ngOnInit(): void {
    const raw = this.data?.item;
    this.type = this.data?.type || 'INFLOWS';
    this.displayedData = Array.isArray(raw) ? raw : raw ? [raw] : [];
    this.initializeMaterialSourceValues();
  }

  ngOnDestroy(): void {
    this.materialFormSubscription?.unsubscribe();
  }

  calculateSummary(): void {
    if (!this.materialForm) {
      return;
    }

    // Current Values
    const currentTotalMass = this.toSafeNumber(this.materialForm.get('totalMass')?.value);
    const currentLinearPct = this.toSafeNumber(
      this.materialForm.get('linearPercentage')?.value ?? this.data?.item?.linearPercentage ?? 0
    );
    const currentCircularPct = 100 - currentLinearPct;

    // Calculate New Linear Mass
    const newLinearMass = (currentTotalMass * currentLinearPct) / 100;

    // Changes
    this.summary.circularInflow.new = currentCircularPct;
    this.summary.circularInflow.change = currentCircularPct - this.originalValues.circularPercentage;

    // Assuming Material Circularity tracks Circular Inflow for this context
    this.summary.materialCircularity.new = currentCircularPct;
    this.summary.materialCircularity.change = currentCircularPct - this.originalValues.circularPercentage;

    this.summary.totalMass.new = currentTotalMass;
    this.summary.totalMass.change = currentTotalMass - this.originalValues.weight;

    this.summary.linearMass.new = newLinearMass;
    this.summary.linearMass.change = newLinearMass - this.originalValues.linearMass;
  }

  // Custom validator for percentage fields (accepts comma or dot as decimal separator, 0-100 range)
  percentageValidator = (control: any) => {
    if (!control.value || control.value === '') {
      return null; // Allow empty, will be handled by required validator if needed
    }
    const value = String(control.value).trim();
    // Accept numbers with comma or dot as decimal separator
    const pattern = /^\d+([,.]\d+)?$/;
    if (!pattern.test(value)) {
      return { invalidFormat: true };
    }
    // Convert to number (replace comma with dot)
    const normalized = value.replace(',', '.');
    const numValue = Number(normalized);
    // Strict check: must be between 0 and 100 (inclusive)
    if (isNaN(numValue) || numValue < 0 || numValue > 100) {
      return { outOfRange: true };
    }
    return null;
  };

  // Real-time input validation to prevent values over 100
  onPercentageInput(event: any, controlName: string): void {
    const input = event.target;
    let value = input.value;

    // Remove any non-digit, comma, or dot characters
    value = value.replace(/[^\d,.]/g, '');

    // Replace comma with dot for calculation
    const normalized = value.replace(',', '.');
    const numValue = Number(normalized);

    // If value exceeds 100, limit it to 100
    if (!isNaN(numValue) && numValue > 100) {
      value = '100';
      input.value = value;
      this.materialForm.get(controlName)?.setValue(value, { emitEvent: true });
    }
  }

  toSafeNumber(value: any): number {
    if (value === null || value === undefined || value === '') {
      return 0;
    }
    if (typeof value === 'number') {
      return Number.isFinite(value) ? value : 0;
    }
    if (typeof value === 'string') {
      const normalized = value.replace(',', '.');
      const parsed = Number(normalized);
      return Number.isFinite(parsed) ? parsed : 0;
    }
    return 0;
  }

  getLinearMass(item: any): number {
    const weight = this.toSafeNumber(item?.weight);
    const linearPct = this.toSafeNumber(item?.linearPercentage);
    const linearWeight = this.toSafeNumber(item?.linearWeight);
    if (linearWeight > 0) {
      return linearWeight;
    }
    return (weight * linearPct) / 100;
  }

  close(): void {
    this.dialogRef.close(false);
  }

  onConfirm(action: 'REPLACE' | 'ADD' = 'REPLACE'): void {
    const result: any = {
      action,
      data: {
        name: this.materialForm.get('flowName')?.value,
      },
    };

    // Get form values
    const totalMassValue = this.materialForm.get('totalMass')?.value;
    const hasMassValue = totalMassValue !== null && totalMassValue !== undefined && totalMassValue !== '';
    const currentWeight = hasMassValue ? this.toSafeNumber(totalMassValue) : this.originalValues.weight ?? 0;

    // Only include weight if it has changed from original
    if (hasMassValue && currentWeight !== this.originalValues.weight) {
      result.data.weight = currentWeight;
    }

    if (this.data.type === 'OUTFLOWS') {
      const potentialRecoveryValue = this.materialForm.get('potentialRecovery')?.value;
      const actualRecoveryValue = this.materialForm.get('actualRecovery')?.value;

      const hasPotentialValue =
        potentialRecoveryValue !== null && potentialRecoveryValue !== undefined && potentialRecoveryValue !== '';
      const currentPotentialRecovery = hasPotentialValue
        ? this.toSafeNumber(potentialRecoveryValue)
        : this.originalValues.potentialRecovery ?? 0;

      const hasActualValue =
        actualRecoveryValue !== null && actualRecoveryValue !== undefined && actualRecoveryValue !== '';
      const currentActualRecovery = hasActualValue
        ? this.toSafeNumber(actualRecoveryValue)
        : this.originalValues.actualRecovery ?? 0;

      // Only include if changed from original
      if (hasPotentialValue && currentPotentialRecovery !== this.originalValues.potentialRecovery) {
        result.data.potentialRecovery = currentPotentialRecovery;
      }

      if (hasActualValue && currentActualRecovery !== this.originalValues.actualRecovery) {
        result.data.actualRecovery = currentActualRecovery;
      }
    } else {
      // INFLOWS
      const linearPercentageValue = this.materialForm.get('linearPercentage')?.value;
      const hasLinearValue =
        linearPercentageValue !== null && linearPercentageValue !== undefined && linearPercentageValue !== '';
      const currentLinearPercentage = hasLinearValue
        ? this.toSafeNumber(linearPercentageValue)
        : this.originalValues.linearPercentage ?? 0;

      // Only include if changed from original
      if (hasLinearValue && currentLinearPercentage !== this.originalValues.linearPercentage) {
        result.data.TI9 = currentLinearPercentage;
      }
    }
    this.dialogRef.close(result);
  }

  private initializeMaterialSourceValues(): void {
    const rawItem = this.data?.item;
    let linearPercentage = this.toSafeNumber(rawItem?.linearPercentage);
    let circularPercentage = this.toSafeNumber(rawItem?.circularPercentage);

    // If one is 0 and the other is also 0, it's likely missing data.
    // In CIQ, if Linear is 0, Circular must be 100.
    if (linearPercentage === 0 && (circularPercentage === 0 || circularPercentage === undefined)) {
      circularPercentage = 100;
    } else if (circularPercentage === 0 && (linearPercentage === 0 || linearPercentage === undefined)) {
      linearPercentage = 100;
    }

    const weight = this.toSafeNumber(rawItem?.weight);

    // Capture original values for change calculation
    this.originalValues = {
      weight: weight,
      circularPercentage: circularPercentage,
      linearPercentage: linearPercentage,
      linearMass: (weight * linearPercentage) / 100,
    };

    if (this.data.type === 'OUTFLOWS') {
      // Capture outflow specific values
      this.originalValues.potentialRecovery = this.toSafeNumber(this.data?.item?.potentialRecovery);
      this.originalValues.actualRecovery = this.toSafeNumber(this.data?.item?.actualRecovery);
      this.setUpMaterialForm(linearPercentage, weight);
    } else {
      this.setUpMaterialForm(linearPercentage, weight);
    }
  }

  private setUpMaterialForm(defaultLinearPercentage: number, defaultTotalMass: number): void {
    this.materialFormSubscription?.unsubscribe();
    const group: any = {
      flowName: [`${this.data?.item?.name} ${this.storyblokDashboardFlow?.replacedSuffix || '(Replaced)'}` || ''],
      totalMass: [defaultTotalMass],
    };

    if (this.data.type === 'OUTFLOWS') {
      // Outflow specific inputs
      group.potentialRecovery = [this.toSafeNumber(this.data?.item?.potentialRecovery), [this.percentageValidator]];
      group.actualRecovery = [this.toSafeNumber(this.data?.item?.actualRecovery), [this.percentageValidator]];
    } else {
      // INFLOWS: Only linearPercentage input
      group.linearPercentage = [defaultLinearPercentage, [this.percentageValidator]];
    }

    this.materialForm = this.fb.group(group);

    this.materialFormSubscription = this.materialForm.valueChanges.subscribe(() => this.calculateSummary());
    this.calculateSummary();
  }
}
