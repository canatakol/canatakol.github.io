import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DashboardScenarioSyncService {
  // Inflow scenario selection
  private readonly inflowScenarioSubject = new BehaviorSubject<string | null>(null);
  public readonly inflowScenario$ = this.inflowScenarioSubject.asObservable();

  // Outflow scenario selection
  private readonly outflowScenarioSubject = new BehaviorSubject<string | null>(null);
  public readonly outflowScenario$ = this.outflowScenarioSubject.asObservable();

  // Inflow scenarios list
  private readonly inflowScenariosListSubject = new BehaviorSubject<any[]>([]);
  public readonly inflowScenariosList$ = this.inflowScenariosListSubject.asObservable();

  // Outflow scenarios list
  private readonly outflowScenariosListSubject = new BehaviorSubject<any[]>([]);
  public readonly outflowScenariosList$ = this.outflowScenariosListSubject.asObservable();

  // Filter selection synchronization (shared between INFLOWS and OUTFLOWS)
  private readonly filterSelectionSubject = new BehaviorSubject<string>('material-category');
  public readonly filterSelection$ = this.filterSelectionSubject.asObservable();

  setInflowScenario(scenarioId: string | null): void {
    this.inflowScenarioSubject.next(scenarioId);
  }

  setOutflowScenario(scenarioId: string | null): void {
    this.outflowScenarioSubject.next(scenarioId);
  }

  getInflowScenario(): string | null {
    return this.inflowScenarioSubject.value;
  }

  getOutflowScenario(): string | null {
    return this.outflowScenarioSubject.value;
  }

  setInflowScenariosList(scenarios: any[]): void {
    this.inflowScenariosListSubject.next(scenarios);
  }

  setOutflowScenariosList(scenarios: any[]): void {
    this.outflowScenariosListSubject.next(scenarios);
  }

  getInflowScenariosList(): any[] {
    return this.inflowScenariosListSubject.value;
  }

  getOutflowScenariosList(): any[] {
    return this.outflowScenariosListSubject.value;
  }

  setFilterSelection(filterId: string): void {
    this.filterSelectionSubject.next(filterId);
  }

  getFilterSelection(): string {
    return this.filterSelectionSubject.value;
  }
}
