import { Injectable, inject } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { Observable, of } from 'rxjs';
import { filter, switchMap, tap } from 'rxjs/operators';
import { ImproveFlowDialogComponent } from './improve-flow-dialog/improve-flow-dialog.component';
import { ReplaceFlowDialogComponent } from './replace-flow-dialog/replace-flow-dialog.component';
import { CreateScenarioDialogComponent } from './create-scenario-dialog/create-scenario-dialog.component';
import { NewCustomViewDialogComponent } from './new-custom-view-dialog/new-custom-view-dialog.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsActionService {
  private readonly dialog = inject(MatDialog);
  private readonly http = inject(ApiRequestService);
  private readonly storyblokService = inject(StoryblokService);

  openReplaceFlowDialog(item: any, type: string): Observable<any> {
    const dialogRef = this.dialog.open(ReplaceFlowDialogComponent, {
      width: '80%',
      maxWidth: '1400px',
      panelClass: 'centered-dialog',
      data: { item, type },
    });
    return dialogRef.afterClosed();
  }

  openImproveFlowDialog(item: any, type: string): Observable<any> {
    const dialogRef = this.dialog.open(ImproveFlowDialogComponent, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { item, type },
    });
    return dialogRef.afterClosed();
  }

  openCreateScenarioDialog(): Observable<string | undefined> {
    const dialogRef = this.dialog.open(CreateScenarioDialogComponent, {
      width: '80%',
      maxWidth: '800px',
      panelClass: 'centered-dialog',
    });
    return dialogRef.afterClosed();
  }

  openNewCustomViewDialog(): Observable<string | undefined> {
    const dialogRef = this.dialog.open(NewCustomViewDialogComponent, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
    });
    return dialogRef.afterClosed();
  }

  openDiscardChangesDialog(): Observable<boolean> {
    return this.getStoryblokData().pipe(
      switchMap((storyblokDashboardFlow) => {
        const dialogRef = this.dialog.open(DeleteConfirmDialog, {
          width: '80%',
          maxWidth: '600px',
          panelClass: 'centered-dialog',
          data: {
            title: storyblokDashboardFlow?.discardChangesTitle || 'Discard Changes?',
            message:
              storyblokDashboardFlow?.discardChangesMessage ||
              'Are you sure you want to discard all changes? All modifications will be reset.',
            yesButtonText2: storyblokDashboardFlow?.discardButtonLabel || 'DISCARD',
            noButtonText: storyblokDashboardFlow?.cancelButtonLabel || 'CANCEL',
          },
        });
        return dialogRef.afterClosed();
      })
    );
  }

  openDeleteScenarioDialog(scenarioName: string): Observable<boolean> {
    return this.getStoryblokData().pipe(
      switchMap((storyblokDashboardFlow) => {
        const dialogRef = this.dialog.open(DeleteConfirmDialog, {
          width: '80%',
          maxWidth: '600px',
          panelClass: 'centered-dialog',
          data: {
            title: storyblokDashboardFlow?.deleteScenarioTitle || 'Delete Scenario',
            message: `${
              storyblokDashboardFlow?.deleteScenarioMessage || 'Are you sure you want to delete the scenario'
            } '${scenarioName}'?`,
            yesButtonText: storyblokDashboardFlow?.deleteButtonLabel || 'DELETE',
          },
        });
        return dialogRef.afterClosed();
      })
    );
  }

  private getStoryblokData(): Observable<any> {
    return new Observable((observer) => {
      this.storyblokService.getStoryService().then((data) => {
        const dashboardFlowStory = data.find((item) => item.slug === 'dashboard-flows');
        observer.next(dashboardFlowStory?.content || {});
        observer.complete();
      });
    });
  }

  createScenario(dashboardId: string, type: string, name: string): Observable<any> {
    const category = type === 'INFLOWS' ? 'INFLOW' : 'OUTFLOW';
    return this.http.callService(
      new Method(environment.services.dashboardScenarios(dashboardId, category), { name }, 'post')
    );
  }

  deleteScenario(scenarioId: string): Observable<any> {
    return this.http.callService(new Method(environment.services.deleteDashboardScenario(scenarioId), '', 'delete'));
  }

  saveImprovements(scenarioId: string, payload: any): Observable<any> {
    return this.http.callService(
      new Method(environment.services.improvementsDashboardScenario(scenarioId), payload, 'put')
    );
  }
}
