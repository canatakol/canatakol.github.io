import { Injectable } from '@angular/core';
import { normalizePercentageValue } from './utils/flow-data-transformer.util';

export interface SankeyMetrics {
  base: number;
  scenario: number;
  delta: number;
  isIncrease: boolean;
  isDecrease: boolean;
}

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsMetricsService {
  calculateItemMasses(
    item: any,
    useImprovements: boolean,
    type: 'INFLOWS' | 'OUTFLOWS'
  ): { total: number; linear: number; circular: number } {
    if (!item) return { total: 0, linear: 0, circular: 0 };

    const snapshot = item.__initialSnapshot || { weight: 0, linearPercentage: 0 };

    const originalTotalMass = item.baseBeforeImprove?.weight ?? item.baseFlowTotalMass ?? snapshot.weight ?? 0;
    const originalLinearPercentage = normalizePercentageValue(
      item.baseBeforeImprove?.linearPercentage ??
        (item.baseFlowCircularity !== undefined ? 100 - item.baseFlowCircularity : undefined) ??
        snapshot.linearPercentage ??
        0
    );

    const improvedTotalMass =
      item.temporaryReplaceFlow?.weight ??
      item.temporaryImproveFlow?.weight ??
      item.totalMass ??
      item.weight ??
      originalTotalMass;

    const improvedLinearPercentage = normalizePercentageValue(
      item.temporaryReplaceFlow?.linearPercentage ??
        item.temporaryImproveFlow?.linearPercentage ??
        item.linearPercentage ??
        originalLinearPercentage
    );

    const totalMass = useImprovements ? improvedTotalMass : originalTotalMass;
    const linearPercentage = useImprovements ? improvedLinearPercentage : originalLinearPercentage;

    const linearMass = (totalMass * linearPercentage) / 100;
    const circularMass = Math.max(0, totalMass - linearMass);

    return { total: totalMass, linear: linearMass, circular: circularMass };
  }

  getDiffCircularOutflowPercentage(
    displayedData: any[],
    type: 'INFLOWS' | 'OUTFLOWS',
    getBaseRowOutflowCircularMass: Function,
    getItemOutflowCircularMass: Function,
    getBaseRowWeight: Function,
    getItemWeight: Function
  ): number {
    if (!displayedData || displayedData.length === 0) return 0;

    let originalTotalMass = 0;
    let newTotalMass = 0;
    let originalCircularMass = 0;
    let newCircularMass = 0;

    displayedData.forEach((item) => {
      originalTotalMass += getBaseRowWeight(item);
      newTotalMass += getItemWeight(item);
      originalCircularMass += getBaseRowOutflowCircularMass(item);
      newCircularMass += getItemOutflowCircularMass(item);
    });

    const originalPercentage = originalTotalMass > 0 ? (originalCircularMass / originalTotalMass) * 100 : 0;
    const newPercentage = newTotalMass > 0 ? (newCircularMass / newTotalMass) * 100 : 0;

    return newPercentage - originalPercentage;
  }

  getDiffActualRecoveryOverallPercentage(
    displayedData: any[],
    getBaseRowWeight: Function,
    getItemWeight: Function,
    getBaseRowActualRecovery: Function,
    getItemActualRecovery: Function
  ): number {
    if (!displayedData || displayedData.length === 0) return 0;

    let originalTotalMass = 0;
    let newTotalMass = 0;
    let originalActualRecoveryWeighted = 0;
    let newActualRecoveryWeighted = 0;

    displayedData.forEach((item) => {
      const baseWeight = getBaseRowWeight(item);
      const updatedWeight = getItemWeight(item);
      originalTotalMass += baseWeight;
      newTotalMass += updatedWeight;
      originalActualRecoveryWeighted += getBaseRowActualRecovery(item) * baseWeight;
      newActualRecoveryWeighted += getItemActualRecovery(item) * updatedWeight;
    });

    const originalActualRecovery = originalTotalMass > 0 ? originalActualRecoveryWeighted / originalTotalMass : 0;
    const newActualRecovery = newTotalMass > 0 ? newActualRecoveryWeighted / newTotalMass : 0;

    return newActualRecovery - originalActualRecovery;
  }

  getDiffCircularOutflowMass(
    displayedData: any[],
    getBaseRowOutflowCircularMass: Function,
    getItemOutflowCircularMass: Function
  ): number {
    if (!displayedData || displayedData.length === 0) return 0;
    let originalCircularMass = 0;
    let newCircularMass = 0;

    displayedData.forEach((item) => {
      originalCircularMass += getBaseRowOutflowCircularMass(item);
      newCircularMass += getItemOutflowCircularMass(item);
    });

    return newCircularMass - originalCircularMass;
  }

  getDiffLinearMass(displayedData: any[], type: 'INFLOWS' | 'OUTFLOWS'): number {
    if (!displayedData || displayedData.length === 0) return 0;

    let originalLinear = 0;
    let newLinear = 0;

    displayedData.forEach((item) => {
      const original = this.calculateItemMasses(item, false, type);
      const modified = this.calculateItemMasses(item, true, type);
      originalLinear += original.linear;
      newLinear += modified.linear;
    });

    return newLinear - originalLinear;
  }

  getDiffTotalMass(displayedData: any[], type: 'INFLOWS' | 'OUTFLOWS'): number {
    if (!displayedData || displayedData.length === 0) return 0;

    let originalTotal = 0;
    let newTotal = 0;

    displayedData.forEach((item) => {
      const original = this.calculateItemMasses(item, false, type);
      const modified = this.calculateItemMasses(item, true, type);
      originalTotal += original.total;
      newTotal += modified.total;
    });

    return newTotal - originalTotal;
  }

  getDiffCircularInflowPercentage(displayedData: any[], type: 'INFLOWS' | 'OUTFLOWS'): number {
    if (!displayedData || displayedData.length === 0) return 0;

    let originalTotalMass = 0;
    let originalCircularMass = 0;
    let newTotalMass = 0;
    let newCircularMass = 0;

    displayedData.forEach((item) => {
      const original = this.calculateItemMasses(item, false, type);
      const modified = this.calculateItemMasses(item, true, type);

      originalTotalMass += original.total;
      originalCircularMass += original.circular;
      newTotalMass += modified.total;
      newCircularMass += modified.circular;
    });

    const originalPercentage = originalTotalMass > 0 ? (originalCircularMass / originalTotalMass) * 100 : 0;
    const newPercentage = newTotalMass > 0 ? (newCircularMass / newTotalMass) * 100 : 0;

    return newPercentage - originalPercentage;
  }

  computeMetricDelta(base: number | undefined, scenario: number | undefined): any {
    const baseValue = base ?? 0;
    const scenarioValue = scenario ?? baseValue;
    const rawDelta = scenarioValue - baseValue;
    return {
      baseValue,
      scenarioValue,
      delta: Math.abs(rawDelta),
      isIncrease: rawDelta > 0,
      isDecrease: rawDelta < 0,
    };
  }

  getSankeyMetricColorClass(metric: SankeyMetrics, isMass: boolean, isLinearMass: boolean = false): string {
    if (metric.delta === 0) {
      return '';
    }

    if (isLinearMass || isMass) {
      return metric.isIncrease ? 'negative' : 'positive';
    } else {
      return metric.isIncrease ? 'positive' : 'negative';
    }
  }

  getSankeyMetricCardClass(metric: SankeyMetrics, isMass: boolean, isLinearMass: boolean = false): string {
    if (metric.delta === 0) {
      return 'type-gray';
    }

    if (isLinearMass || isMass) {
      return metric.isIncrease ? 'type-red' : 'type-green';
    } else {
      return metric.isIncrease ? 'type-green' : 'type-red';
    }
  }
}
