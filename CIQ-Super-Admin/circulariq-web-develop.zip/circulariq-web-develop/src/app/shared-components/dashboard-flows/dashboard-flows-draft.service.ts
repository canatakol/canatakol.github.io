import { Injectable, inject } from '@angular/core';
import { DashboardFlowsUnsavedService } from './dashboard-flows-unsaved.service';
import { normalizePercentageValue, getFlowName } from './utils/flow-data-transformer.util';

export type FlowType = 'INFLOWS' | 'OUTFLOWS';

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsDraftService {
  private readonly unsavedService = inject(DashboardFlowsUnsavedService);

  private improveDrafts: Record<FlowType, Map<string, any>> = {
    INFLOWS: new Map(),
    OUTFLOWS: new Map(),
  };

  private replaceDrafts: Record<FlowType, Map<string, any>> = {
    INFLOWS: new Map(),
    OUTFLOWS: new Map(),
  };

  private addedDraftFlows: Record<FlowType, any[]> = {
    INFLOWS: [],
    OUTFLOWS: [],
  };

  getImproveDrafts(type: FlowType) {
    return this.improveDrafts[type];
  }

  getReplaceDrafts(type: FlowType) {
    return this.replaceDrafts[type];
  }

  getAddedDraftFlows(type: FlowType) {
    return this.addedDraftFlows[type];
  }

  hasDrafts(type: FlowType): boolean {
    return (
      this.improveDrafts[type].size > 0 || this.replaceDrafts[type].size > 0 || this.addedDraftFlows[type].length > 0
    );
  }

  persistImproveDraft(type: FlowType, item: any, flowId: string): void {
    if (!item || !flowId) return;

    const snapshot = this.cloneDraft(item.__initialSnapshot);
    let baseBefore = item.baseBeforeImprove ? this.cloneDraft(item.baseBeforeImprove) : null;

    if (!baseBefore) {
      const baseWeight = item.weight ?? item.totalMass ?? 0;
      if (type === 'OUTFLOWS') {
        baseBefore = {
          weight: baseWeight,
          potentialRecovery: normalizePercentageValue(item.potentialRecovery ?? 0),
          actualRecovery: normalizePercentageValue(item.actualRecovery ?? 0),
        };
      } else {
        const baseLinearPct = normalizePercentageValue(item.linearPercentage ?? 0);
        baseBefore = {
          weight: baseWeight,
          linearPercentage: baseLinearPct,
          circularPercentage: Math.max(0, 100 - baseLinearPct),
        };
      }
    }

    const tempImprove = item.temporaryImproveFlow ? this.cloneDraft(item.temporaryImproveFlow) : {};
    const itemSnapshot = this.cloneDraft(item);

    this.improveDrafts[type].set(flowId, {
      baseBeforeImprove: baseBefore,
      initialSnapshot: snapshot,
      temporaryImproveFlow: tempImprove,
      itemSnapshot,
    });
  }

  persistReplaceDraft(type: FlowType, flowId: string, baseItem: any, replacementRow: any, isAdd = false): void {
    if (!flowId) return;

    const storedRow = this.cloneDraft(replacementRow);
    const initialSnapshot = baseItem?.__initialSnapshot ? this.cloneDraft(baseItem.__initialSnapshot) : null;
    const baseBeforeImprove = baseItem?.baseBeforeImprove ? this.cloneDraft(baseItem.baseBeforeImprove) : null;

    this.replaceDrafts[type].set(flowId, {
      replacementRow: storedRow,
      baseBeforeImprove,
      initialSnapshot,
      isAdd,
    });

    if (isAdd) {
      const added = this.addedDraftFlows[type];
      if (!added.some((f) => f?.id === storedRow?.id)) {
        added.push(storedRow);
      }
    }
  }

  clearDraftStateForType(type: FlowType): void {
    this.improveDrafts[type].clear();
    this.replaceDrafts[type].clear();
    this.addedDraftFlows[type] = [];
    this.unsavedService.setHasUnsavedChanges(false);
  }

  resetAllDrafts(): void {
    this.clearDraftStateForType('INFLOWS');
    this.clearDraftStateForType('OUTFLOWS');
  }

  buildImprovementsPayload(
    type: FlowType,
    allItems: any[],
    getItemPotentialRecovery: Function,
    getItemActualRecovery: Function,
    getBaseRowPotentialRecovery: Function,
    getBaseRowActualRecovery: Function,
    getItemWeight: Function,
    getItemCircularPercentage: Function,
    getBaseRowCircularInflowPercentage: Function,
    isImproved: Function,
    isReplaced: Function
  ): {
    save: boolean;
    improvedFlows: any[];
    replacedFlows: any[];
  } {
    const category = type === 'INFLOWS' ? 'INFLOW' : 'OUTFLOW';

    const improvedFlows = allItems
      .filter((item) => isImproved(item))
      .map((item) => {
        const name = getFlowName(item);
        const targetMass = getItemWeight(item);

        if (type === 'OUTFLOWS') {
          return {
            name,
            category,
            targetMass,
            actualPotentialRecovery: getBaseRowPotentialRecovery(item),
            targetPotentialRecovery: getItemPotentialRecovery(item),
            actualActualRecovery: getBaseRowActualRecovery(item),
            targetActualRecovery: getItemActualRecovery(item),
          };
        }

        return {
          name,
          category,
          actualCircularity: getBaseRowCircularInflowPercentage(item),
          targetCircularity: getItemCircularPercentage(item),
          targetMass,
        };
      });

    const replacedFlows = allItems
      .filter((item) => isReplaced(item))
      .map((flowData: any) => {
        const actualName = flowData?.baseFlowName ?? getFlowName(flowData);
        const targetName = getFlowName(flowData);
        const targetMass = getItemWeight(flowData);

        if (type === 'OUTFLOWS') {
          return {
            actualName,
            targetName,
            category,
            actualPotentialRecovery: getBaseRowPotentialRecovery(flowData),
            targetPotentialRecovery: getItemPotentialRecovery(flowData),
            actualActualRecovery: getBaseRowActualRecovery(flowData),
            targetActualRecovery: getItemActualRecovery(flowData),
            targetMass,
          };
        }

        return {
          actualName,
          targetName,
          category,
          actualCircularity: getBaseRowCircularInflowPercentage(flowData),
          targetCircularity: getItemCircularPercentage(flowData),
          targetMass,
        };
      })
      .filter((x: any) => !!x?.actualName && !!x?.targetName);

    return {
      save: true,
      improvedFlows,
      replacedFlows,
    };
  }

  getAllDraftAwareItems(
    type: FlowType,
    displayedData: any[],
    getFlowIdentifier: Function,
    applyImprovedValuesToItem: Function
  ): any[] {
    const result: any[] = [];
    const seenItemKeys = new Set<string>();

    const addItemIfNotSeen = (item: any) => {
      if (!item) return;
      const key = getFlowIdentifier(item);
      if (!key || seenItemKeys.has(key)) return;
      seenItemKeys.add(key);
      result.push(item);
    };

    (displayedData || []).forEach((item) => {
      const cloned = JSON.parse(JSON.stringify(item));
      const flowId = getFlowIdentifier(cloned);

      if (flowId) {
        const improveDraft = this.getImproveDrafts(type).get(flowId);
        if (improveDraft) {
          if (improveDraft.baseBeforeImprove)
            cloned.baseBeforeImprove = JSON.parse(JSON.stringify(improveDraft.baseBeforeImprove));
          if (improveDraft.initialSnapshot)
            cloned.__initialSnapshot = JSON.parse(JSON.stringify(improveDraft.initialSnapshot));
          if (improveDraft.temporaryImproveFlow)
            cloned.temporaryImproveFlow = JSON.parse(JSON.stringify(improveDraft.temporaryImproveFlow));
        }
        const replaceDraft = this.getReplaceDrafts(type).get(flowId);
        if (replaceDraft && replaceDraft.replacementRow) {
          const replacementClone = JSON.parse(JSON.stringify(replaceDraft.replacementRow));
          if (replaceDraft.baseBeforeImprove)
            replacementClone.baseBeforeImprove = JSON.parse(JSON.stringify(replaceDraft.baseBeforeImprove));
          if (replaceDraft.initialSnapshot)
            replacementClone.__initialSnapshot = JSON.parse(JSON.stringify(replaceDraft.initialSnapshot));
          addItemIfNotSeen(replacementClone);
          return;
        }
      }
      addItemIfNotSeen(cloned);
    });

    this.getImproveDrafts(type).forEach((draft, flowId) => {
      const existingIndex = result.findIndex((item) => {
        const itemId = getFlowIdentifier(item);
        return itemId === flowId;
      });

      if (existingIndex >= 0) {
        const existing = result[existingIndex];
        if (draft.baseBeforeImprove) existing.baseBeforeImprove = JSON.parse(JSON.stringify(draft.baseBeforeImprove));
        if (draft.initialSnapshot) existing.__initialSnapshot = JSON.parse(JSON.stringify(draft.initialSnapshot));
        if (draft.temporaryImproveFlow)
          existing.temporaryImproveFlow = JSON.parse(JSON.stringify(draft.temporaryImproveFlow));
        applyImprovedValuesToItem(existing);
      } else if (draft?.itemSnapshot) {
        const clone = JSON.parse(JSON.stringify(draft.itemSnapshot));
        if (draft.baseBeforeImprove) clone.baseBeforeImprove = JSON.parse(JSON.stringify(draft.baseBeforeImprove));
        if (draft.initialSnapshot) clone.__initialSnapshot = JSON.parse(JSON.stringify(draft.initialSnapshot));
        if (draft.temporaryImproveFlow)
          clone.temporaryImproveFlow = JSON.parse(JSON.stringify(draft.temporaryImproveFlow));
        applyImprovedValuesToItem(clone);
        addItemIfNotSeen(clone);
      }
    });

    this.getReplaceDrafts(type).forEach((draft, flowId) => {
      if (draft?.replacementRow) {
        const existingIndex = result.findIndex((item) => {
          const itemId = getFlowIdentifier(item);
          return itemId === flowId;
        });

        if (existingIndex < 0) {
          const clone = JSON.parse(JSON.stringify(draft.replacementRow));
          if (draft.baseBeforeImprove) clone.baseBeforeImprove = JSON.parse(JSON.stringify(draft.baseBeforeImprove));
          if (draft.initialSnapshot) clone.__initialSnapshot = JSON.parse(JSON.stringify(draft.initialSnapshot));
          addItemIfNotSeen(clone);
        }
      }
    });

    const added = this.getAddedDraftFlows(type) || [];
    added.forEach((flow) => {
      addItemIfNotSeen(JSON.parse(JSON.stringify(flow)));
    });

    return result;
  }

  private cloneDraft<T>(value: T): T {
    return value ? JSON.parse(JSON.stringify(value)) : value;
  }
}
