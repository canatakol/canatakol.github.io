import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';
import { FlexDecimalModule } from '@app/directives/flex-decimal.module';

@Component({
  selector: 'app-improve-flow-dialog',
  templateUrl: './improve-flow-dialog.component.html',
  styleUrls: ['./improve-flow-dialog.component.scss'],
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, FlexDecimalModule],
})
export class ImproveFlowDialogComponent implements OnDestroy, OnInit {
  storyblok: any;
  storyblokDashboardFlow: any;
  materialForm!: FormGroup;
  private materialFormSubscription?: Subscription;
  isOutflow = false;

  // Summary Card Properties
  originalValues: any = {};
  summary = {
    circularInflow: { change: 0, new: 0 },
    materialCircularity: { change: 0, new: 0 },
    linearMass: { change: 0, new: 0 },
    totalMass: { change: 0, new: 0 },
  };

  constructor(
    public dialogRef: MatDialogRef<ImproveFlowDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private storyblokService: StoryblokService,
    private fb: FormBuilder
  ) {
    this.isOutflow = data?.type === 'OUTFLOWS';
    this.storyblokService.getStoryService().then((stories) => {
      if (Array.isArray(stories)) {
        const stepStory = stories.find((item) => item.slug === 'step3');
        this.storyblok = stepStory?.content;
        const dashboardFlowStory = stories.find((item) => item.slug === 'dashboard-flows');
        this.storyblokDashboardFlow = dashboardFlowStory?.content || {};
      } else {
        this.storyblok = undefined;
        this.storyblokDashboardFlow = {};
      }
    });
  }

  ngOnInit(): void {
    this.initializeMaterialSourceValues();
  }

  ngOnDestroy(): void {
    this.materialFormSubscription?.unsubscribe();
  }

  materialSourceCalculate(): void {
    if (!this.materialForm) {
      return;
    }

    if (this.isOutflow) {
      return;
    }

    this.calculateSummary();
  }

  calculateSummary(): void {
    if (this.isOutflow) {
      return;
    }
    // Current Values
    const currentTotalMass = this.toSafeNumber(this.materialForm.get('totalMass')?.value);
    const currentLinearPct = this.toSafeNumber(this.materialForm.get('linearPercentage')?.value);
    const currentCircularPct = Math.max(0, 100 - currentLinearPct);

    // Calculate Linear Mass
    const newLinearMass = (currentTotalMass * currentLinearPct) / 100;

    // Circular Inflow (same as circular percentage)
    this.summary.circularInflow.new = currentCircularPct;
    this.summary.circularInflow.change = currentCircularPct - this.originalValues.circularPercentage;

    // Material Circularity (same as circular percentage)
    this.summary.materialCircularity.new = currentCircularPct;
    this.summary.materialCircularity.change = currentCircularPct - this.originalValues.circularPercentage;

    // Linear Mass
    this.summary.linearMass.new = newLinearMass;
    this.summary.linearMass.change = newLinearMass - this.originalValues.linearMass;

    // Total Mass
    this.summary.totalMass.new = currentTotalMass;
    this.summary.totalMass.change = currentTotalMass - this.originalValues.weight;
  }

  toSafeNumber(value: any): number {
    if (value === null || value === undefined || value === '') {
      return 0;
    }
    if (typeof value === 'number') {
      return Number.isFinite(value) ? value : 0;
    }
    if (typeof value === 'string') {
      const normalized = value.replace(',', '.');
      const parsed = Number(normalized);
      return Number.isFinite(parsed) ? parsed : 0;
    }
    return 0;
  }

  // Custom validator for percentage fields (accepts comma or dot as decimal separator, 0-100 range)
  percentageValidator = (control: any) => {
    if (!control.value || control.value === '') {
      return null; // Allow empty, will be handled by required validator if needed
    }
    const value = String(control.value).trim();
    // Accept numbers with comma or dot as decimal separator
    const pattern = /^\d+([,.]\d+)?$/;
    if (!pattern.test(value)) {
      return { invalidFormat: true };
    }
    // Convert to number (replace comma with dot)
    const normalized = value.replace(',', '.');
    const numValue = Number(normalized);
    // Strict check: must be between 0 and 100 (inclusive)
    if (isNaN(numValue) || numValue < 0 || numValue > 100) {
      return { outOfRange: true };
    }
    return null;
  };

  // Real-time input validation to prevent values over 100
  onPercentageInput(event: any, controlName: string): void {
    const input = event.target;
    let value = input.value;

    // Remove any non-digit, comma, or dot characters
    value = value.replace(/[^\d,.]/g, '');

    // Replace comma with dot for calculation
    const normalized = value.replace(',', '.');
    const numValue = Number(normalized);

    // If value exceeds 100, limit it to 100
    if (!isNaN(numValue) && numValue > 100) {
      value = '100';
      input.value = value;
      this.materialForm.get(controlName)?.setValue(value, { emitEvent: true });
    }
  }

  close(): void {
    this.dialogRef.close(false);
  }

  hasChanges(): boolean {
    if (!this.materialForm) {
      return false;
    }

    if (this.isOutflow) {
      const currentTotalMass = this.toSafeNumber(this.materialForm.get('totalMass')?.value);
      const currentPotentialRecovery = this.toSafeNumber(this.materialForm.get('potentialRecovery')?.value);
      const currentActualRecovery = this.toSafeNumber(this.materialForm.get('actualRecovery')?.value);

      const totalMassChanged = Math.abs(currentTotalMass - this.originalValues.weight) > 0.0001;
      const potentialChanged = Math.abs(currentPotentialRecovery - this.originalValues.potentialRecovery) > 0.0001;
      const actualChanged = Math.abs(currentActualRecovery - this.originalValues.actualRecovery) > 0.0001;

      return totalMassChanged || potentialChanged || actualChanged;
    }

    const currentTotalMass = this.toSafeNumber(this.materialForm.get('totalMass')?.value);
    const currentLinearPct = this.toSafeNumber(this.materialForm.get('linearPercentage')?.value);

    const totalMassChanged = Math.abs(currentTotalMass - this.originalValues.weight) > 0.0001;
    const linearPctChanged = Math.abs(currentLinearPct - this.originalValues.linearPercentage) > 0.0001;

    return totalMassChanged || linearPctChanged;
  }

  onConfirm(): void {
    const currentWeight = this.toSafeNumber(this.materialForm.get('totalMass')?.value);
    const result: any = {};

    if (this.isOutflow) {
      const currentPotentialRecovery = this.toSafeNumber(this.materialForm.get('potentialRecovery')?.value);
      const currentActualRecovery = this.toSafeNumber(this.materialForm.get('actualRecovery')?.value);

      // Only include weight if it has changed
      if (Math.abs(currentWeight - (this.originalValues.weight ?? 0)) > 0.0001) {
        result.weight = currentWeight;
      }

      // Only include potentialRecovery if it has changed
      if (Math.abs(currentPotentialRecovery - (this.originalValues.potentialRecovery ?? 0)) > 0.0001) {
        result.potentialRecovery = currentPotentialRecovery;
      }

      // Only include actualRecovery if it has changed
      if (Math.abs(currentActualRecovery - (this.originalValues.actualRecovery ?? 0)) > 0.0001) {
        result.actualRecovery = currentActualRecovery;
      }

      this.dialogRef.close(result);
      return;
    }

    // INFLOWS
    const currentLinearPercentage = this.toSafeNumber(this.materialForm.get('linearPercentage')?.value);

    // Only include weight if it has changed
    if (Math.abs(currentWeight - (this.originalValues.weight ?? 0)) > 0.0001) {
      result.weight = currentWeight;
    }

    // Only include linearPercentage if it has changed
    if (Math.abs(currentLinearPercentage - (this.originalValues.linearPercentage ?? 0)) > 0.0001) {
      result.linearPercentage = currentLinearPercentage;
    }

    this.dialogRef.close(result);
  }

  private initializeMaterialSourceValues(): void {
    if (this.isOutflow) {
      const weight = this.toSafeNumber(this.data?.item?.weight ?? this.data?.item?.totalMass);
      const potentialRecovery = this.toSafeNumber(
        this.data?.item?.potentialRecovery ?? this.data?.item?.potentialRecoveryPercentage
      );
      const actualRecovery = this.toSafeNumber(
        this.data?.item?.actualRecovery ?? this.data?.item?.actualRecoveryPercentage
      );

      this.originalValues = {
        weight,
        potentialRecovery,
        actualRecovery,
      };

      this.setUpOutflowForm(weight, potentialRecovery, actualRecovery);
      return;
    }

    const weight = this.toSafeNumber(this.data?.item?.weight);
    const linearPercentage = this.toSafeNumber(this.data?.item?.linearPercentage);
    const circularPercentage = Math.max(0, 100 - linearPercentage);
    const linearMass = (weight * linearPercentage) / 100;

    // Capture original values for change calculation
    this.originalValues = {
      weight: weight,
      circularPercentage: circularPercentage,
      linearPercentage: linearPercentage,
      linearMass: linearMass,
    };

    this.setUpMaterialForm(weight);
  }

  private setUpMaterialForm(defaultTotalMass: number): void {
    this.materialFormSubscription?.unsubscribe();
    const defaultLinearPercentage = this.toSafeNumber(this.data?.item?.linearPercentage);
    this.materialForm = this.fb.group({
      totalMass: [defaultTotalMass],
      linearPercentage: [defaultLinearPercentage, [this.percentageValidator]],
    });

    this.materialFormSubscription = this.materialForm.valueChanges.subscribe(() => this.materialSourceCalculate());
    this.materialSourceCalculate();
  }

  private setUpOutflowForm(defaultTotalMass: number, defaultPotential: number, defaultActual: number): void {
    this.materialFormSubscription?.unsubscribe();
    this.materialForm = this.fb.group({
      totalMass: [defaultTotalMass],
      potentialRecovery: [defaultPotential, [this.percentageValidator]],
      actualRecovery: [defaultActual, [this.percentageValidator]],
    });

    this.materialFormSubscription = this.materialForm.valueChanges.subscribe(() => this.materialSourceCalculate());
  }
}
