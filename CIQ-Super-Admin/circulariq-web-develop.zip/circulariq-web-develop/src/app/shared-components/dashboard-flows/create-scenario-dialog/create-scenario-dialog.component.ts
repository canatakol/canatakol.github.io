import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-create-scenario-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './create-scenario-dialog.component.html',
  styleUrls: ['./create-scenario-dialog.component.scss'],
})
export class CreateScenarioDialogComponent implements OnInit {
  scenarioForm!: FormGroup;
  storyblokDashboardFlow: any;

  constructor(
    private fb: FormBuilder,
    private dialogRef: MatDialogRef<CreateScenarioDialogComponent>,
    private storyblokService: StoryblokService
  ) {
    this.scenarioForm = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(150)]],
    });
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const dashboardFlowStory = data.find((item) => item.slug === 'dashboard-flows');
      this.storyblokDashboardFlow = dashboardFlowStory?.content || {};
    });
  }

  close(): void {
    this.dialogRef.close();
  }

  confirm(): void {
    const rawName = this.scenarioForm.get('name')?.value ?? '';
    const trimmedName = rawName.trim();

    if (!trimmedName) {
      this.scenarioForm.get('name')?.setErrors({ required: true });
      return;
    }

    this.dialogRef.close(trimmedName);
  }
}
