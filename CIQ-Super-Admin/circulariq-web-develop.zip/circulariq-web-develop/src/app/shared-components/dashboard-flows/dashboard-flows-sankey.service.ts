import { Injectable, inject } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { environment } from '@env/environment';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { take, tap, catchError } from 'rxjs/operators';
import { getBaseSankeyData } from './utils/sankey-metrics.util';

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsSankeyService {
  private readonly http = inject(ApiRequestService);
  private readonly localStorageService = inject(LocalStorageService);

  private baseSankeyDataSubject = new BehaviorSubject<any | null>(null);
  private scenarioSankeyDataSubject = new BehaviorSubject<any | null>(null);

  baseSankeyData$ = this.baseSankeyDataSubject.asObservable();
  scenarioSankeyData$ = this.scenarioSankeyDataSubject.asObservable();

  get baseSankeyData() {
    return this.baseSankeyDataSubject.value;
  }

  get scenarioSankeyData() {
    return this.scenarioSankeyDataSubject.value;
  }

  loadBaseSankeyData(): void {
    const data = getBaseSankeyData(this.localStorageService);
    this.baseSankeyDataSubject.next(data);
  }

  loadScenarioSankeyData(dashboardId: string, scenarioId: string | null): Observable<any> {
    if (!scenarioId || !dashboardId) {
      this.scenarioSankeyDataSubject.next(null);
      return of(null);
    }

    return this.http.callService(new Method(environment.services.deleteDashboardScenario(scenarioId), '', 'get')).pipe(
      take(1),
      tap((res: any) => {
        const data = res?.sankeyData ?? res?.sankey ?? res ?? null;
        this.scenarioSankeyDataSubject.next(data);
      }),
      catchError((error) => {
        console.error('Error loading scenario sankey data:', error);
        this.scenarioSankeyDataSubject.next(null);
        return of(null);
      })
    );
  }

  loadPreviewSankeyData(dashboardId: string, type: string, payload: any): Observable<any> {
    if (!dashboardId || !payload) {
      return of(null);
    }

    if (payload.improvedFlows.length === 0 && payload.replacedFlows.length === 0) {
      this.scenarioSankeyDataSubject.next(null);
      return of(null);
    }

    const category = type === 'INFLOWS' ? 'INFLOW' : 'OUTFLOW';

    return this.http
      .callService(new Method(environment.services.reviewImprovements(dashboardId, category), payload, 'post'))
      .pipe(
        take(1),
        tap((res: any) => {
          const data =
            res?.sankeyData ??
            res?.sankey ??
            (res && typeof res === 'object' && ('outflowCircularPercentage' in res || 'inflowCircularPercentage' in res)
              ? res
              : null);
          this.scenarioSankeyDataSubject.next(data);
        }),
        catchError((error) => {
          console.error('Error loading preview sankey data:', error);
          this.scenarioSankeyDataSubject.next(null);
          return of(null);
        })
      );
  }

  clearScenarioSankeyData(): void {
    this.scenarioSankeyDataSubject.next(null);
  }
}
