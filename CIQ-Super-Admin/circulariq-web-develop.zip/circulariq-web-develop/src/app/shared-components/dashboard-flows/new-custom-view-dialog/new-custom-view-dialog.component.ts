import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-new-custom-view-dialog',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './new-custom-view-dialog.component.html',
  styleUrls: ['./new-custom-view-dialog.component.scss'],
})
export class NewCustomViewDialogComponent {
  form: FormGroup;

  constructor(private fb: FormBuilder, private dialogRef: MatDialogRef<NewCustomViewDialogComponent>) {
    this.form = this.fb.group({
      viewName: ['', [Validators.required]],
    });
  }

  close(): void {
    this.dialogRef.close();
  }

  cancel(): void {
    this.dialogRef.close();
  }

  confirm(): void {
    const value = this.form.get('viewName')?.value ?? '';
    this.dialogRef.close(value.trim() || undefined);
  }
}
