/**
 * Utility functions for transforming flow data
 * These are pure functions that can be easily tested and reused
 */

/**
 * Normalizes a percentage value to be between 0 and 100
 * Handles values that might be in 0-1 range (scales to 0-100)
 */
export function normalizePercentageValue(value?: number): number {
  if (value === undefined || value === null || Number.isNaN(value)) {
    return 0;
  }

  const scaledValue = value >= 0 && value <= 1 ? value * 100 : value;
  if (scaledValue < 0) {
    return 0;
  }
  if (scaledValue > 100) {
    return 100;
  }

  return scaledValue;
}

/**
 * Converts various input types to a number
 */
function toNumber(value: any): number | undefined {
  if (value === null || value === undefined || value === '') {
    return undefined;
  }
  if (typeof value === 'number') {
    return Number.isFinite(value) ? value : undefined;
  }
  if (typeof value === 'string') {
    const normalized = value.replace(',', '.');
    const numeric = Number(normalized);
    return Number.isFinite(numeric) ? numeric : undefined;
  }
  return undefined;
}

/**
 * Transforms a raw flow item from the API into a standardized format
 * Handles various field name variations and calculates missing values
 */
export function transformFlowItem(item: any): any {
  if (!item || typeof item !== 'object') {
    return item;
  }

  const resolveName = (v: any) => (typeof v === 'string' && v.trim() ? v : undefined);
  const name =
    resolveName(item.name) ??
    resolveName(item.assessmentName) ??
    resolveName(item.assessment_name) ??
    resolveName(item.displayName) ??
    resolveName(item.tradeName) ??
    resolveName(item.flowName) ??
    resolveName(item.flow?.name) ??
    resolveName(item.flow?.displayName) ??
    resolveName(item.flow?.tradeName) ??
    resolveName(item.assessment?.name) ??
    resolveName(item.assessment?.assessmentName) ??
    '';

  const totalMassRaw =
    toNumber(item.totalMass) ??
    toNumber(item.mass) ??
    toNumber(item.weight) ??
    toNumber(item.total_weight) ??
    toNumber(item.flow?.totalMass) ??
    toNumber(item.flow?.mass) ??
    toNumber(item.flow?.weight);

  const linearMassRaw =
    toNumber(item.linearMass) ??
    toNumber(item.linear_mass) ??
    toNumber(item.linear_mass_kg) ??
    toNumber(item.linearWeight) ??
    toNumber(item.flow?.linearMass) ??
    toNumber(item.flow?.linear_mass) ??
    toNumber(item.flow?.linearWeight);

  const circularMassRaw =
    toNumber(item.circularMass) ??
    toNumber(item.circular_mass) ??
    toNumber(item.circularWeight) ??
    toNumber(item.circular_weight) ??
    toNumber(item.flow?.circularMass) ??
    toNumber(item.flow?.circular_mass) ??
    toNumber(item.flow?.circularWeight);

  const totalMass =
    totalMassRaw ??
    (linearMassRaw !== undefined && circularMassRaw !== undefined
      ? linearMassRaw + circularMassRaw
      : linearMassRaw ?? circularMassRaw ?? 0);

  const linearMass =
    linearMassRaw ??
    (totalMass !== undefined && circularMassRaw !== undefined ? Math.max(totalMass - circularMassRaw, 0) : totalMass);

  const circularMass =
    circularMassRaw ??
    (totalMass !== undefined && linearMass !== undefined ? Math.max(totalMass - linearMass, 0) : undefined);

  let linearPercentage =
    toNumber(item.linearPercentage) ??
    toNumber(item.linear_percentage) ??
    toNumber(item.linearPercent) ??
    toNumber(item.flow?.linearPercentage) ??
    toNumber(item.flow?.linear_percentage);

  let circularPercentage =
    toNumber(item.circularPercentage) ??
    toNumber(item.circularity) ??
    toNumber(item.circular_percentage) ??
    toNumber(item.circularPercent) ??
    toNumber(item.flow?.circularPercentage) ??
    toNumber(item.flow?.circularity) ??
    toNumber(item.flow?.circular_percentage);

  // Cross-calculation: If one is missing, derive from the other
  if (linearPercentage === undefined && circularPercentage !== undefined) {
    linearPercentage = Math.max(0, 100 - normalizePercentageValue(circularPercentage));
  } else if (circularPercentage === undefined && linearPercentage !== undefined) {
    circularPercentage = Math.max(0, 100 - normalizePercentageValue(linearPercentage));
  }

  // Mass-based fallbacks if still undefined
  if (linearPercentage === undefined && linearMass !== undefined && totalMass) {
    linearPercentage = (linearMass / totalMass) * 100;
  }
  if (circularPercentage === undefined && circularMass !== undefined && totalMass) {
    circularPercentage = (circularMass / totalMass) * 100;
  }

  // Final cross-calculation after mass fallbacks
  if (linearPercentage === undefined && circularPercentage !== undefined) {
    linearPercentage = Math.max(0, 100 - normalizePercentageValue(circularPercentage));
  } else if (circularPercentage === undefined && linearPercentage !== undefined) {
    circularPercentage = Math.max(0, 100 - normalizePercentageValue(linearPercentage));
  }

  linearPercentage = normalizePercentageValue(linearPercentage);
  circularPercentage = normalizePercentageValue(circularPercentage);

  const potentialRecovery =
    toNumber(item.potentialRecovery) ??
    toNumber(item.potentialRecoveryPercentage) ??
    toNumber(item.potentialRecoveryPercent) ??
    toNumber(item.potential_recovery);

  const actualRecovery =
    toNumber(item.actualRecovery) ??
    toNumber(item.actualRecoveryPercentage) ??
    toNumber(item.actualRecoveryPercent) ??
    toNumber(item.actual_recovery);

  return {
    assessments: item.assessments ?? [],
    ...item,
    name,
    totalMass,
    linearMass,
    circularMass,
    circularPercentage,
    linearPercentage,
    potentialRecovery,
    actualRecovery,
  };
}

/**
 * Maps a replacement entry from the service response into the flow item shape
 */
export function mapReplacementToFlow(replacement: any, baseItem: any): any {
  // Ensure baseItem is transformed to have normalized fields
  const transformedBase = transformFlowItem(baseItem);

  const actualPotentialRecovery = normalizePercentageValue(
    replacement?.actualPotentialRecovery ?? replacement?.potentialRecovery ?? transformedBase?.potentialRecovery ?? 0
  );
  const targetPotentialRecovery = normalizePercentageValue(
    replacement?.targetPotentialRecovery ?? actualPotentialRecovery
  );
  const actualActualRecovery = normalizePercentageValue(
    replacement?.actualActualRecovery ??
      replacement?.actualRecovery ??
      transformedBase?.actualActualRecovery ??
      transformedBase?.actualRecovery ??
      0
  );
  const targetActualRecovery = normalizePercentageValue(replacement?.targetActualRecovery ?? actualActualRecovery);

  const mappedReplacement = {
    ...replacement,
    name: replacement?.targetName ?? replacement?.name ?? '',
    weight:
      replacement?.targetMass ??
      replacement?.weight ??
      replacement?.totalMass ??
      transformedBase?.totalMass ??
      transformedBase?.weight,
    totalMass:
      replacement?.targetMass ??
      replacement?.weight ??
      replacement?.totalMass ??
      transformedBase?.totalMass ??
      transformedBase?.weight,
    circularPercentage: normalizePercentageValue(
      replacement?.targetCircularity ?? replacement?.circularPercentage ?? transformedBase?.circularPercentage ?? 0
    ),
    category: replacement?.category ?? transformedBase?.category ?? transformedBase?.flow?.category,
    potentialRecovery: targetPotentialRecovery ?? 0,
    actualRecovery: targetActualRecovery ?? 0,
    baseFlowName: getFlowName(transformedBase),
    baseFlowId: transformedBase?.id ?? transformedBase?.flow?.id,
    replacement: true,
    isReplaced: true,
    isImprovement: false,
    // Store original values for history display
    actualPotentialRecovery: actualPotentialRecovery,
    actualActualRecovery: actualActualRecovery,
    actualMass: transformedBase?.totalMass ?? transformedBase?.weight ?? transformedBase?.mass,
    actualCircularity:
      transformedBase?.circularPercentage ?? transformedBase?.circularity ?? transformedBase?.circularPercent,
    actualLinearPercentage:
      transformedBase?.linearPercentage ??
      (transformedBase?.circularPercentage !== undefined ? 100 - transformedBase?.circularPercentage : undefined),
  };

  return transformFlowItem(mappedReplacement);
}

/**
 * Maps an improvement entry (OUTFLOW only) into the flow item shape
 */
export function mapImprovementToFlow(improvement: any, baseItem: any): any {
  // Ensure baseItem is transformed to have normalized fields
  const transformedBase = transformFlowItem(baseItem);

  const actualPotentialRecovery = normalizePercentageValue(
    improvement?.actualPotentialRecovery ??
      improvement?.potentialRecovery ??
      transformedBase?.actualPotentialRecovery ??
      transformedBase?.potentialRecovery ??
      0
  );
  const actualActualRecovery = normalizePercentageValue(
    improvement?.actualActualRecovery ??
      improvement?.actualRecovery ??
      transformedBase?.actualActualRecovery ??
      transformedBase?.actualRecovery ??
      0
  );

  const mappedImprovement = {
    ...improvement,
    name: improvement?.name ?? getFlowName(transformedBase),
    weight:
      improvement?.targetMass ??
      improvement?.weight ??
      improvement?.totalMass ??
      transformedBase?.totalMass ??
      transformedBase?.weight,
    totalMass:
      improvement?.targetMass ??
      improvement?.weight ??
      improvement?.totalMass ??
      transformedBase?.totalMass ??
      transformedBase?.weight,
    circularPercentage: normalizePercentageValue(
      improvement?.targetCircularity ?? improvement?.circularPercentage ?? transformedBase?.circularPercentage ?? 0
    ),
    category: improvement?.category ?? transformedBase?.category ?? transformedBase?.flow?.category,
    potentialRecovery: normalizePercentageValue(improvement?.targetPotentialRecovery ?? 0),
    actualRecovery: normalizePercentageValue(improvement?.targetActualRecovery ?? 0),
    baseFlowName: getFlowName(transformedBase),
    baseFlowId: transformedBase?.id ?? transformedBase?.flow?.id,
    improvement: true,
    isImprovement: true,
    isReplaced: false,
    // Store original values for history display
    actualPotentialRecovery: actualPotentialRecovery,
    actualActualRecovery: actualActualRecovery,
    actualMass: transformedBase?.totalMass ?? transformedBase?.weight ?? transformedBase?.mass,
    actualCircularity:
      transformedBase?.circularPercentage ?? transformedBase?.circularity ?? transformedBase?.circularPercent,
    actualLinearPercentage:
      transformedBase?.linearPercentage ??
      (transformedBase?.circularPercentage !== undefined ? 100 - transformedBase?.circularPercentage : undefined),
  };

  return transformFlowItem(mappedImprovement);
}

/**
 * Gets flow name from various possible field names
 */
export function getFlowName(item: any): string {
  return (
    item?.name ??
    item?.displayName ??
    item?.tradeName ??
    item?.flowName ??
    item?.flow?.name ??
    item?.flow?.displayName ??
    item?.flow?.tradeName ??
    ''
  );
}

/**
 * Builds a derived list combining originals, replacements, and (for outflows) improvements
 */
export function buildDisplayedList(
  rawItems: any[],
  flowType: 'INFLOWS' | 'OUTFLOWS',
  transformFn: (item: any) => any,
  mapReplacementFn: (replacement: any, baseItem: any) => any,
  mapImprovementFn: (improvement: any, baseItem: any) => any
): any[] {
  if (!Array.isArray(rawItems)) {
    return [];
  }

  const combined: any[] = [];
  const skippedBaseIds = new Set<string>();
  const seenItemIds = new Set<string>();

  const getItemId = (item: any): string => {
    return item?.id ?? item?.flow?.id ?? '';
  };

  const getBaseFlowId = (item: any): string => {
    return item?.baseFlowId ?? item?.flow?.id ?? item?.id ?? '';
  };

  const pushUnique = (mapped: any) => {
    const itemId = getItemId(mapped);
    if (!itemId) {
      combined.push(mapped);
      return;
    }
    if (seenItemIds.has(itemId)) return;
    seenItemIds.add(itemId);
    combined.push(mapped);
  };

  rawItems.forEach((rawItem) => {
    const itemId = getItemId(rawItem);
    const baseFlowId = getBaseFlowId(rawItem);
    const replacements = Array.isArray(rawItem?.replacements) ? rawItem.replacements : [];
    const hasReplacements = replacements.length > 0;
    const hasImprovement = flowType === 'OUTFLOWS' && rawItem?.improvement;

    if (hasReplacements) {
      if (baseFlowId) skippedBaseIds.add(baseFlowId);
      replacements.forEach((replacement) => {
        const mapped = mapReplacementFn(replacement, rawItem);
        pushUnique(mapped);
      });
    } else if (hasImprovement) {
      if (baseFlowId) skippedBaseIds.add(baseFlowId);
      pushUnique(mapImprovementFn(rawItem.improvement, rawItem));
    } else if (rawItem?.replacement || rawItem?.isReplaced || rawItem?.baseFlowId) {
      if (baseFlowId) skippedBaseIds.add(baseFlowId);
      pushUnique(mapReplacementFn(rawItem, rawItem));
    } else {
      if (!skippedBaseIds.has(itemId) && !skippedBaseIds.has(baseFlowId)) {
        const transformedBase = {
          ...transformFn(rawItem),
          isReplaced: false,
          isImprovement: false,
        };
        pushUnique(transformedBase);
      }
    }
  });

  return combined;
}
