import { getFlowName, normalizePercentageValue } from './flow-data-transformer.util';

export function getLegacySortField(sortActive?: string): string | undefined {
  if (!sortActive) {
    return 'NAME';
  }
  const normalized = sortActive.toLowerCase();
  const sortMap: Record<string, string> = {
    name: 'NAME',
    totalmass: 'WEIGHT',
    weight: 'WEIGHT',
  };
  return sortMap[normalized] || (sortActive === 'NAME' || sortActive === 'WEIGHT' ? sortActive : 'CREATION');
}

export function getNodeSortField(sortActive?: string): string | undefined {
  if (!sortActive) {
    return undefined;
  }
  const normalized = sortActive.toLowerCase();
  const sortMap: Record<string, string> = {
    name: 'displayName',
    totalmass: 'weight',
    weight: 'weight',
  };
  return sortMap[normalized] || sortActive;
}

export function getLegacySortDirection(direction?: string): string | undefined {
  if (!direction) {
    return undefined;
  }
  if (direction === 'asc') {
    return 'ASCENDING';
  }
  if (direction === 'desc') {
    return 'DESCENDING';
  }
  return direction;
}

export function getNodeSortDirection(direction?: string): string | undefined {
  if (!direction) {
    return undefined;
  }
  if (direction === 'asc') {
    return 'ASC';
  }
  if (direction === 'desc') {
    return 'DESC';
  }
  return direction;
}

export function getItemBackgroundColor(item: any, selectedScenarioId: string | null, isDraft: boolean): string {
  if (!item) return 'transparent';

  if (!selectedScenarioId) {
    if (isDraft) {
      return '#FFF4E6';
    }
    return 'transparent';
  }

  if (isDraft) {
    return '#FFF4E6';
  }

  const hasSavedImprovement =
    (item?.scenarioImproveFlow || item?.improvement || item?.flow?.improvement) && !item?.temporaryImproveFlow;
  const hasSavedReplacement =
    (item?.scenarioIsReplaced || item?.replacement || item?.flow?.replacement || item?.isReplaced) &&
    !item?.temporaryReplaceFlow;

  if (hasSavedImprovement || hasSavedReplacement) {
    return '#eff8f6';
  }

  return 'transparent';
}

export function shouldShowHistoryButton(
  item: any,
  selectedScenarioId: string | null,
  isImproved: boolean,
  isReplaced: boolean
): boolean {
  if (!item) return false;

  if (!selectedScenarioId) {
    return isImproved || isReplaced;
  }

  const isSavedImproved =
    (item?.scenarioImproveFlow || item?.improvement || item?.flow?.improvement) && !item?.temporaryImproveFlow;
  const isSavedReplaced =
    (item?.scenarioIsReplaced || item?.replacement || item?.flow?.replacement || item?.isReplaced) &&
    !item?.temporaryReplaceFlow;

  return isSavedImproved || isSavedReplaced;
}

export function isImproved(item: any): boolean {
  return (
    !!item?.temporaryImproveFlow || !!item?.scenarioImproveFlow || !!item?.improvement || !!item?.flow?.improvement
  );
}

export function isReplaced(item: any, type: string, replacedFlows: Map<string, Set<string>>): boolean {
  return (
    !!item?.scenarioIsReplaced ||
    !!item?.isReplaced ||
    !!item?.replacement ||
    !!item?.flow?.replacement ||
    (replacedFlows.get(type)?.has(getFlowName(item) || item?.id) ?? false)
  );
}

export function getBaseRowName(item: any, getOriginalItemFn: (item: any) => any): string {
  if (!item) return '';
  const originalItem = getOriginalItemFn(item);
  if (originalItem && originalItem !== item) {
    return getFlowName(originalItem);
  }
  return item.baseFlowName || getFlowName(item);
}

export function getBaseRowWeight(item: any, getOriginalItemFn: (item: any) => any): number {
  if (!item) return 0;
  if (item.actualMass !== undefined) return item.actualMass;
  if (item.actualWeight !== undefined) return item.actualWeight;

  const originalItem = getOriginalItemFn(item);
  if (originalItem && originalItem !== item) {
    return originalItem.totalMass ?? originalItem.weight ?? 0;
  }

  return (
    item.baseBeforeImprove?.weight ??
    item.baseFlowTotalMass ??
    item.__initialSnapshot?.weight ??
    item.totalMass ??
    item.weight ??
    0
  );
}

export function getBaseRowLinearPercentage(item: any, getOriginalItemFn: (item: any) => any): number {
  if (!item) return 0;
  if (item.actualLinearPercentage !== undefined) return normalizePercentageValue(item.actualLinearPercentage);
  if (item.actualCircularity !== undefined) return normalizePercentageValue(100 - item.actualCircularity);

  const originalItem = getOriginalItemFn(item);
  if (originalItem && originalItem !== item) {
    return normalizePercentageValue(
      originalItem.linearPercentage ??
        (originalItem.circularPercentage !== undefined ? 100 - originalItem.circularPercentage : 0)
    );
  }

  return normalizePercentageValue(
    item.baseBeforeImprove?.linearPercentage ??
      (item.baseFlowCircularity !== undefined ? 100 - item.baseFlowCircularity : undefined) ??
      item.__initialSnapshot?.linearPercentage ??
      item.linearPercentage ??
      0
  );
}

export function getOriginalItem(item: any, displayedData: any[], getFlowNameFn: Function): any {
  if (!item) return null;
  if (item.baseFlowId && displayedData) {
    const originalItem = displayedData.find((d) => {
      const matchesId = d.id === item.baseFlowId || d.flow?.id === item.baseFlowId;
      const isOriginal = !d.isReplaced && !d.temporaryReplaceFlow && !d.baseFlowId;
      return matchesId && isOriginal;
    });
    if (originalItem) return originalItem;
    if (item.baseFlowName) {
      const originalByName = displayedData.find((d) => {
        const matchesName = getFlowNameFn(d) === item.baseFlowName;
        const isOriginal = !d.isReplaced && !d.temporaryReplaceFlow && !d.baseFlowId;
        return matchesName && isOriginal;
      });
      if (originalByName) return originalByName;
    }
  }
  return item;
}

export function getBaseRowPotentialRecovery(item: any, getOriginalItemFn: Function): number {
  if (!item) return 0;
  if (item.actualPotentialRecovery !== undefined) return normalizePercentageValue(item.actualPotentialRecovery);
  const originalItem = getOriginalItemFn(item);
  if (originalItem && originalItem !== item) return normalizePercentageValue(originalItem.potentialRecovery ?? 0);
  return normalizePercentageValue(
    item.baseBeforeImprove?.potentialRecovery ??
      item.baseFlowPotentialRecovery ??
      item.__initialSnapshot?.potentialRecovery ??
      item.potentialRecovery ??
      0
  );
}

export function getBaseRowActualRecovery(item: any, getOriginalItemFn: Function): number {
  if (!item) return 0;
  if (item.actualActualRecovery !== undefined) return normalizePercentageValue(item.actualActualRecovery);
  const originalItem = getOriginalItemFn(item);
  if (originalItem && originalItem !== item) return normalizePercentageValue(originalItem.actualRecovery ?? 0);
  return normalizePercentageValue(
    item.baseBeforeImprove?.actualRecovery ??
      item.baseFlowActualRecovery ??
      item.__initialSnapshot?.actualRecovery ??
      item.actualRecovery ??
      0
  );
}

export function getItemWeight(item: any): number {
  if (!item) return 0;
  return (
    item.temporaryReplaceFlow?.weight ??
    item.temporaryImproveFlow?.weight ??
    item.improvement?.targetMass ??
    item.flow?.improvement?.targetMass ??
    item.replacement?.targetMass ??
    item.flow?.replacement?.targetMass ??
    item.totalMass ??
    item.weight ??
    0
  );
}

export function getItemLinearPercentage(item: any): number {
  if (!item) return 0;
  const tempLinear = item.temporaryReplaceFlow?.linearPercentage ?? item.temporaryImproveFlow?.linearPercentage;
  if (tempLinear !== undefined) return normalizePercentageValue(tempLinear);
  const improvementCircularity = item.improvement?.targetCircularity ?? item.flow?.improvement?.targetCircularity;
  if (improvementCircularity !== undefined)
    return normalizePercentageValue(100 - normalizePercentageValue(improvementCircularity));
  const replacementCircularity = item.replacement?.targetCircularity ?? item.flow?.replacement?.targetCircularity;
  if (replacementCircularity !== undefined)
    return normalizePercentageValue(100 - normalizePercentageValue(replacementCircularity));
  return normalizePercentageValue(item.linearPercentage ?? 0);
}

export function getItemPotentialRecovery(item: any): number {
  if (!item) return 0;
  return normalizePercentageValue(
    item.temporaryReplaceFlow?.potentialRecovery ??
      item.temporaryImproveFlow?.potentialRecovery ??
      item.improvement?.targetPotentialRecovery ??
      item.flow?.improvement?.targetPotentialRecovery ??
      item.replacement?.targetPotentialRecovery ??
      item.flow?.replacement?.targetPotentialRecovery ??
      item.potentialRecovery ??
      0
  );
}

export function getItemActualRecovery(item: any): number {
  if (!item) return 0;
  return normalizePercentageValue(
    item.temporaryReplaceFlow?.actualRecovery ??
      item.temporaryImproveFlow?.actualRecovery ??
      item.improvement?.targetActualRecovery ??
      item.flow?.improvement?.targetActualRecovery ??
      item.replacement?.targetActualRecovery ??
      item.flow?.replacement?.targetActualRecovery ??
      item.actualRecovery ??
      0
  );
}

export function getDisplayCircularOutflow(item: any): number {
  if (!item) return 0;
  const potential = getItemPotentialRecovery(item);
  const actual = getItemActualRecovery(item);
  return normalizePercentageValue((potential * actual) / 100);
}

export function getDisplayLinearOutflow(item: any): number {
  if (!item) return 0;
  return normalizePercentageValue(100 - getDisplayCircularOutflow(item));
}

export function getBaseRowCircularOutflow(item: any, getOriginalItemFn: Function): number {
  if (!item) return 0;
  const potential = getBaseRowPotentialRecovery(item, getOriginalItemFn);
  const actual = getBaseRowActualRecovery(item, getOriginalItemFn);
  return normalizePercentageValue((potential * actual) / 100);
}

export function getBaseRowLinearOutflow(item: any, getOriginalItemFn: Function): number {
  if (!item) return 0;
  return normalizePercentageValue(100 - getBaseRowCircularOutflow(item, getOriginalItemFn));
}

export function getDisplayCircularPercentage(item: any): number {
  if (!item) return 0;
  return normalizePercentageValue(100 - getItemLinearPercentage(item));
}

export function getDisplayLinearPercentage(item: any): number {
  if (!item) return 0;
  return getItemLinearPercentage(item);
}
