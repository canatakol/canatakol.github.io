/**
 * Interface for sankey metric data
 */
export interface SankeyMetrics {
  baseValue: number;
  scenarioValue: number;
  delta: number;
  isIncrease: boolean;
}

/**
 * Pure function to compute metric delta between base and scenario values
 * @param baseValue - Base value from localStorage sankey data
 * @param scenarioValue - Scenario value from API response sankey data
 * @returns SankeyMetrics object with baseValue, scenarioValue, delta, and isIncrease flag
 */
export function computeMetricDelta(baseValue: number | undefined, scenarioValue: number | undefined): SankeyMetrics {
  const base = baseValue ?? 0;
  const scenario = scenarioValue !== undefined ? scenarioValue : base;
  const delta = scenario - base;
  const isIncrease = delta > 0;

  return {
    baseValue: base,
    scenarioValue: scenario,
    delta: Math.abs(delta),
    isIncrease,
  };
}

/**
 * Get base sankey data from localStorage
 * @param localStorageService - LocalStorageService instance
 * @returns Base sankey data object or null
 */
export function getBaseSankeyData(localStorageService: any): any | null {
  try {
    const aggregateData = localStorageService.getCompressedItem(localStorageService.AGGREGATE_DATA_KEY);
    return aggregateData?.sankey ?? aggregateData?.aggregate?.sankey ?? null;
  } catch (error) {
    console.error('Error reading base sankey data from localStorage:', error);
    return null;
  }
}
