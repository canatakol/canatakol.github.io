import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
declare var $: any;
@Component({
  selector: 'app-nature-impact',
  templateUrl: './nature-impact.component.html',
  styleUrls: ['./nature-impact.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class NatureImpactComponent implements OnInit {
  @Input() public data: string;
  @Input() public isReport: boolean;
  alphabet = 'ABCD'.split('');
  storyblok;
  unitId = this.route.snapshot.params.unitId;
  selectedExtent;
  alternatives = null;
  selectedCondition;
  selectedSignifican;
  environment = environment;
  extentValue;
  conditiontValue;
  significanValue;
  natureImpactmaxValue;
  natureImpactExtentList = environment.services.natureImpactExtentList;
  natureImpactConditionList = environment.services.natureImpactConditionList;
  natureImpactSignificancenList = environment.services.natureImpactSignificancenList;
  constructor(
    private storyblokService: StoryblokService,
    private route: ActivatedRoute,
    private http: ApiRequestService
  ) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step-3-top-boxes');
      this.storyblok = story[0].content;
    });
    if (this.data['conditionDimension']) {
      this.conditiontValue = this.data['conditionDimension'];
      this.changeCondition(this.conditiontValue);
    }
    if (this.data['extendDimension']) {
      this.extentValue = this.data['extendDimension'];
      this.changeExtent(this.extentValue);
    }
    if (this.data['significanceDimension']) {
      this.significanValue = this.data['significanceDimension'];
      this.changeSignificancen(this.significanValue);
    }
    this.getAlternatives();
  }

  getAlternatives() {
    this.http
      .callService(new Method(environment.services.natureImpactImprovement(this.unitId), '', 'get'))
      .subscribe((res) => {
        if (res['alternatives'].length > 0) {
          this.alternatives = res['alternatives'];
          this.alternatives.unshift(this.data);
          const natureImpactValues = [];
          this.alternatives.forEach((element) => {
            natureImpactValues.push(element.natureImpact);
          });
          this.natureImpactmaxValue = Math.max(...natureImpactValues);
        }
      });
  }

  changeExtent(value: any) {
    this.natureImpactExtentList.forEach((element) => {
      if (value === element.extendDimension) {
        this.selectedExtent = element;
      }
    });
  }
  changeCondition(value: any) {
    this.natureImpactConditionList.forEach((element) => {
      if (value === element.conditionDimension) {
        this.selectedCondition = element;
      }
    });
  }
  changeSignificancen(value: any) {
    this.natureImpactSignificancenList.forEach((element) => {
      if (value === element.significanceDimension) {
        this.selectedSignifican = element;
      }
    });
  }
}
