import {
  Component,
  Input,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { CiqNumberPipe } from '@app/pipes';
import { environment } from '@env/environment';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';

declare var $: any;

@Component({
  selector: 'app-sankey-info-overlay',
  templateUrl: './sankey-info-overlay.component.html',
  styleUrls: ['./sankey-info-overlay.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, MatSlideToggleModule, CiqNumberPipe, CommentBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SankeyInfoOverlayComponent implements OnInit, OnChanges {
  // Original inputs
  @Input() public importData: any;
  @Input() public isReport: string;
  @Input() public isBreakdown: boolean = false;
  @Input() public isDashboard: boolean = false;
  @Input() public isProcurement: boolean = false;
  @Input() public isFlows: boolean = false;

  // New overlay inputs
  @Input() public baseSankeyData: any;
  @Input() public overlaySankeyData?: any;
  @Input() public overlayType?: 'INFLOW' | 'OUTFLOW';
  // Alternative: separate inputs for inflow/outflow overlays (for simultaneous overlay support)
  @Input() public inflowOverlayData?: any;
  @Input() public outflowOverlayData?: any;

  data;
  baseData; // Holds the base sankey data for comparison
  overlayData; // Holds the overlay/scenario data (for single overlayType mode)
  inflowOverlay; // Holds inflow overlay data (for dual overlay mode)
  outflowOverlay; // Holds outflow overlay data (for dual overlay mode)
  organizationGoal;
  isEnabledCTIGoal;
  storyblok;
  goalsWiev = false;
  environment = environment;
  isDashboardPage: boolean = false;

  constructor(
    private http: ApiRequestService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private commonService: CommonService,
    private cdr: ChangeDetectorRef
  ) {
    this.organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
    this.isEnabledCTIGoal = JSON.parse(localStorage.getItem('isEnabledCTIGoal'));
  }

  ngOnInit(): void {
    this.setDataFromImport();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'sankey-chart');
      this.storyblok = story[0].content;
      this.cdr.markForCheck();
    });
    this.isDashboardPage = window.location.href.includes('dashboard');
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (
      (changes['importData'] && !changes['importData'].firstChange) ||
      (changes['baseSankeyData'] && !changes['baseSankeyData'].firstChange) ||
      (changes['overlaySankeyData'] && !changes['overlaySankeyData'].firstChange) ||
      (changes['inflowOverlayData'] && !changes['inflowOverlayData'].firstChange) ||
      (changes['outflowOverlayData'] && !changes['outflowOverlayData'].firstChange)
    ) {
      this.setDataFromImport();
      this.cdr.markForCheck();
    }
  }

  private setDataFromImport(): void {
    // Handle base sankey data (new overlay mode)
    if (this.baseSankeyData) {
      const baseSource = this.baseSankeyData['sankey'] ? this.baseSankeyData['sankey'] : this.baseSankeyData;
      this.baseData = baseSource;
      this.data = baseSource; // Use base data as default
    } else if (this.importData) {
      // Fallback to original behavior
      this.data = this.importData['sankey'] ? this.importData['sankey'] : this.importData;
      this.baseData = this.data;
    } else {
      this.data = null;
      this.baseData = null;
    }

    // Handle overlay sankey data (single overlay mode)
    if (this.overlaySankeyData) {
      this.overlayData = this.overlaySankeyData['sankey'] ? this.overlaySankeyData['sankey'] : this.overlaySankeyData;
    } else {
      this.overlayData = null;
    }

    // Handle separate inflow/outflow overlay data (dual overlay mode)
    if (this.inflowOverlayData) {
      this.inflowOverlay = this.inflowOverlayData['sankey'] ? this.inflowOverlayData['sankey'] : this.inflowOverlayData;
    } else {
      this.inflowOverlay = null;
    }

    if (this.outflowOverlayData) {
      this.outflowOverlay = this.outflowOverlayData['sankey']
        ? this.outflowOverlayData['sankey']
        : this.outflowOverlayData;
    } else {
      this.outflowOverlay = null;
    }
  }

  /**
   * Check if overlay should be shown for inflow side
   * Supports both single overlayType mode and dual overlay mode
   */
  hasInflowOverlay(): boolean {
    // Dual overlay mode: check inflowOverlay directly
    if (this.inflowOverlay != null) {
      return true;
    }
    // Single overlay mode: check overlayType
    return this.overlayType === 'INFLOW' && this.overlayData != null;
  }

  /**
   * Check if overlay should be shown for outflow side
   * Supports both single overlayType mode and dual overlay mode
   */
  hasOutflowOverlay(): boolean {
    // Dual overlay mode: check outflowOverlay directly
    if (this.outflowOverlay != null) {
      return true;
    }
    // Single overlay mode: check overlayType
    return this.overlayType === 'OUTFLOW' && this.overlayData != null;
  }

  /**
   * Get the effective inflow overlay data
   */
  private getInflowOverlayData(): any {
    return this.inflowOverlay ?? (this.overlayType === 'INFLOW' ? this.overlayData : null);
  }

  /**
   * Get the effective outflow overlay data
   */
  private getOutflowOverlayData(): any {
    return this.outflowOverlay ?? (this.overlayType === 'OUTFLOW' ? this.overlayData : null);
  }

  /**
   * Get the overlay value for a specific field (inflow fields)
   */
  getInflowOverlayValue(field: string): any {
    return this.getInflowOverlayData()?.[field];
  }

  /**
   * Get the overlay value for a specific field (outflow fields)
   */
  getOutflowOverlayValue(field: string): any {
    return this.getOutflowOverlayData()?.[field];
  }

  /**
   * Get the overlay value for a specific field
   * Legacy method - determines type based on field name prefix
   */
  getOverlayValue(field: string): any {
    if (field.startsWith('inflow') || field === 'inflowCircularPercentage' || field === 'inflowLinearPercentage') {
      return this.getInflowOverlayValue(field);
    }
    return this.getOutflowOverlayValue(field);
  }

  /**
   * Check if a field has an overlay value different from base (inflow)
   */
  hasInflowOverlayDifference(field: string): boolean {
    const overlayData = this.getInflowOverlayData();
    if (!overlayData || !this.baseData) return false;
    return overlayData[field] !== this.baseData[field];
  }

  /**
   * Check if a field has an overlay value different from base (outflow)
   */
  hasOutflowOverlayDifference(field: string): boolean {
    const overlayData = this.getOutflowOverlayData();
    if (!overlayData || !this.baseData) return false;
    return overlayData[field] !== this.baseData[field];
  }

  /**
   * Check if a field has an overlay value different from base
   * Legacy method - determines type based on field name
   */
  hasOverlayDifference(field: string): boolean {
    if (field.startsWith('inflow') || field === 'inflowCircularPercentage' || field === 'inflowLinearPercentage') {
      return this.hasInflowOverlayDifference(field);
    }
    return this.hasOutflowOverlayDifference(field);
  }

  /**
   * Calculate delta between base and overlay for inflow fields
   */
  getInflowDelta(field: string): number | null {
    const baseVal = this.baseData?.[field];
    const overlayVal = this.getInflowOverlayValue(field);
    if (baseVal == null || overlayVal == null) return null;
    return Number(overlayVal) - Number(baseVal);
  }

  /**
   * Calculate delta between base and overlay for outflow fields
   */
  getOutflowDelta(field: string): number | null {
    const baseVal = this.baseData?.[field];
    const overlayVal = this.getOutflowOverlayValue(field);
    if (baseVal == null || overlayVal == null) return null;
    return Number(overlayVal) - Number(baseVal);
  }

  /**
   * Determine if delta represents an improvement for inflow
   * For percentages: higher is better (circular)
   * For linear: lower is better
   */
  getInflowChangeType(field: string): 'improvement' | 'decline' | 'neutral' {
    const delta = this.getInflowDelta(field);
    if (delta == null || Math.abs(delta) < 0.01) return 'neutral';

    // For circular percentage fields, increase is improvement
    if (field.includes('Circular')) {
      return delta > 0 ? 'improvement' : 'decline';
    }
    // For linear fields, decrease is improvement
    if (field.includes('Linear')) {
      return delta < 0 ? 'improvement' : 'decline';
    }
    return 'neutral';
  }

  /**
   * Determine if delta represents an improvement for outflow
   */
  getOutflowChangeType(field: string): 'improvement' | 'decline' | 'neutral' {
    const delta = this.getOutflowDelta(field);
    if (delta == null || Math.abs(delta) < 0.01) return 'neutral';

    // For circular/recovery percentage fields, increase is improvement
    if (field.includes('Circular') || field.includes('Recovery') || field.includes('Actual')) {
      return delta > 0 ? 'improvement' : 'decline';
    }
    // For linear/non fields, decrease is improvement
    if (field.includes('Linear') || field.includes('Non')) {
      return delta < 0 ? 'improvement' : 'decline';
    }
    return 'neutral';
  }

  /**
   * Format delta value for display
   */
  formatDelta(delta: number | null, isPercentage: boolean = true): string {
    if (delta == null) return '';
    const sign = delta > 0 ? '+' : '';
    const formatted = isPercentage ? delta.toFixed(2) : delta.toFixed(3);
    return `${sign}${formatted}${isPercentage ? '%' : ' kg'}`;
  }

  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }

  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }

  /**
   * Check if scenario value is growing (higher than base)
   */
  isInflowGrowth(field: string): boolean {
    if (!this.hasInflowOverlay()) return false;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getInflowOverlayValue(field) ?? 0;
    return overlay > base;
  }

  isOutflowGrowth(field: string): boolean {
    if (!this.hasOutflowOverlay()) return false;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getOutflowOverlayValue(field) ?? 0;
    return overlay > base;
  }

  /**
   * Calculate gradient stop percentage for growth visualization
   * Returns the percentage where base color ends and 80% opacity begins
   */
  getInflowGradientStop(field: string): number {
    if (!this.hasInflowOverlay()) return 100;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getInflowOverlayValue(field) ?? 0;
    if (overlay <= base || overlay === 0) return 100;
    // Calculate base height as percentage of total height
    const baseHeight = base * 2 + 30;
    const overlayHeight = overlay * 2 + 30;
    return (baseHeight / overlayHeight) * 100;
  }

  getOutflowGradientStop(field: string): number {
    if (!this.hasOutflowOverlay()) return 100;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getOutflowOverlayValue(field) ?? 0;
    if (overlay <= base || overlay === 0) return 100;
    // Calculate base height as percentage of total height
    const baseHeight = base * 2 + 30;
    const overlayHeight = overlay * 2 + 30;
    return (baseHeight / overlayHeight) * 100;
  }

  /**
   * Calculate growth percentage: ((overlay - base) / base) * 100
   */
  getInflowGrowthPercentage(field: string): number | null {
    if (!this.isInflowGrowth(field)) return null;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getInflowOverlayValue(field) ?? 0;
    if (base === 0) return null;
    return ((overlay - base) / base) * 100;
  }

  getOutflowGrowthPercentage(field: string): number | null {
    if (!this.isOutflowGrowth(field)) return null;
    const base = this.baseData?.[field] ?? 0;
    const overlay = this.getOutflowOverlayValue(field) ?? 0;
    if (base === 0) return null;
    return ((overlay - base) / base) * 100;
  }
}
