import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { environment } from '@env/environment';
import { CommentBadgeComponent, Comment } from '../comment-badge/comment-badge.component';

@Component({
  selector: 'app-packaging',
  templateUrl: './packaging.component.html',
  styleUrls: ['./packaging.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe, CommentBadgeComponent],
})
export class PackagingComponent implements OnInit {
  @Input() public packagingData: any;
  @Input() public report: boolean;
  @Input() public dashboardId: string;
  @ViewChild('commentBadge') commentBadge!: CommentBadgeComponent;
  storyblok;
  environment = environment;

  constructor(private storyblokService: StoryblokService) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'packaging');
      this.storyblok = story[0].content;
    });
  }
}
