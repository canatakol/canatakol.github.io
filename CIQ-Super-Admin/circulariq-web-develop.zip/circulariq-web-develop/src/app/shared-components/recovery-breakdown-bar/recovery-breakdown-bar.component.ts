import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { environment } from '@env/environment';
@Component({
  selector: 'app-recovery-breakdown-bar',
  templateUrl: './recovery-breakdown-bar.component.html',
  styleUrls: ['./recovery-breakdown-bar.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class RecoveryBreakdownBarComponent implements OnInit {
  @Input() public data: string;
  @Input() public lifetimeExtension: string;
  showTooltip = false;
  unitId = this.route.snapshot.params.unitId;
  @Input() public report: boolean;
  storyblok;
  showType = '';
  chartData;
  breakdown;
  environment = environment;
  constructor(private storyblokService: StoryblokService, private router: Router, private route: ActivatedRoute) {}
  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step4-dashboard');
      const breakdown = data.filter((item) => item.slug === 'recovery-breakdown');
      this.storyblok = story[0].content;
      this.breakdown = breakdown[0].content.recovery_breakdown.tbody;

      this.breakdown.forEach((item) => {
        this.data['recoveryType']['technical'].forEach((technical) => {
          if (item.body[0].value === technical.name) {
            technical.name = item.body[1].value;
          }
        });
        this.data['recoveryType']['nonFood'].forEach((nonFood) => {
          if (item.body[0].value === nonFood.name) {
            nonFood.name = item.body[1].value;
          }
        });
        this.data['recoveryType']['food'].forEach((food) => {
          if (item.body[0].value === food.name) {
            food.name = item.body[1].value;
          }
        });
      });

      this.data['recoveryType'].breakdown.forEach((element) => {
        if (element.percentage === 100) {
          switch (element.name) {
            case 'biological':
              this.showType = 'nonFood';
              this.chartData = this.data['recoveryType']['nonFood'];
              break;
            case 'foodAndFeed':
              this.chartData = this.data['recoveryType']['food'];
              this.showType = 'food';
              break;
            case 'unknown':
              this.chartData = null;
              break;
            default:
              this.showType = 'technical';
              this.chartData = this.data['recoveryType']['technical'];
              break;
          }
        }
      });
      this.data['recoveryType'].breakdown.forEach((item) => {
        switch (item.name) {
          case 'technical':
            item.storyblok = this.storyblok.technical;
            break;
          case 'biological':
            item.storyblok = this.storyblok.bological_cycle_non_food;
            break;
          case 'foodAndFeed':
            item.storyblok = this.storyblok.biological_cycle_food;
            break;
          default:
            item.storyblok = this.storyblok.recovery_type_other;
            break;
        }
      });
    });
  }
  goToTheStep2(item: string) {
    this.router.navigateByUrl(`/cti/${this.unitId}/assessment/step2`, { state: { selectedProduct: item } });
  }
}
