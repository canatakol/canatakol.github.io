import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { environment } from '@env/environment';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';
@Component({
  selector: 'app-recovery-breakdown',
  templateUrl: './recovery-breakdown.component.html',
  styleUrls: ['./recovery-breakdown.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe, CommentBadgeComponent],
})
export class RecoveryBreakdownComponent implements OnInit {
  @Input() public data: string;
  @Input() public lifetimeExtension: string;
  showTooltip = false;
  unitId = this.route.snapshot.params.unitId;
  @Input() public report: boolean;
  storyblok;
  breakdown;
  environment = environment;
  constructor(private storyblokService: StoryblokService, private router: Router, private route: ActivatedRoute) {}
  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step4-dashboard');
      const breakdown = data.filter((item) => item.slug === 'recovery-breakdown');
      this.storyblok = story[0].content;
      this.breakdown = breakdown[0].content.recovery_breakdown.tbody;
      this.breakdown.forEach((item) => {
        this.data['recoveryType']['technical'].forEach((technical) => {
          if (item.body[0].value === technical.name) {
            technical.name = item.body[1].value;
          }
        });
        this.data['recoveryType']['nonFood'].forEach((nonFood) => {
          if (item.body[0].value === nonFood.name) {
            nonFood.name = item.body[1].value;
          }
        });
        this.data['recoveryType']['food'].forEach((food) => {
          if (item.body[0].value === food.name) {
            food.name = item.body[1].value;
          }
        });
      });
    });
  }
  goToTheStep2(item: string) {
    this.router.navigateByUrl(`/cti/${this.unitId}/assessment/step2`, { state: { selectedProduct: item } });
  }
}
