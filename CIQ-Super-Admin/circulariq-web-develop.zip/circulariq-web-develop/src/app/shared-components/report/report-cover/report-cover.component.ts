import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-report-cover',
  templateUrl: './report-cover.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class ReportCoverComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
}
