import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';

@Component({
  selector: 'app-material-analysis-outflow',
  standalone: true,
  templateUrl: './material-analysis-outflow.component.html',
  imports: [CommonModule, CiqNumberPipe, TruncatePipe],
})
export class MaterialAnalysisOutflowComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() mainPage: any;
  @Input() step5Content: any;
  @Input() outflowAnalysis: any;
}
