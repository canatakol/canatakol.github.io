import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-water-analysis',
  standalone: true,
  templateUrl: './water-analysis.component.html',
  imports: [CommonModule, CiqNumberPipe],
})
export class WaterAnalysisComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() waterData: any;
  @Input() step5Content: any;
  @Input() mainPage: any;
}
