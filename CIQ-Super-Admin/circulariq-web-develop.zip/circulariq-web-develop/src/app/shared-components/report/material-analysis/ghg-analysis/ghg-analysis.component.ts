import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';

@Component({
  selector: 'app-ghg-analysis',
  standalone: true,
  templateUrl: './ghg-analysis.component.html',
  imports: [CommonModule, CiqNumberPipe, TruncatePipe],
})
export class GhgAnalysisComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() stepper: any;
  @Input() step5Ghg: any;
  @Input() step5OutflowGhg: any;
  @Input() ghgData: any;
  @Input() mainPage: any;
  @Input() outflowGhgWidth = '0%';
}
