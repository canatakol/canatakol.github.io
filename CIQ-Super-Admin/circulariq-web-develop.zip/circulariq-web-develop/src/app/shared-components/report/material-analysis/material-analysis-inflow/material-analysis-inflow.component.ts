import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';

@Component({
  selector: 'app-material-analysis-inflow',
  standalone: true,
  templateUrl: './material-analysis-inflow.component.html',
  imports: [CommonModule, CiqNumberPipe, TruncatePipe],
})
export class MaterialAnalysisInflowComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() mainPage: any;
  @Input() step5Content: any;
  @Input() inflowAnalysis: any;
}
