import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-energy-analysis',
  standalone: true,
  templateUrl: './energy-analysis.component.html',
  imports: [CommonModule, CiqNumberPipe],
})
export class EnergyAnalysisComponent {
  @Input() imgUrl: string;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() energyData: any;
  @Input() step5Content: any;
  @Input() mainPage: any;
}
