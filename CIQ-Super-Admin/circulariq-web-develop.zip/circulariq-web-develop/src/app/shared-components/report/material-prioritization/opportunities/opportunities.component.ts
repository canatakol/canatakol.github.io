import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-opportunities',
  templateUrl: './opportunities.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class OpportunitiesComponent {
  @Input() opportunitiesData: any; // opportunities data from step6
  @Input() step6: any;
  @Input() title: string; // "Inflow", "Outflow", "Water", "Energy"
  @Input() ctireport: any;
}
