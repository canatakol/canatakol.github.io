import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RiskAssessmentComponent } from '../risk-assessment/risk-assessment.component';
import { PriorityChartComponent } from '../priority-chart/priority-chart.component';
import { OpportunitiesComponent } from '../opportunities/opportunities.component';

@Component({
  selector: 'app-prioritization-section',
  templateUrl: './prioritization-section.component.html',
  standalone: true,
  imports: [CommonModule, RiskAssessmentComponent, PriorityChartComponent, OpportunitiesComponent],
})
export class PrioritizationSectionComponent implements OnInit {
  @Input() imgUrl: string;
  @Input() content: any; // all content
  @Input() riskData: any; // e.g., content.step6.inflow
  @Input() step6: any;
  @Input() ctireport: any;
  @Input() pageindex: number[];
  @Input() title: string; // e.g., step6.inflow
  @Input() type: 'inflow' | 'outflow' | 'water' | 'energy';
  @Input() showInfoBox: boolean = false; // Only for inflow/outflow
  @Input() infoNote1?: string;
  @Input() infoNote2?: string;

  hasRisksData: boolean = false;
  hasOpportunitiesData: boolean = false;
  showSection: boolean = false;

  ngOnInit() {
    this.checkDataAvailability();
  }

  private checkDataAvailability() {
    if (!this.riskData) {
      this.showSection = false;
      return;
    }
    this.hasRisksData = this.hasAnyRiskData();
    this.hasOpportunitiesData = this.hasAnyOpportunitiesData();
    this.showSection = this.hasRisksData || this.hasOpportunitiesData;
  }

  private hasAnyRiskData(): boolean {
    const data = this.riskData;
    if (!data) return false;

    const hasTextData = !!(
      this.hasContent(data.market) ||
      this.hasContent(data.operational) ||
      this.hasContent(data.business) ||
      this.hasContent(data.legal)
    );
    const hasScoreData = !!(
      data.marketThreat ||
      data.marketVulnerability ||
      data.operationalThreat ||
      data.operationalVulnerability ||
      data.businessThreat ||
      data.businessVulnerability ||
      data.legalThreat ||
      data.legalVulnerability
    );
    const hasBubbleChartData = this.hasBubbleChart();

    return hasTextData || hasScoreData || hasBubbleChartData;
  }

  private hasBubbleChart(): boolean {
    const data = this.riskData;
    if (!data) {
      return false;
    }

    const hasMaterials = data.materials && Array.isArray(data.materials) && data.materials.length > 0;
    const hasBubbleData = data.bubbleData && Array.isArray(data.bubbleData) && data.bubbleData.length > 0;
    const hasChartData = data.chartData && Array.isArray(data.chartData) && data.chartData.length > 0;
    const hasCoordinates = data.x !== undefined && data.y !== undefined;
    const hasPriority = this.hasPriorityData(data);
    return !!(hasMaterials || hasBubbleData || hasChartData || hasCoordinates || hasPriority);
  }

  private hasPriorityData(data: any): boolean {
    return !!(
      data.priority ||
      data.priorityScore ||
      data.riskScore ||
      data.vulnerabilityScore ||
      (typeof data.threat === 'number' && typeof data.vulnerability === 'number')
    );
  }

  private hasAnyOpportunitiesData(): boolean {
    const data = this.riskData;
    if (!data) return false;

    return !!(
      this.hasContent(data.opportunitiesMarket) ||
      this.hasContent(data.opportunitiesOperational) ||
      this.hasContent(data.opportunitiesBusiness) ||
      this.hasContent(data.opportunitiesLegal)
    );
  }

  private hasContent(value: any): boolean {
    return value && typeof value === 'string' && value.trim().length > 0;
  }
}
