import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-risk-assessment',
  templateUrl: './risk-assessment.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class RiskAssessmentComponent {
  @Input() riskData: any; // content.step6.inflow or content.step6.outflow
  @Input() step6: any;
  @Input() ctireport: any;
  @Input() pageindex: number[] = [1, 2, 3, 4, 5, 6, 7];
}
