import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BubbleChartComponent } from '@app/assessment-level/step6/bubble-chart/bubble-chart.component';

@Component({
  selector: 'app-priority-chart',
  templateUrl: './priority-chart.component.html',
  standalone: true,
  imports: [CommonModule, BubbleChartComponent],
})
export class PriorityChartComponent {
  @Input() data: any; // Bubble chart data
  @Input() type: 'inflow' | 'outflow' | 'energy' | 'water' | 'critical';
}
