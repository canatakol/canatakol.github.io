import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-top-materials',
  templateUrl: './top-materials.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class TopMaterialsComponent {
  @Input() materials: any[]; // Top materials list
  @Input() type: 'inflow' | 'outflow';
  @Input() step6: any;
}
