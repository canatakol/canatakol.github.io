import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-circular-productivity',
  templateUrl: './circular-productivity.component.html',
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class CircularProductivityComponent {
  @Input() imgUrl: string;
  @Input() productivityData: any; // content.detailedUnit.productivity
  @Input() dashboard: any;
  @Input() ctireport: any;
}
