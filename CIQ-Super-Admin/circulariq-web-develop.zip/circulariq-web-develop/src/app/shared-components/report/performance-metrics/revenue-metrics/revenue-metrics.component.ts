import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-revenue-metrics',
  templateUrl: './revenue-metrics.component.html',
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class RevenueMetricsComponent {
  @Input() imgUrl: string;
  @Input() revenueData: any; // content.detailedUnit.ctiRevenue
  @Input() dashboard: any;
  @Input() ctireport: any;
}
