import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-ghg-impact',
  templateUrl: './ghg-impact.component.html',
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class GhgImpactComponent {
  @Input() imgUrl: string;
  @Input() ghgData: any; // content.detailedUnit.ghgOrganisationData
  @Input() dashboard: any;
  @Input() ctireport: any;
  @Input() showTitle: boolean = true;
}
