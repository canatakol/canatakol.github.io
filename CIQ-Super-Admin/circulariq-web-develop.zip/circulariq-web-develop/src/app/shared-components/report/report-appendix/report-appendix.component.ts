import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-report-appendix',
  templateUrl: './report-appendix.component.html',
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe],
})
export class ReportAppendixComponent {
  @Input() content: any;
  @Input() ctireport: any;
  @Input() step5: any;
  @Input() appendixInflowMaterialsPage: any[];
  @Input() appendixOutflowMaterialsPage: any[];
}
