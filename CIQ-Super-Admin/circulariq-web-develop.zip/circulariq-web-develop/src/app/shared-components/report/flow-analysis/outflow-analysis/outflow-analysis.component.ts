import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { SankeyInfoComponent } from '@app/shared-components/sankey-info/sankey-info.component';

@Component({
  selector: 'app-outflow-analysis',
  templateUrl: './outflow-analysis.component.html',
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe, SankeyInfoComponent],
})
export class OutflowAnalysisComponent {
  @Input() imgUrl: string;
  @Input() content: any; // full content for sankey and outflow
  @Input() ctireport: any;
  @Input() dashboard: any;
  @Input() packagingText: any;
}
