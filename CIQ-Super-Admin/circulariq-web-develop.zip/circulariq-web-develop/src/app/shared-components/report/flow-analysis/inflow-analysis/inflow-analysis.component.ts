import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-inflow-analysis',
  templateUrl: './inflow-analysis.component.html',
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe],
})
export class InflowAnalysisComponent {
  @Input() imgUrl: string;
  @Input() inflowDetails: any; // content.inflowDetails
  @Input() ctireport: any;
}
