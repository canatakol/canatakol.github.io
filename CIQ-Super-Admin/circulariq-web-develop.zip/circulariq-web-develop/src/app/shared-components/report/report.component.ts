import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { saveAs } from '@progress/kendo-file-saver';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { SankeyInfoComponent } from '@app/shared-components/sankey-info/sankey-info.component';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
import { CriticalInflowComponent } from '@app/shared-components/critical-inflow/critical-inflow.component';
import { RecoveryBreakdownComponent } from '@app/shared-components/recovery-breakdown/recovery-breakdown.component';
import { ActualLifetimeComponent } from '@app/shared-components/actual-lifetime/actual-lifetime.component';
import { NatureImpactComponent } from '@app/shared-components/nature-impact/nature-impact.component';
// Cover & Container
import { ReportCoverComponent } from './report-cover/report-cover.component';
import { ReportAppendixComponent } from './report-appendix/report-appendix.component';
// Summary Components ✅
import { CompanyInfoComponent } from './summary/company-info/company-info.component';
import { IndicatorGridComponent } from './summary/indicator-grid/indicator-grid.component';
import { ExcludedItemsComponent } from './summary/excluded-items/excluded-items.component';
import { PerformanceOverviewComponent } from './summary/performance-overview/performance-overview.component';
// Flow Analysis Components ✅
import { InflowAnalysisComponent } from './flow-analysis/inflow-analysis/inflow-analysis.component';
import { OutflowAnalysisComponent } from './flow-analysis/outflow-analysis/outflow-analysis.component';
// Material Analysis Components (Step 5)
import { MaterialAnalysisInflowComponent } from './material-analysis/material-analysis-inflow/material-analysis-inflow.component';
import { MaterialAnalysisOutflowComponent } from './material-analysis/material-analysis-outflow/material-analysis-outflow.component';
import { EnergyAnalysisComponent } from './material-analysis/energy-analysis/energy-analysis.component';
import { WaterAnalysisComponent } from './material-analysis/water-analysis/water-analysis.component';
import { GhgAnalysisComponent } from './material-analysis/ghg-analysis/ghg-analysis.component';
// Performance Metrics Components ✅
import { GhgImpactComponent } from './performance-metrics/ghg-impact/ghg-impact.component';
import { CircularProductivityComponent } from './performance-metrics/circular-productivity/circular-productivity.component';
import { RevenueMetricsComponent } from './performance-metrics/revenue-metrics/revenue-metrics.component';
// Material Prioritization Components ✅
import { PrioritizationSectionComponent } from './material-prioritization/prioritization-section/prioritization-section.component';
// Action Planning Components ✅
import { TargetCardComponent } from './action-planning/target-card/target-card.component';
import { SmartDetailsComponent } from './action-planning/smart-details/smart-details.component';
import { StakeholderListComponent } from './action-planning/stakeholder-list/stakeholder-list.component';

declare var $: any;
@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: [`../../../assets/report.css`],
  standalone: true,
  imports: [
    CommonModule,
    CiqNumberPipe,
    SankeyInfoComponent,
    LoadingBarComponent,
    CriticalInflowComponent,
    RecoveryBreakdownComponent,
    ActualLifetimeComponent,
    NatureImpactComponent,
    // Cover & Container
    ReportCoverComponent,
    ReportAppendixComponent,
    // Summary Components ✅
    CompanyInfoComponent,
    IndicatorGridComponent,
    ExcludedItemsComponent,
    PerformanceOverviewComponent,
    // Flow Analysis Components ✅
    InflowAnalysisComponent,
    OutflowAnalysisComponent,
    // Material Analysis Components (Step 5)
    MaterialAnalysisInflowComponent,
    MaterialAnalysisOutflowComponent,
    EnergyAnalysisComponent,
    WaterAnalysisComponent,
    GhgAnalysisComponent,
    // Performance Metrics Components ✅
    GhgImpactComponent,
    CircularProductivityComponent,
    RevenueMetricsComponent,
    // Material Prioritization Components ✅
    PrioritizationSectionComponent,
    // Action Planning Components ✅
    TargetCardComponent,
    SmartDetailsComponent,
    StakeholderListComponent,
  ],
})
export class ReportComponent {
  environment = environment;
  reportCSS;
  fontStyles = this.environment.fileUrl + 'font.css';
  imgUrl = this.environment.fileUrl;
  unitId = this.route.snapshot.params.unitId;
  authToken = this.route.snapshot.params.authToken;
  content;
  data;
  stepper;
  step2;
  step5;
  step6;
  step7;
  packagingText;
  dashboard;
  ctireport;
  lang = 'en';
  page = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25];
  download = true;
  pageindex = [1, 2, 3, 4, 5, 6, 7];
  alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
  showReport = false;
  reportName = 'report.pdf';
  appendixInflowMaterialsPage = [];
  appendixOutflowMaterialsPage = [];
  recoveryTypeBarVersionShow = false;
  constructor(
    private route: ActivatedRoute,
    private http: ApiRequestService,
    private sanitizer: DomSanitizer,
    private storyblokService: StoryblokService
  ) {
    this.reportCSS = this.environment.reportCSS;
    this.storyblokService.getStoryService().then((data) => {
      const stepper = data.filter((item) => item.slug === 'stepper');
      this.stepper = stepper[0].content;
      const ctireport = data.filter((item) => item.slug === 'cti-report');
      this.ctireport = ctireport[0].content;
      this.ctireport.description = this.ctireport.description.content[0].content[0].text;
      const step2 = data.filter((item) => item.slug === 'step2');
      this.step2 = step2[0].content;
      const step5 = data.filter((item) => item.slug === 'step5');
      this.step5 = step5[0].content;
      const step6 = data.filter((item) => item.slug === 'step6');
      this.step6 = step6[0].content;
      const step7 = data.filter((item) => item.slug === 'step7');
      this.step7 = step7[0].content;
      const dashboard = data.filter((item) => item.slug === 'step4-dashboard');
      this.dashboard = dashboard[0].content;
      const packagingText = data.filter((item) => item.slug === 'packaging');
      this.packagingText = packagingText[0].content;
      this.flowComplate('CTI_REPORT_DONE');
      this.getReport();
    });
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    fetch(environment.serverUrl + environment.services.guidance(), {
      headers: {
        'x-auth-token': this.authToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
      method: 'PUT',
    });
  }

  calcPercentage(data: any) {
    if (data.improvedMaterials?.length > 0) {
      const largestImprovedMaterials = Math.max.apply(
        Math,

        data.improvedMaterials.map(function (o) {
          return o.potentialGhgSavings;
        })
      );

      data.potentialImprovementResult = Number(
        data.improvedMaterials.reduce((n, { potentialGhgSavings }) => n + potentialGhgSavings, 0)
      );
      data.scenarioResult = Number(
        data.improvedMaterials.reduce((n, { scenarioGhgSavings }) => n + scenarioGhgSavings, 0)
      );
      data.sumScenarioPercentage = (data.scenarioResult / data.potentialImprovementResult) * 100;
      data.improvedMaterials.forEach((item) => {
        item.percentage = (item.potentialGhgSavings / largestImprovedMaterials) * 100;
        item.scenarioPercentage = (item.scenarioGhgSavings / item.potentialGhgSavings) * 100;
      });
    }
  }

  getOutflowGhgWidth(): string {
    if (
      !this.content?.step5OutflowGhg?.totalScenarioGhgSavings ||
      !this.content?.step5OutflowGhg?.totalPotentialGhgSavings
    ) {
      return '0%';
    }

    const percentage =
      (this.content.step5OutflowGhg.totalScenarioGhgSavings / this.content.step5OutflowGhg.totalPotentialGhgSavings) *
      100;
    return Math.min(percentage, 100) + '%';
  }

  getReport() {
    fetch(environment.serverUrl + environment.services.ctiReport(this.unitId), {
      headers: {
        'x-auth-token': this.authToken,
        'Content-Type': 'application/json',
      },
      method: 'GET',
    })
      .then((res) => res.json())
      .then(async (res) => {
        this.content = res;
        this.data = res;
        console.log(JSON.stringify(this.content));
        this.recoveryTypeBarVersionShow = this.content?.detailedUnit?.recoveryType?.breakdown.some(
          (element) => element.percentage === 100
        );

        this.calcPercentage(this.data.step5Ghg);
        await this.data.outflowDetails.largestOutflow.forEach((element) => {
          element.series.forEach((item) => {
            if (item.name === 'LinearOutflow') {
              item.label = this.ctireport?.linear_outflow;
            }
            if (item.name === 'CircularOutflow') {
              item.label = this.ctireport?.circular_outflow;
            }
          });
        });
        await this.data.outflowDetails.mostCircularOutflow.forEach((element) => {
          element.series.forEach((item) => {
            if (item.name === 'LinearOutflow') {
              item.label = this.ctireport?.linear_outflow;
            }
            if (item.name === 'CircularOutflow') {
              item.label = this.ctireport?.circular_outflow;
            }
          });
        });
        await this.data.outflowDetails.mostLinearOutflow.forEach((element) => {
          element.series.forEach((item) => {
            if (item.name === 'LinearOutflow') {
              item.label = this.ctireport?.linear_outflow;
            }
            if (item.name === 'CircularOutflow') {
              item.label = this.ctireport?.circular_outflow;
            }
          });
        });
        const appendixInflowMaterialsSize = Math.ceil(this.content.appendix.inflowMaterials.length / 20);
        this.appendixInflowMaterialsPage = this.page.slice(0, appendixInflowMaterialsSize);
        const appendixOutflowMaterialsSize = Math.ceil(this.content.appendix.outflowMaterials.length / 20);
        this.appendixOutflowMaterialsPage = this.page.slice(0, appendixOutflowMaterialsSize);
        this.showReport = true;
        this.reportName =
          this.content.mainPage.company.replace(/[^a-z,A-Z]/g, '') +
          '-' +
          this.content.mainPage.name.replace(/[^a-z,A-Z]/g, '') +
          '.pdf';
        if (environment.name !== 'default-cti') {
          await this.isDownloadready();
        }
      });
  }

  async isDownloadready() {
    await this.delay(500);
    if (this.reportName !== 'report.pdf') {
      this.downloadReport();
    } else {
      await this.delay(500);
      this.isDownloadready();
    }
  }
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  downloadReport() {
    const markup = document.getElementById('pdfContainer');
    const parser = markup.outerHTML;
    const data = btoa(unescape(encodeURIComponent(parser)));
    const f = `  <img style="width: 100%;"  src="${location.origin}/assets/img/report-footer.png" alt="">`;
    const fd = window.btoa(f);
    fetch(environment.serverUrl + '/pdf/generate', {
      headers: {
        'x-auth-token': this.authToken,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ footer: fd, report: data }),
      method: 'PUT',
    })
      .then((response) => {
        if (response.status !== 200) {
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const blob = new Blob([buffer], { type: 'application/pdf' });
        saveAs(blob, this.reportName);
      })
      .then((buffer) => {
        this.download = false;
      });
  }
}
