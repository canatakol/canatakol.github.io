import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from '@app/pipes/truncate-text';

@Component({
  selector: 'app-company-info',
  templateUrl: './company-info.component.html',
  standalone: true,
  imports: [CommonModule, TruncatePipe],
})
export class CompanyInfoComponent {
  @Input() imgUrl: string;
  @Input() companyData: any; // content.mainPage
  @Input() ctireport: any;
}
