import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-indicator-grid',
  templateUrl: './indicator-grid.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class IndicatorGridComponent {
  @Input() indicators: any; // content.mainPage.indicators
  @Input() ctireport: any;
  @Input() step2: any;
}
