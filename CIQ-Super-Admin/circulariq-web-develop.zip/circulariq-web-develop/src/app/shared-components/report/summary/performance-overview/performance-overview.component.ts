import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-performance-overview',
  templateUrl: './performance-overview.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class PerformanceOverviewComponent {
  @Input() imgUrl: string;
  @Input() performanceNote3: string;
  @Input() ctireport: any;
}
