import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-excluded-items',
  templateUrl: './excluded-items.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class ExcludedItemsComponent {
  @Input() excludedText: string;
  @Input() ctireport: any;
}
