import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-target-card',
  templateUrl: './target-card.component.html',
  standalone: true,
  imports: [CommonModule],
})
export class TargetCardComponent {
  @Input() target: any;
  @Input() index: number;
  @Input() step7: any;
  @Input() ctireport: any;
}
