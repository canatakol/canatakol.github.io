import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-stakeholder-list',
  templateUrl: './stakeholder-list.component.html',
  styleUrls: ['../../../../../assets/report.css'],
  standalone: true,
  imports: [CommonModule],
})
export class StakeholderListComponent {
  @Input() departments: any[];
  @Input() others: any[];
  @Input() considerations: any[];
  @Input() step7: any;
}
