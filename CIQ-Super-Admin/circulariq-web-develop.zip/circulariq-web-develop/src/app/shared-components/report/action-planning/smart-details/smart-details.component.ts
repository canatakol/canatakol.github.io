import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-smart-details',
  templateUrl: './smart-details.component.html',
  styleUrls: ['../../../../../assets/report.css'],
  standalone: true,
  imports: [CommonModule],
})
export class SmartDetailsComponent {
  @Input() target: any;
  @Input() alphabet: string[] = 'abcdefghijklmnopqrstuvwxyz'.split('');
  @Input() step7: any;
  @Input() ctireport: any;
}
