import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CurrentUserService } from '@app/core/services/current-user.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DashboardStateService } from '@app/core/services/dashboard-state.service';
import { Subscription, interval } from 'rxjs';
import { CommentService, Comment } from '@app/core/services/comment.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

interface Mention {
  userId: string;
  username: string;
  startIndex: number;
  endIndex: number;
}

interface Related {
  dashboardID: string;
  dashboardName: string;
  TabName: string;
  compponetName: string;
}

interface ServiceNotification {
  id: string;
  dashboardId: string;
  dashboardName: string;
  subLevel: string;
  section: string;
  text: string;
  authorId: string;
  authorName: string;
  creationDate: string;
  lastModifiedDate: string;
  isRead: boolean;
  mentions: Mention[];
}

interface Notification {
  id: string;
  avatar: string;
  message: string;
  formattedMessage: string;
  breadcrumb: string;
  time: string;
  originalData: ServiceNotification;
}

@Component({
  selector: 'app-comment-center',
  templateUrl: './comment-center.component.html',
  styleUrls: ['./comment-center.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class CommentCenterComponent implements OnInit, OnDestroy {
  @Input() isHeaderDropdown: boolean = false;
  @Input() defaultActiveTab: string = 'unread';
  @Output() closeDropdown = new EventEmitter<void>();

  dashboardId: string = '';
  currentUserEmail: string = '';
  currentSubLevel: string = '';
  storyblok: any;
  activeTab: string = 'unread';

  serviceData: ServiceNotification[] = [];

  notifications: Notification[] = [];

  private dashboardStateSubscription: Subscription;
  private commentUpdateSubscription: Subscription;
  private previousCommentCount: number = 0;

  constructor(
    private http: ApiRequestService,
    private currentUserService: CurrentUserService,
    public router: Router,
    private route: ActivatedRoute,
    private dashboardStateService: DashboardStateService,
    private commentService: CommentService,
    private storyblokService: StoryblokService
  ) {
    this.dashboardId = localStorage.getItem('lastSelectedDashboardId') as string;
    this.currentUserEmail = this.currentUserService.getCurrentUserEmail();
    this.currentSubLevel = this.dashboardStateService.getCurrentSubLevel();
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'dashboard')[0].content;
    });
    // Set default active tab based on input
    this.activeTab = this.defaultActiveTab;

    this.processServiceData();
    this.loadCommentsFromService();

    // Start timer to check for new comments every 30 seconds
    this.commentUpdateSubscription = interval(30000).subscribe(() => {
      if (this.dashboardId) {
        this.commentService.refreshComments(this.dashboardId);
      }
    });

    this.dashboardStateSubscription = this.dashboardStateService.currentState$.subscribe((state) => {
      this.currentSubLevel = state.subLevel;
    });
  }

  ngOnDestroy(): void {
    if (this.dashboardStateSubscription) {
      this.dashboardStateSubscription.unsubscribe();
    }
    if (this.commentUpdateSubscription) {
      this.commentUpdateSubscription.unsubscribe();
    }
  }

  getCurrentUserEmail(): string {
    return this.currentUserService.getCurrentUserEmail();
  }

  getCurrentUserCredentials(): any {
    return this.currentUserService.getCurrentUserCredentials();
  }

  isCurrentUserMentioned(notification: Notification): boolean {
    if (!notification.originalData.mentions || notification.originalData.mentions.length === 0) {
      return false;
    }

    const currentUserCredentials = this.currentUserService.getCurrentUserCredentials();
    if (!currentUserCredentials) {
      return false;
    }

    return notification.originalData.mentions.some(
      (mention) => mention.userId === currentUserCredentials.userId || mention.username === currentUserCredentials.email
    );
  }

  getCurrentUserName(): string {
    return this.currentUserService.getCurrentUserName();
  }

  capitalizeText(text: string): string {
    if (!text) return '';
    const textWithSpaces = text.replace(/_/g, ' ');
    return textWithSpaces.charAt(0).toUpperCase() + textWithSpaces.slice(1).toLowerCase();
  }

  get filteredNotifications(): Notification[] {
    let filtered: Notification[] = [];

    switch (this.activeTab) {
      case 'unread':
        filtered = this.notifications.filter((notification) => {
          // Show all unread comments
          return !notification.originalData.isRead;
        });
        break;
      case 'mentions':
        filtered = this.notifications.filter((notification) => {
          if (!notification.originalData.mentions || notification.originalData.mentions.length === 0) {
            return false;
          }

          const currentUserCredentials = this.currentUserService.getCurrentUserCredentials();
          if (currentUserCredentials) {
            return notification.originalData.mentions.some(
              (mention) =>
                mention.userId === currentUserCredentials.userId || mention.username === currentUserCredentials.email
            );
          }

          return true;
        });
        break;
      case 'this-view':
        filtered = this.notifications.filter(
          (notification) => notification.originalData.subLevel === this.currentSubLevel
        );
        break;
      case 'dashboard':
        filtered = this.notifications;
        break;
      case 'all':
        filtered = this.notifications;
        break;
      default:
        filtered = this.notifications;
    }

    return filtered;
  }

  getTabCount(tab: string): number {
    let filtered: Notification[] = [];

    switch (tab) {
      case 'unread':
        filtered = this.notifications.filter((notification) => {
          // Count all unread comments
          return !notification.originalData.isRead;
        });
        break;
      case 'mentions':
        filtered = this.notifications.filter((notification) => {
          if (!notification.originalData.mentions || notification.originalData.mentions.length === 0) {
            return false;
          }

          const currentUserCredentials = this.currentUserService.getCurrentUserCredentials();
          if (currentUserCredentials) {
            return notification.originalData.mentions.some(
              (mention) =>
                mention.userId === currentUserCredentials.userId || mention.username === currentUserCredentials.email
            );
          }

          return true;
        });
        break;
      case 'this-view':
        filtered = this.notifications.filter(
          (notification) => notification.originalData.subLevel === this.currentSubLevel
        );
        break;
      case 'dashboard':
        filtered = this.notifications;
        break;
      case 'all':
        filtered = this.notifications;
        break;
      default:
        filtered = this.notifications;
    }

    return filtered.length;
  }

  processServiceData(): void {
    this.notifications = this.serviceData.map((data) => {
      const authorName = data.authorName;

      const breadcrumb = `${data.dashboardName} > ${data.subLevel} > ${data.section}`;

      const avatar = this.generateAvatarFromName(authorName);

      return {
        id: data.id,
        avatar: avatar,
        message: data.text,
        formattedMessage: this.formatMessageWithMentions(data.text, data.mentions),
        breadcrumb: breadcrumb,
        time: this.formatTimeFromDate(data.creationDate),
        originalData: data,
      };
    });

    // Auto-select tab based on unread comments after processing data
    this.updateActiveTabBasedOnUnreadComments();
  }

  formatMessageWithMentions(message: string, mentions: Mention[]): string {
    if (mentions.length === 0) {
      return message;
    }

    const sortedMentions = [...mentions].sort((a, b) => b.startIndex - a.startIndex);

    let formattedMessage = message;

    sortedMentions.forEach((mention) => {
      const beforeMention = formattedMessage.substring(0, mention.startIndex);
      const afterMention = formattedMessage.substring(mention.endIndex);
      const mentionText = formattedMessage.substring(mention.startIndex, mention.endIndex);

      formattedMessage = beforeMention + `<span class="mention-highlight">@${mention.username}</span>` + afterMention;
    });

    return formattedMessage;
  }

  formatTimeFromDate(dateString: string): string {
    // Parse the date and ensure it's treated as UTC if no timezone info
    let date: Date;
    try {
      // If the dateString doesn't include timezone info, treat it as UTC
      if (!dateString.includes('Z') && !dateString.includes('+') && !dateString.includes('-', 10)) {
        // Add Z to treat as UTC
        date = new Date(dateString + 'Z');
      } else {
        date = new Date(dateString);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn('Invalid date string:', dateString);
        return 'Unknown time';
      }
    } catch (error) {
      console.warn('Error parsing date:', dateString, error);
      return 'Unknown time';
    }

    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    const diffInDays = diffInHours / 24;

    // Handle negative differences (future dates)

    if (diffInMs < 0) {
      const absDiffInHours = Math.abs(diffInHours);
      if (absDiffInHours < 0.1) {
        return 'Just now';
      } else if (absDiffInHours < 24) {
        return `In ${Math.floor(absDiffInHours)}h`;
      } else {
        return `In ${Math.floor(Math.abs(diffInDays))}d`;
      }
    }

    if (diffInHours < 0.1) {
      // Less than 6 minutes
      return 'Just now';
    } else if (diffInHours < 1) {
      return `${Math.floor(diffInHours * 60)}m ago`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInDays < 7) {
      return `${Math.floor(diffInDays)}d ago`;
    } else if (diffInDays < 30) {
      return `${Math.floor(diffInDays / 7)}w ago`;
    } else {
      // For very old comments, show the actual date
      return date.toLocaleDateString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
    }
  }

  trackByNotification(index: number, notification: Notification): string {
    return notification.id;
  }

  trackByPart(index: number, part: any): string {
    return `${part.type}-${index}-${part.content}`;
  }

  setActiveTab(tab: string): void {
    this.activeTab = tab;
  }

  updateNotifications(serviceData: ServiceNotification[]): void {
    this.serviceData = serviceData;
    this.processServiceData();
  }

  navigateToContent(notification: ServiceNotification): void {
    const navigationData = {
      dashboardID: notification.dashboardId,
      dashboardName: notification.dashboardName,
      tabName: notification.subLevel,
      componentName: notification.section,
    };

    // Close the dropdown when navigating
    this.closeDropdown.emit();

    if (notification.dashboardId && notification.subLevel) {
      try {
        const tabName = notification.subLevel.toLowerCase();

        this.router
          .navigate(['cti/dashboard', notification.dashboardId, tabName])
          .then(() => {
            this.dashboardStateService.updateState({
              selectedTab: notification.subLevel.toUpperCase(),
              dashboardId: notification.dashboardId,
              subLevel: notification.subLevel,
            });

            setTimeout(() => {
              this.scrollToComponent(notification.section);
            }, 1500);

            setTimeout(() => {
              this.scrollToComponent(notification.section);
            }, 3000);
          })
          .catch((error) => {
            this.router.navigate(['cti/dashboard', notification.dashboardId]);
          });
        this.commentService.markCommentReadAndRefresh(notification.id, this.dashboardId).subscribe({
          next: (response) => {
            // Refresh is handled automatically by markCommentReadAndRefresh
          },
          error: (error) => {
            console.error('Error marking comment as read:', error);
          },
        });
      } catch (error) {
        this.router.navigate(['cti/dashboard', notification.dashboardId]);
      }
    }
  }

  private scrollToComponent(sectionName: string): void {
    if (!sectionName) {
      return;
    }

    const componentId = this.getComponentIdForSection(sectionName);

    if (componentId) {
      const element = document.getElementById(componentId);

      if (element) {
        const elementRect = element.getBoundingClientRect();
        const offsetTop = elementRect.top + window.pageYOffset - 100;

        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth',
        });

        this.highlightElement(element);
      } else {
        this.tryAlternativeScrollMethods(componentId, sectionName);
      }
    }
  }

  private tryAlternativeScrollMethods(componentId: string, sectionName: string): void {
    const commentBadge = document.querySelector(`app-comment-badge[componentId="${componentId}"]`);

    if (commentBadge) {
      const elementRect = commentBadge.getBoundingClientRect();
      const offsetTop = elementRect.top + window.pageYOffset - 100;

      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });

      this.highlightElement(commentBadge);
      return;
    }

    const dataComponent = document.querySelector(`[data-component-id="${componentId}"]`);

    if (dataComponent) {
      const elementRect = dataComponent.getBoundingClientRect();
      const offsetTop = elementRect.top + window.pageYOffset - 100;

      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });

      this.highlightElement(dataComponent);
      return;
    }

    const elements = Array.from(document.querySelectorAll('*'));
    for (const element of elements) {
      if (element.textContent && element.textContent.toLowerCase().includes(sectionName.toLowerCase())) {
        if (
          element.tagName === 'H1' ||
          element.tagName === 'H2' ||
          element.tagName === 'H3' ||
          element.tagName === 'H4' ||
          element.tagName === 'H5' ||
          element.tagName === 'H6' ||
          element.classList.contains('title') ||
          element.classList.contains('header')
        ) {
          const elementRect = element.getBoundingClientRect();
          const offsetTop = elementRect.top + window.pageYOffset - 100;

          window.scrollTo({
            top: offsetTop,
            behavior: 'smooth',
          });

          this.highlightElement(element);
          return;
        }
      }
    }
  }

  private getComponentIdForSection(sectionName: string): string | null {
    const componentNameMappings: { [key: string]: string } = {
      PACKAGING: 'packaging-component',
      GHG_IMPACT: 'ghg-component',
      CRITICAL_INFLOW: 'critical-inflow-component',
      MOST_LINEAR_INFLOWS: 'most-linear-inflow-component',
      SANKEY: 'sankey-info-inflow-component',
      RECOVERY: 'recovery-breakdown-component',
      MASS_BREAKDOWN: 'breakdown-of-mass-component',
      PRODUCTIVITY: 'circular-material-productivity-component',
      REVENUE: 'cti-revenue-component',
      ON_SITE_WATER: 'onsite-water-circulation-component',
      ENERGY: 'renewable-energy-component',
      WATER: 'water-circularity-component',
    };

    if (componentNameMappings[sectionName]) {
      return componentNameMappings[sectionName];
    }

    const normalizedMappings: { [key: string]: string } = {
      packaging: 'packaging-component',
      ghg: 'ghg-component',
      'critical-inflow': 'critical-inflow-component',
      'most-linear-inflow': 'most-linear-inflow-component',
      'sankey-info': 'sankey-info-inflow-component',
      'recovery-breakdown': 'recovery-breakdown-component',
      'breakdown-of-mass': 'breakdown-of-mass-component',
      'circular-material-productivity': 'circular-material-productivity-component',
      'cti-revenue': 'cti-revenue-component',
      'onsite-water-circulation': 'onsite-water-circulation-component',
      'critical-inflow-optimize': 'critical-inflow-optimize-component',
      'renewable-energy': 'renewable-energy-component',
      'water-circularity': 'water-circularity-component',
    };

    const normalizedSectionName = sectionName.toLowerCase().replace(/[^a-z0-9]/g, '-');
    return normalizedMappings[normalizedSectionName] || null;
  }

  private highlightElement(element: Element): void {
    element.classList.add('scroll-highlight');

    setTimeout(() => {
      element.classList.remove('scroll-highlight');
    }, 1000);
  }

  getMentions(notification: Notification): Mention[] {
    return notification.originalData.mentions;
  }

  generateAvatarFromName(fullName: string): string {
    if (!fullName || fullName.trim() === '') {
      return 'NA';
    }

    const nameParts = fullName.trim().split(' ');

    if (nameParts.length === 1) {
      return nameParts[0].substring(0, 2).toUpperCase();
    } else {
      const firstName = nameParts[0];
      const lastName = nameParts[nameParts.length - 1];

      return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
    }
  }

  renderMessageWithMentions(message: string, mentions: Mention[]): any[] {
    if (mentions.length === 0) {
      return [{ type: 'text', content: message }];
    }

    const sortedMentions = [...mentions].sort((a, b) => a.startIndex - b.startIndex);

    const result: any[] = [];
    let currentIndex = 0;

    sortedMentions.forEach((mention) => {
      if (mention.startIndex > currentIndex) {
        result.push({
          type: 'text',
          content: message.substring(currentIndex, mention.startIndex),
        });
      }

      result.push({
        type: 'mention',
        content: mention.username,
        userId: mention.userId,
      });

      currentIndex = mention.endIndex;
    });

    if (currentIndex < message.length) {
      result.push({
        type: 'text',
        content: message.substring(currentIndex),
      });
    }

    return result;
  }

  private loadCommentsFromService(): void {
    if (this.dashboardId) {
      this.commentService.getComments(this.dashboardId).subscribe({
        next: (comments: Comment[]) => {
          this.updateNotificationsFromService(comments);
        },
        error: (error) => {
          console.error('Error loading comments:', error);
        },
      });
    }
  }

  private updateNotificationsFromService(comments: Comment[]): void {
    const apiNotifications: ServiceNotification[] = comments.map((comment: Comment) => ({
      id: comment.id,
      dashboardId: comment.dashboardId,
      dashboardName: comment.dashboardName,
      subLevel: comment.subLevel,
      section: comment.section,
      text: comment.text,
      authorId: comment.authorId,
      authorName: comment.authorName,
      creationDate: comment.creationDate,
      lastModifiedDate: comment.lastModifiedDate,
      isRead: comment.isRead,
      mentions: (comment.mentions || []).map((mention) => ({
        userId: mention.userId,
        username: mention.fullname || mention.userId, // Use fullname if available, otherwise fallback to userId
        startIndex: mention.startIndex,
        endIndex: mention.endIndex,
      })),
    }));

    // Check if new comments arrived
    if (this.previousCommentCount > 0 && apiNotifications.length > this.previousCommentCount) {
      const newCommentCount = apiNotifications.length - this.previousCommentCount;
      console.log(`${newCommentCount} new comment(s) received`);
    }

    this.previousCommentCount = apiNotifications.length;
    this.serviceData = apiNotifications;
    this.processServiceData();
  }

  private updateActiveTabBasedOnUnreadComments(): void {
    // Check if there are any unread comments
    const hasUnreadComments = this.serviceData.some((notification) => !notification.isRead);

    if (hasUnreadComments) {
      this.activeTab = 'unread';
    } else {
      this.activeTab = 'dashboard';
    }
  }
}
