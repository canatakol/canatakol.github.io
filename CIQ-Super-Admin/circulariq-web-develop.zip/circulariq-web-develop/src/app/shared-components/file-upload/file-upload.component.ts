import { Component, Input, ViewChild } from '@angular/core';
import { environment } from '@env/environment';
import { MaterialsComponent } from '@app/assessment-level/materials/materials.component';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  standalone: false,
})
export class FileUploadComponent {
  displayedColumns: string[] = ['sheet', 'cellAddress', 'message'];
  @ViewChild('myPond') myPond: any;
  category = 'INFLOW';
  progressStatus;
  responseData;
  fName = '';
  fileType;
  active = false;
  openText = false;
  numericSeparator = '.';
  cellSeparator = ';';
  storyblok;
  errorMessage;
  unitId = this.route.snapshot.params.unitId;
  contents: any[];
  name = '';
  fileName;
  pondOptions;

  constructor(
    private materialsComponent: MaterialsComponent,
    private route: ActivatedRoute,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'file-upload');
      this.storyblok = story[0].content;
      this.changeFileType('xlxs');
      this.fileType = 'xlxs';
    });
  }

  changeFileType(type: string) {
    this.responseData = null;
    this.progressStatus = null;
    if (type === 'csv') {
      this.pondOptions = {
        class: 'my-filepond',
        multiple: false,
        labelIdle: this.storyblok.upload_file,
        acceptedFileTypes: 'application/vnd.ms-excel,text/comma-separated-values, text/csv, application/csv , .csv',
        server: {
          url: environment.serverUrl,
          process: async (fieldName, file, metadata, load, error, progress, abort) => {
            const formData = new FormData();
            const self = this;
            formData.append('file', file, file.name);
            const request = new XMLHttpRequest();
            request.open('POST', environment.serverUrl + environment.services.upload());
            request.upload.onprogress = (e) => {
              progress(e.lengthComputable, e.loaded, e.total);
            };
            request.onload = function () {
              if (request.status >= 200 && request.status < 300) {
                load(request.responseText);
                const name = JSON.parse(request.response).fileName;
                const data = {
                  fileName: name,
                  numericSeparator: self.numericSeparator,
                  cellSeparator: self.cellSeparator,
                };
                const token = JSON.parse(sessionStorage.getItem('credentials')).authToken;
                fetch(environment.serverUrl + environment.services.importUnitProduct(self.unitId), {
                  headers: {
                    'x-auth-token': token,
                    'Content-Type': 'application/json',
                  },
                  method: 'POST',
                  body: JSON.stringify(data),
                })
                  .then((response) => {
                    if (response.status === 200) {
                      return (self.progressStatus = 200);
                    } else {
                      self.progressStatus = 400;
                      const json = response.json();
                      return json;
                    }
                  })
                  .then((data) => {
                    if (data) {
                      self.responseData = data;
                    }
                  });
                sessionStorage.setItem('uploadFile', request.response);
              } else {
                alert('something went wrong');
              }
            };
            request.send(formData);
            return {
              abort: () => {
                request.abort();
                abort();
              },
            };
          },
          revert: (uniqueFileId, load, error) => {
            error(error);
            load();
          },
          load: (uniqueFileId, load, error) => {
            fetch(uniqueFileId)
              .then((res) => res.blob())
              .then((res) => {
                load(new File([res], '', { type: 'image' }));
              })
              .catch(error);
          },
        },
      };
    }
    if (type === 'xlxs') {
      this.pondOptions = {
        class: 'my-filepond',
        multiple: false,
        labelIdle: this.storyblok.upload_file,
        acceptedFileTypes: 'text/xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        server: {
          url: environment.serverUrl,
          process: async (fieldName, file, metadata, load, error, progress, abort) => {
            const formData = new FormData();
            const self = this;
            formData.append('file', file, file.name);
            const request = new XMLHttpRequest();
            request.open('POST', environment.serverUrl + environment.services.uploadPermanent());
            request.upload.onprogress = (e) => {
              progress(e.lengthComputable, e.loaded, e.total);
            };
            request.onload = function () {
              if (request.status >= 200 && request.status < 300) {
                load(request.responseText);
                const url = `${environment.serverUrl}/assets/download/${JSON.parse(request.response)[0].fileName}`;
                const data = {
                  organisationUnitUuid: self.unitId,
                  url: url,
                };
                const token = JSON.parse(sessionStorage.getItem('credentials')).authToken;
                fetch(environment.serverUrl + environment.services.excelUploadFlow(), {
                  headers: {
                    'x-auth-token': token,
                    'Content-Type': 'application/json',
                  },
                  method: 'POST',
                  body: JSON.stringify(data),
                })
                  .then((response) => {
                    if (response.status === 200) {
                      return (self.progressStatus = 200);
                    } else {
                      self.progressStatus = 400;
                      const json = response.json();
                      return json;
                    }
                  })
                  .then((data) => {
                    if (data) {
                      self.responseData = data;
                    }
                  });
                sessionStorage.setItem('uploadFile', request.response);
              } else {
                alert('something went wrong');
              }
            };
            request.send(formData);
            return {
              abort: () => {
                request.abort();
                abort();
                $('#close').trigger('click');
              },
            };
          },
          revert: (uniqueFileId, load, error) => {
            error(error);
            load();
          },
          load: (uniqueFileId, load, error) => {
            fetch(uniqueFileId)
              .then((res) => res.blob())
              .then((res) => {
                load(new File([res], '', { type: 'image' }));
                $('#close').trigger('click');
              })
              .catch(error);
          },
        },
      };
    }
  }

  get errorResponse() {
    return this.responseData;
  }

  get progress() {
    return this.progressStatus;
  }

  close() {
    this.materialsComponent.hideModal();
  }
}
