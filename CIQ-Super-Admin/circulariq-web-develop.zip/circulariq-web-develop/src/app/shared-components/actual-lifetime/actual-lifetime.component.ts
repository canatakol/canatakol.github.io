import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-actual-lifetime',
  templateUrl: './actual-lifetime.component.html',
  styleUrls: ['./actual-lifetime.component.scss'],
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe],
})
export class ActualLifetimeComponent implements OnInit {
  @Input() public data: string;
  @Input() public report: boolean;
  @Input() public compare: boolean;
  environment = environment;
  showTooltip = false;
  storyblok;
  unitId = this.route.snapshot.params.unitId;
  constructor(private storyblokService: StoryblokService, private router: Router, private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'actual-lifetime');
      this.storyblok = story[0].content;
    });
  }
  goToTheStep2(item: string) {
    this.router.navigateByUrl(`/cti/${this.unitId}/assessment/step2`, { state: { selectedProduct: item } });
  }
}
