import { Component } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { first } from 'rxjs/operators';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';
declare var $: any;
@Component({
  selector: 'app-boxes',
  templateUrl: './boxes.component.html',
  styleUrls: ['./boxes.component.scss'],
  standalone: false,
})
export class BoxesComponent {
  indicators;
  language;
  data;
  tooltipShow = false;
  selectedTooltip;
  storyblok;
  showModal = false;
  showEnergy = false;
  showWater = false;
  environment = environment;
  showCirculation = false;
  showProductivity = false;
  showRevenue = false;
  showNatureImpact = false;
  dialogName;
  unitId = this.route.snapshot.params.unitId;
  constructor(
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    private storyblokService: StoryblokService,
    private commonService: CommonService
  ) {
    if (this.unitId) {
      this.language = localStorage.getItem('language') || 'English';
      this.unitdetail();
    }
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step-3-top-boxes');
      this.storyblok = story[0].content;
    });
  }
  unitdetail() {
    this.http.callService(new Method(environment.services.unitDetailed(this.unitId), '', 'get')).subscribe((res) => {
      this.data = res;
      this.indicators = this.data.indicators;
      setTimeout(() => {
        $('dl').width((101 - $('dl').length) / $('dl').length + '%');
      }, 200);
    });
  }
  selectEvent(item: string, i: number) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedTooltip = item;
    this.tooltipShow = true;
    const btnPosition = $('dl:eq( ' + i + ' )').offset().left;
    if (btnPosition > 350) {
      $('.tool-tip').css('left', btnPosition - 350 + 'px');
    } else {
      $('.tool-tip').css('left', 0);
    }
    setTimeout(() => {
      this.tooltipShow = false;
    }, 5000);
  }
  goToTheStep2() {
    this.router.navigateByUrl(`/cti/${this.unitId}/assessment/step2`, {
      state: { selectedProduct: this.selectedTooltip },
    });
  }

  updateEvent(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.showModal = true;
    switch (item) {
      case 'energy':
        this.showEnergy = true;
        break;
      case 'water':
        this.showWater = true;
        break;
      case 'circulation':
        this.showCirculation = true;
        break;
      case 'productivity':
        this.showProductivity = true;
        break;
      case 'revenue':
        this.showRevenue = true;
        break;
      case 'natureImpact':
        this.showNatureImpact = true;
        break;

      default:
        return;
        break;
    }
  }

  public hideModal() {
    this.showEnergy = false;
    this.showWater = false;
    this.showCirculation = false;
    this.showProductivity = false;
    this.showRevenue = false;
    this.showNatureImpact = false;
    this.showModal = false;
  }

  public async modalSave() {
    this.unitdetail();
    this.snackBar.open(this.commonService.storyblok?.success_message, '', {
      duration: 5000,
      panelClass: ['success-snackBar'],
    });
    this.hideModal();
  }
}
