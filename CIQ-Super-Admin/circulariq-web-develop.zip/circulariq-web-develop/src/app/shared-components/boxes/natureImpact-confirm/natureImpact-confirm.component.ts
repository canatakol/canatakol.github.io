import { Component, Input } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { BoxesComponent } from '../boxes.component';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-natureimpact-confirm',
  templateUrl: './natureImpact-confirm.component.html',
  styleUrls: ['./natureImpact-confirm.component.scss'],
  standalone: false,
})
export class NatureImpactConfirm {
  @Input() public storyblok: any;
  res;
  cmpBoxShow = false;
  searchText = '';
  inflowListShow = false;
  environment = environment;
  selectedUnitDetails;
  selectedUnit;
  inflows;
  unitId = this.route.snapshot.params.unitId;
  selectedInflow;
  extentValue;
  conditiontValue;
  significanValue;
  selectedExtent;
  selectedCondition;
  selectedSignifican;
  data;
  natureImpactExtentList = environment.services.natureImpactExtentList;
  natureImpactConditionList = environment.services.natureImpactConditionList;
  natureImpactSignificancenList = environment.services.natureImpactSignificancenList;
  constructor(private http: ApiRequestService, private boxesComponent: BoxesComponent, private route: ActivatedRoute) {
    this.selectedUnitDetails = JSON.parse(localStorage.getItem('selectedUnit'));
    if (this.unitId) {
      this.getInflow();
      this.getNatureImpact();
    }
  }
  getNatureImpact() {
    this.http.callService(new Method(environment.services.natureImpact(this.unitId), '', 'get')).subscribe((res) => {
      if (res['conditionDimension']) {
        this.conditiontValue = res['conditionDimension'];
        this.changeCondition(this.conditiontValue);
      }
      if (res['extendDimension']) {
        this.extentValue = res['extendDimension'];
        this.changeExtent(this.extentValue);
      }
      if (res['significanceDimension']) {
        this.significanValue = res['significanceDimension'];
        this.changeSignificancen(this.significanValue);
      }
      this.selectedInflow = {
        displayName: res['flowName'],
        weight: res['flowMass'],
      };
    });
  }
  getInflow() {
    this.http
      .callService(
        new Method(
          environment.services.inflowsandOutflofList(this.unitId, 'INFLOW', 1, 1000, 'WEIGHT', 'DESCENDING'),
          '',
          'get'
        )
      )
      .subscribe((res) => {
        this.inflows = res['results'];
      });
  }
  selectInflow(selectedInflow: any) {
    this.selectedInflow = selectedInflow;
    this.inflowListShow = false;
  }
  changeExtent(value: any) {
    this.natureImpactExtentList.forEach((element) => {
      if (value === element.extendDimension) {
        this.selectedExtent = element;
      }
    });
  }
  changeCondition(value: any) {
    this.natureImpactConditionList.forEach((element) => {
      if (value === element.conditionDimension) {
        this.selectedCondition = element;
      }
    });
  }
  changeSignificancen(value: any) {
    this.natureImpactSignificancenList.forEach((element) => {
      if (value === element.significanceDimension) {
        this.selectedSignifican = element;
      }
    });
  }

  save() {
    const data = {
      conditionDimension: this.conditiontValue,
      extendDimension: this.extentValue,
      significanceDimension: this.significanValue,
      productUuid: this.selectedInflow.id,
    };
    this.http.callService(new Method(environment.services.natureImpact(this.unitId), data, 'put')).subscribe((res) => {
      this.boxesComponent.modalSave();
    });
  }

  cancel() {
    this.boxesComponent.hideModal();
  }
}
