import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { saveAs } from '@progress/kendo-file-saver';
import { CommonModule } from '@angular/common';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-e5-report',
  templateUrl: './e5-report.component.html',
  styleUrls: ['../../../assets/download.css'],
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe],
})
export class E5PDFReportComponent implements OnInit {
  environment = environment;
  imgUrl = this.environment.fileUrl + 'img/ciq-logo.png';
  e5ReportCss;
  fontStyles = this.environment.fileUrl + 'font.css';
  download = true;
  mounthList = environment.services.mounthList;
  storyblok;
  unit: 'kg';
  data;
  unsortedAssessmentList;
  reportId = this.route.snapshot.params.reportId;
  reportName = 'E5-report.pdf';
  itemsPerPage = 20;
  pages: any[] = [];
  sortedItemsWithTotalInflow: any[];
  sortedItemsWithTotalBioWeight: any[];
  sortedItemsWithTotalSecondaryWeight: any[];
  sortedItemsWithTotalRecoverableMass: any[];

  constructor(
    public sanitizer: DomSanitizer,
    private router: Router,
    private http: ApiRequestService,
    public route: ActivatedRoute,
    private storyblokService: StoryblokService
  ) {
    this.e5ReportCss = this.environment.e5ReportCSS;
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'e5-report');
      this.storyblok = story[0].content;
    });
  }

  async ngOnInit(): Promise<void> {
    await this.route.queryParams.subscribe((params) => {
      this.unit = params['unit'] || 'kg';
    });
    await this.http
      .callService(new Method(environment.services.getESRSPDFReportDetail(this.reportId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.unsortedAssessmentList = res;
        const totalPages = Math.ceil((this.data.assessments.length - 20) / this.itemsPerPage);
        for (let i = 0; i < totalPages; i++) {
          this.pages.push({ pageNumber: i + 1 });
        }
        this.sortData();
        this.setReportName();
        if (environment.name !== 'default-cti') {
          setTimeout(() => {
            this.downloadReport();
          }, 2000);
        }
      });
  }

  sortData(): void {
    this.sortedItemsWithTotalInflow = this.sortItems(this.unsortedAssessmentList.assessments, 'totalInflow', 'desc');

    this.sortedItemsWithTotalBioWeight = this.sortItems(
      this.unsortedAssessmentList.assessments,
      'totalBioWeight',
      'desc'
    );

    this.sortedItemsWithTotalSecondaryWeight = this.sortItems(
      this.unsortedAssessmentList.assessments,
      'totalSecondaryWeight',
      'desc'
    );
    this.sortedItemsWithTotalRecoverableMass = this.sortItems(
      this.unsortedAssessmentList.assessments,
      'totalRecoverableMass',
      'desc'
    );
  }

  sortItems(data: any[], field: string, order: string = 'desc'): any[] {
    return data.slice().sort((a, b) => {
      const valueA = a[field];
      const valueB = b[field];

      if (valueA === undefined || valueB === undefined) {
        return 0; // If the field doesn't exist, do not sort
      }

      if (valueA > valueB) {
        return order === 'desc' ? -1 : 1;
      } else if (valueA < valueB) {
        return order === 'desc' ? 1 : -1;
      } else {
        return 0;
      }
    });
  }

  setReportName(): void {
    const [startmonth, startyear] = this.data.startDate.split('/');
    const startmonthObject = this.mounthList.find((m) => m.num === startmonth);
    this.data.startMonth = startmonthObject.name;
    this.data.startYear = startyear;

    const [endmonth, endyear] = this.data.endDate.split('/');
    const endmonthObject = this.mounthList.find((m) => m.num === endmonth);
    this.data.endMonth = endmonthObject.name;
    this.data.endYear = endyear;

    this.reportName =
      this.data.organisationName.replace(/[^a-z,A-Z]/g, '') + '-' + this.data.name.replace(/[^a-z,A-Z]/g, '') + '.pdf';
  }

  downloadReport() {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    const token = credentials.authToken;
    const markup = document.getElementById('pdfContainer');
    const parser = markup.outerHTML;
    const data = btoa(unescape(encodeURIComponent(parser)));
    const f = ``;
    const fd = window.btoa(f);
    fetch(environment.serverUrl + '/pdf/generate', {
      headers: {
        'x-auth-token': token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ footer: fd, report: data }),
      method: 'PUT',
    })
      .then((response) => {
        if (response.status !== 200) {
          window.location.href = '/e5';
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const blob = new Blob([buffer], { type: 'application/pdf' });
        saveAs(blob, this.reportName);
      })
      .then(() => {
        this.download = false;
      });
  }
}
