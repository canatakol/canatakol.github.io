import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';

@Component({
  selector: 'app-ghg',
  templateUrl: './ghg.component.html',
  styleUrls: ['./ghg.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe, CommentBadgeComponent],
})
export class GHGComponent {
  @Input() data: any;
  @Input() storyblok: any;
  @Input() isReport: boolean = false;
  constructor() {
    // Component initialized
  }
}
