import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { SankeyInfoOverlayComponent } from '@app/shared-components/sankey-info-overlay/sankey-info-overlay.component';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { take } from 'rxjs/operators';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
import { DashboardScenarioSyncService } from '@app/shared-components/dashboard-flows/dashboard-scenario-sync.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-flow-analysis-sankey',
  templateUrl: './flow-analysis-sankey.component.html',
  styleUrls: ['./flow-analysis-sankey.component.scss'],
  standalone: true,
  imports: [CommonModule, SankeyInfoOverlayComponent, LoadingBarComponent, FormsModule],
})
export class FlowAnalysisSankeyComponent implements OnInit, OnDestroy {
  @Input() dashboardId?: string;
  @Input() aggregateData?: any;
  sankeyDataForChart: any;
  selectedInflowScenarioId: string | null = null;
  selectedOutflowScenarioId: string | null = null;
  inflowImprovements: any = null;
  outflowImprovements: any = null;
  loadingInflow = false;
  loadingOutflow = false;
  inflowScenarios: any[] = [];
  outflowScenarios: any[] = [];

  private _baseSankey: any;
  private scenarioSyncSubscriptions: Subscription[] = [];

  /**
   * Getter for base sankey data - used by the overlay component
   * Always returns the original (unmodified) sankey data
   */
  get baseSankeyData(): any {
    return this._baseSankey ? { sankey: structuredClone(this._baseSankey) } : null;
  }

  /**
   * Getter for inflow overlay data from scenario improvements
   */
  get inflowOverlayData(): any {
    return this.selectedInflowScenarioId && this.inflowImprovements?.sankeyData
      ? { sankey: this.inflowImprovements.sankeyData }
      : null;
  }

  /**
   * Getter for outflow overlay data from scenario improvements
   */
  get outflowOverlayData(): any {
    return this.selectedOutflowScenarioId && this.outflowImprovements?.sankeyData
      ? { sankey: this.outflowImprovements.sankeyData }
      : null;
  }

  get inflowPerformance(): PerformanceRow[] {
    return this.computePerformanceRows(
      [
        { label: '% circular inflow', field: 'inflowCircularPercentage', unit: 'percent' },
        { label: '% material circularity', field: 'inflowCircularityPercentage', unit: 'percent' },
        { label: 'Linear mass', field: 'inflowLinearWeight', unit: 'mass' },
        { label: 'Total mass', field: 'inflowWeight', unit: 'mass' },
      ],
      'inflow'
    );
  }

  get outflowPerformance(): PerformanceRow[] {
    return this.computePerformanceRows(
      [
        { label: '% circular outflow', field: 'outflowCircularPercentage', unit: 'percent' },
        { label: '% material circularity', field: 'outflowCircularityPercentage', unit: 'percent' },
        { label: 'Linear mass', field: 'outflowLinearWeight', unit: 'mass' },
        { label: 'Total mass', field: 'outflowWeight', unit: 'mass' },
      ],
      'outflow'
    );
  }

  constructor(
    private localStorageService: LocalStorageService,
    private http: ApiRequestService,
    private scenarioSyncService: DashboardScenarioSyncService
  ) {}

  ngOnInit(): void {
    const source =
      this.aggregateData ??
      this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY) ??
      {};

    this._baseSankey = structuredClone(source?.sankey ?? source?.aggregate?.sankey ?? {});
    if (this._baseSankey && Object.keys(this._baseSankey).length > 0) {
      this.sankeyDataForChart = { sankey: structuredClone(this._baseSankey) };
    }

    console.log('[STATIC SANKEY DATA]', JSON.stringify(this._baseSankey));

    if (this.dashboardId) {
      this.loadScenarios();
    }

    // Subscribe to scenario changes from dashboard-flows component
    this.scenarioSyncSubscriptions.push(
      this.scenarioSyncService.inflowScenario$.subscribe((scenarioId) => {
        if (scenarioId !== this.selectedInflowScenarioId) {
          this.selectedInflowScenarioId = scenarioId;
          if (scenarioId) {
            this.loadInflowScenario(scenarioId);
          } else {
            this.inflowImprovements = null;
            this.updateChart();
          }
        }
      })
    );

    this.scenarioSyncSubscriptions.push(
      this.scenarioSyncService.outflowScenario$.subscribe((scenarioId) => {
        if (scenarioId !== this.selectedOutflowScenarioId) {
          this.selectedOutflowScenarioId = scenarioId;
          if (scenarioId) {
            this.loadOutflowScenario(scenarioId);
          } else {
            this.outflowImprovements = null;
            this.updateChart();
          }
        }
      })
    );

    // Subscribe to scenario list updates from dashboard-flows component
    this.scenarioSyncSubscriptions.push(
      this.scenarioSyncService.inflowScenariosList$.subscribe((scenarios) => {
        this.inflowScenarios = scenarios;
        this.checkAndSelectDefaultScenario('INFLOW', scenarios);
      })
    );

    this.scenarioSyncSubscriptions.push(
      this.scenarioSyncService.outflowScenariosList$.subscribe((scenarios) => {
        this.outflowScenarios = scenarios;
        this.checkAndSelectDefaultScenario('OUTFLOW', scenarios);
      })
    );
  }

  ngOnDestroy(): void {
    this.scenarioSyncSubscriptions.forEach((sub) => sub.unsubscribe());
  }

  private loadScenarios(): void {
    // Inflow scenarios
    this.http
      .callService(new Method(environment.services.dashboardScenarios(this.dashboardId!, 'INFLOW'), {}, 'get'))
      .pipe(take(1))
      .subscribe((res: any) => {
        this.inflowScenarios = Array.isArray(res) ? res : [];
        this.checkAndSelectDefaultScenario('INFLOW', this.inflowScenarios);
      });

    // Outflow scenarios
    this.http
      .callService(new Method(environment.services.dashboardScenarios(this.dashboardId!, 'OUTFLOW'), {}, 'get'))
      .pipe(take(1))
      .subscribe((res: any) => {
        this.outflowScenarios = Array.isArray(res) ? res : [];
        this.checkAndSelectDefaultScenario('OUTFLOW', this.outflowScenarios);
      });
  }

  private checkAndSelectDefaultScenario(type: 'INFLOW' | 'OUTFLOW', scenarios: any[]): void {
    const currentSelection = type === 'INFLOW' ? this.selectedInflowScenarioId : this.selectedOutflowScenarioId;

    // If already selected, do nothing
    if (currentSelection) {
      return;
    }

    // Find default logic (same as dashboard-flows)
    const defaultScenario =
      scenarios.find(
        (s: any) =>
          s?.isDefault || s?.default || s?.defaultScenario || s?.active || s?.isActive || s?.selected || s?.isSelected
      ) || null;

    if (defaultScenario && defaultScenario.id) {
      if (type === 'INFLOW') {
        this.onInflowChange(defaultScenario.id);
      } else {
        this.onOutflowChange(defaultScenario.id);
      }
    }
  }

  onInflowChange(value: string): void {
    const scenarioId = value || null;
    this.selectedInflowScenarioId = scenarioId;

    // Sync with service
    this.scenarioSyncService.setInflowScenario(scenarioId);

    // Close chart before loading new data to force refresh
    this.sankeyDataForChart = null;

    if (!value) {
      this.inflowImprovements = null;
      this.updateChart();
      return;
    }

    this.loadInflowScenario(value);
  }

  loadInflowScenario(id: string): void {
    this.loadingInflow = true;

    this.http
      .callService(new Method(environment.services.deleteDashboardScenario(id), '', 'get'))
      .pipe(take(1))
      .subscribe((res) => {
        this.inflowImprovements = res;
        this.loadingInflow = false;
        this.updateChart();
      });
  }

  onOutflowChange(value: string): void {
    const scenarioId = value || null;
    this.selectedOutflowScenarioId = scenarioId;

    // Sync with service
    this.scenarioSyncService.setOutflowScenario(scenarioId);

    // Close chart before loading new data to force refresh
    this.sankeyDataForChart = null;

    if (!value) {
      this.outflowImprovements = null;
      this.updateChart();
      return;
    }

    this.loadOutflowScenario(value);
  }

  loadOutflowScenario(id: string): void {
    this.loadingOutflow = true;

    this.http
      .callService(new Method(environment.services.deleteDashboardScenario(id), '', 'get'))
      .pipe(take(1))
      .subscribe((res) => {
        this.outflowImprovements = res;
        this.loadingOutflow = false;
        this.updateChart();
      });
  }

  private updateChart(): void {
    if (!this._baseSankey || Object.keys(this._baseSankey).length === 0) {
      return;
    }

    const next = structuredClone(this._baseSankey);

    if (this.selectedInflowScenarioId && this.inflowImprovements?.sankeyData) {
      const inflow = this.inflowImprovements.sankeyData;
      next.inflowCircularPercentage = inflow.inflowCircularPercentage;
      next.inflowLinearPercentage = inflow.inflowLinearPercentage;
      next.inflowCircularWeight = inflow.inflowCircularWeight;
      next.inflowLinearWeight = inflow.inflowLinearWeight;
      next.inflowWeight = inflow.inflowWeight;
      next.inflowCircularityPercentage = inflow.circularityPercentage;
    }

    if (this.selectedOutflowScenarioId && this.outflowImprovements?.sankeyData) {
      const outflow = this.outflowImprovements.sankeyData;
      next.outflowCircularPercentage = outflow.outflowCircularPercentage;
      next.outflowLinearPercentage = outflow.outflowLinearPercentage;
      next.outflowCircularWeight = outflow.outflowCircularWeight;
      next.outflowLinearWeight = outflow.outflowLinearWeight;
      next.outflowWeight = outflow.outflowWeight;
      next.displayPotentialRecoveryPercentage = outflow.displayPotentialRecoveryPercentage;
      next.displayNonPotentialRecoveryPercentage = outflow.displayNonPotentialRecoveryPercentage;
      next.displayActualRecoveryPercentage = outflow.displayActualRecoveryPercentage;
      next.displayNonActualRecoveryPercentage = outflow.displayNonActualRecoveryPercentage;
      next.actualRecoveryPercentageOverPotential = outflow.actualRecoveryPercentageOverPotential;
      next.nonActualRecoveryPercentageOverPotential = outflow.nonActualRecoveryPercentageOverPotential;
      next.potentialRecoveryWeight = outflow.potentialRecoveryWeight;
      next.nonPotentialRecoveryWeight = outflow.nonPotentialRecoveryWeight;
      next.actualRecoveryWeight = outflow.actualRecoveryWeight;
      next.nonActualRecoveryWeight = outflow.nonActualRecoveryWeight;
      next.outflowCircularityPercentage = outflow.circularityPercentage;
    }

    this.sankeyDataForChart = { sankey: next };
  }

  private computePerformanceRows(items: PerformanceConfig[], flowType: 'inflow' | 'outflow'): PerformanceRow[] {
    if (!this._baseSankey || !this.sankeyDataForChart?.sankey) {
      return [];
    }

    // Create a filtered current data that only includes relevant flow type data
    const current = this.sankeyDataForChart.sankey;
    const filteredCurrent: any = { ...this._baseSankey };

    // Only apply the relevant flow type's scenario data
    if (flowType === 'inflow' && this.selectedInflowScenarioId && this.inflowImprovements?.sankeyData) {
      const inflow = this.inflowImprovements.sankeyData;
      filteredCurrent.inflowCircularPercentage = inflow.inflowCircularPercentage;
      filteredCurrent.inflowLinearPercentage = inflow.inflowLinearPercentage;
      filteredCurrent.inflowCircularWeight = inflow.inflowCircularWeight;
      filteredCurrent.inflowLinearWeight = inflow.inflowLinearWeight;
      filteredCurrent.inflowWeight = inflow.inflowWeight;
      filteredCurrent.inflowCircularityPercentage = inflow.circularityPercentage;
    } else if (flowType === 'outflow' && this.selectedOutflowScenarioId && this.outflowImprovements?.sankeyData) {
      const outflow = this.outflowImprovements.sankeyData;
      filteredCurrent.outflowCircularPercentage = outflow.outflowCircularPercentage;
      filteredCurrent.outflowLinearPercentage = outflow.outflowLinearPercentage;
      filteredCurrent.outflowCircularWeight = outflow.outflowCircularWeight;
      filteredCurrent.outflowLinearWeight = outflow.outflowLinearWeight;
      filteredCurrent.outflowWeight = outflow.outflowWeight;
      filteredCurrent.outflowCircularityPercentage = outflow.circularityPercentage;
    }

    return items.map((item) => {
      // Fallback to circularityPercentage if specific field doesn't exist
      let baseField = item.field;
      let currentField = item.field;

      if (item.field === 'inflowCircularityPercentage' || item.field === 'outflowCircularityPercentage') {
        if (this._baseSankey[item.field] === undefined) {
          baseField = 'circularityPercentage';
        }
        if (filteredCurrent[item.field] === undefined) {
          currentField = 'circularityPercentage';
        }
      }

      const baseVal = this.toNumber(this._baseSankey[baseField]);
      const newVal = this.toNumber(filteredCurrent[currentField]);
      if (baseVal === null || newVal === null) {
        return { label: item.label, change: '-', newValue: '-', colorClass: '' };
      }

      const delta = newVal - baseVal;
      const isPercentage = item.unit === 'percent';

      // Logic:
      // For Percentage (Circularity): Increase (+) GREEN, Decrease (-) RED
      // For Mass (Weight): Decrease (-) GREEN, Increase (+) RED
      // Don't apply color if delta is 0 or very close to 0, or if newVal is 0
      let colorClass = '';
      if (delta > 0) {
        colorClass = isPercentage ? 'type-green' : 'type-red';
      } else if (delta < 0) {
        colorClass = isPercentage ? 'type-red' : 'type-green';
      }

      return {
        label: item.label,
        change: this.formatValue(delta, item.unit, true),
        newValue: this.formatValue(newVal, item.unit, false),
        colorClass: colorClass,
      };
    });
  }

  private toNumber(val: any): number | null {
    const num = typeof val === 'string' ? Number(val) : val;
    return typeof num === 'number' && !isNaN(num) ? num : null;
  }

  private formatValue(value: number, unit: 'percent' | 'mass', withSign: boolean): string {
    const rounded = unit === 'percent' ? value.toFixed(1) : value.toFixed(3);
    const prefix = withSign ? (value > 0 ? '+' : value < 0 ? '' : '') : '';
    const suffix = unit === 'percent' ? ' %' : ' kg';
    return `${prefix}${rounded}${suffix}`;
  }
}

interface PerformanceConfig {
  label: string;
  field: string;
  unit: 'percent' | 'mass';
}

interface PerformanceRow {
  label: string;
  change: string;
  newValue: string;
  colorClass: string;
}
