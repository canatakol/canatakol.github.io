import { Component, OnInit } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NewSupplierDialogComponent } from '@app/shared/dialog/new-supplier/new-supplier.component';
import { MaterialsComponent } from '../../assessment-level/materials/materials.component';
import { InviteNewMemberDialog } from '@app/shared/dialog/invite-new-member/invite-new-member.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  selector: 'app-add-material',
  templateUrl: './add-material.component.html',
  styleUrls: ['./add-material.component.scss'],
  standalone: false,
})
export class AddMaterialComponent implements OnInit {
  unitId = this.route.snapshot.params.unitId;
  users;
  storyblok;
  suppliers = [];
  dontShow = false;
  showCotinue = false;
  creatButtonDisabled = true;
  nameAvailable = false;
  supplierInfoDontShow;
  addColleagueMail;
  addColleagueId;
  addSupplierMail;
  suppliersRes;
  material = {
    displayName: '',
    category: '',
    ownership: 'ME',
    hasData: 'WE HAVE THE DATA',
    responsibleUserEmail: '',
    suppliers: '',
    colleague: '',
  };

  constructor(
    private http: ApiRequestService,
    private materialsComponent: MaterialsComponent,
    public router: Router,
    public route: ActivatedRoute,
    public commonService: CommonService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService
  ) {
    this.supplierInfoDontShow = localStorage.getItem('supplierInfoDontShow');
    if (this.commonService.addmaterialType === 'INFLOW') {
      this.material['category'] = 'INFLOW';
    }
    if (this.commonService.addmaterialType === 'OUTFLOW') {
      this.material['category'] = 'OUTFLOW';
      this.material.hasData = ' ';
      this.creatButtonDisabled = false;
    }
  }
  categoryChange() {
    this.material['hasData'] = '';
    this.material['ownership'] = '';
  }
  hasDataChange() {
    this.material['ownership'] = '';
  }
  hide(dontShow: any) {
    this.showCotinue = true;
    if (dontShow) {
      localStorage.setItem('supplierInfoDontShow', dontShow);
    }
  }
  async createMaterial(material: any, isAddUser: any) {
    material['tradeName'] = material['displayName'];
    material['unitId'] = this.unitId;
    if (!isAddUser) {
      if (material['hasData'] === 'SUPPLIER HAS THE DATA') {
        if (material['suppliers']) {
          this.material['responsibleUserEmail'] = material['suppliers'];
        }
        const data = {
          unitId: this.unitId,
          displayName: material['displayName'],
          responsibleUserEmail: this.material['responsibleUserEmail'],
          tradeName: material['displayName'],
        };
        this.http
          .callService(new Method(environment.services.addSuppliers(this.unitId, material['category']), data, 'post'))
          .subscribe((res) => {
            this.commonService.lastCreateMaterial = { id: res['id'], type: material['category'] };
            this.materialsComponent.hideModal();
            this.materialsComponent.initData();
          });
      } else {
        this.material['responsibleUserEmail'] = '';
        if (material['ownership'] === 'COLLEAGUE') {
          this.material['responsibleUserEmail'] = material['colleague'];
        } else {
          this.material['responsibleUserEmail'] = '';
        }
        this.http
          .callService(
            new Method(environment.services.addMaterial(this.unitId, material['category']), material, 'post')
          )
          .subscribe((res) => {
            this.commonService.lastCreateMaterial = { id: res['id'], type: material['category'] };
            this.materialsComponent.hideModal();
            this.materialsComponent.initData();
          });
      }
    } else {
      this.http
        .callService(
          new Method(environment.services.addMaterial(this.unitId, material['category']), this.material, 'post')
        )
        .subscribe((res) => {
          this.commonService.lastCreateMaterial = { id: res['id'], type: material['category'] };
          this.materialsComponent.hideModal();
          this.materialsComponent.initData();
        });
    }
    this.snackBar.open(this.commonService.storyblok?.success_message, '', {
      duration: 5000,
      panelClass: ['success-snackBar'],
    });
  }

  addUser(material: any): void {
    const dialogRef = this.dialog.open(InviteNewMemberDialog, {
      width: '80%',
      maxWidth: '640px',
      panelClass: 'centered-dialog',
      data: JSON.parse(localStorage.getItem('selectedBusiness')),
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.addColleagueMail = result['email'];
        this.addColleagueId = result['userId'];
        this.material['responsibleUserEmail'] = result['email'];
        this.creatButtonDisabled = false;
        this.createMaterial(material, true);
      } catch (error) {}
    });
  }

  addSupplier(material: string): void {
    if (material) {
      const dialogRef = this.dialog.open(NewSupplierDialogComponent, {
        width: '80%',
        maxWidth: '600px',
        panelClass: 'centered-dialog',
        data: { unitId: this.unitId, selectMaterial: material },
      });

      dialogRef.afterClosed().subscribe(async (result) => {
        if (!result) {
          return;
        }
        try {
          this.addSupplierMail = result;
          this.material.suppliers = result;
          this.material['responsibleUserEmail'] = result;
          this.creatButtonDisabled = false;
          this.createMaterial(material, false);
        } catch (error) {}
      });
    } else {
      this.snackBar.open(this.storyblok.no_flow_name, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    }
  }

  ngOnInit() {
    this.getUser();
    this.getSuppliers();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'add-flow');
      this.storyblok = story[0].content;
    });
  }
  getUser() {
    this.http.callService(new Method(environment.services.user() + '?size=999', '', 'get')).subscribe((res) => {
      const userListWithoutMyUser = [];
      res['results'].forEach((element) => {
        if (element.email !== localStorage.getItem('user-email')) {
          userListWithoutMyUser.push(element);
        }
        element.roles.forEach((role) => {
          if (role.name === 'Company admin') {
            element.admin = true;
          }
        });
      });
      this.users = userListWithoutMyUser;
      if (this.addColleagueMail) {
        this.material.colleague = this.addColleagueMail;
      }
    });
  }
  ownershipChange(owner: string) {
    if (owner === 'ME') {
      this.creatButtonDisabled = false;
    }
    if (owner !== 'ME') {
      this.creatButtonDisabled = true;
    }
  }
  getSuppliers() {
    this.http.callService(new Method(environment.services.suppliers(999), '', 'get')).subscribe((res) => {
      this.suppliersRes = res;
      if (this.addSupplierMail) {
        this.material.suppliers = this.addColleagueMail;
      }
    });
  }
  inviteColleague(val: string) {
    this.material.colleague = val;
    this.creatButtonDisabled = false;
  }

  inviteSupplier(val: string) {
    this.material.suppliers = val;
    this.creatButtonDisabled = false;
  }

  ckeckName() {
    if (this.material.displayName.length >= 3) {
      this.http
        .callService(
          new Method(
            environment.services.flowNameCheck(this.unitId, this.material.category),
            { name: this.material.displayName },
            'put'
          )
        )
        .subscribe((res) => {
          this.nameAvailable = res['available'];
        });
    } else {
      this.nameAvailable = false;
    }
  }

  cancel() {
    this.materialsComponent.hideModal();
  }
}
