import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { saveAs } from '@progress/kendo-file-saver';
import { LocalStorageService } from '@app/core/services/local-storage.service';
@Component({
  selector: 'app-aggregate-report',
  templateUrl: './aggregate-report.component.html',
  styleUrls: ['../../../assets/aggregate-report.css'],
  standalone: false,
})
export class AggregateReportComponent implements OnInit {
  environment = environment;
  data;
  storyblokReport;
  storyblok;
  assesmentList;
  packagingText;
  dashboardStoryblok;
  organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
  download = true;
  recoveryTypeBarVersionShow = false;
  aggregateReportCSS;
  fontStyles = this.environment.fileUrl + 'font.css';
  imgUrl = this.environment.fileUrl + 'img/CTITOOL_BIG_SIZE.png';
  reportCSS;
  date = new Date();
  reportName = 'aggregate-report.pdf';
  constructor(
    private sanitizer: DomSanitizer,
    private router: Router,
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {
    this.aggregateReportCSS = this.environment.aggregateReportCSS;
    this.reportCSS = this.environment.reportCSS;
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'aggregate-report');
      const compare = data.filter((item) => item.slug === 'aggregate');
      const packagingText = data.filter((item) => item.slug === 'packaging');
      const dashboardStoryblok = data.filter((item) => item.slug === 'step4-dashboard');
      this.storyblokReport = story.length > 0 ? story[0].content : {};
      this.storyblok = compare.length > 0 ? compare[0].content : {};
      this.packagingText = packagingText.length > 0 ? packagingText[0].content : {};
      this.dashboardStoryblok = dashboardStoryblok.length > 0 ? dashboardStoryblok[0].content : {};
    });
  }
  ngOnInit(): void {
    const aggregateData = this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY);
    if (aggregateData) {
      this.data = aggregateData;
      this.recoveryTypeBarVersionShow = this.data['aggregate'].recoveryType.breakdown.some(
        (element) => element.percentage === 100
      );
      this.getProData();
    } else {
      this.router.navigate(['cti/pro']);
    }
  }

  getProData() {
    this.http.callService(new Method(environment.services.getCTIProDashboard(), '', 'get')).subscribe((res) => {
      this.assesmentList = res;
      this.assesmentList.forEach((businnes) => {
        businnes.showAsssessment = [];
        businnes.assessments.forEach((assesment, index) => {
          this.data.assessments.forEach((element) => {
            if (assesment.unitId === element.id) {
              assesment.startPeriod = element.startPeriod;
              assesment.endPeriod = element.endPeriod;
              businnes.showAsssessment.push(assesment);
            }
          });
        });
      });
      if (environment.name !== 'default-cti') {
        setTimeout(() => {
          this.downloadReport();
        }, 2000);
      }
    });
  }
  downloadReport() {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    const token = credentials.authToken;
    const markup = document.getElementById('pdfContainer');
    const parser = markup.outerHTML;
    const data = btoa(unescape(encodeURIComponent(parser)));
    const f = `  <img style="width: 100%;"  src="${location.origin}/assets/img/report-footer.png" alt="">`;
    const fd = window.btoa(f);
    fetch(environment.serverUrl + '/pdf/generate', {
      headers: {
        'x-auth-token': token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ footer: fd, report: data }),
      method: 'PUT',
    })
      .then((response) => {
        if (response.status !== 200) {
          this.router.navigate(['login']);
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const blob = new Blob([buffer], { type: 'application/pdf' });
        saveAs(blob, this.reportName);
      })
      .then((buffer) => {
        this.download = false;
      });
  }
}
