import { Component, OnInit } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';

declare var $: any;

@Component({
  selector: 'app-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss'],
  standalone: false,
})
export class StepperComponent implements OnInit {
  criticalBoxShow = false;
  step;
  storyblok;
  isGHGShow;
  activeStep5Tab = 0;
  activeStep6Tab = 0;
  activeStep;
  activeCase5 = 'inflow-question';
  activeCase6 = 'inflow6';
  activeCase7;
  unitId = this.route.snapshot.params.unitId;
  id;
  indicators;
  closeTheLoop;
  optimizeTheLoop;
  impactTheLoop;
  isShowstep5Intro;
  isShowstep6Intro;
  constructor(
    private http: ApiRequestService,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private storyblokService: StoryblokService
  ) {
    if (!this.indicators) {
      this.http.callService(new Method(environment.services.getIndicators(this.unitId), '', 'get')).subscribe((res) => {
        this.indicators = res;
        sessionStorage.setItem('indicators', JSON.stringify(this.indicators));
        this.commonService.stepsData.next(this.indicators);
      });
    }

    this.activeStep =
      this.route.snapshot.url[this.route.snapshot.url.length - 1].path === 'materials'
        ? 'step3'
        : this.route.snapshot.url[this.route.snapshot.url.length - 1].path;

    this.route.params.subscribe((params) => {
      this.unitId = params.unitId;
    });
    this.isShowstep5Intro = localStorage.getItem('isShowstep5Intro');
    this.commonService.isShowstep5Intro.subscribe((res) => {
      this.isShowstep5Intro = res;
    });
    this.isShowstep6Intro = localStorage.getItem('isShowstep6Intro');
    this.commonService.isShowstep6Intro.subscribe((res) => {
      this.isShowstep6Intro = res;
    });
    if (sessionStorage.getItem('ctiUnitGuidance')) {
      this.step = JSON.parse(sessionStorage.getItem('ctiUnitGuidance'));
    } else {
      this.http
        .callService(new Method(environment.services.ctiUnitGuidance(this.unitId), '', 'get'))
        .subscribe((res) => {
          this.step = res;
          sessionStorage.setItem('ctiUnitGuidance', JSON.stringify(res));
          this.commonService.stepsData.next(res);
        });
    }
    this.commonService.step5ActiveCase.subscribe((res) => {
      this.activeCase5 = res;
      if (res === 'GHGImpactAnalysis') {
        this.activeStep5Tab = 2;
      }
      if (res === 'inflow-question') {
        this.activeStep5Tab = 0;
      }
    });
    this.commonService.step6ActiveCase.subscribe((res) => {
      this.activeCase6 = res;
      if (res === 'inflow6') {
        this.activeStep6Tab = 0;
      }
    });
    this.commonService.step7ActiveCase.subscribe((res) => {
      this.activeCase7 = res;
    });
    if (this.commonService.stepsData) {
      this.commonService.stepsData.subscribe((res) => {
        this.step = res;
        sessionStorage.setItem('ctiUnitGuidance', JSON.stringify(res));
      });
      this.commonService.refreshStep.subscribe((res) => {
        sessionStorage.setItem('ctiUnitGuidance', JSON.stringify(res));
        this.step = JSON.parse(sessionStorage.getItem('ctiUnitGuidance'));
      });
    }
    this.criticalBoxShow = this.indicators ? this.indicators?.criticalInflow : false;
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'stepper');
      this.storyblok = story[0].content;
    });
  }
  ngOnInit(): void {
    this.commonService.selectedUnit = JSON.parse(sessionStorage.getItem('selectedAssessment'));
    this.isGHGShow = this.commonService.isGHGShow;
  }
  setActiveCase5(active: string) {
    switch (Number(active['index'])) {
      case 0:
        active = 'inflow-question';
        break;
      case 1:
        if (this.indicators?.waterCircularity) {
          active = 'waterAnalaysis';
        } else {
          if (this.indicators?.greenhouseGases) {
            active = 'GHGImpactAnalysis';
          } else {
            if (this.indicators?.natureImpact) {
              active = 'NatureImpactAnalysis';
            }
          }
        }
        break;
      case 2:
        if (this.indicators?.greenhouseGases) {
          active = 'GHGImpactAnalysis';
        } else {
          if (this.indicators?.natureImpact) {
            active = 'NatureImpactAnalysis';
          }
        }
        break;
      default:
        active = active;
        break;
    }
    this.activeCase5 = active;
    this.commonService.step5ActiveCase.next(this.activeCase5);
  }
  setActiveCase6(active: string) {
    switch (Number(active['index'])) {
      case 0:
        active = 'inflow6';
        break;
      case 1:
        active = 'water';
        break;
      default:
        active = active;
        break;
    }
    this.activeCase6 = active;
    this.commonService.step6ActiveCase.next(this.activeCase6);
  }
  setActiveCase7(active: string) {
    this.activeCase7 = active;
    this.commonService.step7ActiveCase.next(this.activeCase7);
  }
}
