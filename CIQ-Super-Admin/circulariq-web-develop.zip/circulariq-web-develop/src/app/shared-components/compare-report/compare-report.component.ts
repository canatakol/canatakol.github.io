import { DatePipe, CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { environment } from '@env/environment';
import { saveAs } from '@progress/kendo-file-saver';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

@Component({
  selector: 'app-compare-report',
  templateUrl: './compare-report.component.html',
  standalone: true,
  imports: [CommonModule, TruncatePipe, CiqNumberPipe],
})
export class CompareReportComponent implements OnInit {
  environment = environment;
  data;
  chunkedData: any[][] = [];
  organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
  download = true;
  compareReportCSS;
  fontStyles = this.environment.fileUrl + 'font.css';
  imgUrl = this.environment.fileUrl + 'img/CTITOOL_BIG_SIZE.png';
  CLdata;
  selectAssetList = JSON.parse(localStorage.getItem('selectAssetList'));
  totalRevenues;
  CTIRevenues;
  storyblok;
  storyblokReport;
  actualLifetimeStoryblok;
  date = new Date();
  reportName = 'compare-report.pdf';
  assessmentsWithActualLifetime = [];
  firstHalfAssessmentsWithActualLifetime = [];
  constructor(
    private sanitizer: DomSanitizer,
    private router: Router,
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {
    this.compareReportCSS = this.environment.compareReportCSS;
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'compare-report');
      const compare = data.filter((item) => item.slug === 'compare');
      const actualLifetimeStoryblok = data.filter((item) => item.slug === 'actual-lifetime');
      this.storyblokReport = story[0].content;
      this.storyblok = compare[0].content;
      this.actualLifetimeStoryblok = actualLifetimeStoryblok[0].content;
    });
  }
  chunkData(): void {
    const chunkSize = 18;
    this.chunkedData = [];
    for (let i = 0; i < this.data.length; i += chunkSize) {
      this.chunkedData.push(this.data.slice(i, i + chunkSize));
    }
  }
  async ngOnInit(): Promise<void> {
    const compareData = this.localStorageService.getCompressedItem(this.localStorageService.COMPARE_DATA_KEY);
    if (compareData) {
      this.data = compareData;
      this.chunkData();
      const datePipe = new DatePipe('en-US');
      this.data.forEach((assess) => {
        try {
          assess.startDateText = datePipe.transform(assess.startDate, 'MM/yyyy');
          assess.endDateText = datePipe.transform(assess.endDate, 'MM/yyyy');
        } catch (err) {
          // Error on date transform
        }
      });
      this.data.forEach((element, index) => {
        if (element.actualLifetimeData) {
          this.assessmentsWithActualLifetime.push(element);
        }
      });
      const firstHalfAssessmentsWithActualLifetime = Math.ceil(this.assessmentsWithActualLifetime.length / 2);
      this.firstHalfAssessmentsWithActualLifetime = this.assessmentsWithActualLifetime.slice(
        0,
        firstHalfAssessmentsWithActualLifetime
      );
    } else {
      this.router.navigate(['cti/pro']);
    }
    if (!this.CLdata && this.selectAssetList) {
      this.revenueCompanyLevel();
    }
    if (environment.name !== 'default-cti') {
      setTimeout(() => {
        this.downloadReport();
      }, 2000);
    }
  }
  downloadReport() {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    const token = credentials.authToken;
    const markup = document.getElementById('pdfContainer');
    const parser = markup.outerHTML;
    const data = btoa(unescape(encodeURIComponent(parser)));
    const footerImage = `  <img style="width: 100%;"  src="${location.origin}/assets/img/report-footer.png" alt="">`;
    const footer = window.btoa(footerImage);
    fetch(environment.serverUrl + '/pdf/generate', {
      headers: {
        'x-auth-token': token,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ footer: footer, report: data }),
      method: 'PUT',
    })
      .then((response) => {
        if (response.status !== 200) {
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const blob = new Blob([buffer], { type: 'application/pdf' });
        saveAs(blob, this.reportName);
      })
      .then((buffer) => {
        this.download = false;
      });
  }

  revenueCompanyLevel() {
    this.http
      .callService(new Method(environment.services.revenueCompanyLevel(), this.selectAssetList, 'put'))
      .subscribe((res) => {
        this.CLdata = res;
        const largestImprovedMaterials = Math.max.apply(
          Math,
          this.CLdata.map(function (o: any) {
            return o.totalCtiRevenue;
          })
        );
        this.CLdata.forEach((item) => {
          item.percentage = (item.totalCtiRevenue / largestImprovedMaterials) * 100;
        });
        this.totalRevenues = Number(this.CLdata.reduce((n, { totalRevenue }) => n + totalRevenue, 0));
        this.CTIRevenues = Number(this.CLdata.reduce((n, { totalCtiRevenue }) => n + totalCtiRevenue, 0));
      });
  }
}
