import {
  Component,
  Input,
  OnInit,
  ViewChild,
  AfterViewInit,
  OnChanges,
  SimpleChanges,
  OnDestroy,
  HostListener,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { environment } from '@env/environment';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule, MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSortModule, MatSort, Sort } from '@angular/material/sort';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { Subscription } from 'rxjs';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import {
  DashboardFlowsUnsavedService,
  DASHBOARD_FLOW_UNSAVED_MESSAGE,
} from '../dashboard-flows/dashboard-flows-unsaved.service';
import { DashboardScenarioSyncService } from '../dashboard-flows/dashboard-scenario-sync.service';
import { DashboardFlowsDraftService, FlowType } from '../dashboard-flows/dashboard-flows-draft.service';
import { DashboardFlowsMetricsService, SankeyMetrics } from '../dashboard-flows/dashboard-flows-metrics.service';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import {
  normalizePercentageValue,
  transformFlowItem,
  mapReplacementToFlow,
  mapImprovementToFlow,
  buildDisplayedList,
  getFlowName as getFlowNameUtil,
} from '../dashboard-flows/utils/flow-data-transformer.util';
import * as UIUtils from '../dashboard-flows/utils/dashboard-flows-ui.util';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { take } from 'rxjs/operators';
import { DashboardFlowsSankeyService } from '../dashboard-flows/dashboard-flows-sankey.service';
import { DashboardFlowsActionService } from '../dashboard-flows/dashboard-flows-action.service';
import {
  DashboardFlowsGroupDetailModalComponent,
  GroupDetailModalData,
} from './dashboard-flows-group-detail-modal/dashboard-flows-group-detail-modal.component';

@Component({
  selector: 'app-dashboard-flows-group',
  templateUrl: './dashboard-flows-group.component.html',
  styleUrls: ['./dashboard-flows-group.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    CiqNumberPipe,
    TruncatePipe,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatCheckboxModule,
    LoadingBarComponent,
    MatDialogModule,
    MatSnackBarModule,
    ReactiveFormsModule,
  ],
})
export class DashboardFlowsGroupComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @Input() public report: boolean;
  @Input() public dashboardId: string;
  @Input() public type: string;
  @Input() public importData: any;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  inflowsScenarios: any[] = [];
  outflowsScenarios: any[] = [];
  storyblok;
  storyblokDashboardFlow: any;
  environment = environment;
  selectedItemData;
  detailshow = false;
  dashboardPage = false;
  displayedData: any[] = [];
  pageSize = 10;
  pageSizeOptions = [10, 25, 50, 100];
  totalCount = 0;
  isLoading = false;
  hasLoaded = false;
  selectedFlows: string[] = [];
  temporary = {
    weight: 0,
    circularPercentage: 0,
  };
  inflowOriginalScenarioText = '';
  outflowOriginalScenarioText = '';
  selectedFilter = 'material-category';
  filterDropdownOpen = false;
  private paginatorSubscription: Subscription | null = null;
  private scenarioControlSubscription: Subscription | null = null;
  private scenarioSyncSubscription: Subscription | null = null;
  private filterSyncSubscription: Subscription | null = null;
  private isUpdatingFromFilterSync = false;
  private readonly dashboardFlowsUnsavedService = inject(DashboardFlowsUnsavedService);
  private readonly scenarioSyncService = inject(DashboardScenarioSyncService);
  private readonly draftService = inject(DashboardFlowsDraftService);
  private readonly metricsService = inject(DashboardFlowsMetricsService);
  private readonly sankeyService = inject(DashboardFlowsSankeyService);
  private readonly actionService = inject(DashboardFlowsActionService);
  showActionIsland = false;
  replacedFlows: Map<string, Set<string>> = new Map();
  createdScenarioName: string | null = null;
  expandedBaseFlowId: string | null = null;
  selectedScenarioId: string | null = null;
  scenarioControl = new FormControl<string | null>(null);
  private scenarioControlInitialized = false;
  private isUpdatingFromSync = false;
  showOnlyChanges = false;
  isScenarioDirty = false;

  /** Material category groups (when selectedFilter === 'material-category'); each has groupItem, subCategories, id. */
  groupsList: { id: string; groupItem: any; subCategories: any[] }[] = [];
  /** Which group ids are expanded to show sub_categories. */
  expandedGroupIds = new Set<string>();

  constructor(
    private storyblokService: StoryblokService,
    private http: ApiRequestService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private localStorageService: LocalStorageService
  ) {}

  readonly filterOptions: { id: string; label: string; description: string }[] = [
    {
      id: 'material-category',
      label: 'Material category',
      description: 'Grouping the flows in your assessments per material group',
    },
    {
      id: 'group-by-flow-name',
      label: 'Group by flow name',
      description: 'Grouping the flows in your assessments per flow name',
    },
    {
      id: 'same-name-and-circularity',
      label: 'Same name and circularity',
      description: 'Grouping the flows in your assessments per flow name and exact CI and CO values',
    },
  ];

  get selectedFilterOption(): { id: string; label: string; description: string } {
    return this.filterOptions.find((o) => o.id === this.selectedFilter) ?? this.filterOptions[0];
  }

  toggleFilterDropdown(): void {
    this.filterDropdownOpen = !this.filterDropdownOpen;
    if (this.filterDropdownOpen) {
      this.productPackagingDropdownOpen = false;
      this.suppliersDropdownOpen = false;
      this.currentViewDropdownOpen = false;
    }
  }

  selectFilter(id: string): void {
    this.selectedFilter = id;
    this.filterDropdownOpen = false;
    // Sync filter selection: when INFLOWS changes, notify service so OUTFLOWS can sync
    if (this.type === 'INFLOWS' && !this.isUpdatingFromFilterSync) {
      this.scenarioSyncService.setFilterSelection(id);
    }
    if (this.dashboardId) {
      this.loadFlowsData(true);
    }
  }

  // Area B: Product, packaging and waste + Suppliers multi-select dropdowns
  productPackagingDropdownOpen = false;
  suppliersDropdownOpen = false;
  readonly productPackagingOptions: { id: string; label: string; description: string }[] = [
    { id: 'products', label: 'Products', description: 'Inline with GCP' },
    { id: 'plastics', label: 'Plastics', description: 'Discover product and packaging hotpoints' },
    { id: 'waste', label: 'Waste', description: 'Flows with same name' },
  ];
  readonly supplierOptions: { id: string; label: string }[] = [
    { id: 'supplier-a', label: 'Supplier A' },
    { id: 'supplier-b', label: 'Supplier B' },
    { id: 'supplier-c', label: 'Supplier C' },
  ];
  selectedProductPackagingIds = new Set<string>(['products', 'plastics', 'waste']);
  selectedSupplierIds = new Set<string>(['supplier-a', 'supplier-b', 'supplier-c']);

  toggleProductPackagingDropdown(): void {
    this.productPackagingDropdownOpen = !this.productPackagingDropdownOpen;
    if (this.productPackagingDropdownOpen) {
      this.suppliersDropdownOpen = false;
      this.filterDropdownOpen = false;
      this.currentViewDropdownOpen = false;
    }
  }

  toggleSuppliersDropdown(): void {
    this.suppliersDropdownOpen = !this.suppliersDropdownOpen;
    if (this.suppliersDropdownOpen) {
      this.productPackagingDropdownOpen = false;
      this.filterDropdownOpen = false;
      this.currentViewDropdownOpen = false;
    }
  }

  // Area C: New section – Current view dropdown (example data, not linked to scenarios)
  currentViewDropdownOpen = false;
  readonly currentViewOptions: { id: string; label: string }[] = [
    { id: 'current-view', label: 'Current view' },
    { id: 'current-view-2', label: 'Current view 2' },
  ];
  selectedCurrentViewId: string | null = null;

  get selectedCurrentViewLabel(): string {
    if (this.selectedCurrentViewId == null) return 'Current view';
    return this.currentViewOptions.find((v) => v.id === this.selectedCurrentViewId)?.label ?? 'Current view';
  }

  toggleCurrentViewDropdown(): void {
    this.currentViewDropdownOpen = !this.currentViewDropdownOpen;
    if (this.currentViewDropdownOpen) {
      this.filterDropdownOpen = false;
      this.productPackagingDropdownOpen = false;
      this.suppliersDropdownOpen = false;
    }
  }

  selectCurrentViewOption(id: string): void {
    this.selectedCurrentViewId = id;
    this.currentViewDropdownOpen = false;
  }

  onNewCustomView(): void {
    this.actionService.openNewCustomViewDialog().subscribe((result) => {
      if (result !== undefined) {
        // User confirmed with optional value – can be wired later
      }
    });
  }

  isProductPackagingSelected(id: string): boolean {
    return this.selectedProductPackagingIds.has(id);
  }

  toggleProductPackaging(id: string): void {
    if (this.selectedProductPackagingIds.has(id)) {
      this.selectedProductPackagingIds.delete(id);
    } else {
      this.selectedProductPackagingIds.add(id);
    }
    this.selectedProductPackagingIds = new Set(this.selectedProductPackagingIds);
    if (this.selectedFilter === 'material-category') {
      this.loadFlowsData(true);
    }
  }

  isSupplierSelected(id: string): boolean {
    return this.selectedSupplierIds.has(id);
  }

  toggleSupplier(id: string): void {
    if (this.selectedSupplierIds.has(id)) {
      this.selectedSupplierIds.delete(id);
    } else {
      this.selectedSupplierIds.add(id);
    }
    this.selectedSupplierIds = new Set(this.selectedSupplierIds);
  }

  @HostListener('document:click')
  onDocumentClick(): void {
    this.filterDropdownOpen = false;
    this.productPackagingDropdownOpen = false;
    this.suppliersDropdownOpen = false;
    this.currentViewDropdownOpen = false;
  }

  @HostListener('window:beforeunload', ['$event'])
  handleBeforeUnload(event: BeforeUnloadEvent): string | void {
    if (this.shouldWarnBeforeLeave()) {
      event.preventDefault();
      event.returnValue = DASHBOARD_FLOW_UNSAVED_MESSAGE;
      return DASHBOARD_FLOW_UNSAVED_MESSAGE;
    }
    return undefined;
  }

  close() {
    this.detailshow = false;
  }

  replaceFlow(item: any) {
    this.actionService.openReplaceFlowDialog(item, this.type).subscribe((result) => {
      if (!result) return;
      const action = result.action || 'REPLACE';
      const data = result.data || result;

      if (action === 'REPLACE') {
        this.handleReplaceAction(item, data);
      } else if (action === 'ADD') {
        this.handleAddAction(item, data);
      }

      if (this.selectedScenarioId) this.isScenarioDirty = true;
      this.updateUnsavedChangesState();
      this.checkAndShowActionIsland();
      this.loadPreviewSankeyData();
    });
  }

  private handleReplaceAction(item: any, data: any) {
    this.captureInitialSnapshotIfNeeded(item);
    const newRow = JSON.parse(JSON.stringify(item));
    const baseFlowName = this.getFlowName(item);

    if (data.name) newRow.name = data.name;

    const baseValues = this.metricsService.calculateItemMasses(item, false, this.type as any);
    const originalWeight = baseValues.total;
    const originalLinearPercentage = (baseValues.linear / baseValues.total) * 100 || 0;

    newRow.baseFlowCircularity = 100 - originalLinearPercentage;
    newRow.baseFlowTotalMass = originalWeight;
    newRow.baseFlowPotentialRecovery = this.getBaseRowPotentialRecovery(item);
    newRow.baseFlowActualRecovery = this.getBaseRowActualRecovery(item);

    newRow.baseBeforeImprove = {
      weight: originalWeight,
      linearPercentage: originalLinearPercentage,
      circularPercentage: 100 - originalLinearPercentage,
      potentialRecovery: newRow.baseFlowPotentialRecovery,
      actualRecovery: newRow.baseFlowActualRecovery,
    };

    newRow.__initialSnapshot = {
      weight: originalWeight,
      linearPercentage: originalLinearPercentage,
      potentialRecovery: newRow.baseFlowPotentialRecovery,
      actualRecovery: newRow.baseFlowActualRecovery,
    };

    newRow.weight = data.weight !== undefined ? data.weight : originalWeight;
    newRow.totalMass = newRow.weight;
    const normalizedTI9 = normalizePercentageValue(data.TI9 !== undefined ? data.TI9 : originalLinearPercentage);
    newRow.linearPercentage = normalizedTI9;

    if (this.type === 'INFLOWS') {
      newRow.circularPercentage = 100 - normalizedTI9;
      newRow.linearMass = (newRow.weight * normalizedTI9) / 100;
      newRow.circularWeight = (newRow.weight * (100 - normalizedTI9)) / 100;
      newRow.nonVirginRenewablePercentage = data.TI17;
      newRow.nonVirginNonRenewablePercentage = data.TI2;
      newRow.virginRenewablePercentage = data.TI1;
      newRow.virginNonRenewablePercentage = data.TI9 !== undefined ? data.TI9 : originalLinearPercentage;
    } else {
      newRow.potentialRecovery =
        data.potentialRecovery !== undefined ? data.potentialRecovery : newRow.baseFlowPotentialRecovery;
      newRow.actualRecovery = data.actualRecovery !== undefined ? data.actualRecovery : newRow.baseFlowActualRecovery;
    }

    newRow.temporaryReplaceFlow = {
      weight: data.weight,
      potentialRecovery: data.potentialRecovery,
      actualRecovery: data.actualRecovery,
      linearPercentage: this.type === 'INFLOWS' ? normalizedTI9 : undefined,
    };

    newRow.isReplaced = true;
    newRow.baseFlowName = baseFlowName;
    newRow.baseFlowId = item?.id;
    delete newRow.temporaryImproveFlow;
    newRow.id = `${item.id || 'flow'}_replaced_${Date.now()}`;

    const index = this.displayedData.indexOf(item);
    if (index !== -1) {
      newRow.__historyKey = this.getHistoryKey(item, index);
      this.displayedData.splice(index, 1, newRow);
    }

    if (!this.replacedFlows.has(this.type)) this.replacedFlows.set(this.type, new Set());
    this.replacedFlows.get(this.type)!.add(newRow.name || newRow.id);
    this.persistReplaceDraft(item, newRow);
  }

  private handleAddAction(item: any, data: any) {
    const normalizedTI9 = normalizePercentageValue(data.TI9);
    const newFlow: any = {
      ...item,
      id: `new_${Date.now()}`,
      name: data.name || this.storyblokDashboardFlow?.newFlowDefaultName || '',
      weight: data.weight,
      totalMass: data.weight,
      linearPercentage: normalizedTI9,
      nonVirginRenewablePercentage: data.TI17,
      nonVirginNonRenewablePercentage: data.TI2,
      virginRenewablePercentage: data.TI1,
      virginNonRenewablePercentage: data.TI9,
      potentialRecovery: data.potentialRecovery,
      actualRecovery: data.actualRecovery,
      assessments: [],
      isReplaced: true,
    };

    if (this.type === 'INFLOWS') {
      newFlow.circularPercentage = 100 - normalizedTI9;
      newFlow.linearMass = (data.weight * normalizedTI9) / 100;
      newFlow.circularWeight = (data.weight * (100 - normalizedTI9)) / 100;
    }

    newFlow.__initialSnapshot = {
      weight: data.weight,
      linearPercentage: normalizedTI9,
      potentialRecovery: normalizePercentageValue(data.potentialRecovery ?? 0),
      actualRecovery: normalizePercentageValue(data.actualRecovery ?? 0),
    };

    newFlow.baseBeforeImprove = {
      weight: data.weight,
      linearPercentage: normalizedTI9,
      circularPercentage: this.type === 'INFLOWS' ? 100 - normalizedTI9 : 0,
      potentialRecovery: newFlow.__initialSnapshot.potentialRecovery,
      actualRecovery: newFlow.__initialSnapshot.actualRecovery,
    };

    newFlow.temporaryReplaceFlow = {
      weight: data.weight,
      potentialRecovery: data.potentialRecovery,
      actualRecovery: data.actualRecovery,
      linearPercentage: this.type === 'INFLOWS' ? normalizedTI9 : undefined,
    };

    newFlow.__historyKey = this.createHistoryKey(newFlow, this.displayedData.length);
    this.displayedData.push(newFlow);
    this.totalCount++;
    this.persistReplaceDraft(item, newFlow, true);
  }

  toggleBaseFlow(item: any, index?: number): void {
    const id = this.getHistoryKey(item, index);
    if (this.expandedBaseFlowId === id) {
      this.expandedBaseFlowId = null;
    } else {
      this.expandedBaseFlowId = id;
    }
  }

  improveFlow(item: any) {
    this.ensureBaseBeforeImprove(item);
    this.captureInitialSnapshotIfNeeded(item);

    this.actionService.openImproveFlowDialog(item, this.type).subscribe((result) => {
      if (!result) return;
      this.handleImproveResult(item, result);
      if (this.selectedScenarioId) this.isScenarioDirty = true;
      this.updateUnsavedChangesState();
      this.checkAndShowActionIsland();
      this.loadPreviewSankeyData();
    });
  }

  private ensureBaseBeforeImprove(item: any) {
    if (item.baseBeforeImprove) return;
    const baseWeight = item.weight ?? item.totalMass ?? 0;
    if (this.type === 'INFLOWS') {
      const baseLinearPct = normalizePercentageValue(item.linearPercentage ?? 0);
      item.baseBeforeImprove = {
        weight: baseWeight,
        linearPercentage: baseLinearPct,
        circularPercentage: normalizePercentageValue(item.circularPercentage ?? Math.max(0, 100 - baseLinearPct)),
        linearMass: (baseWeight * baseLinearPct) / 100,
        circularMass: Math.max(0, baseWeight - (baseWeight * baseLinearPct) / 100),
      };
    } else {
      item.baseBeforeImprove = {
        weight: baseWeight,
        potentialRecovery: normalizePercentageValue(item.potentialRecovery ?? 0),
        actualRecovery: normalizePercentageValue(item.actualRecovery ?? 0),
      };
    }
  }

  private handleImproveResult(item: any, result: any) {
    if (!item.temporaryImproveFlow) item.temporaryImproveFlow = {};
    if (result.weight !== undefined) item.temporaryImproveFlow.weight = result.weight;
    if (this.type === 'OUTFLOWS') {
      if (result.potentialRecovery !== undefined)
        item.temporaryImproveFlow.potentialRecovery = result.potentialRecovery;
      if (result.actualRecovery !== undefined) item.temporaryImproveFlow.actualRecovery = result.actualRecovery;
    } else {
      if (result.linearPercentage !== undefined) item.temporaryImproveFlow.linearPercentage = result.linearPercentage;
    }
    this.applyImprovedValuesToItem(item);
    this.persistImproveDraft(item);
  }

  private applyImprovedValuesToItem(item: any): void {
    if (!item) return;
    const total = item.temporaryImproveFlow?.weight ?? item.weight ?? item.totalMass ?? 0;
    const linearPct =
      this.type === 'INFLOWS'
        ? normalizePercentageValue(item.temporaryImproveFlow?.linearPercentage ?? item.linearPercentage ?? 0)
        : item.linearPercentage;

    item.weight = total;
    item.totalMass = total;
    if (this.type === 'INFLOWS') {
      item.linearPercentage = linearPct;
      item.circularPercentage = Math.max(0, 100 - linearPct);
      item.linearMass = (total * linearPct) / 100;
      item.circularMass = Math.max(0, total - item.linearMass);
    } else {
      if (item.temporaryImproveFlow?.potentialRecovery !== undefined)
        item.potentialRecovery = normalizePercentageValue(item.temporaryImproveFlow.potentialRecovery);
      if (item.temporaryImproveFlow?.actualRecovery !== undefined)
        item.actualRecovery = normalizePercentageValue(item.temporaryImproveFlow.actualRecovery);
    }
  }

  getDetail(item: any) {
    this.selectedItemData = item;
    this.detailshow = true;
  }

  /**
   * Opens group detail modal showing all flows in the selected material category group
   */
  openGroupDetailModal(group: any): void {
    if (!group?.groupItem) return;

    const flowTypeArray = Array.from(this.selectedProductPackagingIds);
    const flowCategory = this.type === 'INFLOWS' ? 'inflow' : 'outflow';

    const modalData: GroupDetailModalData = {
      baselineId: this.dashboardId,
      materialCategory: group.groupItem.material_category || group.groupItem.name,
      subMaterialCategory: group.groupItem.sub_material_category,
      flowType: flowTypeArray,
      flowCategory: flowCategory,
      groupLabel: this.getFlowLabel(group.groupItem) || '',
      groupName: this.getFlowDisplayName(group.groupItem),
      summaryItem: group.groupItem,
    };

    this.dialog.open(DashboardFlowsGroupDetailModalComponent, {
      width: '80vw',
      maxWidth: 'none',
      height: '100vh',
      data: modalData,
      panelClass: 'flows-detail-panel-dialog',
      position: { right: '0', top: '0', bottom: '0' },
      hasBackdrop: true,
      backdropClass: 'flows-detail-panel-dialog-backdrop',
      disableClose: false,
    });
  }

  /**
   * Opens subgroup detail modal
   */
  openSubGroupDetailModal(subItem: any, parentGroup: any): void {
    if (!subItem) return;

    const flowTypeArray = Array.from(this.selectedProductPackagingIds);
    const flowCategory = this.type === 'INFLOWS' ? 'inflow' : 'outflow';

    const modalData: GroupDetailModalData = {
      baselineId: this.dashboardId,
      materialCategory: parentGroup?.groupItem?.material_category || parentGroup?.groupItem?.name,
      subMaterialCategory: subItem.sub_material_category || subItem.name,
      flowType: flowTypeArray,
      flowCategory: flowCategory,
      groupLabel: this.getFlowLabel(subItem) || '',
      groupName: this.getFlowDisplayName(subItem),
      summaryItem: subItem,
    };

    console.log('📂 Opening subgroup detail modal:', modalData);

    this.dialog.open(DashboardFlowsGroupDetailModalComponent, {
      width: '80vw',
      maxWidth: 'none',
      height: '100vh',
      data: modalData,
      panelClass: 'flows-detail-panel-dialog',
      position: { right: '0', top: '0', bottom: '0' },
      hasBackdrop: true,
      backdropClass: 'flows-detail-panel-dialog-backdrop',
      disableClose: false,
    });
  }

  ngOnInit(): void {
    this.dashboardPage = window.location.href.includes('dashboard');
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'aggregate');
      this.storyblok = story.length > 0 ? story[0].content : {};
      const dashboardFlowStory = data.find((item) => item.slug === 'dashboard-flows');
      this.storyblokDashboardFlow = dashboardFlowStory?.content || {};
      this.updateScenarioTextLabels();
    });

    this.loadBaseSankeyData();

    this.dashboardId = this.dashboardId || this.resolveDashboardIdFromRoute();

    this.scenarioControlSubscription = this.scenarioControl.valueChanges.subscribe((id) => {
      this.selectedScenarioId = id || null;
      if (!this.isUpdatingFromSync) {
        if (this.type === 'INFLOWS') {
          this.scenarioSyncService.setInflowScenario(id || null);
        } else if (this.type === 'OUTFLOWS') {
          this.scenarioSyncService.setOutflowScenario(id || null);
        }
      }

      this.isScenarioDirty = false;
      this.expandedBaseFlowId = null;
      if (!id) this.sankeyService.clearScenarioSankeyData();
      this.loadScenarioSankeyData(id);

      if (this.dashboardId) this.loadFlowsData(true);
    });

    const syncSub =
      this.type === 'INFLOWS' ? this.scenarioSyncService.inflowScenario$ : this.scenarioSyncService.outflowScenario$;
    this.scenarioSyncSubscription = syncSub.subscribe((scenarioId) => {
      if (scenarioId !== this.selectedScenarioId) {
        this.isUpdatingFromSync = true;
        this.setScenarioSelection(scenarioId);
        this.loadScenarioSankeyData(scenarioId);
        this.isUpdatingFromSync = false;
      }
    });

    // Filter synchronization: OUTFLOWS listens to INFLOWS filter changes
    this.filterSyncSubscription = this.scenarioSyncService.filterSelection$.subscribe((filterId) => {
      if (this.type === 'OUTFLOWS' && this.selectedFilter !== filterId) {
        this.isUpdatingFromFilterSync = true;
        this.selectedFilter = filterId;
        if (this.dashboardId) {
          this.loadFlowsData(true);
        }
        this.isUpdatingFromFilterSync = false;
      }
    });

    // Initialize filter from service (in case OUTFLOWS loads before INFLOWS changes filter)
    if (this.type === 'OUTFLOWS') {
      const currentFilter = this.scenarioSyncService.getFilterSelection();
      if (currentFilter && this.selectedFilter !== currentFilter) {
        this.selectedFilter = currentFilter;
      }
    }

    this.getScenarios();
  }

  getScenarios(selectScenarioId?: string) {
    const category = this.type === 'INFLOWS' ? 'INFLOW' : 'OUTFLOW';
    this.http
      .callService(new Method(environment.services.dashboardScenarios(this.dashboardId, category), '', 'get'))
      .subscribe((res: any) => {
        const list = Array.isArray(res) ? res : [];
        if (this.type === 'INFLOWS') {
          this.inflowsScenarios = list;
          this.scenarioSyncService.setInflowScenariosList(list);
        } else {
          this.outflowsScenarios = list;
          this.scenarioSyncService.setOutflowScenariosList(list);
        }

        if (selectScenarioId !== undefined) {
          this.setScenarioSelection(selectScenarioId || null);
          return;
        }

        if (!this.scenarioControlInitialized) {
          const defaultId = list.find((s: any) => s?.isDefault || s?.active || s?.selected)?.id ?? null;
          this.setScenarioSelection(defaultId);
          if (defaultId) this.loadScenarioSankeyData(defaultId);
          this.scenarioControlInitialized = true;
        }
      });
  }

  private getFlowName(item: any): string {
    return getFlowNameUtil(item);
  }

  /**
   * UI-only label shown next to the flow name (e.g. "MF2", "MF2.1").
   * Does NOT affect replace/improve/sort logic.
   *
   * Extracts MF code from service response fields:
   * - material_category: "MF2 Metals (excluding CRMs)" → "MF2"
   * - sub_material_category: "MF 2.1 Iron and steel" → "MF2.1"
   */
  getFlowLabel(item: any): string | null {
    if (!item) return null;

    // DEBUG: Uncomment to always show test label
    // return 'MF2';

    // 1. Prefer explicit label/code fields if present
    const explicit =
      item?.label ||
      item?.code ||
      item?.category?.code ||
      item?.categoryCode ||
      item?.materialCode ||
      item?.materialCategoryCode;
    if (explicit) return String(explicit).trim();

    // 2. Check for category text fields (both snake_case from API and camelCase)
    const rawCategoryText =
      item?.material_category ||
      item?.sub_material_category ||
      item?.materialCategory ||
      item?.subMaterialCategory ||
      item?.categoryName ||
      item?.materialCategoryName ||
      item?.name;

    if (!rawCategoryText) return null;

    // 3. Extract MF code from strings like:
    //    "MF2 Metals (excluding CRMs)" → "MF2"
    //    "MF 2.1 Iron and steel" → "MF2.1"
    const match = String(rawCategoryText).match(/MF\s*\d+(?:\.\d+)?/i);
    if (!match) return null;

    // 4. Normalize spacing: "MF 2.1" → "MF2.1"
    return match[0].replace(/\s+/g, '').toUpperCase();
  }

  /**
   * Returns the display name for the flow, stripping the label prefix when it's already shown in the blue badge.
   * e.g. label="MF5", name="MF5 Plastics" → "Plastics"
   */
  getFlowDisplayName(item: any, nameOverride?: string): string {
    const name = nameOverride ?? item?.name ?? '';
    if (!name) return '';
    const label = this.getFlowLabel(item);
    if (!label) return name;
    // Strip label (with optional space) from start of name: "MF5 Plastics" → "Plastics"
    const escapedLabel = label.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`^${escapedLabel}\\s*`, 'i');
    return name.replace(regex, '').trim() || name;
  }

  getHistoryKey(item: any, index?: number): string {
    if (!item) {
      return '';
    }
    if (!item.__historyKey) {
      item.__historyKey = this.createHistoryKey(item, index);
    }
    return item.__historyKey;
  }

  private createHistoryKey(item: any, index?: number): string {
    const base = this.getFlowName(item) || item?.id || item?.flow?.id || 'flow';
    const resolvedIndex =
      index !== undefined && index !== null && index >= 0 ? index : this.displayedData.indexOf(item);
    const safeIndex = resolvedIndex >= 0 ? resolvedIndex : Date.now();
    return `${base}__${safeIndex}`;
  }

  isHistoryExpanded(item: any, index?: number): boolean {
    if (!item) {
      return false;
    }
    return this.expandedBaseFlowId === this.getHistoryKey(item, index);
  }

  isImproved(item: any): boolean {
    return UIUtils.isImproved(item);
  }

  isReplaced(item: any): boolean {
    return UIUtils.isReplaced(item, this.type, this.replacedFlows);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['dashboardId'] && !changes['dashboardId'].firstChange && this.dashboardId) {
      this.loadFlowsData(true);
    }
    if (changes['type'] && !changes['type'].firstChange) {
      this.scenarioControlInitialized = false;
      this.setScenarioSelection(null);
      this.sankeyService.clearScenarioSankeyData();
      this.getScenarios('');
      this.loadFlowsData(true);
    }
  }

  ngAfterViewInit(): void {
    if (this.paginator) {
      this.paginatorSubscription = this.paginator.page.subscribe(() => {
        if (this.dashboardId) {
          this.loadFlowsData();
        }
      });
    }

    if (this.dashboardId && !this.hasLoaded) {
      this.loadFlowsData(true);
    }
  }

  ngOnDestroy(): void {
    this.paginatorSubscription?.unsubscribe();
    this.scenarioControlSubscription?.unsubscribe();
    this.scenarioSyncSubscription?.unsubscribe();
    this.filterSyncSubscription?.unsubscribe();
    this.dashboardFlowsUnsavedService.setHasUnsavedChanges(false);
  }

  loadFlowsData(resetPage: boolean = false): void {
    if (!this.dashboardId) {
      this.displayedData = [];
      this.totalCount = 0;
      return;
    }

    if (resetPage && this.paginator) {
      this.paginator.firstPage();
    }

    this.isLoading = true;

    const useGroupsApi = this.selectedFilter === 'material-category';

    if (useGroupsApi) {
      const flowTypeArray = Array.from(this.selectedProductPackagingIds);
      const flowCategory = this.type === 'INFLOWS' ? 'inflow' : 'outflow';
      const resource = environment.services.dashboardGroups(
        this.dashboardId,
        flowTypeArray,
        flowCategory,
        this.getSortByForGroups(),
        this.selectedScenarioId || undefined
      );

      this.http.callService(new Method(resource, '', 'get')).subscribe({
        next: (res: any) => {
          this.groupsList = this.buildGroupsList(res);
          this.displayedData = [];
          this.totalCount = this.groupsList.reduce((sum, g) => sum + 1 + (g.subCategories?.length ?? 0), 0);

          this.reapplyDraftChanges();
          this.isLoading = false;
          this.hasLoaded = true;
          this.applyScenarioBadgesToDisplayedData();

          if (this.selectedScenarioId) {
            this.isScenarioDirty =
              this.displayedData?.some((item) => !!(item?.temporaryImproveFlow || item?.temporaryReplaceFlow)) ?? false;
          }
          this.updateUnsavedChangesState();
          this.checkAndShowActionIsland();
        },
        error: (error) => {
          console.error('Error loading dashboard groups:', error);
          this.groupsList = [];
          this.displayedData = [];
          this.totalCount = 0;
          this.reapplyDraftChanges();
          this.isLoading = false;
          this.hasLoaded = true;
          this.applyScenarioBadgesToDisplayedData();
          this.updateUnsavedChangesState();
          this.checkAndShowActionIsland();
        },
      });
      return;
    }

    this.groupsList = [];

    const page = this.paginator ? this.paginator.pageIndex : 0;
    const size = this.paginator ? this.paginator.pageSize : this.pageSize;
    this.pageSize = size;

    const sortParams = this.getSortParams(this.sort?.active, this.sort?.direction, this.hasNodeEndpointSupport());

    const resource = environment.services.dashboardFlows(
      this.dashboardId,
      this.type === 'INFLOWS' ? 'INFLOW' : 'OUTFLOW',
      page + 1,
      size,
      sortParams,
      this.selectedScenarioId || undefined
    );

    this.http.callService(new Method(resource, '', 'get')).subscribe({
      next: (res: any) => {
        let content = [];
        if (res?.content) content = Array.isArray(res.content) ? res.content : [];
        else if (Array.isArray(res?.results)) content = res.results;
        else if (Array.isArray(res)) content = res;
        else if (res?.data) content = Array.isArray(res.data) ? res.data : [];

        this.displayedData = this.buildDisplayedList(content);
        this.totalCount = res?.totalElements || res?.total || res?.count || content.length || 0;

        this.reapplyDraftChanges();
        this.isLoading = false;
        this.hasLoaded = true;
        this.applyScenarioBadgesToDisplayedData();

        if (this.selectedScenarioId) {
          this.isScenarioDirty =
            this.displayedData?.some((item) => !!(item?.temporaryImproveFlow || item?.temporaryReplaceFlow)) ?? false;
        }
        this.updateUnsavedChangesState();
        this.checkAndShowActionIsland();
      },
      error: (error) => {
        console.error('Error loading flows data:', error);
        this.displayedData = [];
        this.totalCount = 0;
        this.reapplyDraftChanges();
        this.isLoading = false;
        this.hasLoaded = true;
        this.applyScenarioBadgesToDisplayedData();
        if (this.selectedScenarioId) {
          this.isScenarioDirty =
            this.displayedData?.some((item) => !!(item?.temporaryImproveFlow || item?.temporaryReplaceFlow)) ?? false;
        }
        this.updateUnsavedChangesState();
        this.checkAndShowActionIsland();
      },
    });
  }

  private applyScenarioBadgesToDisplayedData(): void {
    if (!Array.isArray(this.displayedData)) {
      return;
    }

    this.displayedData.forEach((item) => {
      if (item?.scenarioImproveFlow) {
        delete item.scenarioImproveFlow;
      }
      if (item?.scenarioIsReplaced) {
        delete item.scenarioIsReplaced;
      }

      if (this.selectedScenarioId) {
        if (item?.improvement || item?.flow?.improvement) {
          item.scenarioImproveFlow = true;
        }
        if (item?.replacement || item?.flow?.replacement) {
          item.scenarioIsReplaced = true;
        }
      }
    });
  }

  private resolveDashboardIdFromRoute(): string | null {
    let currentRoute: ActivatedRoute | null = this.route;

    while (currentRoute) {
      const id = currentRoute.snapshot.paramMap.get('dashboardId');
      if (id) {
        return id;
      }
      currentRoute = currentRoute.parent;
    }

    return null;
  }

  private getSortParams(sortActive?: string, direction?: string, nodeSupport = true) {
    return {
      legacyField: UIUtils.getLegacySortField(sortActive),
      legacyDirection: UIUtils.getLegacySortDirection(direction),
      ...(nodeSupport && {
        nodeField: UIUtils.getNodeSortField(sortActive),
        nodeDirection: UIUtils.getNodeSortDirection(direction),
      }),
    };
  }

  /**
   * Maps table sort to dashboardGroups API sort_by (e.g. total_mass, material_category).
   */
  private getSortByForGroups(): string {
    const active = this.sort?.active?.toLowerCase();
    if (active === 'name' || active === 'displayname') return 'material_category';
    if (active === 'weight' || active === 'totalmass') return 'total_mass';
    return 'total_mass';
  }

  toggleGroupExpand(groupId: string): void {
    if (this.expandedGroupIds.has(groupId)) {
      this.expandedGroupIds.delete(groupId);
    } else {
      this.expandedGroupIds.add(groupId);
    }
    this.expandedGroupIds = new Set(this.expandedGroupIds);
  }

  isGroupExpanded(groupId: string): boolean {
    return this.expandedGroupIds.has(groupId);
  }

  /**
   * Builds groupsList from dashboardGroups API response for expand/collapse UI.
   * Each group has id, groupItem (transformed), subCategories (transformed).
   */
  private buildGroupsList(res: any): { id: string; groupItem: any; subCategories: any[] }[] {
    const groups = res?.groups ?? [];
    return groups.map((group: any) => {
      const groupRow = {
        ...group,
        name: group.material_category ?? group.materialCategory ?? '',
        total_mass: group.total_mass ?? group.totalMass,
        linear_mass: group.linear_mass ?? group.linearMass,
        circular_mass: group.circular_mass ?? group.circularMass,
        linear_percentage: group.linear_percentage ?? group.linearPercentage,
        potential_recovery_percentage: group.potential_recovery_percentage ?? group.potentialRecoveryPercentage,
        actual_recovery_percentage: group.actual_recovery_percentage ?? group.actualRecoveryPercentage,
      };
      const subCategories = group.sub_categories ?? group.subCategories ?? [];
      const subItems = subCategories.map((sub: any) => {
        const subRow = {
          ...sub,
          name: sub.sub_material_category ?? sub.subMaterialCategory ?? '',
          sub_material_category: sub.sub_material_category ?? sub.subMaterialCategory,
          total_mass: sub.total_mass ?? sub.totalMass,
          linear_mass: sub.linear_mass ?? sub.linearMass,
          circular_mass: sub.circular_mass ?? sub.circularMass,
          linear_percentage: sub.linear_percentage ?? sub.linearPercentage,
          potential_recovery_percentage: sub.potential_recovery_percentage ?? sub.potentialRecoveryPercentage,
          actual_recovery_percentage: sub.actual_recovery_percentage ?? sub.actualRecoveryPercentage,
        };
        return this.transformFlowItem(subRow);
      });
      const id = String(group.material_category ?? group.materialCategory ?? group.name ?? '');
      return {
        id,
        groupItem: this.transformFlowItem(groupRow),
        subCategories: subItems,
      };
    });
  }

  /**
   * Flattens dashboardGroups API response ({ groups }) into table rows (used when not using expand/collapse).
   */
  private flattenGroupsResponse(res: any): any[] {
    const groups = res?.groups ?? [];
    const rows: any[] = [];
    groups.forEach((group: any) => {
      const groupRow = {
        ...group,
        name: group.material_category ?? group.materialCategory ?? '',
        total_mass: group.total_mass ?? group.totalMass,
        linear_mass: group.linear_mass ?? group.linearMass,
        circular_mass: group.circular_mass ?? group.circularMass,
        linear_percentage: group.linear_percentage ?? group.linearPercentage,
        potential_recovery_percentage: group.potential_recovery_percentage ?? group.potentialRecoveryPercentage,
        actual_recovery_percentage: group.actual_recovery_percentage ?? group.actualRecoveryPercentage,
      };
      rows.push(groupRow);
      const subCategories = group.sub_categories ?? group.subCategories ?? [];
      subCategories.forEach((sub: any) => {
        rows.push({
          ...sub,
          name: sub.sub_material_category ?? sub.subMaterialCategory ?? '',
          sub_material_category: sub.sub_material_category ?? sub.subMaterialCategory,
          total_mass: sub.total_mass ?? sub.totalMass,
          linear_mass: sub.linear_mass ?? sub.linearMass,
          circular_mass: sub.circular_mass ?? sub.circularMass,
          linear_percentage: sub.linear_percentage ?? sub.linearPercentage,
          potential_recovery_percentage: sub.potential_recovery_percentage ?? sub.potentialRecoveryPercentage,
          actual_recovery_percentage: sub.actual_recovery_percentage ?? sub.actualRecoveryPercentage,
        });
      });
    });
    return rows;
  }

  private transformFlowItem(item: any): any {
    return transformFlowItem(item);
  }

  private buildDisplayedList(rawItems: any[]): any[] {
    const list = buildDisplayedList(
      rawItems,
      this.type as 'INFLOWS' | 'OUTFLOWS',
      (item) => this.transformFlowItem(item),
      (replacement, baseItem) => this.mapReplacementToFlow(replacement, baseItem),
      (improvement, baseItem) => this.mapImprovementToFlow(improvement, baseItem)
    );

    list.forEach((item, index) => {
      if (!item.__historyKey) {
        item.__historyKey = this.createHistoryKey(item, index);
      }
    });

    return list;
  }

  private mapReplacementToFlow(replacement: any, baseItem: any): any {
    return mapReplacementToFlow(replacement, baseItem);
  }

  private mapImprovementToFlow(improvement: any, baseItem: any): any {
    return mapImprovementToFlow(improvement, baseItem);
  }

  onPageChange(event: PageEvent): void {
    if (this.paginator) {
      this.paginator.pageIndex = event.pageIndex;
      this.paginator.pageSize = event.pageSize;
    } else {
      this.pageSize = event.pageSize;
    }

    if (this.dashboardId) {
      this.loadFlowsData();
    }
  }

  private hasNodeEndpointSupport(): boolean {
    const overriddenBaseUrl = localStorage.getItem('apiBaseUrl');
    const activeUrl = overriddenBaseUrl || this.environment.serverUrl || '';
    return activeUrl.includes('node');
  }

  onSortChange(sort: Sort): void {
    if (!this.dashboardId) {
      return;
    }

    if (this.paginator) {
      this.paginator.pageIndex = 0;
    }

    this.loadFlowsData();
  }

  private setScenarioSelection(id: string | null): void {
    this.selectedScenarioId = id;
    const controlValue = id ?? '';
    if (this.scenarioControl.value !== controlValue) {
      this.scenarioControl.setValue(controlValue as any, { emitEvent: true });
    }
  }

  private shouldWarnBeforeLeave(): boolean {
    return this.draftService.hasDrafts(this.type as FlowType);
  }

  private updateUnsavedChangesState(): void {
    const hasChanges = this.shouldWarnBeforeLeave();
    this.dashboardFlowsUnsavedService.setHasUnsavedChanges(hasChanges);
    this.updateScenarioTextLabel(hasChanges);
  }

  private updateScenarioTextLabel(hasChanges: boolean): void {
    const text = hasChanges
      ? this.storyblokDashboardFlow?.draftModeWaitingChanges || ''
      : this.storyblokDashboardFlow?.originalScenario || '';
    this.inflowOriginalScenarioText = text;
    this.outflowOriginalScenarioText = text;
  }

  private updateScenarioTextLabels(): void {
    if (this.storyblokDashboardFlow) {
      this.inflowOriginalScenarioText = this.storyblokDashboardFlow?.originalScenario || '';
      this.outflowOriginalScenarioText = this.storyblokDashboardFlow?.originalScenario || '';
    }
  }

  toggleFlowSelection(event: any, flowName: string): void {
    if (event.checked) {
      if (!this.selectedFlows.includes(flowName)) {
        this.selectedFlows.push(flowName);
      }
    } else {
      const index = this.selectedFlows.indexOf(flowName);
      if (index > -1) {
        this.selectedFlows.splice(index, 1);
      }
    }
  }

  isFlowSelected(flowName: string): boolean {
    return this.selectedFlows.includes(flowName);
  }

  clearSelection(): void {
    this.selectedFlows = [];
  }

  getReplacedCount(): number {
    return this.replacedFlows.get(this.type)?.size ?? 0;
  }

  getImprovedCount(): number {
    return this.displayedData?.filter((item) => !!item?.temporaryImproveFlow).length || 0;
  }

  private ensureInitialSnapshot(item: any): {
    weight: number;
    linearPercentage: number;
    potentialRecovery?: number;
    actualRecovery?: number;
  } {
    if (!item.__initialSnapshot) {
      const baseTotal = item.totalMass ?? item.weight ?? 0;
      const baseLinearPct = normalizePercentageValue(
        item.linearPercentage ??
          (item.circularPercentage !== undefined ? 100 - item.circularPercentage : undefined) ??
          0
      );

      const snapshot: any = {
        weight: baseTotal,
        linearPercentage: baseLinearPct,
      };

      if (this.type === 'OUTFLOWS') {
        snapshot.potentialRecovery = normalizePercentageValue(item.potentialRecovery ?? 0);
        snapshot.actualRecovery = normalizePercentageValue(item.actualRecovery ?? 0);
      }

      item.__initialSnapshot = snapshot;
    }
    return item.__initialSnapshot;
  }

  private captureInitialSnapshotIfNeeded(item: any): void {
    this.ensureInitialSnapshot(item);
  }

  private calculateItemMasses(
    item: any,
    useImprovements: boolean
  ): { total: number; linear: number; circular: number } {
    return this.metricsService.calculateItemMasses(item, useImprovements, this.type as FlowType);
  }

  getDiffTotalMass(): number {
    return this.metricsService.getDiffTotalMass(this.displayedData, this.type as any);
  }

  getDiffLinearMass(): number {
    return this.metricsService.getDiffLinearMass(this.displayedData, this.type as any);
  }

  getLinearMassCardClass(): string {
    const diff = this.getDiffLinearMass();
    if (diff < 0) return 'type-green';
    if (diff > 0) return 'type-red';
    return 'type-gray';
  }

  getTotalMassCardClass(): string {
    const diff = this.getDiffTotalMass();
    if (diff < 0) return 'type-green';
    if (diff > 0) return 'type-red';
    return 'type-gray';
  }

  getDiffMagnitude(value: number): number {
    return Math.abs(value);
  }

  getDiffCircularInflowPercentage(): number {
    return this.metricsService.getDiffCircularInflowPercentage(this.displayedData, this.type as any);
  }

  getDiffMaterialCircularityPercentage(): number {
    return this.getDiffCircularInflowPercentage();
  }

  getDiffCircularOutflowPercentage(): number {
    return this.metricsService.getDiffCircularOutflowPercentage(
      this.displayedData,
      this.type as any,
      this.getBaseRowOutflowCircularMass.bind(this),
      this.getItemOutflowCircularMass.bind(this),
      this.getBaseRowWeight.bind(this),
      this.getItemWeight.bind(this)
    );
  }

  getDiffCircularOutflowValue(): number {
    return Math.abs(this.getDiffCircularOutflowPercentage());
  }

  isCircularOutflowDecrease(): boolean {
    return this.getDiffCircularOutflowPercentage() < 0;
  }

  getDiffActualRecoveryOverallPercentage(): number {
    return this.metricsService.getDiffActualRecoveryOverallPercentage(
      this.displayedData,
      this.getBaseRowWeight.bind(this),
      this.getItemWeight.bind(this),
      this.getBaseRowActualRecovery.bind(this),
      this.getItemActualRecovery.bind(this)
    );
  }

  getDiffActualRecoveryOverallValue(): number {
    return Math.abs(this.getDiffActualRecoveryOverallPercentage());
  }

  isActualRecoveryOverallDecrease(): boolean {
    return this.getDiffActualRecoveryOverallPercentage() < 0;
  }

  getDiffCircularOutflowMass(): number {
    return this.metricsService.getDiffCircularOutflowMass(
      this.displayedData,
      this.getBaseRowOutflowCircularMass.bind(this),
      this.getItemOutflowCircularMass.bind(this)
    );
  }

  getDiffCircularOutflowMassValue(): number {
    return Math.abs(this.getDiffCircularOutflowMass());
  }

  isCircularOutflowMassDecrease(): boolean {
    return this.getDiffCircularOutflowMass() < 0;
  }

  getCircularOutflowMassCardClass(): string {
    const diff = this.getDiffCircularOutflowMass();
    if (diff > 0) return 'type-green';
    if (diff < 0) return 'type-red';
    return 'type-gray';
  }

  getDiffCircularInflowValue(): number {
    return Math.abs(this.getDiffCircularInflowPercentage());
  }

  isCircularInflowDecrease(): boolean {
    return this.getDiffCircularInflowPercentage() < 0;
  }

  getDiffMaterialCircularityValue(): number {
    return Math.abs(this.getDiffMaterialCircularityPercentage());
  }

  isMaterialCircularityDecrease(): boolean {
    return this.getDiffMaterialCircularityPercentage() < 0;
  }

  getDiffLinearMassValue(): number {
    return Math.abs(this.getDiffLinearMass());
  }

  isLinearMassDecrease(): boolean {
    return this.getDiffLinearMass() < 0;
  }

  getDiffTotalMassValue(): number {
    return Math.abs(this.getDiffTotalMass());
  }

  isTotalMassDecrease(): boolean {
    return this.getDiffTotalMass() < 0;
  }

  getLinearPercentageDiffValue(item: any): number {
    if (!item) return 0;
    const oldVal = this.getBaseRowLinearPercentage(item);
    const newVal = this.getItemLinearPercentage(item);
    return Math.abs(oldVal - newVal);
  }

  isLinearPercentageDecrease(item: any): boolean {
    return this.getItemLinearPercentage(item) < this.getBaseRowLinearPercentage(item);
  }

  getTotalMassDiffValue(item: any): number {
    if (!item) return 0;
    const oldVal = this.getBaseRowWeight(item);
    const newVal = this.getItemWeight(item);
    return Math.abs(oldVal - newVal);
  }

  isTotalMassDecreaseForItem(item: any): boolean {
    return this.getItemWeight(item) < this.getBaseRowWeight(item);
  }

  getPotentialRecoveryDiffValue(item: any): number {
    if (!item) return 0;
    const oldVal = this.getBaseRowPotentialRecovery(item);
    const newVal = this.getItemPotentialRecovery(item);
    return Math.abs(oldVal - newVal);
  }

  isPotentialRecoveryDecrease(item: any): boolean {
    return this.getItemPotentialRecovery(item) < this.getBaseRowPotentialRecovery(item);
  }

  getActualRecoveryDiffValue(item: any): number {
    if (!item) return 0;
    const oldVal = this.getBaseRowActualRecovery(item);
    const newVal = this.getItemActualRecovery(item);
    return Math.abs(oldVal - newVal);
  }

  isActualRecoveryDecrease(item: any): boolean {
    return this.getItemActualRecovery(item) < this.getBaseRowActualRecovery(item);
  }

  getCircularInflowPercentage(): number {
    const totalMass = this.getTotalMass();
    if (totalMass === 0) return 0;
    const circularMass = this.displayedData.reduce((sum, item) => sum + (this.getItemCircularMass(item) || 0), 0);
    return (circularMass / totalMass) * 100;
  }

  getMaterialCircularityPercentage(): number {
    return this.getCircularInflowPercentage();
  }

  getTotalLinearMass(): number {
    return this.displayedData.reduce(
      (sum, item) => sum + ((this.getItemWeight(item) * this.getItemLinearPercentage(item)) / 100 || 0),
      0
    );
  }

  getTotalMass(): number {
    return this.displayedData.reduce((sum, item) => sum + (this.getItemWeight(item) || 0), 0);
  }

  private buildImprovementsPayload(): {
    save: boolean;
    improvedFlows: any[];
    replacedFlows: any[];
  } {
    return this.draftService.buildImprovementsPayload(
      this.type as any,
      this.getAllDraftAwareItems(),
      this.getItemPotentialRecovery.bind(this),
      this.getItemActualRecovery.bind(this),
      this.getBaseRowPotentialRecovery.bind(this),
      this.getBaseRowActualRecovery.bind(this),
      this.getItemWeight.bind(this),
      this.getDisplayCircularPercentage.bind(this),
      this.getBaseRowCircularInflowPercentage.bind(this),
      this.isImproved.bind(this),
      this.isReplaced.bind(this)
    );
  }

  private buildPreviewPayload(): {
    save: boolean;
    improvedFlows: any[];
    replacedFlows: any[];
  } {
    const payload = this.buildImprovementsPayload();
    return {
      ...payload,
      save: false,
    };
  }

  private resetChangesForType(flowType: string): void {
    if (flowType !== this.type) {
      return;
    }

    this.displayedData.forEach((item) => {
      if (item?.temporaryImproveFlow) {
        delete item.temporaryImproveFlow;
      }

      if (item?.temporaryReplaceFlow) {
        delete item.temporaryReplaceFlow;
      }
      if (item?.isReplaced) {
        delete item.isReplaced;
      }
    });

    if (flowType === 'INFLOWS' || flowType === 'OUTFLOWS') {
      this.clearDraftStateForType(flowType);
    }
    this.replacedFlows.delete(flowType);
    this.clearSelection();
    this.showActionIsland = false;
    this.updateUnsavedChangesState();
    this.checkAndShowActionIsland();
  }

  createNewScenario(): void {
    this.actionService.openCreateScenarioDialog().subscribe((scenarioName?: string) => {
      if (scenarioName) {
        this.createdScenarioName = scenarioName;
        this.actionService.createScenario(this.dashboardId, this.type, scenarioName).subscribe((res: any) => {
          if (res.id) {
            const payload = this.buildImprovementsPayload();
            this.actionService.saveImprovements(res.id, payload).subscribe(() => {
              this.resetChangesForType(this.type);
              this.isScenarioDirty = false;
              this.expandedBaseFlowId = null;
              this.getScenarios(res.id);
            });
          }
        });
      }
    });
  }

  closeActionIsland(): void {
    this.actionService.openDiscardChangesDialog().subscribe((result) => {
      if (result) {
        this.resetAllChanges();
      }
    });
  }

  resetAllChanges(): void {
    const replacedRowIds = new Set<string>();
    this.displayedData.forEach((item) => {
      if (item?.isReplaced && item?.id && String(item.id).includes('_replaced_')) {
        replacedRowIds.add(item.id);
      }
    });

    if (replacedRowIds.size > 0) {
      this.displayedData = this.displayedData.filter((item) => !replacedRowIds.has(item?.id));
      this.totalCount = this.displayedData.length;
    }

    this.displayedData.forEach((item) => {
      delete item.temporaryImproveFlow;
      delete item.temporaryReplaceFlow;
      delete item.isReplaced;
      delete item.baseBeforeImprove;
      delete item.__initialSnapshot;
    });

    this.clearDraftStateForType(this.type as FlowType);
    this.replacedFlows.delete(this.type);
    this.isScenarioDirty = false;
    this.expandedBaseFlowId = null;
    this.showActionIsland = false;
    this.sankeyService.clearScenarioSankeyData();

    if (this.dashboardId) {
      this.loadFlowsData(false);
    } else {
      this.updateUnsavedChangesState();
    }
  }

  checkAndShowActionIsland(): void {
    this.showActionIsland = this.draftService.hasDrafts(this.type as FlowType);
  }

  get visibleDisplayedData(): any[] {
    if (!this.showOnlyChanges) {
      return this.displayedData;
    }
    return (this.displayedData || []).filter(
      (item) => this.isReplaced(item) || this.isImproved(item) || !!item?.temporaryReplaceFlow
    );
  }

  toggleOnlyChanges(event: any): void {
    this.showOnlyChanges = !!event?.target?.checked;
  }

  get hasChangesToFilter(): boolean {
    return (this.displayedData || []).some(
      (item) => this.isReplaced(item) || this.isImproved(item) || !!item?.temporaryReplaceFlow
    );
  }

  isDraft(item: any): boolean {
    if (!item) return false;
    if (this.selectedScenarioId) {
      return !!(item?.temporaryImproveFlow || item?.temporaryReplaceFlow);
    }
    return this.isImproved(item) || this.isReplaced(item);
  }

  getItemBackgroundColor(item: any): string {
    return UIUtils.getItemBackgroundColor(item, this.selectedScenarioId, this.isDraft(item));
  }

  shouldShowHistoryButton(item: any): boolean {
    return UIUtils.shouldShowHistoryButton(item, this.selectedScenarioId, this.isImproved(item), this.isReplaced(item));
  }

  private getOriginalItem(item: any): any {
    return UIUtils.getOriginalItem(item, this.displayedData, this.getFlowName.bind(this));
  }

  getBaseRowName(item: any): string {
    return UIUtils.getBaseRowName(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowWeight(item: any): number {
    return UIUtils.getBaseRowWeight(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowLinearPercentage(item: any): number {
    return UIUtils.getBaseRowLinearPercentage(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowCircularMass(item: any): number {
    const totalMass = this.getBaseRowWeight(item);
    return Math.max(0, totalMass - (totalMass * this.getBaseRowLinearPercentage(item)) / 100);
  }
  getBaseRowPotentialRecovery(item: any): number {
    return UIUtils.getBaseRowPotentialRecovery(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowActualRecovery(item: any): number {
    return UIUtils.getBaseRowActualRecovery(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowCircularInflowPercentage(item: any): number {
    return Math.max(0, 100 - this.getBaseRowLinearPercentage(item));
  }

  getItemWeight(item: any): number {
    return UIUtils.getItemWeight(item);
  }
  getItemLinearPercentage(item: any): number {
    return UIUtils.getItemLinearPercentage(item);
  }
  getItemPotentialRecovery(item: any): number {
    return UIUtils.getItemPotentialRecovery(item);
  }
  getItemActualRecovery(item: any): number {
    return UIUtils.getItemActualRecovery(item);
  }

  getItemCircularMass(item: any): number {
    if (!item) return 0;
    const totalMass = this.getItemWeight(item);
    const linearPercentage = this.getItemLinearPercentage(item);
    return Math.max(0, totalMass - (totalMass * linearPercentage) / 100);
  }

  getItemOutflowCircularMass(item: any): number {
    if (!item) return 0;
    return (this.getItemWeight(item) * this.getDisplayCircularOutflow(item)) / 100;
  }

  getItemCircularPercentage(item: any): number {
    return UIUtils.getDisplayCircularPercentage(item);
  }

  getBaseRowOutflowCircularMass(item: any): number {
    if (!item) return 0;
    return (this.getBaseRowWeight(item) * this.getBaseRowCircularOutflow(item)) / 100;
  }

  getDisplayCircularOutflow(item: any): number {
    return UIUtils.getDisplayCircularOutflow(item);
  }
  getDisplayLinearOutflow(item: any): number {
    return UIUtils.getDisplayLinearOutflow(item);
  }
  getBaseRowCircularOutflow(item: any): number {
    return UIUtils.getBaseRowCircularOutflow(item, (it) => this.getOriginalItem(it));
  }
  getBaseRowLinearOutflow(item: any): number {
    return UIUtils.getBaseRowLinearOutflow(item, (it) => this.getOriginalItem(it));
  }
  getDisplayCircularPercentage(item: any): number {
    return UIUtils.getDisplayCircularPercentage(item);
  }
  getDisplayLinearPercentage(item: any): number {
    return UIUtils.getDisplayLinearPercentage(item);
  }

  canSaveChanges(): boolean {
    return !!this.selectedScenarioId && this.isScenarioDirty;
  }
  hasUnsavedChanges(): boolean {
    return !!this.selectedScenarioId && this.isScenarioDirty;
  }

  saveChangesToScenario(): void {
    if (!this.selectedScenarioId) {
      return;
    }

    const payload = this.buildImprovementsPayload();
    this.actionService.saveImprovements(this.selectedScenarioId, payload).subscribe({
      next: () => {
        this.displayedData.forEach((item) => {
          if (item?.temporaryImproveFlow) delete item.temporaryImproveFlow;
          if (item?.temporaryReplaceFlow) delete item.temporaryReplaceFlow;
        });
        this.clearDraftStateForType(this.type as FlowType);
        this.replacedFlows.delete(this.type);
        this.isScenarioDirty = false;
        this.expandedBaseFlowId = null;
        this.loadFlowsData(false);
        this.updateUnsavedChangesState();
        this.checkAndShowActionIsland();
      },
      error: (error) => console.error('Error saving changes to scenario:', error),
    });
  }

  deleteScenario(): void {
    if (!this.selectedScenarioId) return;

    const scenarios = this.type === 'INFLOWS' ? this.inflowsScenarios : this.outflowsScenarios;
    const selectedScenario = scenarios.find((s: any) => s.id === this.selectedScenarioId);
    if (!selectedScenario) return;

    this.actionService.openDeleteScenarioDialog(selectedScenario.name || 'Scenario').subscribe((result) => {
      if (result) this.performDeleteScenario();
    });
  }

  private performDeleteScenario(): void {
    if (!this.selectedScenarioId) return;

    const scenarioIdToDelete = this.selectedScenarioId;
    this.actionService.deleteScenario(scenarioIdToDelete).subscribe({
      next: () => {
        if (this.type === 'INFLOWS') {
          this.inflowsScenarios = this.inflowsScenarios.filter((s: any) => s.id !== scenarioIdToDelete);
        } else {
          this.outflowsScenarios = this.outflowsScenarios.filter((s: any) => s.id !== scenarioIdToDelete);
        }

        if (this.selectedScenarioId === scenarioIdToDelete) {
          this.setScenarioSelection(null);
          this.selectedScenarioId = null;
        }

        this.resetAllChanges();
        this.isScenarioDirty = false;
        this.expandedBaseFlowId = null;
        this.showActionIsland = false;
        this.getScenarios();
        this.snackBar.open(this.storyblokDashboardFlow?.scenarioDeletedSuccessMessage || '', '', {
          duration: 3000,
          panelClass: ['success-snackBar'],
        });
      },
    });
  }

  private getFlowIdentifier(item: any): string {
    if (!item) return '';
    const id = item?.baseFlowId ?? item?.id ?? item?.flow?.id ?? item?.flowId;
    if (id) return String(id);
    const historyKey = item?.__historyKey;
    if (historyKey) return historyKey;
    const index = this.displayedData.indexOf(item);
    if (index >= 0) {
      const name = item?.name ?? item?.displayName ?? item?.tradeName ?? 'flow';
      return `${name}_idx_${index}`;
    }
    const name = item?.name ?? item?.displayName ?? item?.tradeName ?? 'flow';
    const uniqueSuffix = item?.__historyKey || `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    return `${name}_${uniqueSuffix}`;
  }

  private persistImproveDraft(item: any): void {
    const flowId = this.getFlowIdentifier(item);
    this.draftService.persistImproveDraft(this.type as FlowType, item, flowId);
  }

  private persistReplaceDraft(baseItem: any, replacementRow: any, isAdd = false): void {
    const flowId = this.getFlowIdentifier(isAdd ? replacementRow : baseItem);
    this.draftService.persistReplaceDraft(this.type as FlowType, flowId, baseItem, replacementRow, isAdd);
  }

  private reapplyDraftChanges(): void {
    const type = this.type as FlowType;
    const currentTotal = this.totalCount || 0;
    if (!Array.isArray(this.displayedData)) this.displayedData = [];

    this.displayedData.forEach((item) => {
      const flowId = this.getFlowIdentifier(item);
      const draft = this.draftService.getImproveDrafts(type).get(flowId);
      if (draft) {
        if (draft.baseBeforeImprove) item.baseBeforeImprove = JSON.parse(JSON.stringify(draft.baseBeforeImprove));
        if (draft.initialSnapshot) item.__initialSnapshot = JSON.parse(JSON.stringify(draft.initialSnapshot));
        item.temporaryImproveFlow = JSON.parse(JSON.stringify(draft.temporaryImproveFlow));
        this.applyImprovedValuesToItem(item);
      }
    });

    this.draftService.getReplaceDrafts(type).forEach((draft, flowId) => {
      if (draft?.isAdd) return;
      const index = this.displayedData.findIndex((d) => this.getFlowIdentifier(d) === flowId);
      if (index >= 0) {
        const replacement = JSON.parse(JSON.stringify(draft.replacementRow));
        replacement.__historyKey = this.createHistoryKey(replacement, index);
        this.displayedData.splice(index, 1, replacement);
        if (!this.replacedFlows.has(this.type)) this.replacedFlows.set(this.type, new Set());
        this.replacedFlows.get(this.type)!.add(this.getFlowName(replacement) || replacement.id);
      }
    });

    const added = this.draftService.getAddedDraftFlows(type) || [];
    added.forEach((flow) => {
      if (!this.displayedData.some((d) => d?.id === flow?.id)) {
        const clone = JSON.parse(JSON.stringify(flow));
        clone.__historyKey = this.createHistoryKey(clone, this.displayedData.length);
        this.displayedData.push(clone);
      }
    });

    this.totalCount = Math.max(currentTotal, this.displayedData.length);
    if (this.selectedScenarioId && this.draftService.hasDrafts(type)) this.isScenarioDirty = true;

    this.updateUnsavedChangesState();
    this.checkAndShowActionIsland();
  }

  private clearDraftStateForType(typeKey: 'INFLOWS' | 'OUTFLOWS'): void {
    this.draftService.clearDraftStateForType(typeKey as FlowType);
  }

  private getAllDraftAwareItems(): any[] {
    return this.draftService.getAllDraftAwareItems(
      this.type as any,
      this.displayedData,
      this.getFlowIdentifier.bind(this),
      this.applyImprovedValuesToItem.bind(this)
    );
  }

  isMainScenario(): boolean {
    return !this.selectedScenarioId;
  }

  private loadBaseSankeyData(): void {
    this.sankeyService.loadBaseSankeyData();
  }

  private loadScenarioSankeyData(scenarioId: string | null): void {
    this.sankeyService.loadScenarioSankeyData(this.dashboardId, scenarioId).subscribe();
  }

  private loadPreviewSankeyData(): void {
    if (!this.dashboardId) {
      return;
    }

    if (!this.shouldWarnBeforeLeave()) {
      this.sankeyService.clearScenarioSankeyData();
      return;
    }

    const payload = this.buildPreviewPayload();
    this.sankeyService.loadPreviewSankeyData(this.dashboardId, this.type, payload).subscribe();
  }

  getSankeyCircularInflowMetric(): SankeyMetrics {
    const isInflow = this.type === 'INFLOWS';
    const baseSankey = this.sankeyService.baseSankeyData;
    const scenarioSankey = this.sankeyService.scenarioSankeyData;
    const base = isInflow ? baseSankey?.inflowCircularPercentage : baseSankey?.outflowCircularPercentage;
    const scenario = isInflow ? scenarioSankey?.inflowCircularPercentage : scenarioSankey?.outflowCircularPercentage;
    return this.metricsService.computeMetricDelta(base, scenario);
  }

  getSankeyMaterialCircularityMetric(): SankeyMetrics {
    return this.metricsService.computeMetricDelta(
      this.sankeyService.baseSankeyData?.circularityPercentage,
      this.sankeyService.scenarioSankeyData?.circularityPercentage
    );
  }

  getSankeyLinearMassMetric(): SankeyMetrics {
    const isInflow = this.type === 'INFLOWS';
    const baseSankey = this.sankeyService.baseSankeyData;
    const scenarioSankey = this.sankeyService.scenarioSankeyData;
    const base = isInflow ? baseSankey?.inflowLinearWeight : baseSankey?.outflowLinearWeight;
    const scenario = isInflow ? scenarioSankey?.inflowLinearWeight : scenarioSankey?.outflowLinearWeight;
    return this.metricsService.computeMetricDelta(base, scenario);
  }

  getSankeyTotalMassMetric(): SankeyMetrics {
    const isInflow = this.type === 'INFLOWS';
    const baseSankey = this.sankeyService.baseSankeyData;
    const scenarioSankey = this.sankeyService.scenarioSankeyData;
    const base = isInflow ? baseSankey?.inflowWeight : baseSankey?.outflowWeight;
    const scenario = isInflow ? scenarioSankey?.inflowWeight : scenarioSankey?.outflowWeight;
    return this.metricsService.computeMetricDelta(base, scenario);
  }

  getSankeyMetricColorClass(metric: SankeyMetrics, isMass: boolean, isLinearMass: boolean = false): string {
    return this.metricsService.getSankeyMetricColorClass(metric, isMass, isLinearMass);
  }

  getSankeyMetricCardClass(metric: SankeyMetrics, isMass: boolean, isLinearMass: boolean = false): string {
    return this.metricsService.getSankeyMetricCardClass(metric, isMass, isLinearMass);
  }

  shouldShowSankeyMetrics(): boolean {
    if (this.type !== 'INFLOWS' && this.type !== 'OUTFLOWS') {
      return false;
    }
    if (!this.sankeyService.baseSankeyData) {
      return false;
    }
    return !!this.selectedScenarioId || this.shouldWarnBeforeLeave();
  }

  bypassHtmlSecurity(html: string) {
    if (!html) {
      return '';
    }
    return this.storyblokService.bypassHtmlSecurity(html);
  }
}
