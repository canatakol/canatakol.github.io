import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatPaginatorModule, PageEvent } from '@angular/material/paginator';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
import { transformFlowItem } from '@app/shared-components/dashboard-flows/utils/flow-data-transformer.util';

export interface GroupDetailModalData {
  baselineId: string;
  materialCategory: string;
  subMaterialCategory?: string;
  flowType: string[];
  flowCategory: string;
  groupLabel: string;
  groupName: string;
  /** Summary item (group or sub) with totalMass, linearPercentage, linearMass, circularMass for header row */
  summaryItem?: any;
}

@Component({
  selector: 'app-dashboard-flows-group-detail-modal',
  templateUrl: './dashboard-flows-group-detail-modal.component.html',
  styleUrls: ['./dashboard-flows-group-detail-modal.component.scss'],
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatPaginatorModule, CiqNumberPipe, LoadingBarComponent],
})
export class DashboardFlowsGroupDetailModalComponent implements OnInit {
  flows: any[] = [];
  isLoading = false;
  totalItems = 0;
  pageSize = 20;
  pageIndex = 0;
  sortBy = 'total_mass';
  private expandedFlowIndices = new Set<number>();

  constructor(
    public dialogRef: MatDialogRef<DashboardFlowsGroupDetailModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: GroupDetailModalData,
    private http: ApiRequestService
  ) {}

  ngOnInit(): void {
    this.loadFlows();
  }

  loadFlows(): void {
    this.isLoading = true;

    const resource = environment.services.dashboardGroupsFlows(this.data.baselineId, {
      materialCategory: this.data.materialCategory,
      subMaterialCategory: this.data.subMaterialCategory,
      flowType: this.data.flowType,
      flowCategory: this.data.flowCategory,
      sortBy: this.sortBy,
      page: this.pageIndex + 1,
      pageSize: this.pageSize,
    });

    console.log('🔍 Loading group flows:', {
      url: resource,
      params: {
        baselineId: this.data.baselineId,
        materialCategory: this.data.materialCategory,
        subMaterialCategory: this.data.subMaterialCategory,
        flowType: this.data.flowType,
        flowCategory: this.data.flowCategory,
        sortBy: this.sortBy,
        page: this.pageIndex + 1,
        pageSize: this.pageSize,
      },
    });

    this.http.callService(new Method(resource, '', 'get')).subscribe({
      next: (res: any) => {
        console.log('✅ Group flows loaded:', res);
        const rawFlows = res?.flows || [];
        this.flows = rawFlows.map((f: any) => transformFlowItem(f));
        this.totalItems = res?.pagination?.totalItems || 0;
        this.expandedFlowIndices = new Set(
          this.flows.map((f, i) => (this.getCircularityGroups(f).length ? i : -1)).filter((i) => i >= 0)
        );
        this.isLoading = false;
      },
      error: (error) => {
        console.error('❌ Error loading group flows:', error);
        this.flows = [];
        this.totalItems = 0;
        this.isLoading = false;
      },
    });
  }

  onPageChange(event: PageEvent): void {
    this.pageIndex = event.pageIndex;
    this.pageSize = event.pageSize;
    this.loadFlows();
  }

  close(): void {
    this.dialogRef.close();
  }

  getCircularPercentage(flow: any): number {
    if (!flow || !flow.totalMass || flow.totalMass === 0) return 0;
    const circular = flow.circularMass || 0;
    return (circular / flow.totalMass) * 100;
  }

  getLinearPercentage(flow: any): number {
    return flow?.linearPercentage || 0;
  }

  getCircularityGroups(flow: any): any[] {
    const groups = flow?.circularityGroups;
    return Array.isArray(groups) ? groups : [];
  }

  isFlowExpanded(index: number): boolean {
    return this.expandedFlowIndices.has(index);
  }

  toggleFlowExpand(index: number): void {
    if (this.expandedFlowIndices.has(index)) {
      this.expandedFlowIndices.delete(index);
    } else {
      this.expandedFlowIndices.add(index);
    }
    this.expandedFlowIndices = new Set(this.expandedFlowIndices);
  }

  getGroupLinearPercentage(group: any): number {
    return group?.linearPercentage ?? 0;
  }

  getGroupCircularPercentage(group: any): number {
    if (!group || !group.totalMass || group.totalMass === 0) return 0;
    const circular = group.circularMass ?? 0;
    return (circular / group.totalMass) * 100;
  }

  getSummaryTotalMass(): number {
    const item = this.data?.summaryItem;
    return item?.totalMass ?? item?.total_mass ?? 0;
  }

  getSummaryLinearPercentage(): number {
    const item = this.data?.summaryItem;
    return item?.linearPercentage ?? item?.linear_percentage ?? 0;
  }

  getSummaryLinearMass(): number {
    const item = this.data?.summaryItem;
    return item?.linearMass ?? item?.linear_mass ?? 0;
  }

  getSummaryCircularPercentage(): number {
    const item = this.data?.summaryItem;
    if (!item) return 0;
    const total = item.totalMass ?? item.total_mass ?? 0;
    if (!total) return 0;
    const circular = item.circularMass ?? item.circular_mass;
    if (circular !== undefined && circular !== null) {
      return (circular / total) * 100;
    }
    const linearPct = item.linearPercentage ?? item.linear_percentage ?? 0;
    return Math.max(0, 100 - linearPct);
  }
}
