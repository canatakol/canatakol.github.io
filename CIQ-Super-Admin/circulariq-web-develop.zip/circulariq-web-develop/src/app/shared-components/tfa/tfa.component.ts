import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { TFAConfirmDialog } from '@app/shared/dialog/tfa-confirm/tfa-confirm-dialog.component';
import { environment } from '@env/environment';

@Component({
  selector: 'app-tfa',
  templateUrl: './tfa.component.html',
  styleUrls: ['./tfa.component.scss'],
  standalone: false,
})
export class TfaComponent implements OnInit {
  storyblok;
  feature;
  isopen = false;
  isTFA;
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  slide_out = false;
  hide2faBanner = false;
  constructor(
    private storyblokService: StoryblokService,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private commonService: CommonService
  ) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'two-factor-authentication');
      this.storyblok = story[0].content;
    });
    this.fetchMemberPreferences();
  }

  fetchMemberPreferences() {
    this.http.callService(new Method(environment.services.memberPreferences(), '', 'get')).subscribe(
      (preferences: any) => {
        this.hide2faBanner = preferences?.hide2faBanner === 'true';
        this.TFAStatus();
      },
      (error) => {
        // If preference doesn't exist yet, default to false (show banner)
        this.hide2faBanner = false;
        this.TFAStatus();
      }
    );
  }

  TFAStatus() {
    if (!this.credentials || !this.credentials.organisation || !this.credentials.organisation.id) {
      return;
    }
    this.http
      .callService(new Method(environment.services.featuresOrganisation(this.credentials.organisation.id), '', 'get'))
      .subscribe({
        next: (feature) => {
          this.feature = feature;
          this.feature.forEach((element) => {
            if (element.name === '2FA') {
              this.isTFA = element.status;
            }
          });
          if (this.isTFA === 'DISABLED' && !this.hide2faBanner) {
            this.isopen = true;
          }
        },
        error: (error) => {
          // If we can't load TFA status, don't show the banner
          this.isopen = false;
        },
      });
  }
  close() {
    this.slide_out = true;
    setTimeout(() => {
      this.isopen = false;
    }, 2000);
  }
  neverShow(show: boolean) {
    if (show) {
      // Call API to update preference
      const data = { hide: true };
      this.http.callService(new Method(environment.services.update2FABannerPreference(), data, 'put')).subscribe(
        (res) => {
          this.hide2faBanner = true;
        },
        (error) => {
          this.snackBar.open('Failed to save preference. Please try again.', '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        }
      );
    }
  }
  opemodal() {
    if (!this.credentials || !this.credentials.organisation || !this.credentials.organisation.id) {
      return;
    }
    const data = { organisationUuid: this.credentials.organisation.id, feature: '2FA', status: 'ENABLED' };
    const dialogRef = this.dialog.open(TFAConfirmDialog, {
      width: '80%',
      maxWidth: '680px',
      panelClass: 'centered-dialog',
      data: true,
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      this.http.callService(new Method(environment.services.adminOrganisation(), data, 'put')).subscribe({
        next: (res) => {
          if (!res) {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.close();
          }
        },
      });
    });
  }
}
