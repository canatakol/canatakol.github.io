import {
  Component,
  Input,
  OnInit,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { CiqNumberPipe } from '@app/pipes';
import { environment } from '@env/environment';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';
declare var $: any;
@Component({
  selector: 'app-sankey-info',
  templateUrl: './sankey-info.component.html',
  styleUrls: ['./sankey-info.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, MatSlideToggleModule, CiqNumberPipe, CommentBadgeComponent],
  changeDetection: ChangeDetectionStrategy.OnPush, // Optimize change detection
})
export class SankeyInfoComponent implements OnInit, OnChanges {
  @Input() public importData: any;
  @Input() public isReport: string;
  @Input() public isBreakdown: boolean = false;
  @Input() public isDashboard: boolean = false;
  @Input() public isProcurement: boolean = false;
  @Input() public isFlows: boolean = false;
  data;
  organizationGoal;
  isEnabledCTIGoal;
  storyblok;
  goalsWiev = false;
  environment = environment;
  isDashboardPage: boolean = false;
  constructor(
    private http: ApiRequestService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private commonService: CommonService,
    private cdr: ChangeDetectorRef
  ) {
    this.organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
    this.isEnabledCTIGoal = JSON.parse(localStorage.getItem('isEnabledCTIGoal'));
  }

  ngOnInit(): void {
    this.setDataFromImport();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'sankey-chart');
      this.storyblok = story[0].content;
      this.cdr.markForCheck(); // Trigger change detection
    });
    this.isDashboardPage = window.location.href.includes('dashboard');
    console.log('isFlows', this.isFlows);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['importData'] && !changes['importData'].firstChange) {
      this.setDataFromImport();
      this.cdr.markForCheck();
    }
  }

  private setDataFromImport(): void {
    if (!this.importData) {
      this.data = null;
      return;
    }

    this.data = this.importData['sankey'] ? this.importData['sankey'] : this.importData;
  }

  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }
}
