import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-download-report',
  templateUrl: './download-report.component.html',
  styleUrls: ['./download-report.component.scss'],
  standalone: false,
})
export class DownloadReportComponent implements OnInit {
  unitId = this.route.snapshot.params.unitId;
  unit;
  authToken;
  constructor(
    public router: Router,
    private route: ActivatedRoute,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {
    this.unit = JSON.parse(localStorage.getItem('selectedUnit'));
    this.reportStatus(this.unitId);
    this.authToken = JSON.parse(sessionStorage.getItem('credentials')).authToken;
  }

  ngOnInit(): void {
    if (this.router.url.indexOf('step5') > -1) {
      this.router.navigate([`/cti/${this.unitId}/assessment/step6`]);
    }
    if (this.router.url.indexOf('step6') > -1) {
      this.router.navigate([`/cti/${this.unitId}/assessment/step7`]);
    }
  }

  reportStatus(unitId: any) {
    this.http.callService(new Method(environment.services.reportStatus(unitId), '', 'get')).subscribe((res) => {
      if (res['canDownload']) {
        if (res['warningMessage']) {
          const dialogRef = this.dialog.open(ReportStatusDialog, {
            width: '80%',
            maxWidth: '600px',
            panelClass: 'centered-dialog',
            data: {
              message: res['warningMessage'],
            },
          });
          dialogRef.afterClosed().subscribe(async (result) => {
            if (!result) {
              return;
            }
            try {
              window.open(`/cti/${unitId}/${this.authToken}/report`);
            } catch (error) {}
          });
        } else {
          window.open(`/cti/${unitId}/${this.authToken}/report`);
        }
      } else {
        this.snackBar.open(res['warningMessage'], '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  generateReport() {
    const token = JSON.parse(sessionStorage.getItem('credentials')).authToken;

    fetch(environment.serverUrl + environment.services.unitReport(this.unitId), {
      headers: {
        'x-auth-token': token,
      },
      method: 'GET',
    })
      .then((response) => {
        if (response.status !== 200) {
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const FileSaver = require('file-saver');
        let unit_name = this.unit['name'];
        if (!unit_name || 0 === unit_name.length) {
          unit_name = 'business level';
        }
        const reportName = unit_name + ' cti report.pdf';
        const file = new File([buffer], reportName, { type: 'application/pdf' });
        FileSaver.saveAs(file);
      })
      .catch((error) => {
        error.then((result) => {
          let message = 'Unable to create report.';
          if (result.message) {
            message = result.message;
          }
          this.snackBar.open(message, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        });
      });
  }
}
