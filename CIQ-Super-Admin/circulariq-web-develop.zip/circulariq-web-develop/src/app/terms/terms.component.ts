import { Component } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.scss'],
  standalone: false,
})
export class TermsComponent {
  isShow = true;
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  constructor(private http: ApiRequestService) {}

  close() {
    this.http
      .callService(
        new Method(
          environment.services.userJourney(),
          [
            {
              question: 'TERMS_2025_SEEN',
              value: true,
            },
          ],
          'put'
        )
      )
      .subscribe(() => {
        this.credentials.show2025Terms = false;
        this.isShow = false;
        sessionStorage.setItem('credentials', JSON.stringify(this.credentials));
      });
  }
}
