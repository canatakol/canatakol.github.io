import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, NavigationEnd, NavigationStart, ActivatedRoute } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { fromEvent, Observable, Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { environment } from '@env/environment';
import { Logger } from '@app/core';
import posthog from 'posthog-js';
import { StoryblokService } from './core/storyblok/storyblok.service';
import { ApiRequestService, Method } from './core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from './core/common.service';

export let browserRefresh = false;
declare var window: any;
(window as any).global = window;
const log = new Logger('App');
declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: false,
})
export class AppComponent implements OnInit, OnDestroy {
  resizeObservable$: Observable<Event>;
  resizeSubscription$: Subscription;
  project = environment.project;
  subscription: Subscription;
  environmentUrl = 'Debug api';
  environmentName = '';
  windowWidth = window.innerWidth;
  elem;
  copy;
  count = 0;
  credentials;
  isvalidateEmail = true;
  storyblok;
  emailStoryblok;
  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private titleService: Title,
    private http: ApiRequestService,
    public storyblokService: StoryblokService,
    private snackBar: MatSnackBar,
    private commonService: CommonService
  ) {
    this.environmentUrl = environment.serverUrl;
    this.environmentName = environment.project;
    this.subscription = router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        browserRefresh = !router.navigated;
        if (browserRefresh) {
          sessionStorage.removeItem('programs_loaded');
        }
      }
    });
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        const body = document.body;
        const url = this.router.url;
        if (!url.includes('cti') && !url.includes('e5')) {
          body.classList.add('login-zoom');
        } else {
          body.classList.remove('login-zoom');
        }
      }
    });
    router.events.subscribe((val) => {
      if (val instanceof NavigationEnd) {
        val.url.split('/').forEach((element) => {
          if (
            element === 'assessment' ||
            element === 'pro-business' ||
            element === 'pro-label' ||
            element === 'dashboard'
          ) {
            this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
            if (this.count === 0) {
              this.hotjar(this.credentials);
            }
            this.count++;
            if (this.credentials.emailVerified === false) {
              this.isvalidateEmail = this.credentials.emailVerified;
              this.getStortblok();
            }
          } else if (element === 'login') {
            this.isvalidateEmail = true;
          }
        });
        if (environment.project === 'CTI') {
          if (val.url === '/') {
            const user = JSON.parse(sessionStorage.getItem('credentials'));
            if (user && user.organisation && user.organisation.licenseType === 'Free') {
              this.router.navigate(['/cti/materials']);
            } else {
              // Navigate to dashboard - the component will handle first-time user logic
              this.router.navigate(['/cti/dashboard']);
            }
          }
        } else {
          if (val.url.indexOf('/cti') > -1) {
            this.router.navigate(['/products']);
          } else if (val.url === '/') {
            this.router.navigate(['/products']);
          }
        }

        if (environment.project === 'CIQ') {
          if (val.url === '/e5') {
            this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
            if (this.credentials.emailVerified === false) {
              this.isvalidateEmail = this.credentials.emailVerified;
              this.getStortblok();
            }
          }
        }
      }
    });
    this.windowWidth = $(window).width();
  }
  getStortblok() {
    this.storyblokService.getStoryService().then((res) => {
      const email = res.filter((item) => item.slug === 'non-valid-email-alert');
      this.emailStoryblok = email[0].content;
      this.emailStoryblok.confirm_email = this.emailStoryblok.confirm_email.replace(
        '#DYNAMIC_EMAIL',
        `${this.credentials.email}`
      );
      this.emailStoryblok.blocked_email = this.emailStoryblok.blocked_email.replace(
        '#DYNAMIC_EMAIL',
        `${this.credentials.email}`
      );
      this.emailStoryblok.confirm_email = this.emailStoryblok.confirm_email.replace(
        '#DYNAMIC_DAYS',
        `${this.credentials.remainingDaysToVerify}`
      );
      if (this.credentials.remainingDaysToVerify < 0) {
        $('#main').css({ 'z-index': 1, position: 'relative' });
      }
    });
  }
  copyTextShow() {
    this.copy = true;
    setTimeout(() => {
      this.copy = false;
    }, 2000);
  }
  hotjar(user: any) {
    const completedStepsArray = [];
    if (user) {
      for (const [key, value] of Object.entries(user)) {
        if (value) {
          completedStepsArray.push(key);
        }
      }
    }
    if (user && user.organisation && user.organisation.features) {
      const paidUser = user.organisation.features.indexOf('unlimited_user') > -1;
      (window.dataLayer = window.dataLayer || []).push({
        userID: user.userId,
        userName: user.name,
        userEmail: user.email,
        userStatus: paidUser ? 'paid' : 'free',
        organization: user.organisation?.name || '',
        completedSteps: completedStepsArray,
      });
    }
    if (user?.organisation?.features && user.organisation.features.length > 0) {
      user.organisation.features.forEach((element) => {
        if (element === 'hotjar') {
          // tslint:disable-next-line:typedef
          (function (h: any, o, t, j, a, r) {
            h.hj =
              h.hj ||
              function () {
                (h.hj.q = h.hj.q || []).push(arguments);
              };
            h._hjSettings = { hjid: 1828116, hjsv: 6 };
            a = o.getElementsByTagName('head')[0];
            r = o.createElement('script');
            r.async = 1;
            r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
            a.appendChild(r);
          })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv=');
        }
      });
    }
  }
  reSendEmail() {
    this.http.callService(new Method(environment.services.isvalidateEmail(), '', 'post')).subscribe(async (res) => {
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
    localStorage.clear();
    sessionStorage.clear();
  }
  fullScreen() {
    if (this.elem.requestFullscreen) {
      this.elem.requestFullscreen();
    } else if (this.elem.mozRequestFullScreen) {
      /* Firefox */
      this.elem.mozRequestFullScreen();
    } else if (this.elem.webkitRequestFullscreen) {
      /* Chrome, Safari and Opera */
      this.elem.webkitRequestFullscreen();
    } else if (this.elem.msRequestFullscreen) {
      /* IE/Edge */
      this.elem.msRequestFullscreen();
    }
  }
  ngOnInit() {
    this.resizeObservable$ = fromEvent(window, 'resize');
    this.resizeSubscription$ = this.resizeObservable$.subscribe((e) => {
      this.windowWidth = window.innerWidth;
    });
    this.elem = document.documentElement;
    this.storyblokService.getStoryService().then((res) => {
      const story = res.filter((item) => item.slug === 'mobile-alert');
      this.storyblok = story[0].content;
    });
    localStorage.setItem('environment', environment.serverUrl);
    localStorage.setItem('project', environment.project);
    localStorage.setItem('GTAKey', environment['GTAKey']);
    if (environment.production) {
      Logger.enableProductionMode();
    }

    log.debug('init');

    posthog.capture('app_loaded', {
      environment: environment.name,
      project: environment.project,
      version: environment.version,
    });

    const onNavigationEnd = this.router.events.pipe(filter((event) => event instanceof NavigationEnd));
  }
}
