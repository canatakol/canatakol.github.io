import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, EmailValidator, FormControl } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';
import { SetPasswordService } from '@app/login/set-password/set-password.service';
import { AuthenticationService } from '@app/core/authentication/authentication.service';
declare var $: any;
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.scss'],
  standalone: false,
})
export class UserComponent implements OnInit, OnDestroy {
  isLoading = false;
  storyblok;
  passwordRegexText;
  passwordText;
  userForm = false;
  passwordForm = false;
  user;
  quote: string;
  registerForm: FormGroup;
  isConfirm = true;
  type = 'password';
  currenttype = 'password';
  isRegex = true;
  errors = [];
  password;
  changePasswordForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    public router: Router,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private setPasswordService: SetPasswordService,
    private commonService: CommonService,
    private authenticationService: AuthenticationService
  ) {}

  register() {
    const data = this.registerForm.value;
    data['email'] = this.user['email'];
    this.http.callService(new Method(environment.services.currentUser(), data, 'put')).subscribe((res) => {
      this.getUser();
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
    });
  }

  chanepassword() {
    const data = {
      oldPassword: this.changePasswordForm.controls.oldPassword.value,
      newPassword: this.changePasswordForm.controls.password.value,
    };
    this.http.callService(new Method(environment.services.password(), data, 'put')).subscribe((res) => {
      this.authenticationService.logout();
      this.router.navigate(['/login']);
      if (res) {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      }
    });
  }

  // tslint:disable-next-line:member-ordering
  passwordRegex(password: string, confirmedPassword: string) {
    this.errors = this.setPasswordService.passwordRegex(password, confirmedPassword, this.passwordRegexText);
  }
  // tslint:disable-next-line:member-ordering
  isConfirmed(password: string, confirmedPassword: string) {
    this.isConfirm = this.setPasswordService.isConfirmed(password, confirmedPassword);
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const password = data.filter((item) => item.slug === 'signup');
      const story = data.filter((item) => item.slug === 'profile');
      this.passwordText = password[0].content;
      this.storyblok = story[0].content;
      const passwordRegex = data.filter((item) => item.slug === 'signup');
      this.passwordRegexText = passwordRegex[0].content;
    });
    this.getUser();
    $('#main-content').addClass('darkBG');
    $('#header').hide();
    $('#main-content').css('padding-top', '2rem');
  }
  ngOnDestroy() {
    $('#header').show();
    $('#main-content').removeClass('darkBG');
    $('#main-content').css('padding-top', '6rem');
  }
  getUser() {
    this.http.callService(new Method(environment.services.currentUser(), '', 'get')).subscribe((res) => {
      this.user = res;
      this.createForm();
      this.createChangePasswordForm();
    });
  }

  private createForm() {
    this.registerForm = this.formBuilder.group({
      firstName: [this.user['firstname'], Validators.required],
      middleName: [this.user['middlename']],
      lastName: [this.user['lastname'], Validators.required],
      email: [this.user['email'], [Validators.required, Validators.email]],
    });
    this.registerForm.get('email')?.disable();
    this.userForm = true;
  }

  private createChangePasswordForm() {
    this.changePasswordForm = new FormGroup({
      oldPassword: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required]),
      confirmedPassword: new FormControl(null, [Validators.required]),
    });
    this.passwordForm = true;
  }
}
