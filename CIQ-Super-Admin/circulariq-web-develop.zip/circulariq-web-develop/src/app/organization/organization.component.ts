import { Component, OnDestroy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, EmailValidator } from '@angular/forms';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { NewUserDialogComponent } from '../shared/dialog/new-user/new-user.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { TFAConfirmDialog } from '@app/shared/dialog/tfa-confirm/tfa-confirm-dialog.component';
import { ConfirmDialog } from '@app/shared/dialog/confirm-dialog/confirm-dialog.component';
import { LocalStorageService } from '@app/core/services/local-storage.service';
declare var $: any;

@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.scss'],
  standalone: false,
})
// tslint:disable-next-line: class-name
export class OrganizationComponent implements OnDestroy {
  isLoading = false;
  storyblok;
  selectedLanguage = localStorage.getItem('lang') ? localStorage.getItem('lang') : 'en';
  data;
  userData;
  hasSupport;
  userRole = this.commonService.userRole;
  isPro;
  isUserAdmin = false;
  userEmail;
  addColleagueMail;
  addColleagueId;
  feature;
  name;
  languageList = [];
  quote: string;
  registerForm: FormGroup;
  adminForm: FormGroup;
  organisation;
  selectUser = null;
  multiLanguage;
  industries = environment.services.industries;
  positions = environment.services.positions;
  project = environment.project;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private commonService: CommonService,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {
    this.isPro = this.commonService.isPro;
    this.userEmail = localStorage.getItem('user-email');
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (credentials && credentials['organisation'] && credentials['organisation'].features) {
      credentials['organisation'].features.forEach((element) => {
        if (element === 'multi_language') {
          this.multiLanguage = true;
        }
      });
    }
    this.http.callService(new Method(environment.services.organisation(), '', 'get')).subscribe((name) => {
      this.name = name;
      this.adminRequest();
      this.http.callService(new Method(environment.services.organisationDetails(), '', 'get')).subscribe((res) => {
        this.data = res;
        this.createForm();
        this.getUser();
        this.getLanguage();
      });
    });
    this.http.callService(new Method(environment.services.membershipSupport(), '', 'get')).subscribe(async (res) => {
      this.hasSupport = res['hasSupport'];
    });
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'organization');
      this.storyblok = story[0].content;
      this.storyblok.languageList.tbody.forEach((element) => {
        this.languageList.push({ code: element.body[0].value, display_name: element.body[1].value });
      });
    });
  }

  ngOnDestroy() {
    $('#main-content').removeClass('darkBG');
    $('#header').show();
    $('#main-content').css('padding-top', '6rem');
  }
  getUser() {
    this.http.callService(new Method(environment.services.user() + '?size=99', '', 'get')).subscribe((res) => {
      this.userData = res['results'];
      this.userData.forEach((element) => {
        if (this.userEmail === element.email) {
          element.roles.forEach((role) => {
            if (role.name === 'Company admin') {
              this.isUserAdmin = true;
            }
          });
        }
        element.roles.forEach((role) => {
          if (role.name === 'Company admin') {
            element.admin = true;
          }
        });
      });
    });
    $('#main-content').addClass('darkBG');
    $('#header').hide();
    $('#main-content').css('padding-top', '2rem');
  }

  setUserRole(email: string, roles: any) {
    this.http
      .callService(new Method(environment.services.userRole(email), { roleNames: roles }, 'put'))
      .subscribe(async (res) => {
        this.getUser();
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }

  settings(i: any) {
    if (this.selectUser !== i) {
      this.selectUser = i;
    } else {
      this.selectUser = null;
    }
  }
  makeAdmin(item: any) {
    this.selectUser = null;
    const roles = [];
    item.roles.forEach((role) => {
      roles.push(role.name);
    });
    roles.push('Company admin');
    this.setUserRole(item.email, roles);
  }
  dropAdmin(item: any) {
    this.selectUser = null;
    const roles = [];
    item.roles.forEach((role) => {
      if (role.name !== 'Company admin') {
        roles.push(role.name);
      }
    });
    this.setUserRole(item.email, roles);
  }
  removeUser(user: any) {
    this.selectUser = null;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${user['fullname'] ? user['fullname'] : user['email']}`,
        message: this.storyblok.delete_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.deleteMembership(user.id), { project: this.project }, 'put'))
          .subscribe(async (res) => {
            this.getUser();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }
  changeUserRole(user: any, role: string, roleName: string) {
    const dialogRef = this.dialog.open(ConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${user['fullname'] ? user['fullname'] : user['email']}`,
        message: `${this.storyblok.change_role_confirm_text} ${roleName}?`,
        yesButtonText: 'CONFIRM',
        noButtonText: 'CANCEL',
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const selectedRole = role === 'Company admin' ? ['Company admin', 'Product manager'] : [role];

        this.http
          .callService(new Method(environment.services.userRole(user.email), { roleNames: selectedRole }, 'put'))
          .subscribe(async (res) => {
            this.getUser();
            this.selectUser = null;
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }

  adminRequest() {
    this.http
      .callService(new Method(environment.services.featuresOrganisation(this.name.id), '', 'get'))
      .subscribe((feature) => {
        this.feature = feature;
        this.feature.forEach((element) => {
          element.status = element.status === 'ENABLED' ? true : false;
        });
      });
  }

  addUser(material: any): void {
    const dialogRef = this.dialog.open(NewUserDialogComponent, {
      width: '80%',
      maxWidth: '640px',
      panelClass: 'centered-dialog',
      data: material,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.getUser();
        this.addColleagueMail = result['email'];
        this.addColleagueId = result['userId'];
        material['responsibleUserEmail'] = result['email'];
      } catch (error) {}
    });
  }

  getLanguage() {
    this.http.callService(new Method(environment.services.organisationLanguage(), '', 'get')).subscribe(async (res) => {
      this.selectedLanguage = res['language'] ? res['language'] : 'en';
    });
  }

  changeLanguage() {
    this.http
      .callService(
        new Method(
          environment.services.organisationLanguage(),
          {
            language: this.selectedLanguage,
          },
          'put'
        )
      )
      .subscribe(async (res) => {
        localStorage.setItem('lang', this.selectedLanguage);
        this.localStorageService.removeItem('storyBlokData');
        const event = new CustomEvent('language.changed', {
          detail: {
            language: this.selectedLanguage,
          },
        });
        document.dispatchEvent(event);
        location.reload();
      });
  }
  async register() {
    this.data = this.registerForm.value;
    await this.http
      .callService(new Method(environment.services.organisationDetails(), this.data, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
    await this.http
      .callService(new Method(environment.services.organisationName(), { name: this.registerForm.value.name }, 'put'))
      .subscribe((res) => {
        this.commonService.organizationName = res['name'];
      });
  }

  featureChage(item: any) {
    item.status = item.status === true ? 'ENABLED' : 'DISABLED';
    const data = { organisationUuid: this.name.id, feature: item.name, status: item.status };
    const dialogRef = this.dialog.open(TFAConfirmDialog, {
      width: '80%',
      maxWidth: '680px',
      panelClass: 'centered-dialog',
      data: item.status === 'ENABLED' ? true : false,
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        this.adminRequest();
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.adminOrganisation(), data, 'put'))
          .subscribe(async (res) => {
            if (!res) {
              this.adminRequest();
              this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
            }
          });
      } catch (error) {}
    });
  }

  grantAccess(val: boolean) {
    if (val) {
      this.http.callService(new Method(environment.services.membershipSupport(), '', 'put')).subscribe(async (res) => {
        this.adminRequest();
        this.snackBar.open(this.storyblok.grant_access_positive_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
    } else {
      this.http
        .callService(new Method(environment.services.membershipSupport(), '', 'delete'))
        .subscribe(async (res) => {
          this.adminRequest();
          this.snackBar.open(this.storyblok.grant_access_negative_message, '', {
            duration: 5000,
            panelClass: ['info-snackBar'],
          });
        });
    }
  }
  private createForm() {
    this.registerForm = this.formBuilder.group({
      name: [this.name['name'], Validators.required],
      industry: [this.data['industry'], Validators.required],
      industryOther: [this.data['industryOther']],
      position: [this.data['position'], Validators.required],
      positionOther: [this.data['positionOther']],
      address: [this.data['address'], Validators.required],
      revenue: [this.data['revenue'], Validators.required],
      currenctType: [this.data['currenctType'], Validators.required],
    });
  }
}
