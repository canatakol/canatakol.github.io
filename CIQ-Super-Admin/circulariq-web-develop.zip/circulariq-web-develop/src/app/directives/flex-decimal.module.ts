import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FlexDecimalDirective } from './flex-decimal.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [FlexDecimalDirective],
  exports: [FlexDecimalDirective],
})
export class FlexDecimalModule {}
