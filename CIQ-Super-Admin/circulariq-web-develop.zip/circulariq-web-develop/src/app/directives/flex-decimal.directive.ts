import {
  Directive,
  HostListener,
  Optional,
  Self,
  OnInit,
  ElementRef,
  Input,
  OnChanges,
  SimpleChanges,
  AfterViewInit,
  ChangeDetectorRef,
  Renderer2,
} from '@angular/core';
import { NgModel, NgControl } from '@angular/forms';

@Directive({
  selector: '[flexDecimal]',
  standalone: false,
})
export class FlexDecimalDirective implements OnInit, OnChanges, AfterViewInit {
  @Input() maxLimit?: number;
  @Input() mask?: string;
  @Input() maskPosition: 'start' | 'end' = 'end';
  @Input() decimalPlaces?: number;

  private maskSpan: HTMLElement | null = null;

  constructor(
    @Optional() @Self() private ngControl: NgControl,
    @Optional() @Self() private ngModel: NgModel,
    private elRef: ElementRef,
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    setTimeout(() => {
      this.applyLimit();
      this.createMaskElement();
      this.updateMaskPosition();
    });
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.applyLimit();
      this.createMaskElement();
      this.updateMaskPosition();
      // Format existing value if decimalPlaces is set
      if (this.decimalPlaces !== undefined) {
        const inputElement = this.getInputElement();
        if (inputElement && inputElement.value) {
          this.formatDecimalPlaces(inputElement, true);
        }
      }
      this.cdr.detectChanges();
    });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['maxLimit'] || changes['mask'] || changes['maskPosition'] || changes['decimalPlaces']) {
      setTimeout(() => {
        this.applyLimit();
        this.createMaskElement();
        this.updateMaskPosition();
        // Format existing value if decimalPlaces is set
        if (this.decimalPlaces !== undefined) {
          const inputElement = this.getInputElement();
          if (inputElement && inputElement.value) {
            this.formatDecimalPlaces(inputElement, true);
          }
        }
        this.cdr.detectChanges();
      });
    }
  }

  @HostListener('input', ['$event'])
  onInput(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    this.runSanitization(inputElement);
    this.updateMaskPosition();
  }

  @HostListener('blur', ['$event'])
  onBlur(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    if (this.decimalPlaces !== undefined && inputElement.value) {
      this.formatDecimalPlaces(inputElement, true);
    }
  }

  private runSanitization(inputElement: HTMLInputElement): void {
    let enteredValue = inputElement.value;
    let sanitizedValue = enteredValue
      .replace(/[^0-9.,]/g, '')
      .replace(/([.,])(.*?)([.,])/g, '$1$2')
      .replace(/([.,].*?)[.,]/g, '$1');

    if (sanitizedValue.indexOf('.') !== -1 && sanitizedValue.indexOf(',') === -1) {
      sanitizedValue = sanitizedValue.replace('.', ',');
    }

    const parts = sanitizedValue.split(/[.,]/);
    let numericValue = NaN;

    if (parts.length === 1) {
      numericValue = parseFloat(parts[0]);
    } else if (parts.length === 2) {
      // Don't limit decimal places - allow user to enter as many as they want
      numericValue = parseFloat(parts[0] + '.' + parts[1]);
    }

    if (!isNaN(numericValue) && this.maxLimit !== undefined && numericValue > this.maxLimit) {
      numericValue = this.maxLimit;
      sanitizedValue = numericValue.toString().replace('.', ',');
    }

    inputElement.value = sanitizedValue;

    if (!isNaN(numericValue)) {
      setTimeout(() => {
        if (this.ngModel) {
          this.ngModel.update.emit(numericValue);
        } else {
          const control = this.ngControl?.control;
          if (this.ngControl?.valueAccessor) {
            this.ngControl.valueAccessor.writeValue(sanitizedValue);
          }
          if (control) {
            control.setValue(numericValue, { emitModelToViewChange: false });
          }
        }
        this.cdr.detectChanges();
      });
    } else {
      setTimeout(() => {
        if (this.ngModel) {
          this.ngModel.update.emit(null);
        } else {
          const control = this.ngControl?.control;
          if (control) {
            control.setValue(null, { emitEvent: true });
          }
        }
        this.cdr.detectChanges();
      });
    }

    this.updateMaskPosition();
  }

  private applyLimit(): void {
    const inputElement = this.getInputElement();
    if (inputElement) {
      this.runSanitization(inputElement);
      // Format existing value if decimalPlaces is set and input has a value
      if (this.decimalPlaces !== undefined && inputElement.value) {
        // Small delay to ensure value is set
        setTimeout(() => {
          if (inputElement.value) {
            this.formatDecimalPlaces(inputElement, true);
          }
        }, 0);
      }
    }
  }

  private getInputElement(): HTMLInputElement | null {
    const element = this.elRef.nativeElement as HTMLInputElement;
    return element instanceof HTMLInputElement ? element : null;
  }

  private createMaskElement(): void {
    const inputElement = this.getInputElement();
    if (inputElement && this.mask) {
      if (!this.maskSpan) {
        this.maskSpan = this.renderer.createElement('span');
        this.renderer.addClass(this.maskSpan, 'flex-decimal-mask');
        this.renderer.setStyle(this.maskSpan, 'position', 'absolute');
        this.renderer.setStyle(this.maskSpan, 'top', '50%');
        this.renderer.setStyle(this.maskSpan, 'transform', 'translateY(-25%)');
        this.renderer.setStyle(this.maskSpan, 'color', '#1c195b');
        this.renderer.setStyle(this.maskSpan, 'pointerEvents', 'none');
        this.renderer.appendChild(this.maskSpan, this.renderer.createText(this.mask));

        this.renderer.appendChild(inputElement.parentNode, this.maskSpan);
      }

      this.updateMaskPosition();
    }
  }

  private formatDecimalPlaces(inputElement: HTMLInputElement, forceFormat: boolean = false): void {
    const value = inputElement.value.trim();
    if (!value) {
      return;
    }

    // Don't format if input is focused (user is typing) unless forced
    if (!forceFormat && inputElement === document.activeElement) {
      return;
    }

    const parts = value.split(/[.,]/);
    let numericValue: number;
    let existingDecimalPlaces = 0;

    if (parts.length === 1) {
      numericValue = parseFloat(parts[0]);
      existingDecimalPlaces = 0;
    } else if (parts.length === 2) {
      numericValue = parseFloat(parts[0] + '.' + parts[1]);
      existingDecimalPlaces = parts[1].length;
    } else {
      return;
    }

    if (isNaN(numericValue)) {
      return;
    }

    // Use minimum decimal places, but preserve more if user entered more
    const minDecimalPlaces = this.decimalPlaces || 0;

    // If user already entered decimals:
    // - if decimals >= minDecimalPlaces: leave as is
    // - if decimals < minDecimalPlaces: pad to minimum
    if (existingDecimalPlaces > 0) {
      if (existingDecimalPlaces >= minDecimalPlaces) {
        return;
      }
      const paddedValue = parts[0] + ',' + parts[1].padEnd(minDecimalPlaces, '0');
      inputElement.value = paddedValue;
      setTimeout(() => {
        if (this.ngModel) {
          this.ngModel.update.emit(parseFloat(parts[0] + '.' + parts[1]));
        } else {
          const control = this.ngControl?.control;
          if (this.ngControl?.valueAccessor) {
            this.ngControl.valueAccessor.writeValue(paddedValue);
          }
          if (control) {
            control.setValue(parseFloat(parts[0] + '.' + parts[1]), {
              emitModelToViewChange: false,
            });
          }
        }
        this.cdr.detectChanges();
      });
      return;
    }

    // Only format if we need to add decimal places (integer value -> add minimum decimals)
    const targetDecimalPlaces = minDecimalPlaces;
    const formattedValue = numericValue.toFixed(targetDecimalPlaces).replace('.', ',');

    // Only update if value actually changed
    if (formattedValue !== value) {
      inputElement.value = formattedValue;

      // Update the model value
      setTimeout(() => {
        if (this.ngModel) {
          this.ngModel.update.emit(numericValue);
        } else {
          const control = this.ngControl?.control;
          if (this.ngControl?.valueAccessor) {
            this.ngControl.valueAccessor.writeValue(formattedValue);
          }
          if (control) {
            control.setValue(numericValue, { emitModelToViewChange: false });
          }
        }
        this.cdr.detectChanges();
      });
    }
  }

  private updateMaskPosition(): void {
    const inputElement = this.getInputElement();
    if (inputElement && this.maskSpan) {
      const text = inputElement.value;
      const dotCommaCount = (text.match(/[.,]/g) || []).length;
      const textWidth = text.length * 8 - dotCommaCount * 4;
      const padding = 11;

      if (this.maskPosition === 'end') {
        this.renderer.setStyle(this.maskSpan, 'left', `${textWidth + padding}px`);
      } else {
        this.renderer.setStyle(this.maskSpan, 'right', `${textWidth + padding}px`);
      }
    }
  }
}
