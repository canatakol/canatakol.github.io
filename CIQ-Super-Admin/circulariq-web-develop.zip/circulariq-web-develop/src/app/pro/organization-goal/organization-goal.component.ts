import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { SetMeetingEventDialog } from '@app/shared/dialog/set-meeting-event/set-meeting-event-dialog.component';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { environment } from '@env/environment';
declare var $: any;
@Component({
  selector: 'app-organization-goal',
  templateUrl: './organization-goal.component.html',
  styleUrls: ['./organization-goal.component.scss'],
  standalone: false,
})
export class OrganizationGoalComponent implements OnInit {
  storyblok;
  organizationGoal;
  goalsNavShow = false;
  location = location.pathname;
  environment = environment;
  constructor(
    private dialog: MatDialog,
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private snackBar: MatSnackBar,
    private commonService: CommonService
  ) {}

  settMeetingEvent() {
    const dialogRef = this.dialog.open(SetMeetingEventDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
    });
  }

  deleteOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    this.goalsNavShow = false;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: this.storyblok.delete_goals_modal_title,
        message: this.storyblok.delete_goals_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const nullData = {
          actualRecovery: null,
          circularInflow: null,
          circularOutflow: null,
          materialCircularity: null,
          potentialRecovery: null,
          targetDate: null,
          description: null,
        };
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), nullData, 'put'))
          .subscribe((res) => {
            this.organizationGoal = res;
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    this.goalsNavShow = false;
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }
  isEnabledCTIGoal() {
    this.http.callService(new Method(environment.services.isEnabledCTIGoal(), '', 'get')).subscribe((res) => {
      localStorage.setItem('isEnabledCTIGoal', JSON.stringify(res));
    });
  }
  ngOnInit(): void {
    this.getOrganizationGoal();
    this.isEnabledCTIGoal();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'pro-dashboard');
      this.storyblok = story[0].content;
    });
  }
}
