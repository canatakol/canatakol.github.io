import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Sort } from '@angular/material/sort';
import { Router } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { AddAssessmentDialog } from '@app/shared/dialog/add-assessment/add-assessment.component';
import { AddBusinessLevelDialog } from '@app/shared/dialog/add-business-level/add-business-level.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { ManageMembersDialog } from '@app/shared/dialog/manage-members/manage-members-dialog.component';
import { environment } from '@env/environment';
import { EditBusinessLevelDialog } from '@app/shared/dialog/edit-business-level/edit-business-level.component';
import { DupplicateAssessmentDialog } from '@app/shared/dialog/duplicate_assesment/duplicate_assesment_dialog.component';
import { ImportAssessmentDialog } from '@app/shared/dialog/import_assessment/import_assessment_dialog.component';
import { ImportAssessmentErrorDialog } from '@app/shared/dialog/import-assessment-error/import_assessment_error_dialog.component';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { MergeAssessmentsConfirmDialog } from '@app/shared/dialog/merge-assessments-confirm/merge-assessments-confirm.component';
import { MoveAssessmentDialog } from '@app/shared/dialog/move-assessment/move-assessment.component';

import { LoginService } from '@app/login/login.service';
import { ImportAssessmentE5Dialog } from '@app/shared/dialog/import_assessment_e5/import_assessment_e5_dialog.component';
import { LabelManagmentDialog } from '@app/shared/dialog/label-managment/label-managment.component';
import { LabelBaseComponent } from './label-base/label-base.component';
import { DashboardPreferenceService } from '@app/core/dashboard-preference.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';

declare var $: any;

@Component({
  selector: 'app-pro',
  templateUrl: './pro.component.html',
  styleUrls: ['./pro.component.scss', './aggregate/missing-data/missing-data.component.scss'],
  standalone: false,
})
export class ProComponent implements OnInit, OnDestroy {
  @ViewChild('childRef') labelBaseComponent: LabelBaseComponent;
  selectUser = null;
  data;
  authToken;
  searchText = '';
  supplierName = 'null';
  supplierList;
  initialData;
  isLoading = false;
  isLoadingLabel = false;
  sortedData;
  showSnapshot = false;
  snapShotWarning = false;
  mergeWarning = false;
  moveWarning = false;
  snapshotData = { name: 'Snapshots', assessments: [] };
  initialSnapshotData;
  initialRelatedLabelData;
  snapshotList;
  snapshotOpenAccordion = true;
  lastSnapshottId;
  duplicateAssessmentNonSuccessfullData;
  assessmentImportData;
  selectedIndex = 0;
  compare;
  storyblok;
  isDuplicateStatus;
  duplicateAssessmentId;
  interval;
  selectAssetList = [];
  selectSnapShotList = [];
  selectedLabelforLabelManagment = [];
  environment = environment;
  checkDisabled = false;
  maxSelectedSize = 2500;
  openGuidance = false;
  credentials;
  navigationMode;
  relatedLabelData;
  noLabelTextShow = true;
  LabelBaseComponent: any;
  labelList;
  labelListPureData;
  labelManagmentShow = false;
  updateLabelShow = false;
  dropLabelList = [];
  labelToggleShow = false;
  selectedLabelArray: any[] = [];
  showLoadigIconCompare = false;
  showLoadigIconAggregate = false;
  userRole = this.commonService.userRole;
  constructor(
    private dialog: MatDialog,
    private router: Router,
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private dashboardPreferenceService: DashboardPreferenceService,
    private loginService: LoginService,
    private localStorageService: LocalStorageService
  ) {
    this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
    this.authToken = JSON.parse(sessionStorage.getItem('credentials')).authToken;
    if (this.credentials) {
      this.credentials?.organisation?.features.forEach((feature) => {
        if (feature === 'label') {
          if (this.userRole === 'Admin' || this.userRole === 'Viewer') {
            this.labelToggleShow = true;
          }
        }
      });
    }
    this.http.callService(new Method(environment.services.userJourneyCTI(), '', 'get')).subscribe((res) => {
      if (!res['sampleVideosSeen']) {
        this.commonService.mainGuidanceData.next({ show: true, active: 'started' });
      }
    });
    this.setLabel();
    if (!sessionStorage.getItem('onboardingAlwaysOn')) {
      this.http.callService(new Method(environment.services.ctiGuidance(), '', 'get')).subscribe((ctiGuidanceData) => {
        sessionStorage.setItem('ctiGuidance', JSON.stringify(ctiGuidanceData));
        sessionStorage.setItem('onboardingAlwaysOn', JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']));
        this.commonService.onboardingAlwaysOn = JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']);
      });
    }

    if (this.localStorageService.getCompressedSessionItem('questionList') === null) {
      this.loginService.getQuestionList();
    }
    this.commonService.addLabel.subscribe((res) => {
      this.close();
    });
  }

  setLabel() {
    this.http
      .callService(
        new Method(
          environment.services.labelSearch(),
          {
            keyword: '',
          },
          'put'
        )
      )
      .subscribe((res) => {
        this.labelList = res;

        this.labelList.forEach((element) => {
          element.selected = false;
          const arrayAsString: string = element.path.join('');
          element.labelPahtWithTrim = arrayAsString.toLowerCase().replace(/\s/g, '');
        });
        this.labelListPureData = this.labelList;
        this.labelList.sort(this.sortByName);
      });
  }

  sortByName(a: any, b: any) {
    return a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim);
  }

  dashboardChange() {
    this.http
      .callService(
        new Method(
          environment.services.userJourney(),
          [
            {
              question: 'SHOW_BL_VIEW',
              value: false,
            },
          ],
          'put'
        )
      )
      .subscribe((res) => {
        this.close();
        this.dashboardPreferenceService.setShowBLDashboard(false);
        this.router.navigate(['/cti/pro-label']);
      });
  }

  deleteLabel(label: any) {
    this.labelBaseComponent.selectLabel(label.id, false);
  }

  async setRelatedLabelData(data: boolean) {
    this.isLoadingLabel = true;
    this.noLabelTextShow = false;
    this.close();
    switch (data) {
      case undefined:
        this.noLabelTextShow = true;
        this.isLoadingLabel = false;
        break;
      default:
        this.relatedLabelData = data;
        this.initialRelatedLabelData = data;

        if (this.relatedLabelData) {
          this.relatedLabelData.assessments.forEach((assessment) => {
            assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
          });
        }

        if (this.relatedLabelData) {
          this.isLoadingLabel = false;
          this.noLabelTextShow = false;
        }
        break;
    }
  }

  openGuidanceEvent() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'started' });
  }

  supplierFilter(val: string) {
    this.supplierName = val;
    if (val === 'null') {
      this.initialData.forEach((businnesLevel) => {
        businnesLevel.assessments.forEach((assessment) => {
          assessment.expendActive = false;
        });
      });
      this.data = this.initialData;
    } else {
      const initialData = this.initialData.map((businnesLevel) => {
        return {
          ...businnesLevel,
          assessmentImportData: [],
          duplicateAssessmentNonSuccessfullData: [],
          assessments: businnesLevel.assessments.map((assessment) => {
            return {
              ...assessment,
              expendActive: true,
            };
          }),
        };
      });
      const filter = initialData.map((businnesLevel) => {
        return {
          ...businnesLevel,
          assessments: businnesLevel.assessments.filter((assessment) =>
            assessment?.productLineData?.supplierName?.includes(val)
          ),
        };
      });
      this.data = filter;
    }
  }

  searchAssessment(val: any) {
    if (val === null) {
      $('#searchInput').val('');
    }
    this.searchText = $('#searchInput').val();
    this.supplierName = 'null';
    if (this.searchText.length <= 2) {
      this.data = this.initialData;
      this.snapshotData = this.initialSnapshotData;
      this.relatedLabelData = this.initialRelatedLabelData;
      return;
    }
    const filter = this.initialData.map((businnesLevel) => {
      return {
        ...businnesLevel,
        assessmentImportData: [],
        duplicateAssessmentNonSuccessfullData: [],
        assessments: businnesLevel?.assessments.filter((assessment) =>
          assessment.assessmentNameWithTrim.includes(this.searchText.toLowerCase().replace(/\s/g, ''))
        ),
      };
    });
    const snapshotFilter = {
      ...this.initialSnapshotData,
      assessments: this.initialSnapshotData?.assessments.filter((item) => {
        return item.assessmentNameWithTrim.includes(this.searchText.toLowerCase().replace(/\s/g, ''));
      }),
    };
    if (this.relatedLabelData) {
      const relatedLabelDataFilter = {
        ...this.relatedLabelData,
        assessments: this.relatedLabelData?.assessments.filter((item) => {
          return item.assessmentNameWithTrim.includes(this.searchText.toLowerCase().replace(/\s/g, ''));
        }),
      };
      this.relatedLabelData = relatedLabelDataFilter;
    }

    this.data = filter;
    this.snapshotData = snapshotFilter;
  }

  navigationModeEvent(val: boolean) {
    this.navigationMode = val;
  }

  addLabelEvent() {
    this.setLabel();
    setTimeout(() => {
      this.searchLabel($('#searchLabel').val());
    }, 500);
  }

  sortData(sort: Sort, assessmentList: any) {
    if (!sort.active || sort.direction === '') {
      this.sortedData = assessmentList;
      return;
    }
    this.sortedData = assessmentList.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name':
          return this.sortfunc(a.name, b.name, isAsc);
        case 'completion':
          return this.sortfunc(a.completion, b.completion, isAsc);
        case 'materialCircularity':
          return this.sortfunc(a.materialCircularity, b.materialCircularity, isAsc);
        case 'inflowMass':
          return this.sortfunc(a.inflowMass, b.inflowMass, isAsc);
        case 'outflowMass':
          return this.sortfunc(a.outflowMass, b.outflowMass, isAsc);
        default:
          return 0;
      }
    });
  }
  sortfunc(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  settingsBussines(level: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.data.forEach((element) => {
      if (element.id === level.id) {
        element.isSettingsVisible === true ? (element.isSettingsVisible = false) : (element.isSettingsVisible = true);
      }
    });
  }
  settingsClicked(assessment: any, value: Array<any>) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    value.forEach((item) => {
      if (assessment.unitId) {
        if (item.unitId === assessment.unitId) {
          item.isSettingsVisible === true ? (item.isSettingsVisible = false) : (item.isSettingsVisible = true);
        } else {
          item.isSettingsVisible = false;
        }
      }
      if (assessment.assessmentId) {
        if (item.assessmentId === assessment.assessmentId) {
          item.isSettingsVisible === true ? (item.isSettingsVisible = false) : (item.isSettingsVisible = true);
        } else {
          item.isSettingsVisible = false;
        }
      }
      if (assessment.duplicateAssessmentTaskId) {
        if (item.duplicateAssessmentTaskId === assessment.duplicateAssessmentTaskId) {
          item.isSettingsVisible === true ? (item.isSettingsVisible = false) : (item.isSettingsVisible = true);
        } else {
          item.isSettingsVisible = false;
        }
      }
    });
  }
  getSupplierNames() {
    this.http.callService(new Method(environment.services.supplierNames(), '', 'get')).subscribe((res) => {
      this.supplierList = res;
    });
  }
  async removeImportAssessment(assessment: any, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${assessment['assessmentName']}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(
            new Method(environment.services.deleteFailedAssessment(assessment['assessmentId']), '', 'delete')
          )
          .subscribe(async (res) => {
            this.getBusinessLevel();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }
  async removeDuplicateAssessment(assessment: any, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${assessment['copyAssessmentName']}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(
            new Method(
              environment.services.duplicateAssessmentDelete(assessment['duplicateAssessmentTaskId']),
              '',
              'delete'
            )
          )
          .subscribe(async (res) => {
            this.getBusinessLevel();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }

  async addAssests(event: any, assessment: any, level: any) {
    if (this.selectAssetList.length >= this.maxSelectedSize) {
      if (event.checked) {
        assessment.added = false;
        this.checkDisabled = true;
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      } else {
        this.checkDisabled = false;
        const index = this.selectAssetList.indexOf(assessment.unitId);
        if (index === -1) {
          this.selectAssetList.push(assessment.unitId);
          assessment.added = true;
        } else {
          this.selectAssetList.splice(index, 1);
          assessment.added = false;
          level.added = false;
        }
      }
    } else {
      this.checkDisabled = false;
      const index = this.selectAssetList.indexOf(assessment.unitId);
      const snapShotIndex = this.selectSnapShotList.indexOf(assessment.unitId);
      if (index === -1) {
        this.selectAssetList.push(assessment.unitId);
        assessment.added = true;
      } else {
        this.selectAssetList.splice(index, 1);
        assessment.added = false;
        level.added = false;
      }
      if (level?.name === 'Snapshots') {
        if (snapShotIndex === -1) {
          this.selectSnapShotList.push(assessment.unitId);
        } else {
          this.selectSnapShotList.splice(snapShotIndex, 1);
        }
      }
    }
  }

  selectedAllbussinesAssesment(event: any, level: any) {
    level.added = event.checked;
    level.assessments.forEach((assessment) => {
      if (event.checked) {
        if (!assessment.added) {
          this.addAssests(event, assessment, level);
        }
      }
      if (!event.checked) {
        if (assessment.added) {
          this.addAssests(event, assessment, level);
        }
      }
    });
  }

  close() {
    this.selectAssetList = [];
    this.selectSnapShotList = [];
    this.labelManagmentShow = false;
    this.labelList = this.labelListPureData;
    if (this.labelList) {
      this.labelList.forEach((label) => (label.selected = false));
    }
    if (this.relatedLabelData) {
      this.relatedLabelData.added = false;
      this.relatedLabelData.assessments.forEach((assessment) => {
        assessment.added = false;
      });
    }
    if (this.data) {
      this.data.forEach((level) => {
        level.added = false;
        level.assessments.forEach((assessment) => {
          assessment.added = false;
        });
      });
    }
  }

  returnSelectData() {
    let organisationUnitList = [];
    let snapshotList = [];
    organisationUnitList = this.selectAssetList.filter(
      (a) => !this.snapshotData.assessments.map((b) => b.unitId).includes(a)
    );
    snapshotList = this.snapshotData.assessments
      .filter((g) => this.selectAssetList.includes(g.unitId))
      .map((g) => g.unitId);
    return {
      organisationUnitList: this.deleteSame(organisationUnitList),
      snapshotList: this.deleteSame(snapshotList),
    };
  }

  async goToCompare() {
    const returnData = this.returnSelectData();
    if (this.selectAssetList.length > 1) {
      this.showLoadigIconCompare = true;
      this.http.callService(new Method(environment.services.compareBusiness(), returnData, 'put')).subscribe((res) => {
        this.compare = res;
        this.compare.forEach((item) => {
          item.namesort = `${item.businessLevelName.toUpperCase()}-${item.assessmentName.toUpperCase()}`;
        });
        this.showLoadigIconCompare = false;
        localStorage.setItem('selectAssetList', JSON.stringify(returnData));
        this.localStorageService.setCompressedItem(this.localStorageService.COMPARE_DATA_KEY, res);
        this.router.navigate(['cti/pro/compare']);
      });
    }
  }

  goToAggregate() {
    const returnData = this.returnSelectData();
    const setData = {
      memberList: returnData.organisationUnitList,
    };
    if (this.selectAssetList.length > 1) {
      if (returnData.snapshotList.length > 0) {
        this.snapShotWarning = true;
        setTimeout(() => {
          this.snapShotWarning = false;
        }, 3000);
      } else {
        this.showLoadigIconAggregate = true;
        this.snapShotWarning = false;
        this.http.callService(new Method(environment.services.aggregateBusiness(), setData, 'put')).subscribe((res) => {
          this.localStorageService.setCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY, res);
          this.router.navigate(['cti/pro/aggregate']);
          this.showLoadigIconAggregate = false;
        });
      }
    }
  }
  deleteSame = (arr) => {
    return arr.filter(function (elem: any, index: any, self: string | any[]) {
      return index === self.indexOf(elem);
    });
  };
  createSnapshot() {
    const returnData = this.returnSelectData();
    if (returnData.snapshotList.length > 0) {
      this.mergeWarning = true;
      setTimeout(() => {
        this.mergeWarning = false;
      }, 3000);
    } else {
      this.mergeWarning = false;
      const dialogRef = this.dialog.open(MergeAssessmentsConfirmDialog, {
        width: '80%',
        maxWidth: '620px',
        panelClass: 'centered-dialog',
        data: {
          selectAssetList: this.selectAssetList,
        },
      });
      dialogRef.afterClosed().subscribe(async (result) => {
        if (!result) {
          return;
        }
        try {
          const data = {
            name: result.mergeName,
            organisationUnitList: result.selectAssetList,
          };
          this.http
            .callService(new Method(environment.services.assessmentSnapshot(), data, 'post'))
            .subscribe((res) => {
              this.lastSnapshottId = res['unitId'];
              this.showSnapshot = true;
              this.close();
              this.getSnapshot();
            });
        } catch (error) {}
      });
    }
  }

  getSnapshot() {
    this.http.callService(new Method(environment.services.assessmentSnapshot(), '', 'get')).subscribe((res: []) => {
      this.snapshotData.assessments = res['assessments'];
      this.initialSnapshotData = res;
      this.snapshotData.assessments.forEach((assessment) => {
        if (assessment.name) {
          assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
        }
      });
    });
  }

  removeSnapshot(item: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${item.name}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.assessmentSnapshotRemove(item.unitId), '', 'delete'))
          .subscribe(async (res: []) => {
            this.getSnapshot();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }

  renameSnapshot(item: any) {
    this.snapshotData.assessments.forEach((snapshotItem) => {
      if (snapshotItem.unitId === item.unitId) {
        snapshotItem.edit = true;
      } else {
        snapshotItem.edit = false;
      }
    });
  }

  snapshotNameChange(item: any) {
    this.http
      .callService(new Method(environment.services.assessmentSnapshotEdit(item.unitId), { name: item.name }, 'put'))
      .subscribe(async (res) => {
        item.edit = false;
        item.isSettingsVisible = false;
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }

  gotoAssessment(assessment: any, level: any) {
    sessionStorage.setItem('selectedAssessment', JSON.stringify(assessment));
    this.commonService.selectedUnit = assessment;
    this.router.navigate([`/cti/${assessment.unitId}/assessment/step1`]);
  }

  async labelManagment(selectAssetList: any): Promise<void> {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    await this.setLabel();
    await this.labelList.forEach((label) => {
      label.selected = false;
    });
    const selectedAssessments = this.findSameAssessment(selectAssetList, this.relatedLabelData.assessments);
    const commonLabels = this.findCommonLabels(selectedAssessments);
    await this.labelList.forEach((label) => {
      label.selected = commonLabels.includes(label.id);
    });
    await this.labelList.sort(this.sortBySelected);
    const dialogRef = this.dialog.open(LabelManagmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { selectAssetList: this.selectAssetList, labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      this.labelManagmentShow = false;

      if (result) {
        await this.labelBaseComponent.getAssessmentaccordingToLabel();
        await this.labelBaseComponent.getLabel();
        await this.setLabel();
      }
    });
  }
  private findCommonLabels(assessments: any): string[] {
    const labelIds = assessments.flatMap((assessment) => assessment.labels.map((label) => label.id));
    const size = assessments.length;

    return labelIds.filter((id) => labelIds.filter((labelId) => labelId === id).length === size);
  }

  private sortBySelected(a: any, b: any): number {
    return a.selected === b.selected ? 0 : a.selected ? -1 : 1;
  }

  findSameAssessment(selectAssetList: any[], relatedLabelData: any[]): any[] {
    return relatedLabelData.filter((element) => selectAssetList.includes(element.unitId));
  }

  async labelManagment4(selectAssetList: any): Promise<void> {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    await this.setLabel();
    await this.labelList.forEach((label) => {
      label.selected = false;
    });
    const selectedAssessments = this.findSameAssessment(selectAssetList, this.relatedLabelData.assessments);
    const commonLabels = this.findCommonLabels(selectedAssessments);

    await this.labelList.forEach((label) => {
      label.selected = commonLabels.includes(label.id);
    });

    await this.labelList.sort(this.sortBySelected);
    this.labelManagmentShow = !this.labelManagmentShow;
  }

  setSelectedLabelArray(data: any): void {
    this.selectedLabelforLabelManagment = data;
  }
  setDropLabelArray(data: any): void {
    this.dropLabelList = data;
  }

  async setLabelSave(unitIds: any): Promise<void> {
    const labelIds = this.selectedLabelforLabelManagment;
    if (this.dropLabelList.length) {
      this.http
        .callService(new Method(environment.services.labelDrop(), { labelIds: this.dropLabelList, unitIds }, 'put'))
        .subscribe(() => {
          if (labelIds.length) {
            this.http
              .callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'))
              .subscribe(() => {
                this.labelManagmentShow = false;
                this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                  duration: 5000,
                  panelClass: ['success-snackBar'],
                });
                this.labelBaseComponent.getAssessmentaccordingToLabel();
              });
          } else {
            this.labelManagmentShow = false;
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.labelBaseComponent.getAssessmentaccordingToLabel();
          }
        });
    } else {
      if (labelIds.length) {
        this.http
          .callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'))
          .subscribe(() => {
            this.labelManagmentShow = false;
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.labelBaseComponent.getAssessmentaccordingToLabel();
          });
      }
    }
    this.selectAssetList = [];
    this.selectedLabelforLabelManagment = [];
    this.dropLabelList = [];
    this.close();
  }

  searchLabel(val: any) {
    const selectedItems = this.labelList.filter((item) => item.selected);
    this.labelList = this.labelListPureData;

    if (val === null) {
      $('#searchLabel').val('');
    }

    const searchText = $('#searchLabel').val()?.toLowerCase().replace(/\s/g, '');

    if (searchText) {
      const filteredItems = this.labelList.filter((item) => {
        return item.labelPahtWithTrim.includes(searchText) && !item.selected;
      });

      this.labelList = [...selectedItems, ...filteredItems];
    } else {
      this.labelList = [...selectedItems, ...this.labelList.filter((item) => !item.selected)];
    }

    this.moveSelectedItemsToTop();
  }

  addToSelectedLabel(label: { id: number; selected: boolean }): void {
    this.updateLabelShow = true;

    if (label.selected) {
      this.selectedLabelArray.push(label.id);
    } else {
      const index = this.selectedLabelArray.indexOf(label.id);
      if (index > -1) {
        this.selectedLabelArray.splice(index, 1);
      }
    }

    this.moveSelectedItemsToTop();
  }

  moveSelectedItemsToTop(): void {
    this.labelList.sort((a, b) => {
      const aSelected = this.selectedLabelArray.includes(a.id);
      const bSelected = this.selectedLabelArray.includes(b.id);
      return aSelected === bSelected ? 0 : aSelected ? -1 : 1;
    });
  }

  moveAssessment() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const returnData = this.returnSelectData();
    if (returnData.snapshotList.length > 0) {
      this.moveWarning = true;
      setTimeout(() => {
        this.moveWarning = false;
      }, 3000);
    } else {
      const dialogRef = this.dialog.open(MoveAssessmentDialog, {
        width: '80%',
        maxWidth: '600px',
        panelClass: 'centered-dialog',
        data: this.data,
      });
      dialogRef.afterClosed().subscribe((result) => {
        if (!result) {
          return;
        }
        try {
          this.http
            .callService(
              new Method(
                environment.services.moveAssessments(result),
                { assessmentList: returnData.organisationUnitList },
                'put'
              )
            )
            .subscribe((res) => {
              this.getBusinessLevel();
              this.snackBar.open(this.storyblok.move_assessment_snackbar_text, '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
            });
          this.close();
        } catch (error) {}
      });
    }
  }

  async deleteLevel(level: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${level['name']}`,
        message: this.storyblok.delete_business_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.deleteBusinessLevel(level['id']), '', 'delete'))
          .subscribe(async (res) => {
            this.getBusinessLevel();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }

  async removeAssessment(assessment: object, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${assessment['name']}`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.getAssessment(assessment['id']), '', 'delete'))
          .subscribe(async (res) => {
            this.getBusinessLevel();
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }
  async importAssessment(level: object, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(ImportAssessmentDialog, {
      width: '80%',
      maxWidth: '540px',
      panelClass: 'centered-dialog',
      data: level,
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.getBusinessLevel();
      } catch (error) {}
    });
  }

  importData(level: object, index: number): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(ImportAssessmentE5Dialog, {
      width: '80%',
      maxWidth: '640px',
      panelClass: 'centered-dialog',
      data: this.labelList,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.getBusinessLevel();
      }
    });
  }

  async errorDetailImoprtAssessment(assessment: any, index: number) {
    const dialogRef = this.dialog.open(ImportAssessmentErrorDialog, {
      width: '80%',
      maxWidth: '540px',
      panelClass: 'centered-dialog',
      data: assessment,
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.removeImportAssessment(assessment, index);
      } catch (error) {}
    });
  }

  async errorDetailDuplicateAssessment(assessment: any, index: number) {
    const dialogRef = this.dialog.open(ImportAssessmentErrorDialog, {
      width: '80%',
      maxWidth: '540px',
      panelClass: 'centered-dialog',
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.removeDuplicateAssessment(assessment, index);
      } catch (error) {}
    });
  }
  async duplicateAssessment(assessment: object, level: object, index: number) {
    this.selectedIndex = index;
    const dialogRef = this.dialog.open(DupplicateAssessmentDialog, {
      width: '80%',
      maxWidth: '660px',
      panelClass: 'centered-dialog',
      data: {
        name: `${level['name']}`,
        assessmentName: `${assessment['name']}`,
        step5: false,
        step6: false,
        step7: false,
      },
    });
    this.settingsClicked(assessment, level['assessments']);
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.duplicateAssessment(assessment['id']), result, 'post'))
          .subscribe(async (res) => {
            this.duplicateAssessmentId = res['id'];
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
          });
      } catch (error) {}
    });
  }

  setStatus() {
    this.http
      .callService(
        new Method(environment.services.checkduplicateAssessmentStatus(this.duplicateAssessmentId), '', 'get')
      )
      .subscribe(async (res) => {
        this.isDuplicateStatus = res['status'];
        if (this.isDuplicateStatus === 'SUCCESS') {
          this.duplicateAssessmentId = res['copyAssessmentId'];
          clearInterval(this.interval);
          this.getBusinessLevel();
        }
      });
  }

  async getBusinessLevel() {
    this.isLoading = true;
    await this.getSupplierNames();
    await this.http.callService(new Method(environment.services.getCTIProDashboard(), '', 'get')).subscribe((res) => {
      this.isLoading = false;
      this.data = res;
      this.initialData = res;
      if (this.data.length > 0) {
        this.data.forEach((level) => {
          level.assessments.forEach((assessment) => {
            if (assessment.name) {
              assessment.assessmentNameWithTrim = assessment.name.toLowerCase().replace(/\s/g, '');
            }
          });
        });
        this.data.forEach((bussinesLevel, index) => {
          if (index === this.selectedIndex) {
            bussinesLevel.openAccordion = true;
          } else {
            bussinesLevel.openAccordion = false;
          }
        });
      }
      this.http.callService(new Method(environment.services.assessmentImport(), '', 'get')).subscribe((res) => {
        this.assessmentImportData = res;

        if (this.assessmentImportData && this.data) {
          if (this.assessmentImportData.length > 0) {
            this.data.forEach((bussinesLevel) => {
              bussinesLevel.assessmentImportData = [];
              this.assessmentImportData.forEach((assessment) => {
                if (bussinesLevel.id === assessment.businessLevelId) {
                  bussinesLevel.assessmentImportData.push(assessment);
                }
              });
            });
          }
        }
      });
      this.http
        .callService(new Method(environment.services.duplicateAssessmentNonSuccessful(), '', 'get'))
        .subscribe((res) => {
          this.duplicateAssessmentNonSuccessfullData = res;

          if (this.duplicateAssessmentNonSuccessfullData && this.data) {
            if (this.duplicateAssessmentNonSuccessfullData.length > 0) {
              this.data.forEach((bussinesLevel) => {
                bussinesLevel.duplicateAssessmentNonSuccessfullData = [];
                this.duplicateAssessmentNonSuccessfullData.forEach((assessment) => {
                  if (bussinesLevel.id === assessment.businessLevelId) {
                    bussinesLevel.duplicateAssessmentNonSuccessfullData.push(assessment);
                  }
                });
              });
            }
          }
        });
    });
    if (this.userRole === 'Admin' || this.userRole === 'Viewer') {
      await this.getSnapshot();
    }
  }

  businessAccordion(level: any) {
    level.openAccordion = !level.openAccordion;
  }

  manageMember(level: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(ManageMembersDialog, {
      width: '80%',
      maxWidth: '1300px',
      panelClass: 'centered-dialog',
      data: level,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        this.getBusinessLevel();
        return;
      }
      try {
        this.getBusinessLevel();
      } catch (error) {}
    });
  }

  addassessmentForLabel(): void {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(AddAssessmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { data: { name: 'Label view' }, type: 'assessment', labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (result) {
        await this.http
          .callService(new Method(environment.services.addAssessmentDefault(), { name: result.assessmentName }, 'post'))
          .subscribe(async (res) => {
            let unitIds = [];
            unitIds.push(res['unitId']);
            const labelIds = result.labelList;
            await this.http
              .callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'))
              .subscribe((responce) => {
                window.location.href = `/cti/${res['unitId']}/assessment/step1`;
              });
          });
      }
    });
  }

  async bulkDelete(selectAssetList: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `Delete ${selectAssetList.length} assessments`,
        message: this.storyblok.delete_assessment_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.bulkDelete(), { assessmentList: selectAssetList }, 'put'))
          .subscribe(async (res: []) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.close();
            await this.getBusinessLevel();
          });
      } catch (error) {}
    });
  }

  addAssessment(level: any, index?: number) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedIndex = index;

    const dialogRef = this.dialog.open(AddAssessmentDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: { data: level, type: 'assessment' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.addAssessment(level.id), { name: result }, 'post'))
          .subscribe((res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            const result = this.findNewItems(level.assessments, res['assessments']);
            this.gotoAssessment(result[0], res);
          });
      } catch (error) {}
    });
  }

  addBusinessLevel(item: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(AddBusinessLevelDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: item,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.listBusinessLevels(), result, 'post'))
          .subscribe((res) => {
            if (res) {
              this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
              this.getBusinessLevel();
            }
          });
      } catch (error) {}
    });
  }
  reportStatus(assessment: any, level: any) {
    this.http
      .callService(new Method(environment.services.reportStatus(assessment.unitId), '', 'get'))
      .subscribe((res) => {
        if (res['canDownload']) {
          if (res['warningMessage']) {
            const dialogRef = this.dialog.open(ReportStatusDialog, {
              width: '80%',
              maxWidth: '430px',
              panelClass: 'centered-dialog',
              data: {
                message: res['warningMessage'],
              },
            });
            dialogRef.afterClosed().subscribe(async (result) => {
              if (!result) {
                return;
              }
              try {
                window.open(`/cti/${assessment.unitId}/${this.authToken}/report`);
              } catch (error) {}
            });
          } else {
            window.open(`/cti/${assessment.unitId}/${this.authToken}/report`);
          }
        } else {
          this.snackBar.open(res['warningMessage'], '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        }
      });
  }

  editBusinessLevel(item: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(EditBusinessLevelDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: item,
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.editBusinessLevel(item['id']), result, 'put'))
          .subscribe((res) => {
            if (res) {
              this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
              this.getBusinessLevel();
            }
          });
      } catch (error) {}
    });
  }

  showSnapshotevent(checked: any) {
    this.showSnapshot = checked;
    if (!this.showSnapshot) {
      this.selectedAllbussinesAssesment({ checked: false }, this.snapshotData);
    }
  }

  ngOnDestroy() {
    $('#main-content').removeClass('darkBG');
  }

  ngOnInit(): void {
    console.log('pro component');
    delete sessionStorage.indicators;
    $('#main-content').addClass('darkBG');
    this.getBusinessLevel();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'pro-dashboard');
      this.storyblok = story[0].content;
    });
  }
  findNewItems(arr1: Array<any>, arr2: Array<any>): Array<any> {
    const arr1UnitIds = new Set(arr1.map((item) => item.unitId));
    return arr2.filter((item) => !arr1UnitIds.has(item.unitId));
  }
}
