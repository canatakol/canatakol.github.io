import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { CommonModule } from '@angular/common';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';

declare var $: any;
@Component({
  selector: 'app-label-managment',
  templateUrl: './label-managment.component.html',
  styleUrls: ['./label-managment.component.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, MatCheckboxModule],
})
export class LabelManagmentComponent implements OnInit {
  @Input() public labelList: any;
  @Input() public isImport: boolean = false;

  @Output() buttonDisabled: EventEmitter<any> = new EventEmitter();
  @Output() setSelectedLabelArray: EventEmitter<any> = new EventEmitter();
  storyblok;
  storyblokDashboard;
  businessForm: FormGroup;
  showExactMatchWarning;
  searchLabelText: string;
  labelListPureData = [];
  test = [];
  showCreateLabel = false;
  selectedLabelArray: any[] = [];
  removedLabelArray: any[] = [];
  removeableArray: any[] = [];
  removeableLabelArray: any[] = [];
  updateLabelShow = false;
  labelManagmentContentShow = false;
  nestedOptions;
  selectedItem;
  showOptions = false;
  currentLine = 0;
  showLabelSelect = false;
  constructor(
    private storyblokService: StoryblokService,
    private cdr: ChangeDetectorRef,
    private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    private http: ApiRequestService
  ) {}

  async ngOnInit(): Promise<void> {
    await this.storyblokService.getStoryService().then((res) => {
      this.storyblok = res.filter((item) => item.slug === 'add-assessment')[0].content;
      this.storyblokDashboard = res.filter((item) => item.slug === 'pro-dashboard')[0].content;
    });
    this.labelListPureData = this.labelList;
    this.labelListPureData.forEach((element) => {
      if (element.selected) {
        this.removeableArray.push(element.id);
      }
    });
    this.selectedLabelArray = [];
    await this.delay(300);
    await this.afterWorking();
  }

  afterWorking() {
    this.showLabelSelect = true;
    this.removeableLabelArray = [];
    this.labelList = this.labelListPureData;
    this.labelList.forEach((element) => {
      if (element.selected) {
        this.selectedLabelArray.push(element.id);
      }
    });
  }

  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  getLabel() {
    this.http.callService(new Method(environment.services.label(), '', 'get')).subscribe((res) => {
      this.nestedOptions = res;
    });
  }
  setLabel() {
    this.http
      .callService(
        new Method(
          environment.services.labelSearch(),
          {
            keyword: '',
          },
          'put'
        )
      )
      .subscribe((res) => {
        this.labelList = res;

        this.labelList.forEach((element) => {
          element.selected = false;
          const arrayAsString: string = element.path.join('');
          element.labelPahtWithTrim = arrayAsString.toLowerCase().replace(/\s/g, '');
        });
        this.labelListPureData = this.labelList;
        this.labelList.sort(this.sortByName);
      });
  }

  sortByName(a: any, b: any) {
    return a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim);
  }
  searchLabel(val: any) {
    setTimeout(() => {
      this.performSearch(val);
      this.cdr.detectChanges();
    }, 0);
  }

  performSearch(val: any) {
    const selectedItems = this.labelList.filter((item) => item.selected);
    this.labelList = this.labelListPureData;
    if (val === null) {
      this.searchLabelText = '';
    }

    const searchText = this.searchLabelText?.toLowerCase().replace(/\s/g, '');

    let hasExactMatch = false;

    if (searchText) {
      const filteredItems = this.labelList.filter((item) => {
        const isExactMatch = item.labelPahtWithTrim === searchText && !item.selected;

        if (isExactMatch) {
          hasExactMatch = true;
        }

        return item.labelPahtWithTrim.includes(searchText) && !item.selected;
      });

      this.labelList = [...selectedItems, ...filteredItems];
    } else {
      this.labelList = [...selectedItems, ...this.labelList.filter((item) => !item.selected)];
    }

    if (!hasExactMatch && searchText) {
      this.showExactMatchWarning = true;
    } else {
      this.showExactMatchWarning = false;
    }
    this.moveSelectedItemsToTop();
  }

  addLabel(): void {
    this.showCreateLabel = true;
    this.buttonDisabled.emit(true);
    this.createForm();
    this.getLabel();
  }

  goToBack(): void {
    this.showCreateLabel = false;
    this.buttonDisabled.emit(false);
    this.showExactMatchWarning = false;
    this.searchLabelText = '';
    this.setLabel();
  }

  addToSelectedLabel(label: { id: number; selected: boolean }): void {
    this.updateLabelShow = true;
    if (label.selected) {
      this.selectedLabelArray.push(label.id);
    } else {
      const index = this.selectedLabelArray.indexOf(label.id);
      if (index > -1) {
        this.selectedLabelArray.splice(index, 1);

        this.removeableArray.forEach((element) => {
          if (element === label.id) {
            this.removedLabelArray.push(label.id);
          }
        });
      }
    }

    this.selectedLabelArray.forEach((element) => {
      this.removedLabelArray.forEach((removeItem, index) => {
        if (element === removeItem) {
          this.removedLabelArray.splice(index, 1);
        }
      });
    });

    this.moveSelectedItemsToTop();
  }

  moveSelectedItemsToTop(): void {
    this.labelList.sort((a, b) => {
      const aSelected = this.selectedLabelArray.includes(a.id);
      const bSelected = this.selectedLabelArray.includes(b.id);
      return aSelected === bSelected ? 0 : aSelected ? -1 : 1;
    });
  }

  selectedParrent(item: any, line: number) {
    if (line > this.currentLine) {
      this.selectedItem = item;
      this.currentLine = line;
      this.showOptions = false;
    }
    setTimeout(() => {
      this.currentLine = 0;
    }, 100);
  }
  createLabelAndAttach(): void {
    const data = {
      name: this.businessForm.value.name,
      parentId: this.selectedItem ? this.selectedItem.id : null,
    };
    const labelListSelected = [];
    this.labelList.forEach((element) => {
      if (element.selected) {
        labelListSelected.push(element);
      }
    });
    this.http.callService(new Method(environment.services.label(), data, 'post')).subscribe(async (res) => {
      this.showCreateLabel = false;
      this.buttonDisabled.emit(false);
      this.showExactMatchWarning = false;
      await setTimeout(() => {
        this.setLabel();
      }, 100);
      await setTimeout(() => {
        this.labelList.forEach((element) => {
          if (element.id === res['id']) {
            element.selected = true;
            this.addToSelectedLabel(element);
          }
          labelListSelected.forEach((label) => {
            if (element.id === label.id) {
              element.selected = true;
              setTimeout(() => {
                this.addToSelectedLabel(element);
              }, 100);
            }
          });
        });
      }, 300);
      this.searchLabelText = '';
    });
  }
  private createForm() {
    this.businessForm = this.formBuilder.group({
      name: [this.searchLabelText, Validators.required],
    });
  }

  async setLabelSave(unitIds: any): Promise<void> {
    const labelIds = this.selectedLabelArray;
    if (this.isImport) {
      const selectedLabels = this.labelList.filter((label) => this.selectedLabelArray.includes(label.id));

      this.setSelectedLabelArray.emit(selectedLabels);
      return;
    }

    if (this.removedLabelArray.length) {
      this.http
        .callService(new Method(environment.services.labelDrop(), { labelIds: this.removedLabelArray, unitIds }, 'put'))
        .subscribe(() => {
          if (labelIds.length) {
            this.http
              .callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'))
              .subscribe(() => {
                this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                  duration: 5000,
                  panelClass: ['success-snackBar'],
                });
                // this.labelManagmentShow = false;
                // this.labelBaseComponent.getAssessmentaccordingToLabel();
              });
          } else {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            // this.labelManagmentShow = false;
            // this.labelBaseComponent.getAssessmentaccordingToLabel();
          }
        });
    } else {
      if (labelIds.length) {
        this.http
          .callService(new Method(environment.services.labelAttach(), { labelIds, unitIds }, 'put'))
          .subscribe(() => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            // this.labelManagmentShow = false;
            // this.labelBaseComponent.getAssessmentaccordingToLabel();
          });
      }
    }
    this.selectedLabelArray = [];
    this.removedLabelArray = [];
  }
}
