import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
declare var $: any;
@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.scss'],
  standalone: false,
})
export class CompareComponent implements OnInit, OnDestroy {
  seletedMajorPart = 'close';
  storyblok;
  actualLifetimeStoryblok;
  data;
  constructor(
    private commonService: CommonService,
    private router: Router,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {
    $('#main-content').addClass('darkBG');
    $('#header').hide();
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'compare');
      this.storyblok = story[0].content;
      const actualLifetimeStoryblok = data.filter((item) => item.slug === 'actual-lifetime');
      this.actualLifetimeStoryblok = actualLifetimeStoryblok[0].content;
    });
    const compareData = this.localStorageService.getCompressedItem(this.localStorageService.COMPARE_DATA_KEY);
    if (compareData) {
      this.data = compareData;
    } else {
      this.router.navigate(['cti/pro']);
    }
  }
  goToReport() {
    window.open('/cti/compare-report');
  }
  ngOnDestroy() {
    $('#main-content').removeClass('darkBG');
    $('#header').show();
  }
}
