import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import { Sort } from '@angular/material/sort';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-compare-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss'],
  standalone: false,
})
export class CompareValueComponent implements OnInit, AfterViewInit {
  @Input() public data: string;
  @Input() public storyblok: any;
  environment = environment;
  CLdata;
  totalRevenues;
  CTIRevenues;
  selectAssetList = JSON.parse(localStorage.getItem('selectAssetList'));
  seletedProductivityFilter;
  isCompantLevelSelected = false;
  seletedRevenueFilter;
  sortedData;
  res;

  constructor(private http: ApiRequestService) {}

  ngOnInit(): void {
    this.res = this.data;
    const datePipe = new DatePipe('en-US');
    this.res.forEach((assess) => {
      try {
        assess.startDateText = datePipe.transform(assess.startDate, 'MM/yyyy');
        assess.endDateText = datePipe.transform(assess.endDate, 'MM/yyyy');
      } catch (err) {
        console.log(
          'err on date transform for ass ' + assess.assessmentName + ' ' + assess.startDate + ' ' + assess.endDate
        );
      }
    });
    if (!this.CLdata && this.selectAssetList) {
      this.revenueCompanyLevel();
    }
  }

  revenueCompanyLevel() {
    this.http
      .callService(new Method(environment.services.revenueCompanyLevel(), this.selectAssetList, 'put'))
      .subscribe((res) => {
        this.CLdata = res;
        const largestImprovedMaterials = Math.max.apply(
          Math,
          this.CLdata.map(function (o: any) {
            return o.totalCtiRevenue;
          })
        );
        this.CLdata.forEach((item) => {
          item.percentage = (item.totalCtiRevenue / largestImprovedMaterials) * 100;
        });
        this.totalRevenues = Number(this.CLdata.reduce((n, { totalRevenue }) => n + totalRevenue, 0));
        this.CTIRevenues = Number(this.CLdata.reduce((n, { totalCtiRevenue }) => n + totalCtiRevenue, 0));
      });
  }
  sortData(sort: Sort) {
    const data = this.res;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'namesort':
          return this.compare(a.namesort, b.namesort, isAsc);
        case 'startDate':
          return this.compare(a.startDate, b.startDate, isAsc);
        case 'revenue':
          return this.compare(a.revenue, b.revenue, isAsc);
        case 'totalRecoveryMass':
          return this.compare(a.totalRecoveryMass, b.totalRecoveryMass, isAsc);
        case 'productivity':
          return this.compare(a.productivity, b.productivity, isAsc);
        case 'circularity':
          return this.compare(a.circularity, b.circularity, isAsc);
        case 'ctiRevenue':
          return this.compare(a.ctiRevenue, b.ctiRevenue, isAsc);
        default:
          return 0;
      }
    });
  }
  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  ngAfterViewInit() {
    this.sortData({ active: 'namesort', direction: 'asc' });
  }
}
