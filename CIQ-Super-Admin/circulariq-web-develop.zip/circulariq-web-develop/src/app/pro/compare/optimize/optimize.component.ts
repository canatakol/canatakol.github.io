import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import { Sort } from '@angular/material/sort';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-compare-optimize',
  templateUrl: './optimize.component.html',
  styleUrls: ['./optimize.component.scss'],
  standalone: false,
})
export class CompareOptimizeComponent implements OnInit, AfterViewInit {
  @Input() public data: string;
  @Input() public storyblok: any;
  @Input() public actualLifetimeStoryblok: any;
  environment = environment;
  sortedData;
  seletedCirticalMaterialFilter;
  seletedRecoveryFilter;
  seletedOnsiteFilter;
  res;
  constructor() {}

  ngOnInit(): void {
    this.res = this.data;
    const datePipe = new DatePipe('en-US');
    this.res.forEach((assess) => {
      try {
        assess.startDateText = datePipe.transform(assess.startDate, 'MM/yyyy');
        assess.endDateText = datePipe.transform(assess.endDate, 'MM/yyyy');
      } catch (err) {
        // Error on date transform
      }
    });
  }

  sortData(sort: Sort) {
    const data = this.res;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'namesort':
          return this.compare(a.namesort, b.namesort, isAsc);
        case 'startDate':
          return this.compare(a.startDate, b.startDate, isAsc);
        case 'inflowMass':
          return this.compare(a.inflowMass, b.inflowMass, isAsc);
        case 'outflowMass':
          return this.compare(a.outflowMass, b.outflowMass, isAsc);
        case 'totalCriticalMass':
          return this.compare(a.totalCriticalMass, b.totalCriticalMass, isAsc);
        case 'criticalPercentage':
          return this.compare(a.criticalPercentage, b.criticalPercentage, isAsc);
        case 'totalOnsiteWater':
          return this.compare(a.totalOnsiteWater, b.totalOnsiteWater, isAsc);
        case 'onsiteWaterCircularity':
          return this.compare(a.onsiteWaterCircularity, b.onsiteWaterCircularity, isAsc);
        case 'technicalPercentage':
          return this.compare(a.technicalPercentage, b.technicalPercentage, isAsc);
        case 'nonFoodPercentage':
          return this.compare(a.nonFoodPercentage, b.nonFoodPercentage, isAsc);
        case 'foodPercentage':
          return this.compare(a.foodPercentage, b.foodPercentage, isAsc);
        case 'renewableEnergy':
          return this.compare(a.foodPercentage, b.foodPercentage, isAsc);
        case 'unknownPercentage':
          return this.compare(a.unknownPercentage, b.unknownPercentage, isAsc);
        case 'highValue':
          return this.compare(a.lifetimeExtensionResponse.highValue, b.lifetimeExtensionResponse.highValue, isAsc);
        case 'lowValue':
          return this.compare(a.lifetimeExtensionResponse.lowValue, b.lifetimeExtensionResponse.lowValue, isAsc);
        case 'notRecovered':
          return this.compare(
            a.lifetimeExtensionResponse.notRecovered,
            b.lifetimeExtensionResponse.notRecovered,
            isAsc
          );
        default:
          return 0;
      }
    });
  }
  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  ngAfterViewInit() {
    this.sortData({ active: 'namesort', direction: 'asc' });
  }
}
