import { Component, Input, OnInit, AfterViewInit } from '@angular/core';
import { environment } from '@env/environment';
import { Sort } from '@angular/material/sort';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { DatePipe } from '@angular/common';

declare var $: any;
@Component({
  selector: 'app-compare-close',
  templateUrl: './close.component.html',
  styleUrls: ['./close.component.scss'],
  standalone: false,
})
export class CompareCloseComponent implements OnInit, AfterViewInit {
  @Input() public data: string;
  @Input() public storyblok: any;
  environment = environment;
  sortedData;
  organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
  goalsWiev = true;
  materialTop = true;
  inflofTop = true;
  outflowlTop = true;
  seletedMaterialFilter;
  seletedInflowFilter;
  seletedOutflowFilter;
  seletedEnergyFilter;
  seletedWaterFilter;
  res;
  constructor(
    private http: ApiRequestService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private commonService: CommonService
  ) {
    this.sortedData = this.data;
  }
  ngOnInit(): void {
    this.res = this.data;
    const datePipe = new DatePipe('en-US');
    this.res.forEach((assess) => {
      try {
        assess.startDateText = datePipe.transform(assess.startDate, 'MM/yyyy');
        assess.endDateText = datePipe.transform(assess.endDate, 'MM/yyyy');
      } catch (err) {
        console.log(
          'err on date transform for ass ' + assess.assessmentName + ' ' + assess.startDate + ' ' + assess.endDate
        );
      }
    });
    $(document).ready(function () {
      $('.missingBox').hover(
        function () {
          $('#content').addClass('hover');
        },
        function () {
          $('#content').removeClass('hover');
        }
      );
    });
  }
  sortData(sort: Sort) {
    const data = this.res;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'namesort':
          return this.compare(a.namesort, b.namesort, isAsc);
        case 'startDate':
          return this.compare(a.startDate, b.startDate, isAsc);
        case 'inflowMass':
          return this.compare(a.inflowMass, b.inflowMass, isAsc);
        case 'inflowCircularity':
          return this.compare(a.inflowCircularity, b.inflowCircularity, isAsc);
        case 'inflowLinearity':
          return this.compare(a.inflowLinearity, b.inflowLinearity, isAsc);
        case 'outflowCircularity':
          return this.compare(a.outflowCircularity, b.outflowCircularity, isAsc);
        case 'outflowLinearity':
          return this.compare(a.outflowLinearity, b.outflowLinearity, isAsc);
        case 'totalEnergy':
          return this.compare(a.totalEnergy, b.totalEnergy, isAsc);
        case 'renewableEnergy':
          return this.compare(a.renewableEnergy, b.renewableEnergy, isAsc);
        case 'nonRenewableEnergy':
          return this.compare(a.nonRenewableEnergy, b.nonRenewableEnergy, isAsc);
        case 'totalWater':
          return this.compare(a.totalWater, b.totalWater, isAsc);
        case 'waterCircularity':
          return this.compare(a.waterCircularity, b.waterCircularity, isAsc);
        case 'circularity':
          return this.compare(a.circularity, b.circularity, isAsc);
        default:
          return 0;
      }
    });
  }
  compare(a: number | string, b: number | string, isAsc: boolean) {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }
  ngAfterViewInit() {
    this.sortData({ active: 'namesort', direction: 'asc' });
  }
  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }
}
