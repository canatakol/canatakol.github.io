import { Component, EventEmitter, Input, Output } from '@angular/core';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatTreeFlatDataSource, MatTreeFlattener } from '@angular/material/tree';
import { of as observableOf } from 'rxjs';
import { FlatTreeControl } from '@angular/cdk/tree';
import { AddLabelDialog } from '@app/shared/dialog/add-label/add-label.component';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UpdateNameDialog } from '@app/shared/dialog/update-name/update-name-dialog.component';
declare var $: any;
@Component({
  selector: 'app-label-base',
  templateUrl: './label-base.component.html',
  styleUrls: ['./label-base.component.scss'],
  standalone: false,
})
export class LabelBaseComponent {
  @Output() setRelatedLabelData: EventEmitter<any> = new EventEmitter();
  @Output() addLabelEvent: EventEmitter<any> = new EventEmitter();
  @Output() navigationMode: EventEmitter<any> = new EventEmitter();
  @Input() public storyblok: any;
  environment = environment;
  labelData;
  labelIds = [];
  findChildrenByIdList = [];
  foundItemsToDeselect = [];
  navigationModeSelectedLabel;
  selectedNodes;
  noLabelSelect = false;
  /** The TreeControl controls the expand/collapse state of tree nodes.  */
  treeControl: FlatTreeControl<any>;

  /** The TreeFlattener is used to generate the flat list of items from hierarchical data. */
  treeFlattener: MatTreeFlattener<any, any>;

  /** The MatTreeFlatDataSource connects the control and flattener to provide data. */
  dataSource: MatTreeFlatDataSource<any, any>;

  constructor(
    private http: ApiRequestService,
    private dialog: MatDialog,
    private commonService: CommonService,
    private snackBar: MatSnackBar
  ) {
    this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
    this.treeControl = new FlatTreeControl<any>(this.getLevel, this.isExpandable);
    this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);
    this.getLabel();
    this.commonService.addLabel.subscribe((res) => {
      this.addLabel(res);
    });
  }

  getLabel() {
    this.http.callService(new Method(environment.services.label(), '', 'get')).subscribe((res) => {
      this.labelData = res;
      this.dataSource.data = this.labelData;
    });
  }

  getAssessmentaccordingToLabel() {
    this.setRelatedLabelData.emit(null);
    if (this.labelIds.length === 0 && !this.noLabelSelect) {
      this.setRelatedLabelData.emit(undefined);
      return;
    }
    const data = {
      labelIds: this.labelIds,
    };
    this.http
      .callService(new Method(environment.services.getAssessmentaccordingToLabel(), data, 'put'))
      .subscribe((res) => {
        this.setRelatedLabelData.emit(res);
      });
  }
  articleSelect() {
    alert('arhcive cooing soon');
  }

  navigationModeEvent(id: string) {
    this.navigationModeSelectedLabel = id;
    this.navigationMode.emit(true);
    const data = {
      labelIds: [id],
    };
    this.http
      .callService(new Method(environment.services.getAssessmentaccordingToLabel(), data, 'put'))
      .subscribe((res) => {
        this.setRelatedLabelData.emit(res);
      });
    this.treeControl.dataNodes.forEach((item) => {
      item.selected = false;
    });
  }

  setNoLabelSelect() {
    this.navigationMode.emit(false);
    this.navigationModeSelectedLabel = null;
    this.noLabelSelect = true;
    for (let index = 0; index < this.treeControl.dataNodes.length; index++) {
      this.treeControl.dataNodes[index].selected = false;
    }
    this.labelIds = [];
    this.getAssessmentaccordingToLabel();
  }

  selectLabel(id: string, isSelect: boolean) {
    this.navigationMode.emit(false);
    this.navigationModeSelectedLabel = null;
    this.labelIds = [];
    this.noLabelSelect = false;
    this.treeControl.dataNodes.forEach((item) => {
      if (item.id === id && isSelect) {
        item.selected = true;
      }
      if (item.id === id && !isSelect) {
        item.selected = false;
      }
      if (item.selected) {
        this.labelIds.push(item.id);
      }
    });
    this.getAssessmentaccordingToLabel();
  }

  findLabelFromTree(tree: any, id: string) {
    for (let index = 0; index < tree.length; index++) {
      const treeItem = tree[index];
      if (id === treeItem.id) {
        return treeItem;
      } else if (treeItem.children) {
        return this.findLabelFromTree(treeItem.children, id);
      } else {
        return null;
      }
    }
  }
  findItemAllChildren(item: any) {
    if (item?.children) {
      for (let index = 0; index < item.children.length; index++) {
        const child = item.children[index];
        if (child.children) {
          const getAgain = this.findItemAllChildren(child);
          this.foundItemsToDeselect.push(child.id);
        } else {
          this.foundItemsToDeselect.push(child.id);
        }
      }
    }
  }
  setNotSelectedChildren(items: any) {
    items.forEach((item) => {
      this.foundItemsToDeselect.forEach((selectedItem) => {
        if (item.id === selectedItem) {
          item.selected = false;
        }
      });
    });
  }

  addLabel(text: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(AddLabelDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: { storyblok: this.storyblok, labelData: this.labelData, text: text },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.getLabel();
        this.addLabelEvent.emit(true);
      } catch (error) {}
    });
  }

  settingsLabel(node: any, isOpen: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    if (isOpen) {
      node['isSettingsVisible'] = false;
    } else {
      this.treeControl.dataNodes.forEach((item) => {
        item['isSettingsVisible'] = false;
      });
      node['isSettingsVisible'] = true;
    }
  }

  updateLabel(node: any) {
    const dialogRef = this.dialog.open(UpdateNameDialog, {
      width: '80%',
      maxWidth: '500px',
      panelClass: 'centered-dialog',
      data: {
        title: `${node['name']}`,
        message: this.storyblok.updat_label_name_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.labelaction(node['id']), { name: result }, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getLabel();
          });
      } catch (error) {}
    });
  }

  deleteLabel(node: any) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${node['name']}`,
        message: this.storyblok.delete_label_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.labelaction(node['id']), '', 'delete'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getLabel();
          });
      } catch (error) {}
    });
  }

  /** Transform the data to something the tree can read. */
  transformer(node: any, level: number) {
    return {
      name: node.name,
      id: node.id,
      parentId: node.parentId,
      selected: node.selected,
      level: level,
      expandable: !!node.children,
    };
  }

  /** Get the level of the node */
  getLevel(node: any) {
    return node.level;
  }

  /** Return whether the node is expanded or not. */
  isExpandable(node: any) {
    return node.expandable;
  }

  /** Get the children for the node. */
  getChildren(node: any) {
    return observableOf(node.children);
  }

  /** Get whether the node has children or not. */
  hasChild(index: number, node: any) {
    return node.expandable;
  }
  /** Whether the node is expanded */
}
