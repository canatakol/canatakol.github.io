import { Component, OnInit, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { environment } from '@env/environment';

@Component({
  selector: 'app-missing-data',
  templateUrl: './missing-data.component.html',
  styleUrls: ['./missing-data.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class MissingDataComponent implements OnInit {
  @Input() public data: string;
  environment = environment;
  storyblok;
  constructor(private storyblokService: StoryblokService) {}

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'aggregate');
      this.storyblok = story.length > 0 ? story[0].content : {};
    });
  }
}
