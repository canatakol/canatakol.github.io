import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '@env/environment';
import { MissingDataComponent } from '../missing-data/missing-data.component';
import { CriticalInflowComponent } from '@app/shared-components/critical-inflow/critical-inflow.component';
import { RecoveryBreakdownComponent } from '@app/shared-components/recovery-breakdown/recovery-breakdown.component';
import { RecoveryBreakdownBarComponent } from '@app/shared-components/recovery-breakdown-bar/recovery-breakdown-bar.component';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';

@Component({
  selector: 'app-aggregate-optimize',
  templateUrl: './optimize.component.html',
  styleUrls: ['./optimize.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    MissingDataComponent,
    CriticalInflowComponent,
    RecoveryBreakdownComponent,
    RecoveryBreakdownBarComponent,
    CiqNumberPipe,
    CommentBadgeComponent,
  ],
})
export class AggregateOptimizeComponent implements OnInit {
  @Input() public data: string;
  @Input() public storyblok: any;
  @Input() public dashboardStoryblok: any;
  @Input() public recoveryTypeBarVersionShow: boolean;
  environment = environment;
  onSiteWaterAssessments = [];
  criticalDataAssessments = [];
  constructor() {}

  ngOnInit(): void {
    this.data['assessments'].forEach((element) => {
      const onSiteWater = {
        indicatorSelected: element.onSiteWater.indicatorSelected,
        value: element.onSiteWater.onSiteWaterCircularity,
        unit: 'x',
        name: element.name,
        businessLevelName: element.businessLevelName,
        businessLevel: element.businessLevel,
      };
      this.onSiteWaterAssessments.push(onSiteWater);
      const criticalData = {
        indicatorSelected: element.criticalData.indicatorSelected,
        value: element.criticalData.criticalPercentage,
        unit: '%',
        name: element.name,
        businessLevelName: element.businessLevelName,
        businessLevel: element.businessLevel,
      };
      this.criticalDataAssessments.push(criticalData);
    });
  }
}
