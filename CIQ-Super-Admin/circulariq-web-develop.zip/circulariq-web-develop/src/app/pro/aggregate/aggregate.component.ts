import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonModule } from '@angular/common';
import { AggregateCloseComponent } from './close/close.component';
import { AggregateOptimizeComponent } from './optimize/optimize.component';
import { AggregateValueComponent } from './value/value.component';
import { LocalStorageService } from '@app/core/services/local-storage.service';
declare var $: any;

@Component({
  selector: 'app-aggregate',
  templateUrl: './aggregate.component.html',
  styleUrls: ['./aggregate.component.scss'],
  standalone: true,
  imports: [CommonModule, AggregateCloseComponent, AggregateOptimizeComponent, AggregateValueComponent],
})
export class AggregateComponent implements OnInit, OnDestroy {
  seletedMajorPart = 'close';
  data = {};
  storyblok;
  recoveryTypeBarVersionShow = false;
  isDashboard = true;
  dashboardId: string = '';
  dashboardStoryblok;
  constructor(
    private router: Router,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {
    if (!window.location.href.includes('cti/dashboard')) {
      this.isDashboard = false;
      $('#main-content').addClass('darkBG');
      $('#header').hide();
      this.dashboardId = '';
    } else {
      this.dashboardId = this.router.url.split('/')[3] || '';
    }
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'aggregate');
      this.storyblok = story.length > 0 ? story[0].content : {};
      const dashboardStoryblok = data.filter((item) => item.slug === 'step4-dashboard');
      this.dashboardStoryblok = dashboardStoryblok.length > 0 ? dashboardStoryblok[0].content : {};
    });

    // Load data from localStorage regardless of URL
    const aggregateData = this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY);
    if (aggregateData) {
      this.data = aggregateData;
      this.recoveryTypeBarVersionShow = this.data['aggregate'].recoveryType.breakdown.some(
        (element) => element.percentage === 100
      );
    } else {
      // Only redirect if we're not already on a dashboard page
      if (!this.isDashboard) {
        this.router.navigate(['cti/pro']);
      }
    }
  }
  goToReport() {
    window.open('/cti/aggregate-report');
  }
  ngOnDestroy() {
    $('#main-content').removeClass('darkBG');
    $('#header').show();
  }
}
