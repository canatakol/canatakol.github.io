import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { environment } from '@env/environment';
import { MissingDataComponent } from '../missing-data/missing-data.component';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';

@Component({
  selector: 'app-aggregate-value',
  templateUrl: './value.component.html',
  styleUrls: ['./value.component.scss'],
  standalone: true,
  imports: [CommonModule, MissingDataComponent, CiqNumberPipe, CommentBadgeComponent],
})
export class AggregateValueComponent implements OnInit {
  @Input() public data: string;
  @Input() public storyblok: any;
  environment = environment;
  productivityAssessments = [];
  ctiRevenueAssessments = [];
  constructor() {}

  ngOnInit(): void {
    this.data['assessments'].forEach((element) => {
      const productivity = {
        indicatorSelected: element.productivity.indicatorSelected,
        value: element.productivity.productivity,
        unit: `${element.productivity.currency}`,
        name: element.name,
        businessLevelName: element.businessLevelName,
        businessLevel: element.businessLevel,
        type: 'productivity',
      };
      this.productivityAssessments.push(productivity);
      const ctiRevenue = {
        indicatorSelected: element.ctiRevenue.indicatorSelected,
        value: element.ctiRevenue.ctirevenue,
        unit: element.ctiRevenue.currency,
        name: element.name,
        businessLevelName: element.businessLevelName,
        businessLevel: element.businessLevel,
      };
      this.ctiRevenueAssessments.push(ctiRevenue);
    });
  }
}
