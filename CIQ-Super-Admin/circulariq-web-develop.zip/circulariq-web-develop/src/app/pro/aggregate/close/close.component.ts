import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { environment } from '@env/environment';
import { Subscription } from 'rxjs';
import { SankeyInfoComponent } from '@app/shared-components/sankey-info/sankey-info.component';
import { MissingDataComponent } from '../missing-data/missing-data.component';
import { PackagingComponent } from '@app/shared-components/packaging/packaging.component';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';
import { CommentBadgeComponent } from '@app/shared-components/comment-badge/comment-badge.component';
import { MostLinearInflowComponent } from '@app/shared-components/most-linear-inflow/most-linear-inflow.component';
import { DashboardFlowsComponent } from '@app/shared-components/dashboard-flows/dashboard-flows.component';
import { FlowAnalysisSankeyComponent } from '@app/shared-components/flow-analysis-sankey/flow-analysis-sankey.component';
import { DashboardFlowsGroupComponent } from '@app/shared-components/dashboard-flows-group/dashboard-flows-group.component';
import { DashboardScenarioSyncService } from '@app/shared-components/dashboard-flows/dashboard-scenario-sync.service';

@Component({
  selector: 'app-aggregate-close',
  templateUrl: './close.component.html',
  styleUrls: ['./close.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatSlideToggleModule,
    SankeyInfoComponent,
    MissingDataComponent,
    PackagingComponent,
    MostLinearInflowComponent,
    CiqNumberPipe,
    TruncatePipe,
    CommentBadgeComponent,
    DashboardFlowsComponent,
    DashboardFlowsGroupComponent,
    FlowAnalysisSankeyComponent,
  ],
})
export class AggregateCloseComponent implements OnInit, OnDestroy {
  @Input() public data: string;
  @Input() public storyblok: any;
  @Input() public dashboardId: any;
  energyAssessments = [];
  waterAssessments = [];
  environment = environment;
  selectedFilter = 'material-category';
  private filterSyncSubscription: Subscription | null = null;

  constructor(private scenarioSyncService: DashboardScenarioSyncService) {}

  ngOnInit() {
    this.filterSyncSubscription = this.scenarioSyncService.filterSelection$.subscribe((filterId) => {
      this.selectedFilter = filterId;
    });
    console.log('close dashboardId', this.dashboardId);
    this.data['assessments'].forEach((element) => {
      const energy = {
        indicatorSelected: element.energy.indicatorSelected,
        value: element.energy.renewablePercentage,
        unit: '%',
        name: element.name,
        businessLevel: element.businessLevel,
        businessLevelName: element.businessLevelName,
        top: true,
      };
      this.energyAssessments.push(energy);
      const water = {
        indicatorSelected: element.water.indicatorSelected,
        value: element.water.waterCircularity,
        unit: '%',
        name: element.name,
        businessLevel: element.businessLevel,
        businessLevelName: element.businessLevelName,
        top: true,
      };
      this.waterAssessments.push(water);
    });
  }

  ngOnDestroy(): void {
    this.filterSyncSubscription?.unsubscribe();
  }
}
