import { Component, Input, OnInit } from '@angular/core';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss'],
  standalone: false,
})
export class AddProductComponent implements OnInit {
  @Input() public data: any;
  storyblok;
  pondOptions;
  unitId;
  supplierList;
  productForm: FormGroup;
  constructor(
    private storyblokService: StoryblokService,
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private commonService: CommonService
  ) {
    this.pondOptions = {
      class: 'my-filepond',
      multiple: false,
      labelIdle: 'UPLOAD IMAGE',

      acceptedFileTypes:
        'image/apng , image/jpeg , image/png , image/svg+xml , image/webp , image/gif , image/bmp , image/tiff , image/x-icon',
      server: {
        url: environment.serverUrl,
        process: async (fieldName, file, metadata, load, error, progress, abort) => {
          const formData = new FormData();
          const self = this;
          formData.append('file', file, file.name);
          const request = new XMLHttpRequest();
          request.open('POST', environment.serverUrl + environment.services.upload());
          request.upload.onprogress = (e) => {
            progress(e.lengthComputable, e.loaded, e.total);
          };
          request.onload = function () {
            if (request.status >= 200 && request.status < 300) {
              load(request.responseText);
              const name = JSON.parse(request.response).fileName;
              const data = {
                fileName: name,
              };
              const token = JSON.parse(sessionStorage.getItem('credentials')).authToken;
              fetch(environment.serverUrl + environment.services.importUnitProduct(self.unitId), {
                headers: {
                  'x-auth-token': token,
                  'Content-Type': 'application/json',
                },
                method: 'POST',
                body: JSON.stringify(data),
              })
                .then((res) => res.json())
                .then((res) => {
                  if (res['message']) {
                    alert(res['message']);
                  }
                });
              sessionStorage.setItem('uploadFile', request.response);
            } else {
              alert('something went wrong');
            }
          };
          request.send(formData);
          return {
            abort: () => {
              request.abort();
              abort();
            },
          };
        },
        revert: (uniqueFileId, load, error) => {
          error(error);
          load();
        },
        load: (uniqueFileId, load, error) => {
          fetch(uniqueFileId)
            .then((res) => res.blob())
            .then((res) => {
              load(new File([res], '', { type: 'image' }));
            })
            .catch(error);
        },
      },
    };
  }

  getSupplierNames() {
    this.http.callService(new Method(environment.services.supplierNames(), '', 'get')).subscribe((res) => {
      this.supplierList = res;
    });
  }

  addProduct() {
    this.productForm.value.supplierName === 'new'
      ? (this.productForm.value.supplierName = this.productForm.value.supplierOtherName)
      : (this.productForm.value.supplierName = this.productForm.value.supplierName);
    delete this.productForm.value.supplierOtherName;
    this.http
      .callService(new Method(environment.services.productLineDetails(this.data.unitId), this.productForm.value, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }

  ngOnInit(): void {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'pro-dashboard');
      this.storyblok = story[0].content;
    });
    this.createForm();
    this.getSupplierNames();
  }

  private createForm() {
    this.productForm = this.formBuilder.group({
      amount: [this.data?.productLineData?.amount ? this.data.productLineData.amount : ''],
      productId: [this.data?.productLineData?.productId ? this.data.productLineData.productId : ''],
      supplierName: [this.data?.productLineData?.supplierName ? this.data.productLineData.supplierName : ''],
      supplierOtherName: [''],
    });
  }
}
