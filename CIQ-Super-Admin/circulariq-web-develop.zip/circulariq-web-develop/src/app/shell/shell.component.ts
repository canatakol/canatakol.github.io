import { Component, OnInit, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from '@env/environment';
declare var $: any;
@Component({
  selector: 'app-shell',
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss'],
  standalone: false,
})
export class ShellComponent implements OnInit {
  project: string = environment.project;
  showHeader: boolean = true;
  longerMaxWidth: boolean = false;
  constructor(private router: Router) {
    this.checkScreenWidth();
  }
  @HostListener('window:resize', [])
  onResize() {
    this.checkScreenWidth();
  }

  private checkScreenWidth() {
    this.longerMaxWidth = window.innerWidth > 1920;
  }
  ngOnInit(): void {
    this.showHeader =
      !this.router.url.startsWith('/e5') &&
      !this.router.url.startsWith('/cti/user') &&
      !this.router.url.startsWith('/cti/organisation');
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.showHeader =
          !this.router.url.startsWith('/e5') &&
          !this.router.url.startsWith('/cti/user') &&
          !this.router.url.startsWith('/cti/organisation');
      }
    });
  }
}
