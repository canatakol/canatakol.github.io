import { AfterContentChecked, AfterViewChecked, Component } from '@angular/core';
import { ActivatedRoute, Router, NavigationEnd } from '@angular/router';
import { AuthenticationService } from '@app/core';
import { CommonService } from '@app/core/common.service';
import { DashboardPreferenceService } from '@app/core/dashboard-preference.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { filter } from 'rxjs/operators';
@Component({
  selector: 'app-cti-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.scss'],
  standalone: false,
})
export class CtiLeftNavComponent implements AfterContentChecked {
  user;
  freeOrganization;
  isPro = false;
  project = environment.project;
  isProduction = environment.production;
  pathname = location.pathname;
  unitId = this.pathname.split('/')[2];
  storyblok;
  userRole = this.commonService.userRole;
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authenticationService: AuthenticationService,
    private commonService: CommonService,
    private storyblokService: StoryblokService,
    private dashboardPreferenceService: DashboardPreferenceService,
    private http: ApiRequestService
  ) {
    this.user = JSON.parse(sessionStorage.getItem('credentials'));
    this.freeOrganization = this.user?.organisation?.licenseType === 'Free' || false;
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (credentials && credentials['organisation'] && credentials['organisation'].features) {
      credentials['organisation'].features.forEach((element) => {
        if (element === 'unlimited_unit') {
          this.isPro = true;
        }
      });
    }
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'left-sidebar');
      this.storyblok = story[0].content;
    });

    // Router events'leri dinle pathname'i güncellemek için
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((event: NavigationEnd) => {
      this.pathname = event.url;
    });
  }

  ngAfterContentChecked(): void {
    // this.pathname = location.pathname;
  }

  // Active state kontrolü için method
  isAssessmentsActive(): boolean {
    return (
      this.pathname.includes('/assessment') ||
      this.pathname.includes('/cti/pro-business') ||
      this.pathname.includes('/cti/pro-label')
    );
  }

  // Dashboard active state kontrolü için method
  isDashboardActive(): boolean {
    if (this.project === 'CTI' && this.isPro) {
      return this.pathname.includes('/cti/dashboard');
    }
  }

  logout() {
    this.authenticationService.logout().subscribe(async (res) => {
      this.http.callService(new Method(environment.services.login(), '', 'delete'));
      this.router.navigate(['/login'], { replaceUrl: true });
    });
    this.commonService.clearHistory();
  }
  goToDashboard() {
    if (this.project === 'CIQ') {
      this.router.navigate(['/e5']);
    } else {
      if (this.isPro) {
        this.dashboardPreferenceService.getShowBLDashboard().subscribe((showBLDashboard: boolean | null) => {
          if (showBLDashboard === true) {
            this.router.navigate(['/cti/pro-business']);
          } else {
            this.router.navigate(['/cti/pro-label']);
          }
        });
      } else {
        this.router.navigate([`/cti/${this.unitId}/assessment/step1`]);
      }
    }
  }
}
