import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { environment } from '@env/environment';
import { VERSION } from '../../../environments/version';

import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { interval, Subscription } from 'rxjs';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { CommentService } from '@app/core/services/comment.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  standalone: false,
})
export class HeaderComponent implements OnInit, OnDestroy {
  version = VERSION;
  project;
  storyblok;
  mainValue = '';

  displayGuidance = false;
  showCommentCenterDropdown = false;
  unreadMessageCount = 0;
  private unreadCountSubscription: Subscription;

  constructor(
    private router: Router,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    private dialog: MatDialog,
    private storyblokService: StoryblokService,
    private commentService: CommentService
  ) {
    this.project = environment.project;
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    this.mainValue = this.commonService.organizationName
      ? this.commonService.organizationName
      : credentials?.['organisation']?.['name'] || '';
  }
  isOrganizationNameShow(): boolean {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    if (!credentials || !credentials.organisation) {
      return false;
    }
    const freeOrganization = credentials.organisation.licenseType === 'Free';
    return this.project === 'CTI' && !freeOrganization;
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'header');
      this.storyblok = story[0].content;
    });

    this.unreadCountSubscription = interval(30000).subscribe(() => {
      this.commentService.refreshHeaderUnreadCount();
    });

    this.fetchUnreadMessageCount();
  }

  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }

    // Get current organization goal
    this.http
      .callService(new Method(environment.services.setOrganisationGoal(), '', 'get'))
      .subscribe((organizationGoal) => {
        const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
          width: '80%',
          maxWidth: '1200px',
          panelClass: 'centered-dialog',
          data: organizationGoal,
        });

        dialogRef.afterClosed().subscribe(async (result) => {
          if (!result) {
            return;
          }
          try {
            this.http
              .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
              .subscribe(async (res) => {
                this.snackBar.open(
                  this.commonService.storyblok?.success_message || 'Organization goals updated successfully',
                  '',
                  {
                    duration: 5000,
                    panelClass: ['success-snackBar'],
                  }
                );
              });
          } catch (error) {
            // Error handling for organization goal update
          }
        });
      });
  }

  openGuidanceEvent() {
    this.commonService.mainGuidanceData.next({ show: true, active: 'assessment' });
  }

  showCommentCenter() {
    this.showCommentCenterDropdown = !this.showCommentCenterDropdown;

    // Refresh unread count when opening comment center
    if (this.showCommentCenterDropdown) {
      this.commentService.refreshHeaderUnreadCount();
    }
  }

  getUnreadMessageCount(): number {
    return this.unreadMessageCount;
  }

  private fetchUnreadMessageCount(): void {
    this.commentService.getHeaderUnreadCount().subscribe({
      next: (unreadCount: number) => {
        this.unreadMessageCount = unreadCount;
      },
      error: (error) => {
        this.unreadMessageCount = 0;
      },
    });
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as HTMLElement;
    if (!target.closest('.comment-center-container')) {
      this.showCommentCenterDropdown = false;
    }
  }

  ngOnDestroy() {
    if (this.unreadCountSubscription) {
      this.unreadCountSubscription.unsubscribe();
    }
  }
}
