import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';

import { ShellComponent } from './shell.component';
import { HeaderComponent } from './header/header.component';
import { CtiLeftNavComponent } from './cti-left-nav/left-nav.component';
import { HeaderCommentCenterComponent } from '@app/shared-components/header-comment-center/header-comment-center.component';

@NgModule({
  imports: [CommonModule, NgbModule, RouterModule, CiqNumberPipe, HeaderCommentCenterComponent],
  declarations: [HeaderComponent, ShellComponent, CtiLeftNavComponent],
})
export class ShellModule {}
