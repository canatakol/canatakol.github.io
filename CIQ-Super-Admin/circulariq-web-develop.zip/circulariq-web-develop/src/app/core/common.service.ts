import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { StoryblokService } from './storyblok/storyblok.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AggregateDataService } from './services/aggregate-data.service';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  public isLogin = new BehaviorSubject<any>('');
  public breadcrumbOne = new BehaviorSubject<any>('');
  public breadcrumbTwo = new BehaviorSubject<any>('');
  public seletedChemical = new BehaviorSubject<any>('');
  public productId = new BehaviorSubject<any>('');
  public step5ActiveCase = new BehaviorSubject<any>('inflow-question');
  public step6ActiveCase = new BehaviorSubject<any>('inflow6');
  public step7ActiveCase = new BehaviorSubject<any>('smartTarget');
  public mainGuidanceData = new BehaviorSubject<any>({});
  public isLoggingIn = new BehaviorSubject<any>(false);
  public materialType;
  public isLoadingLabelSmall = new BehaviorSubject<any>(false);
  public storyblok;
  public stepsData = new Subject<any>();
  public businessLevelLength = new Subject<any>();
  public addmaterialType;
  public criticalPercentage;
  public selectedProduct;
  public onboardingAlwaysOn;
  public lensData;
  public organizationName;
  public businessLevelsToInviteList = [];
  public isGHGShow = false;
  public isPro = false;
  public addLabel = new Subject<any>();
  public getbusinessLevelList = new Subject<any>();
  public selectedUnit: any = null;
  public refreshStep = new Subject<any>();
  public isShowstep5Intro = new Subject<any>();
  public isShowstep6Intro = new Subject<any>();
  public isShowstep7Intro = new Subject<any>();
  public selectedUnitID = '';
  public lastCreateMaterial = {};
  public selectedCircularUser = new Subject<any>();
  public selectedSupplier = new Subject<any>();
  public isGenerateQuestionnaireForm = new BehaviorSubject<any>(false);
  public updateUserNameandLastname;
  public userRole;

  // Dashboard data sharing
  public selectedDashboard = new BehaviorSubject<any>(null);
  public dashboardAggregateData = new BehaviorSubject<any>(null);
  public organisationGoalData = new BehaviorSubject<any>(null);
  public dashboardLoadingState = new BehaviorSubject<{ tab: string; loading: boolean }>({ tab: '', loading: false });

  constructor(
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private snackBar: MatSnackBar,
    private router: Router,
    private aggregateDataService: AggregateDataService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'notification-messages');
      this.storyblok = story[0].content;
    });
    const user = sessionStorage.getItem('credentials');
    if (user) {
      const userJson = JSON.parse(user);
      const userRoles = userJson.roles.map((role) => role.name);
      if (userRoles.includes('Company admin')) {
        this.userRole = 'Admin';
      }
      if (userRoles.length === 1 && userRoles[0] === 'Product manager') {
        this.userRole = 'Member';
      }
      if (userRoles.length === 1 && userRoles[0] === 'Viewer') {
        this.userRole = 'Viewer';
      }
      this.isGHGShow = userJson?.organisation?.features?.includes('ghg_indicator');
      this.isPro = userJson?.organisation?.features?.includes('unlimited_unit');
    }
  }

  userRoleValidation(types: string[]): boolean {
    const user = sessionStorage.getItem('credentials');
    const userJson = JSON.parse(user);
    if (!userJson || !userJson.roles) {
      return false;
    }
    const userRoles = userJson.roles.map((role) => role.name);
    const hasRole = types.some((type) => {
      if (type === 'Admin') {
        return userRoles.includes('Company admin');
      }
      if (type === 'Member') {
        return userRoles.some((role) => role !== 'Company admin' && role !== 'Viewer');
      }
      if (type === 'Viewer') {
        return userRoles.length === 1 && userRoles[0] === 'Viewer';
      }
      return false;
    });

    if (!hasRole) {
      this.snackBar.open(this.storyblok.not_admin_warrning_massage, '', {
        duration: 5000,
        panelClass: ['info-snackBar'],
      });
    }
    return hasRole; // Changed from !hasRole to hasRole
  }

  public refreshUnitGuindance(id: any) {
    if (this.router.url.startsWith('/dashboard')) {
      return;
    }

    this.http.callService(new Method(environment.services.ctiUnitGuidance(id), '', 'get')).subscribe({
      next: (res) => {
        sessionStorage.setItem('ctiUnitGuidance', JSON.stringify(res));
        this.refreshStep.next(res);
      },
      error: (error) => {
        console.error('Failed to load unit guidance:', error);
        // Continue without guidance data
        this.refreshStep.next(null);
      },
    });
  }

  public clearHistory() {
    this.isLogin = new BehaviorSubject<any>('');
    this.breadcrumbOne = new BehaviorSubject<any>('');
    this.breadcrumbTwo = new BehaviorSubject<any>('');
    this.seletedChemical = new BehaviorSubject<any>('');
    this.productId = new BehaviorSubject<any>('');
    this.step5ActiveCase = new BehaviorSubject<any>('inflow-question');
    this.step6ActiveCase = new BehaviorSubject<any>('inflow6');
    this.step7ActiveCase = new BehaviorSubject<any>('smartTarget');
    this.materialType = null;
    this.userRole = null;
    this.stepsData = new Subject<any>();
    this.businessLevelLength = new Subject<any>();
    this.addmaterialType = null;
    this.criticalPercentage = null;
    this.selectedProduct = null;
    this.lensData = null;
    this.isGHGShow = false;
    this.isPro = false;
    this.getbusinessLevelList = new Subject<any>();
    this.selectedUnit = null;
    this.refreshStep = new Subject<any>();
    this.isShowstep5Intro = new Subject<any>();
    this.isShowstep6Intro = new Subject<any>();
    this.isShowstep7Intro = new Subject<any>();
    this.selectedUnitID = '';
    this.lastCreateMaterial = {};
    this.selectedCircularUser = new Subject<any>();
    this.selectedSupplier = new Subject<any>();
    this.isGenerateQuestionnaireForm = new BehaviorSubject<any>(false);
  }

  /**
   * Clear aggregate data from localStorage and reset reactive data
   * This method can be called from any component to clear cached aggregate data
   */
  public clearAggregateData(): void {
    this.aggregateDataService.clearAggregateData();
    this.dashboardAggregateData.next(null);
    this.dashboardLoadingState.next({ tab: 'all', loading: false });
  }
}
