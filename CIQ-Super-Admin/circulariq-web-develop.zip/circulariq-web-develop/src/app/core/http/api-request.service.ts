import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { from } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { AuthenticationService } from '@app/core';
import { Router } from '@angular/router';
import { StoryblokService } from '../storyblok/storyblok.service';

export class Request {
  resource: String;
  data?: Object;
  type: String;
  constructor(_resource: string, _data: Object, _type: String) {
    this.resource = _resource;
    this.data = _data;
    this.type = _type;
  }
}
export class Method extends Request {}
@Injectable({
  providedIn: 'root',
})
export class ApiRequestService {
  token;
  storyblok;
  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private authenticationService: AuthenticationService,
    private router: Router,
    private storyblokService: StoryblokService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'notification-messages');
      this.storyblok = story[0].content;
    });
  }

  public callService(request: Request) {
    return from(
      new Promise(async (resolve, reject) => {
        try {
          const response = await this.callServiceRequest(request);
          resolve(response);
        } catch (error) {
          reject(error);
        }
      })
    );
  }

  public getHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    if (JSON.parse(sessionStorage.getItem('credentials'))) {
      this.token = JSON.parse(sessionStorage.getItem('credentials')).authToken;
    }
    if (this.token) {
      headers = headers.append('x-auth-token', this.token);
    }
    return headers;
  }

  private callServiceRequest(request: Request): Promise<any> {
    let requestobj: any;
    switch (request.type) {
      case 'post':
        requestobj = this.http.post(this.getUrl(request.resource), request.data, this.getRequestOptions());
        break;
      case 'put':
        requestobj = this.http.put(this.getUrl(request.resource), request.data, this.getRequestOptions());
        break;
      case 'delete':
        requestobj = this.http.delete(this.getUrl(request.resource), this.getRequestOptions());
        break;
      default:
        requestobj = this.http.get(this.getUrl(request.resource), this.getRequestOptions());
        break;
    }
    return new Promise((resolve, reject) => {
      requestobj.subscribe(
        (res) => {
          resolve(res);
        },
        (err) => {
          if (err.status === 401) {
            this.authenticationService.logout().subscribe(() => this.router.navigate(['/login'], { replaceUrl: true }));
            location.reload();
          }
          this.error(err);
          reject(err);
        }
      );
    });
  }
  private getRequestOptions() {
    return { headers: this.getHeaders() };
  }
  private error(err: any) {
    if (err.status === 403) {
      this.snackBar.open(this.storyblok?.unauthorized, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    } else {
      let errorCode = 0;
      this.storyblok?.error_message_from_service.tbody.forEach((storyblokError) => {
        if (Number(storyblokError?.body[0]?.value) === err?.error?.code) {
          errorCode = err.error.code;
          this.snackBar.open(storyblokError.body[1].value, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        }
      });
      let errorMessage = '';
      if (err?.error?.message) {
        errorMessage = err?.error?.message;
      } else if (this.storyblok?.unknown_error_code_message) {
        errorMessage = this.storyblok?.unknown_error_code_message;
      } else {
        errorMessage = 'An error occurred please try again later';
      }

      if (errorCode === 0) {
        this.snackBar.open(errorMessage, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    }
  }
  private getUrl(resource: String) {
    return environment.serverUrl + resource;
  }
}
