import { AngularEditorConfig } from '@kolkov/angular-editor';

const editorConfig: AngularEditorConfig = {
  editable: true,
  spellcheck: true,
  height: '150px',
  minHeight: '150px',
  maxHeight: 'auto',
  width: 'auto',
  minWidth: '0',
  translate: 'no',
  enableToolbar: true,
  showToolbar: true,
  placeholder: 'Enter text here...',
  defaultParagraphSeparator: 'p',
  defaultFontName: '',
  defaultFontSize: '',
  fonts: [{ class: 'aktiv-grotesk', name: 'aktiv-grotesk' }],

  uploadWithCredentials: false,
  sanitize: false,
  toolbarPosition: 'top',
  toolbarHiddenButtons: [
    [
      'strikeThrough',
      'subscript',
      'superscript',
      'justifyLeft',
      'justifyCenter',
      'justifyRight',
      'justifyFull',
      'indent',
      'outdent',
      'insertUnorderedList',
      'insertOrderedList',
      'fontName',
    ],
    [
      'link',
      'fontSize',
      'textColor',
      'backgroundColor',
      'customClasses',
      'unlink',
      'insertHorizontalRule',
      'removeFormat',
      'toggleEditorMode',
    ],
  ],
};

export default editorConfig;
