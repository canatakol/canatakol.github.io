import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ConfirmDialog } from '@app/shared/dialog/confirm-dialog/confirm-dialog.component';
import {
  DashboardFlowsUnsavedService,
  DASHBOARD_FLOW_UNSAVED_MESSAGE,
} from '@app/shared-components/dashboard-flows/dashboard-flows-unsaved.service';
import { DashboardFlowsComponent } from '@app/shared-components/dashboard-flows/dashboard-flows.component';
import { DashboardFlowsDraftService } from '@app/shared-components/dashboard-flows/dashboard-flows-draft.service';

@Injectable({
  providedIn: 'root',
})
export class DashboardFlowsUnsavedGuard implements CanDeactivate<DashboardFlowsComponent> {
  constructor(
    private dashboardFlowsUnsavedService: DashboardFlowsUnsavedService,
    private draftService: DashboardFlowsDraftService,
    private dialog: MatDialog
  ) {}

  canDeactivate(component: DashboardFlowsComponent): Observable<boolean> | boolean {
    if (!this.dashboardFlowsUnsavedService.hasUnsavedChanges()) {
      return true;
    }

    if (typeof window === 'undefined') {
      return true;
    }

    const dialogRef = this.dialog.open(ConfirmDialog, {
      width: '460px',
      disableClose: true,
      data: {
        title: 'Leave without saving?',
        message: DASHBOARD_FLOW_UNSAVED_MESSAGE,
        yesButtonText: 'Leave page',
        noButtonText: 'Stay here',
      },
    });

    return dialogRef.afterClosed().pipe(
      map((confirmed: boolean) => {
        if (confirmed) {
          component?.resetAllChanges?.();
          this.draftService.resetAllDrafts();
          this.dashboardFlowsUnsavedService.setHasUnsavedChanges(false);
          return true;
        }
        return false;
      })
    );
  }
}
