import { Injectable, OnDestroy } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { Observable, BehaviorSubject, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { services } from '../../../environments/services';
import { environment } from '@env/environment';

export interface CommentMention {
  userId: string;
  startIndex: number;
  endIndex: number;
  fullname?: string; // Optional fullname field
}

export interface CommentData {
  subLevel: string;
  section: string;
  text: string;
  mentions: CommentMention[];
}

export interface Comment {
  id: string;
  dashboardId: string;
  dashboardName: string;
  subLevel: string;
  section: string;
  text: string;
  authorId: string;
  authorName: string;
  creationDate: string;
  lastModifiedDate: string;
  isRead: boolean;
  read?: boolean; // Some responses use 'read' instead of 'isRead'
  mentions: CommentMention[];
}

// New interfaces for header comments
export interface HeaderCommentMention {
  userId: string;
  username: string;
  startIndex: number;
  endIndex: number;
}

export interface HeaderComment {
  id: string;
  dashboardId: string;
  dashboardName: string;
  subLevel: string;
  section: string;
  text: string;
  authorId: string;
  authorName: string;
  creationDate: string;
  lastModifiedDate: string;
  isRead: boolean;
  mentions: HeaderCommentMention[];
}

export interface FormattedHeaderComment {
  id: string;
  avatar: string;
  message: string;
  formattedMessage: string;
  breadcrumb: string;
  time: string;
  originalData: HeaderComment;
}

@Injectable({
  providedIn: 'root',
})
export class CommentService implements OnDestroy {
  private commentsCache = new Map<string, BehaviorSubject<Comment[]>>();
  private unreadCountCache = new Map<string, BehaviorSubject<number>>();
  private headerCommentsCache = new BehaviorSubject<FormattedHeaderComment[]>([]);
  private previousHeaderCommentCount: number = 0;

  // Performance optimizations
  private userDataCache: any[] | null = null;
  private userDataCacheTimestamp: number = 0;
  private readonly USER_DATA_CACHE_TTL = 5 * 60 * 1000; // 5 minutes
  private currentTimeCache: number = 0;
  private currentTimeCacheTimestamp: number = 0;
  private readonly TIME_CACHE_TTL = 60 * 1000; // 1 minute

  // Memory leak prevention
  private destroy$ = new Subject<void>();

  constructor(private apiRequestService: ApiRequestService) {}

  /**
   * Post a new comment with mentions
   * @param dashboardId - The dashboard ID
   * @param commentData - The comment data including text and mentions
   * @returns Observable with the response
   */
  postComment(dashboardId: string, commentData: CommentData): Observable<any> {
    const url = services.dashboardComments(dashboardId);

    const request = new Method(url, commentData, 'post');

    return this.apiRequestService.callService(request);
  }

  /**
   * Get comments for a dashboard with caching
   * @param dashboardId - The dashboard ID
   * @returns Observable with the comments
   */
  getComments(dashboardId: string): Observable<Comment[]> {
    if (!this.commentsCache.has(dashboardId)) {
      const subject = new BehaviorSubject<Comment[]>([]);
      this.commentsCache.set(dashboardId, subject);

      // Initial load
      this.loadCommentsFromAPI(dashboardId);
    }

    return this.commentsCache.get(dashboardId)!.asObservable();
  }

  /**
   * Get unread comment count for a dashboard with caching
   * @param dashboardId - The dashboard ID
   * @returns Observable with the unread count
   */
  getUnreadCount(dashboardId: string): Observable<number> {
    if (!this.unreadCountCache.has(dashboardId)) {
      const subject = new BehaviorSubject<number>(0);
      this.unreadCountCache.set(dashboardId, subject);

      // Initial load
      this.loadUnreadCountFromAPI(dashboardId);
    }

    return this.unreadCountCache.get(dashboardId)!.asObservable();
  }

  /**
   * Get unread comment count for header (all dashboards)
   * @returns Observable with the unread count
   */
  getHeaderUnreadCount(): Observable<number> {
    const cacheKey = 'header';
    if (!this.unreadCountCache.has(cacheKey)) {
      const subject = new BehaviorSubject<number>(0);
      this.unreadCountCache.set(cacheKey, subject);

      // Initial load
      this.loadHeaderUnreadCountFromAPI();
    }

    return this.unreadCountCache.get(cacheKey)!.asObservable();
  }

  /**
   * Get header comments with formatting
   * @returns Observable with formatted header comments
   */
  getHeaderComments(): Observable<FormattedHeaderComment[]> {
    return this.headerCommentsCache.asObservable();
  }

  /**
   * Load header comments from service
   */
  loadHeaderCommentsFromService(): void {
    this.apiRequestService
      .callService(new Method(environment.services.headersComments(), {}, 'get'))
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && Array.isArray(response)) {
            this.updateHeaderCommentsFromService(response);
            // Also update header unread count from the same response to avoid duplicate API calls
            this.updateHeaderUnreadCountFromResponse(response);
          } else {
            console.warn('Unexpected response format from headersComments service:', response);
            this.headerCommentsCache.next([]);
          }
        },
        error: (error) => {
          console.error('Error loading comments from headersComments service:', error);
          this.headerCommentsCache.next([]);
        },
      });
  }

  /**
   * Update header comments from service response
   * @param comments - Raw comments from API
   */
  private updateHeaderCommentsFromService(comments: any[]): void {
    const apiComments: HeaderComment[] = comments.map((comment: any) => ({
      id: comment.id || comment.commentId,
      dashboardId: comment.dashboardId || comment.dashboard_id,
      dashboardName: comment.dashboardName || comment.dashboard_name,
      subLevel: comment.subLevel || comment.sub_level,
      section: comment.section,
      text: comment.text || comment.message,
      authorId: comment.authorId || comment.author_id,
      authorName: comment.authorName || comment.author_name,
      creationDate: comment.creationDate || comment.created_at || comment.creation_date,
      lastModifiedDate: comment.lastModifiedDate || comment.updated_at || comment.last_modified_date,
      isRead: comment.isRead || comment.read || false,
      mentions: (comment.mentions || []).map((mention: any) => ({
        userId: mention.userId || mention.user_id,
        username: mention.fullname || mention.username || mention.userId || mention.user_id,
        startIndex: mention.startIndex || mention.start_index,
        endIndex: mention.endIndex || mention.end_index,
      })),
    }));

    if (this.previousHeaderCommentCount > 0 && apiComments.length > this.previousHeaderCommentCount) {
      const newCommentCount = apiComments.length - this.previousHeaderCommentCount;
      console.log(`${newCommentCount} new comment(s) received from headersComments service`);
    }

    this.previousHeaderCommentCount = apiComments.length;

    const formattedComments = this.processHeaderComments(apiComments);
    this.headerCommentsCache.next(formattedComments);
  }

  /**
   * Process header comments and format them for display
   * @param comments - Raw header comments
   * @returns Formatted header comments
   */
  private processHeaderComments(comments: HeaderComment[]): FormattedHeaderComment[] {
    return comments.map((comment) => {
      const authorName = comment.authorName;
      const breadcrumb = `${comment.dashboardName} > ${comment.subLevel} > ${comment.section}`;
      const avatar = this.generateAvatarFromName(authorName);

      return {
        id: comment.id,
        avatar: avatar,
        message: comment.text,
        formattedMessage: this.formatMessageWithMentions(comment.text, comment.mentions),
        breadcrumb: breadcrumb,
        time: this.formatTimeFromDate(comment.creationDate),
        originalData: comment,
      };
    });
  }

  /**
   * Format message with mentions (optimized)
   * @param message - Original message
   * @param mentions - Array of mentions
   * @returns Formatted message with HTML
   */
  private formatMessageWithMentions(message: string, mentions: HeaderCommentMention[]): string {
    if (mentions.length === 0) {
      return message;
    }

    // Sort mentions once and reuse
    const sortedMentions =
      mentions.length > 1 ? mentions.slice().sort((a, b) => b.startIndex - a.startIndex) : mentions;

    let formattedMessage = message;

    for (const mention of sortedMentions) {
      const beforeMention = formattedMessage.substring(0, mention.startIndex);
      const afterMention = formattedMessage.substring(mention.endIndex);

      formattedMessage = beforeMention + `<span class="mention-highlight">@${mention.username}</span>` + afterMention;
    }

    return formattedMessage;
  }

  /**
   * Format time from date string with timezone support
   * @param dateString - Date string
   * @returns Formatted time string
   */
  private formatTimeFromDate(dateString: string): string {
    // Parse the date and ensure it's treated as UTC if no timezone info
    let date: Date;
    try {
      // If the dateString doesn't include timezone info, treat it as UTC
      if (!dateString.includes('Z') && !dateString.includes('+') && !dateString.includes('-', 10)) {
        // Add Z to treat as UTC
        date = new Date(dateString + 'Z');
      } else {
        date = new Date(dateString);
      }

      // Check if date is valid
      if (isNaN(date.getTime())) {
        console.warn('Invalid date string:', dateString);
        return 'Unknown time';
      }
    } catch (error) {
      console.warn('Error parsing date:', dateString, error);
      return 'Unknown time';
    }

    const now = this.getCurrentTime();
    const diffInMs = now - date.getTime();
    const diffInHours = diffInMs / (1000 * 60 * 60);
    const diffInDays = diffInHours / 24;

    // Handle negative differences (future dates)
    if (diffInMs < 0) {
      const absDiffInHours = Math.abs(diffInHours);

      if (absDiffInHours < 0.1) {
        return 'Just now';
      } else if (absDiffInHours < 24) {
        return `In ${Math.floor(absDiffInHours)}h`;
      } else {
        return `In ${Math.floor(Math.abs(diffInDays))}d`;
      }
    }

    if (diffInHours < 0.1) {
      // Less than 6 minutes
      return 'Just now';
    } else if (diffInHours < 1) {
      return `${Math.floor(diffInHours * 60)}m ago`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    } else if (diffInDays < 7) {
      return `${Math.floor(diffInDays)}d ago`;
    } else if (diffInDays < 30) {
      return `${Math.floor(diffInDays / 7)}w ago`;
    } else {
      // For very old comments, show the actual date
      return date.toLocaleDateString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
    }
  }

  /**
   * Get current time with caching to avoid creating new Date objects frequently
   * @returns Current timestamp
   */
  private getCurrentTime(): number {
    const now = Date.now();
    if (now - this.currentTimeCacheTimestamp > this.TIME_CACHE_TTL) {
      this.currentTimeCache = now;
      this.currentTimeCacheTimestamp = now;
    }
    return this.currentTimeCache;
  }

  /**
   * Generate avatar from name
   * @param fullName - Full name
   * @returns Avatar initials
   */
  private generateAvatarFromName(fullName: string): string {
    if (!fullName || fullName.trim() === '') {
      return 'NA';
    }

    const nameParts = fullName.trim().split(' ');

    if (nameParts.length === 1) {
      return nameParts[0].substring(0, 2).toUpperCase();
    } else {
      const firstName = nameParts[0];
      const lastName = nameParts[nameParts.length - 1];

      return (firstName.charAt(0) + lastName.charAt(0)).toUpperCase();
    }
  }

  /**
   * Render message with mentions for template (optimized)
   * @param message - Original message
   * @param mentions - Array of mentions
   * @returns Array of message parts
   */
  renderMessageWithMentions(message: string, mentions: HeaderCommentMention[]): any[] {
    if (mentions.length === 0) {
      return [{ type: 'text', content: message }];
    }

    // Sort mentions once and reuse
    const sortedMentions =
      mentions.length > 1 ? mentions.slice().sort((a, b) => a.startIndex - b.startIndex) : mentions;

    const result: any[] = [];
    let currentIndex = 0;

    for (const mention of sortedMentions) {
      if (mention.startIndex > currentIndex) {
        result.push({
          type: 'text',
          content: message.substring(currentIndex, mention.startIndex),
        });
      }

      result.push({
        type: 'mention',
        content: mention.username,
        userId: mention.userId,
      });

      currentIndex = mention.endIndex;
    }

    if (currentIndex < message.length) {
      result.push({
        type: 'text',
        content: message.substring(currentIndex),
      });
    }

    return result;
  }

  /**
   * Get filtered header comments based on tab
   * @param comments - All comments
   * @param activeTab - Active tab
   * @param currentSubLevel - Current sub level
   * @param currentUserEmail - Current user email
   * @param currentUserCredentials - Current user credentials (optional)
   * @returns Filtered comments
   */
  getFilteredHeaderComments(
    comments: FormattedHeaderComment[],
    activeTab: string,
    currentSubLevel: string,
    currentUserEmail: string,
    currentUserCredentials?: any
  ): FormattedHeaderComment[] {
    let filtered: FormattedHeaderComment[] = [];

    switch (activeTab) {
      case 'unread':
        filtered = comments.filter((comment) => {
          // Show all unread comments
          return !comment.originalData.isRead;
        });
        break;
      case 'mentions':
        filtered = comments.filter((comment) => {
          if (!comment.originalData.mentions || comment.originalData.mentions.length === 0) {
            return false;
          }

          // Check if current user is mentioned
          return comment.originalData.mentions.some((mention) => {
            // Check by userId if credentials are available
            if (currentUserCredentials && currentUserCredentials.userId) {
              if (mention.userId === currentUserCredentials.userId) {
                return true;
              }
            }

            // Check by email/username
            if (mention.username === currentUserEmail || mention.userId === currentUserEmail) {
              return true;
            }

            return false;
          });
        });
        break;
      case 'this-view':
        filtered = comments.filter((comment) => comment.originalData.subLevel === currentSubLevel);
        break;
      case 'dashboard':
      case 'all':
        filtered = comments;
        break;
      default:
        filtered = comments;
    }

    return filtered;
  }

  /**
   * Get tab count for header comments
   * @param comments - All comments
   * @param tab - Tab name
   * @param currentSubLevel - Current sub level
   * @param currentUserEmail - Current user email
   * @param currentUserCredentials - Current user credentials (optional)
   * @returns Count for the tab
   */
  getHeaderCommentTabCount(
    comments: FormattedHeaderComment[],
    tab: string,
    currentSubLevel: string,
    currentUserEmail: string,
    currentUserCredentials?: any
  ): number {
    const filtered = this.getFilteredHeaderComments(
      comments,
      tab,
      currentSubLevel,
      currentUserEmail,
      currentUserCredentials
    );
    return filtered.length;
  }

  /**
   * Refresh comments for a specific dashboard
   * @param dashboardId - The dashboard ID
   */
  refreshComments(dashboardId: string): void {
    this.loadCommentsFromAPI(dashboardId);
  }

  /**
   * Refresh unread count for a specific dashboard
   * @param dashboardId - The dashboard ID
   */
  refreshUnreadCount(dashboardId: string): void {
    this.loadUnreadCountFromAPI(dashboardId);
  }

  /**
   * Refresh header unread count
   */
  refreshHeaderUnreadCount(): void {
    this.loadHeaderUnreadCountFromAPI();
  }

  /**
   * Mark a comment as read
   * @param commentId - The comment ID to mark as read
   * @returns Observable with the response
   */
  markCommentRead(commentId: string): Observable<any> {
    const url = services.markCommentRead(commentId);
    const request = new Method(url, {}, 'put');

    return this.apiRequestService.callService(request);
  }

  /**
   * Mark a comment as read and refresh all related caches
   * @param commentId - The comment ID to mark as read
   * @param dashboardId - The dashboard ID (optional, for specific dashboard refresh)
   * @returns Observable with the response
   */
  markCommentReadAndRefresh(commentId: string, dashboardId?: string): Observable<any> {
    return new Observable((observer) => {
      this.markCommentRead(commentId).subscribe({
        next: (response) => {
          // Refresh header unread count
          this.refreshHeaderUnreadCount();

          // Refresh specific dashboard if provided
          if (dashboardId) {
            this.refreshComments(dashboardId);
            this.refreshUnreadCount(dashboardId);
          }

          observer.next(response);
          observer.complete();
        },
        error: (error) => {
          observer.error(error);
        },
      });
    });
  }

  /**
   * Clear cache for a specific dashboard
   * @param dashboardId - The dashboard ID
   */
  clearCache(dashboardId: string): void {
    this.commentsCache.delete(dashboardId);
    this.unreadCountCache.delete(dashboardId);
  }

  /**
   * Clear all caches including user data cache
   */
  clearAllCaches(): void {
    this.commentsCache.clear();
    this.unreadCountCache.clear();
    this.userDataCache = null;
    this.userDataCacheTimestamp = 0;
    this.currentTimeCache = 0;
    this.currentTimeCacheTimestamp = 0;
  }

  /**
   * Force refresh user data cache
   */
  refreshUserDataCache(): void {
    this.userDataCache = null;
    this.userDataCacheTimestamp = 0;
  }

  /**
   * Debug method to check timezone handling
   * @param dateString - Date string to debug
   * @returns Debug information
   */
  debugTimeFormat(dateString: string): any {
    const originalDate = new Date(dateString);
    const utcDate = new Date(
      dateString + (dateString.includes('Z') || dateString.includes('+') || dateString.includes('-', 10) ? '' : 'Z')
    );
    const now = new Date();

    return {
      originalDateString: dateString,
      originalDate: originalDate.toString(),
      originalISOString: originalDate.toISOString(),
      utcDate: utcDate.toString(),
      utcISOString: utcDate.toISOString(),
      currentTime: now.toString(),
      currentISOString: now.toISOString(),
      timezoneOffset: now.getTimezoneOffset(),
      diffWithOriginal: now.getTime() - originalDate.getTime(),
      diffWithUTC: now.getTime() - utcDate.getTime(),
      formattedTime: this.formatTimeFromDate(dateString),
    };
  }

  /**
   * Cleanup method to prevent memory leaks
   */
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();

    // Complete all BehaviorSubjects
    this.commentsCache.forEach((subject) => subject.complete());
    this.unreadCountCache.forEach((subject) => subject.complete());
    this.headerCommentsCache.complete();

    // Clear caches
    this.clearAllCaches();
  }

  private loadCommentsFromAPI(dashboardId: string): void {
    const request = new Method(services.dashboardComments(dashboardId), {}, 'get');

    this.apiRequestService
      .callService(request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && Array.isArray(response)) {
            const comments: Comment[] = response.map((comment: any) => ({
              id: comment.id,
              dashboardId: comment.dashboardId,
              dashboardName: comment.dashboardName,
              subLevel: comment.subLevel,
              section: comment.section,
              text: comment.text,
              authorId: comment.authorId,
              authorName: comment.authorName,
              creationDate: comment.creationDate,
              lastModifiedDate: comment.lastModifiedDate,
              isRead: comment.read !== undefined ? comment.read : comment.isRead,
              read: comment.read !== undefined ? comment.read : comment.isRead,
              mentions: this.mapMentionsWithFullnames(comment.mentions || []),
            }));

            const subject = this.commentsCache.get(dashboardId);
            if (subject) {
              subject.next(comments);
            }

            // Also update unread count
            this.updateUnreadCount(dashboardId, comments);
          }
        },
        error: (error) => {
          console.error('Error loading comments:', error);
        },
      });
  }

  private loadUnreadCountFromAPI(dashboardId: string): void {
    // Check if comments are already being loaded to avoid duplicate API calls
    const commentsSubject = this.commentsCache.get(dashboardId);
    if (commentsSubject && commentsSubject.value.length > 0) {
      // Use existing comments data to calculate unread count
      this.updateUnreadCount(dashboardId, commentsSubject.value);
      return;
    }

    const request = new Method(services.dashboardComments(dashboardId), {}, 'get');

    this.apiRequestService
      .callService(request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && Array.isArray(response)) {
            const unreadCount = response.filter((comment: any) => {
              const isRead = comment.read !== undefined ? comment.read : comment.isRead;
              return !isRead;
            }).length;

            const subject = this.unreadCountCache.get(dashboardId);
            if (subject) {
              subject.next(unreadCount);
            }
          }
        },
        error: (error) => {
          console.error('Error loading unread count:', error);
        },
      });
  }

  /**
   * Update header unread count from existing response data
   * @param response - Header comments response
   */
  private updateHeaderUnreadCountFromResponse(response: any[]): void {
    const unreadCount = response.filter((comment: any) => {
      const isRead = comment.read !== undefined ? comment.read : comment.isRead;
      return !isRead;
    }).length;

    const subject = this.unreadCountCache.get('header');
    if (subject) {
      subject.next(unreadCount);
    }
  }

  private loadHeaderUnreadCountFromAPI(): void {
    // Only load if not already loading header comments
    // This method is now mostly redundant as we update from header comments response
    const request = new Method(services.headersComments(), {}, 'get');

    this.apiRequestService
      .callService(request)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (response: any) => {
          if (response && Array.isArray(response)) {
            this.updateHeaderUnreadCountFromResponse(response);
          }
        },
        error: (error) => {
          console.error('Error loading header unread count:', error);
        },
      });
  }

  private updateUnreadCount(dashboardId: string, comments: Comment[]): void {
    const unreadCount = comments.filter((comment) => !comment.isRead).length;
    const subject = this.unreadCountCache.get(dashboardId);
    if (subject) {
      subject.next(unreadCount);
    }
  }

  /**
   * Get cached user data with TTL
   * @returns Cached user data array
   */
  private getCachedUserData(): any[] {
    const now = Date.now();
    if (!this.userDataCache || now - this.userDataCacheTimestamp > this.USER_DATA_CACHE_TTL) {
      try {
        this.userDataCache = JSON.parse(localStorage.getItem('userData') || '[]');
        this.userDataCacheTimestamp = now;
      } catch (error) {
        console.warn('Failed to parse userData from localStorage:', error);
        this.userDataCache = [];
      }
    }
    return this.userDataCache;
  }

  private mapMentionsWithFullnames(mentions: any[]): CommentMention[] {
    if (!mentions || mentions.length === 0) {
      return [];
    }

    // Get cached user data
    const userData = this.getCachedUserData();

    return mentions.map((mention) => {
      // Find user by userId in cached data
      const user = userData.find((u) => u.id === mention.userId);

      return {
        userId: mention.userId,
        startIndex: mention.startIndex,
        endIndex: mention.endIndex,
        fullname: user?.fullname || mention.userId, // Use fullname if found, otherwise fallback to userId
      };
    });
  }
}
