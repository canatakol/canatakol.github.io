import { Injectable } from '@angular/core';
import * as LZString from 'lz-string';

@Injectable({
  providedIn: 'root',
})
export class LocalStorageService {
  // Storage keys
  public readonly AGGREGATE_DATA_KEY = 'aggregateData';
  public readonly COMPARE_DATA_KEY = 'compareData';
  public readonly STORYBLOK_DATA_KEY = 'storyBlokData';

  /**
   * Sıkıştırılmış veri ile localStorage'a kaydet
   */
  setCompressedItem(key: string, value: any): void {
    try {
      const jsonString = JSON.stringify(value);
      const compressed = LZString.compress(jsonString);
      localStorage.setItem(key, compressed);
    } catch (error) {
      console.error('Error setting compressed item in localStorage:', error);
    }
  }

  /**
   * Sıkıştırılmış veriyi localStorage'dan oku
   */
  getCompressedItem(key: string): any {
    try {
      const compressed = localStorage.getItem(key);
      if (!compressed) {
        return null;
      }

      // Eski sıkıştırılmamış veriyi kontrol et
      try {
        const parsed = JSON.parse(compressed);
        // Eğer parse başarılı olursa, bu eski formattaki veri
        // Yeni formata çevir
        this.setCompressedItem(key, parsed);
        return parsed;
      } catch {
        // Parse başarısız, bu sıkıştırılmış veri demektir
        const decompressed = LZString.decompress(compressed);
        return decompressed ? JSON.parse(decompressed) : null;
      }
    } catch (error) {
      console.error('Error getting compressed item from localStorage:', error);
      return null;
    }
  }

  /**
   * localStorage'dan item sil
   */
  removeItem(key: string): void {
    try {
      localStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing item from localStorage:', error);
    }
  }

  /**
   * Normal setItem (sıkıştırma olmadan)
   */
  setItem(key: string, value: any): void {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error setting item in localStorage:', error);
    }
  }

  /**
   * Normal getItem (sıkıştırma olmadan)
   */
  getItem(key: string): any {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Error getting item from localStorage:', error);
      return null;
    }
  }

  /**
   * Sıkıştırılmış veri ile sessionStorage'a kaydet
   */
  setCompressedSessionItem(key: string, value: any): void {
    try {
      const jsonString = JSON.stringify(value);
      const compressed = LZString.compress(jsonString);
      sessionStorage.setItem(key, compressed);
    } catch (error) {
      console.error('Error setting compressed item in sessionStorage:', error);
    }
  }

  /**
   * Sıkıştırılmış veriyi sessionStorage'dan oku
   */
  getCompressedSessionItem(key: string): any {
    try {
      const compressed = sessionStorage.getItem(key);
      if (!compressed) {
        return null;
      }

      // Eski sıkıştırılmamış veriyi kontrol et
      try {
        const parsed = JSON.parse(compressed);
        // Eğer parse başarılı olursa, bu eski formattaki veri
        // Yeni formata çevir
        this.setCompressedSessionItem(key, parsed);
        return parsed;
      } catch {
        // Parse başarısız, bu sıkıştırılmış veri demektir
        const decompressed = LZString.decompress(compressed);
        return decompressed ? JSON.parse(decompressed) : null;
      }
    } catch (error) {
      console.error('Error getting compressed item from sessionStorage:', error);
      return null;
    }
  }

  /**
   * sessionStorage'dan item sil
   */
  removeSessionItem(key: string): void {
    try {
      sessionStorage.removeItem(key);
    } catch (error) {
      console.error('Error removing item from sessionStorage:', error);
    }
  }

  /**
   * Normal setSessionItem (sıkıştırma olmadan)
   */
  setSessionItem(key: string, value: any): void {
    try {
      sessionStorage.setItem(key, JSON.stringify(value));
    } catch (error) {
      console.error('Error setting item in sessionStorage:', error);
    }
  }

  /**
   * Normal getSessionItem (sıkıştırma olmadan)
   */
  getSessionItem(key: string): any {
    try {
      const item = sessionStorage.getItem(key);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Error getting item from sessionStorage:', error);
      return null;
    }
  }
}
