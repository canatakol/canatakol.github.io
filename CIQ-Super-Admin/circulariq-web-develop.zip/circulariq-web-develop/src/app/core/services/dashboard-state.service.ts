import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

export interface DashboardState {
  selectedTab: string;
  dashboardId: string;
  subLevel: string;
}

@Injectable({
  providedIn: 'root',
})
export class DashboardStateService {
  private currentStateSubject = new BehaviorSubject<DashboardState>({
    selectedTab: 'PROCUREMENT',
    dashboardId: '',
    subLevel: 'PROCUREMENT',
  });

  public currentState$: Observable<DashboardState> = this.currentStateSubject.asObservable();

  constructor() {
    // Initialize from localStorage
    this.loadStateFromStorage();
  }

  /**
   * Updates the current dashboard state
   * @param state Partial state to update
   */
  updateState(state: Partial<DashboardState>): void {
    const currentState = this.currentStateSubject.value;
    const newState = { ...currentState, ...state };

    // Update subLevel based on selectedTab
    if (state.selectedTab) {
      newState.subLevel = this.mapTabToSubLevel(state.selectedTab);
    }

    this.currentStateSubject.next(newState);
    this.saveStateToStorage(newState);
  }

  /**
   * Gets the current dashboard state
   * @returns Current dashboard state
   */
  getCurrentState(): DashboardState {
    return this.currentStateSubject.value;
  }

  /**
   * Gets the current selected tab
   * @returns Current selected tab
   */
  getCurrentTab(): string {
    return this.currentStateSubject.value.selectedTab;
  }

  /**
   * Gets the current subLevel
   * @returns Current subLevel
   */
  getCurrentSubLevel(): string {
    return this.currentStateSubject.value.subLevel;
  }

  /**
   * Gets the current dashboard ID
   * @returns Current dashboard ID
   */
  getCurrentDashboardId(): string {
    return this.currentStateSubject.value.dashboardId;
  }

  /**
   * Maps tab name to subLevel value
   * @param tab Tab name
   * @returns Corresponding subLevel
   */
  private mapTabToSubLevel(tab: string): string {
    switch (tab?.toUpperCase()) {
      case 'SUSTAINABILITY':
        return 'SUSTAINABILITY';
      case 'PROCUREMENT':
        return 'PROCUREMENT';
      case 'DESIGN':
        return 'DESIGN';
      case 'ASSESSMENT':
        return 'ASSESSMENT';
      case 'E5':
        return 'E5';
      case 'PRO':
        return 'PRO';
      default:
        return 'PROCUREMENT';
    }
  }

  /**
   * Loads state from localStorage
   */
  private loadStateFromStorage(): void {
    try {
      const savedState = localStorage.getItem('dashboardState');
      if (savedState) {
        const state = JSON.parse(savedState);
        this.currentStateSubject.next(state);
      }
    } catch (error) {
      console.error('Error loading dashboard state from storage:', error);
    }
  }

  /**
   * Saves state to localStorage
   * @param state State to save
   */
  private saveStateToStorage(state: DashboardState): void {
    try {
      localStorage.setItem('dashboardState', JSON.stringify(state));
    } catch (error) {
      console.error('Error saving dashboard state to storage:', error);
    }
  }

  /**
   * Clears the dashboard state
   */
  clearState(): void {
    const defaultState: DashboardState = {
      selectedTab: 'PROCUREMENT',
      dashboardId: '',
      subLevel: 'PROCUREMENT',
    };
    this.currentStateSubject.next(defaultState);
    localStorage.removeItem('dashboardState');
  }
}
