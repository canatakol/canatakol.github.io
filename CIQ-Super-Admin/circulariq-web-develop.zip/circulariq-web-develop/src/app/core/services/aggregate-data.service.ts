import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { LocalStorageService } from './local-storage.service';

export interface AggregateDataState {
  data: any;
  dashboardId: string;
  loading: boolean;
  lastUpdated: Date;
}

@Injectable({
  providedIn: 'root',
})
export class AggregateDataService {
  private aggregateDataSubject = new BehaviorSubject<AggregateDataState | null>(null);

  constructor(private http: ApiRequestService, private localStorageService: LocalStorageService) {}

  /**
   * Get the current aggregate data state
   */
  getAggregateDataState(): AggregateDataState | null {
    return this.aggregateDataSubject.value;
  }

  /**
   * Get aggregate data as an observable
   */
  getAggregateData$() {
    return this.aggregateDataSubject.asObservable();
  }

  /**
   * Get aggregate data from localStorage
   */
  getAggregateData(): any {
    try {
      return this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY);
    } catch (error) {
      console.error('Error parsing aggregate data from localStorage:', error);
      return null;
    }
  }

  /**
   * Set aggregate data in localStorage and update the subject
   */
  setAggregateData(data: any, dashboardId?: string): void {
    const state: AggregateDataState = {
      data: data,
      dashboardId: dashboardId || data?.dashboardId || '',
      loading: false,
      lastUpdated: new Date(),
    };

    this.localStorageService.setCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY, data);
    this.aggregateDataSubject.next(state);
  }

  /**
   * Clear aggregate data from localStorage and reset the subject
   */
  clearAggregateData(): void {
    this.localStorageService.removeItem(this.localStorageService.AGGREGATE_DATA_KEY);
    this.aggregateDataSubject.next(null);
  }

  /**
   * Check if aggregate data is valid for a specific dashboard
   */
  isValidAggregateData(dashboardId: string): boolean {
    const data = this.getAggregateData();
    return data && typeof data === 'object' && Object.keys(data).length > 0 && data.dashboardId === dashboardId;
  }

  /**
   * Fetch fresh aggregate data for a dashboard
   */
  fetchAggregateData(dashboardId: string): Promise<any> {
    return new Promise((resolve, reject) => {
      // Set loading state
      this.aggregateDataSubject.next({
        data: null,
        dashboardId: dashboardId,
        loading: true,
        lastUpdated: new Date(),
      });

      this.http.callService(new Method(environment.services.dashboardAggregate(dashboardId), {}, 'get')).subscribe({
        next: (res) => {
          const data = Object.assign({}, res, { dashboardId });
          this.setAggregateData(data, dashboardId);
          resolve(data);
        },
        error: (error) => {
          this.aggregateDataSubject.next({
            data: null,
            dashboardId: dashboardId,
            loading: false,
            lastUpdated: new Date(),
          });
          reject(error);
        },
      });
    });
  }

  /**
   * Refresh aggregate data for the current dashboard
   */
  async refreshAggregateData(dashboardId: string): Promise<any> {
    // Clear current data to force fresh fetch
    this.clearAggregateData();

    // Fetch fresh data
    return this.fetchAggregateData(dashboardId);
  }

  /**
   * Get aggregate data for a dashboard (from cache or fetch fresh)
   */
  async getAggregateDataForDashboard(dashboardId: string, forceRefresh: boolean = false): Promise<any> {
    // If force refresh is requested, fetch fresh data
    if (forceRefresh) {
      return this.refreshAggregateData(dashboardId);
    }

    // Check if we have valid cached data
    if (this.isValidAggregateData(dashboardId)) {
      const data = this.getAggregateData();
      this.aggregateDataSubject.next({
        data: data,
        dashboardId: dashboardId,
        loading: false,
        lastUpdated: new Date(),
      });
      return data;
    }

    // Fetch fresh data
    return this.fetchAggregateData(dashboardId);
  }
}
