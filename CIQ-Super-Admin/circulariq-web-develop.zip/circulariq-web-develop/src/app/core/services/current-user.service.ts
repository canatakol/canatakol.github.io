import { Injectable } from '@angular/core';

export interface UserCredentials {
  authToken: string;
  userId: string;
  email: string;
  name: string;
  organisation?: any;
  memberships?: any[];
  features?: string[];
  emailVerified?: boolean;
  show2025Terms?: boolean;
  [key: string]: any; // Allow additional properties
}

@Injectable({
  providedIn: 'root',
})
export class CurrentUserService {
  private readonly CREDENTIALS_KEY = 'credentials';

  constructor() {}

  /**
   * Gets the current user's credentials from sessionStorage
   * @returns The current user's credentials object or null if not found
   */
  getCurrentUserCredentials(): UserCredentials | null {
    try {
      const credentials = sessionStorage.getItem(this.CREDENTIALS_KEY);
      if (credentials) {
        return JSON.parse(credentials);
      }
    } catch (error) {
      console.error('Error parsing credentials from sessionStorage:', error);
    }
    return null;
  }

  /**
   * Gets the current user's email
   * @returns The current user's email or empty string if not found
   */
  getCurrentUserEmail(): string {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.email || '';
  }

  /**
   * Gets the current user's name
   * @returns The current user's name or empty string if not found
   */
  getCurrentUserName(): string {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.name || '';
  }

  /**
   * Gets the current user's ID
   * @returns The current user's ID or empty string if not found
   */
  getCurrentUserId(): string {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.userId || '';
  }

  /**
   * Gets the current user's auth token
   * @returns The current user's auth token or empty string if not found
   */
  getCurrentUserToken(): string {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.authToken || '';
  }

  /**
   * Checks if the current user is authenticated
   * @returns True if user is authenticated, false otherwise
   */
  isAuthenticated(): boolean {
    const credentials = this.getCurrentUserCredentials();
    return !!(credentials && credentials.authToken);
  }

  /**
   * Checks if the current user has a specific feature
   * @param feature The feature to check for
   * @returns True if user has the feature, false otherwise
   */
  hasFeature(feature: string): boolean {
    const credentials = this.getCurrentUserCredentials();
    return !!(credentials?.features && credentials.features.includes(feature));
  }

  /**
   * Checks if the current user is a CIQ user (has e5 feature)
   * @returns True if user is CIQ user, false otherwise
   */
  isCIQUser(): boolean {
    return this.hasFeature('e5');
  }

  /**
   * Checks if the current user is a Pro user (has unlimited_unit feature)
   * @returns True if user is Pro user, false otherwise
   */
  isProUser(): boolean {
    return this.hasFeature('unlimited_unit');
  }

  /**
   * Gets the current user's organisation
   * @returns The current user's organisation or null if not found
   */
  getCurrentUserOrganisation(): any {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.organisation || null;
  }

  /**
   * Gets the current user's memberships
   * @returns The current user's memberships array or empty array if not found
   */
  getCurrentUserMemberships(): any[] {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.memberships || [];
  }

  /**
   * Checks if the current user's email is verified
   * @returns True if email is verified, false otherwise
   */
  isEmailVerified(): boolean {
    const credentials = this.getCurrentUserCredentials();
    return credentials?.emailVerified === true;
  }

  /**
   * Updates the current user's credentials in sessionStorage
   * @param credentials The new credentials to store
   */
  updateCredentials(credentials: UserCredentials): void {
    try {
      sessionStorage.setItem(this.CREDENTIALS_KEY, JSON.stringify(credentials));
    } catch (error) {
      console.error('Error updating credentials in sessionStorage:', error);
    }
  }

  /**
   * Clears the current user's credentials from sessionStorage
   */
  clearCredentials(): void {
    try {
      sessionStorage.removeItem(this.CREDENTIALS_KEY);
    } catch (error) {
      console.error('Error clearing credentials from sessionStorage:', error);
    }
  }
}
