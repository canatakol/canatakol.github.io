import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { DomSanitizer } from '@angular/platform-browser';
import Storyblok from 'storyblok-js-client';
import { LocalStorageService } from '../services/local-storage.service';
@Injectable({
  providedIn: 'root',
})
export class StoryblokService {
  set storyObject(story: object) {
    this.story = story;
  }
  storyBlokData;
  private storyblokToken: string;
  private storyblokGuidanceToken: string;
  private endpointUrl;
  private endpointUrlpage2;
  private language: string;
  private sanitizer: DomSanitizer;
  private story: object;
  private storyblokClient;
  private stories = {};

  constructor(sanitizer: DomSanitizer, private localStorageService: LocalStorageService) {
    this.storyblokGuidanceToken = environment.storyblokGuidanceToken;
    this.storyblokToken = environment.storyblokToken;
    this.sanitizer = sanitizer;
    this.refreshLang();
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });

    document.addEventListener('language.changed', (e: CustomEvent) => {
      this.refreshLang(e.detail.language);
    });
  }

  refreshLang(defaultLang: string = 'de-de') {
    this.language = localStorage.getItem('lang') || defaultLang;
  }
  async getStoryGuidance(slug: string, params: any = {}) {
    let endpointUrl =
      environment.storiesEndpoint +
      slug +
      '?token=' +
      this.storyblokGuidanceToken +
      '&language=' +
      this.language +
      '&version=' +
      environment.storyblokVersion;
    if (params.findBy !== undefined) {
      endpointUrl += '&find_by=' + params.findBy;
    }

    if (this.stories[slug] === undefined) {
      let response: any = await fetch(endpointUrl);
      response = await response.json();
      this.stories[slug] = response.story;
    }

    return this.stories[slug];
  }

  public async getStoryService() {
    if (this.storyBlokData) {
      return this.storyBlokData;
    }

    const cached = this.localStorageService.getCompressedItem(this.localStorageService.STORYBLOK_DATA_KEY);
    if (cached) {
      this.storyBlokData = cached;
      return this.storyBlokData;
    }

    const lang = localStorage.getItem('lang');
    const langQuery = lang ? `language=${this.language}&` : '';
    const baseParams = `${langQuery}token=${this.storyblokToken}&version=${environment.storyblokVersion}&per_page=100`;

    const endpoints = [
      `${environment.storiesEndpoint}?${baseParams}&page=1`,
      `${environment.storiesEndpoint}?${baseParams}&page=2`,
    ];

    const storyBlokData = [];
    const mainRes = await Promise.all(
      endpoints.map((endpoint) =>
        fetch(endpoint)
          .then((res) => res.json())
          .then((res) => res.stories)
      )
    );
    mainRes.forEach((stories) => {
      storyBlokData.push(...stories);
    });

    this.storyBlokData = storyBlokData;
    this.localStorageService.setCompressedItem(this.localStorageService.STORYBLOK_DATA_KEY, storyBlokData);

    return this.storyBlokData;
  }

  getRichTextResolver() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });

    return this.storyblokClient.richTextResolver;
  }
  renderRichText(content: any) {
    return this.getRichTextResolver().render(content);
  }

  mapShortcodes(content: string) {
    // TODO: Need a shortcode mapper here!
    return content;
  }

  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }

  trustResourceUrl(html: string) {
    return this.sanitizer.bypassSecurityTrustResourceUrl(html);
  }

  // tslint:disable-next-line:typedef
  nl2br(str: string, is_xhtml = true) {
    if (typeof str === 'undefined' || str === null) {
      return '';
    }
    const breakTag = is_xhtml || typeof is_xhtml === 'undefined' ? '<br />' : '<br>';
    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
  }
}
