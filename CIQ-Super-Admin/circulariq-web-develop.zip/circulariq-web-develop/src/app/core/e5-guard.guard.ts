import { CanActivateFn } from '@angular/router';
import { environment } from '@env/environment';

export const e5GuardGuard: CanActivateFn = (route, state) => {
  const credentials = JSON.parse(sessionStorage.getItem('credentials'));
  const project = environment.project;

  if (!credentials || !credentials.organisation || !credentials.organisation.features) {
    window.location.assign('/login');
    return false;
  }

  let isE5User = false;
  if (credentials.organisation.features.includes('e5')) {
    isE5User = true;
  }
  if (isE5User) {
    return true;
  } else {
    window.location.assign('/login');
    return false;
  }
};
