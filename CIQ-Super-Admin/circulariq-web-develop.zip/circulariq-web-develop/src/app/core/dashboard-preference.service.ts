import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiRequestService, Method } from './http/api-request.service';
import { environment } from '@env/environment';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class DashboardPreferenceService {
  private showBLDashboardSubject = new BehaviorSubject<boolean>(null);

  constructor(private http: ApiRequestService) {}

  setShowBLDashboard(value: boolean): void {
    this.showBLDashboardSubject.next(value);
  }

  getShowBLDashboard(): Observable<boolean> {
    if (this.showBLDashboardSubject.getValue() === null) {
      return this.refreshDashboardPreference();
    } else {
      return this.showBLDashboardSubject.asObservable();
    }
  }

  refreshDashboardPreference(): Observable<boolean> {
    return this.http.callService(new Method(environment.services.userJourney(), '', 'get')).pipe(
      map((res) => {
        if (res['SHOW_BL_VIEW'] === undefined) {
          return false;
        }
        const value = res['SHOW_BL_VIEW'].value === true || res['SHOW_BL_VIEW'].value === 'true' ? true : false;
        this.showBLDashboardSubject.next(value);
        return value;
      })
    );
  }
}
