import { Injectable } from '@angular/core';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Logger } from '../logger.service';
import { AuthenticationService } from './authentication.service';
import { stat } from 'fs';

const log = new Logger('AuthenticationGuard');

@Injectable()
export class AuthenticationGuard {
  constructor(private router: Router, private authenticationService: AuthenticationService) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (this.authenticationService.isAuthenticated()) {
      return true;
    }

    log.debug('Not authenticated, redirecting and adding redirect url...');
    var queryParams = {};
    if (state.url != '/') {
      queryParams['redirect'] = state.url;
    }
    this.router.navigate(['/login'], { queryParams, replaceUrl: true });
    return false;
  }
}
