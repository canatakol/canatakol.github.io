import { Observable, of } from 'rxjs';

import { LoginContext } from './authentication.service';
import { UserCredentials } from '../services/current-user.service';

export class MockAuthenticationService {
  credentials: UserCredentials | null = {
    authToken: 'string',
    userId: 'string',
    email: 'string',
    name: 'string',
  };

  login(context: LoginContext): Observable<UserCredentials> {
    return of({
      authToken: 'string',
      userId: 'string',
      email: 'string',
      name: 'string',
    });
  }

  logout(): Observable<boolean> {
    this.credentials = null;
    return of(true);
  }

  isAuthenticated(): boolean {
    return !!this.credentials;
  }
}
