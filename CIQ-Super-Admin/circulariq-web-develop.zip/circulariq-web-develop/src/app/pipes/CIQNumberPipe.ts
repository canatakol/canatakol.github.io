import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'ciqNumber',
  standalone: true,
})
export class CiqNumberPipe implements PipeTransform {
  constructor(private decimalPipe: DecimalPipe) {}

  transform(
    value: any,
    format: 'integer' | 'percentage' | 'mass' | 'input' | 'threeDecimal',
    unit?: 'kg' | 't' | 'tt',
    appendUnit: boolean = false
  ): string {
    if (value == null) {
      return '';
    }

    // Normalize incoming value: handle thousand separators and locale decimals
    const rawStr = value.toString().trim().replace(/\s+/g, '');
    let parseStr = rawStr;

    if (parseStr.includes(',') && parseStr.includes('.')) {
      // Assume comma is thousand, dot is decimal
      parseStr = parseStr.replace(/,/g, '');
    } else if (parseStr.includes(',') && !parseStr.includes('.')) {
      // Assume comma is decimal
      parseStr = parseStr.replace(',', '.');
    }

    const numericValue = parseFloat(parseStr);
    if (isNaN(numericValue)) {
      return '';
    }
    const formatNumber = (num: number, decimals: number): string => {
      const formatString = `1.${decimals}-${decimals}`;
      return this.decimalPipe.transform(num, formatString) || '';
    };

    if (format === 'mass') {
      let result = numericValue;

      if (unit === 't') {
        result = numericValue / 1000;
      } else if (unit === 'tt') {
        result = numericValue / 1000000;
      }

      // Determine decimals from the original string (last separator wins)
      const lastComma = rawStr.lastIndexOf(',');
      const lastDot = rawStr.lastIndexOf('.');
      let originalDecimalPlaces = 0;
      if (!rawStr.toLowerCase().includes('e')) {
        if (lastComma > -1 || lastDot > -1) {
          const sep = Math.max(lastComma, lastDot);
          if (sep < rawStr.length - 1) {
            const decPart = rawStr.substring(sep + 1).replace(/[^0-9]/g, '');
            // Show only significant digits from the original string
            originalDecimalPlaces = decPart.replace(/0+$/, '').length;
          }
        }
      }

      // Show at least 3 decimals; if more significant digits exist, show them (up to 20)
      // Using min-max range prevents forced trailing zeros for values like 0.000000...
      const maxDecimals = Math.max(3, originalDecimalPlaces, 20);
      const formatString = `1.3-${maxDecimals}`;
      let formattedResult = this.decimalPipe.transform(result, formatString) || '';

      // Remove trailing separator like "100." or "100,"
      if (formattedResult.endsWith('.') || formattedResult.endsWith(',')) {
        formattedResult = formattedResult.slice(0, -1);
      }

      return appendUnit ? `${formattedResult} ${unit || 'kg'}` : formattedResult;
    }

    // Diğer formatlar
    if (format === 'integer') {
      return formatNumber(Math.round(numericValue), 0);
    }
    if (format === 'percentage') {
      const decimals = 2;
      return formatNumber(numericValue, decimals);
    }
    if (format === 'threeDecimal') {
      const decimals = 3;
      const formattedResult = formatNumber(numericValue, decimals);
      return appendUnit ? `${formattedResult} ${unit || 'kg'}` : formattedResult;
    }
    if (format === 'input') {
      const parts = numericValue.toString().split('.');
      if (parts.length === 2) {
        return this.decimalPipe.transform(parseInt(parts[0], 10), '1.0-0') + ',' + parts[1];
      }
      return this.decimalPipe.transform(numericValue, '1.0-0') || '';
    }
    return numericValue.toString();
  }
}
