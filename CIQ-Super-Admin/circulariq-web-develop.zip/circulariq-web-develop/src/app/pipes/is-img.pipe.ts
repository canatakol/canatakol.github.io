import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'isImg',
  standalone: false,
})
export class IsImgPipe implements PipeTransform {
  transform(value: unknown, ...args: unknown[]): unknown {
    if (
      value === 'tif' ||
      value === 'tiff' ||
      value === 'png' ||
      value === 'jpeg' ||
      value === 'jpg' ||
      value === 'gif' ||
      value === 'webp'
    ) {
      value = true;
    }
    return value;
  }
}
