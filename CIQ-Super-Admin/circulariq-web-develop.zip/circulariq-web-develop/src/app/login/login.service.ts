import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';
import { finalize, tap, catchError, switchMap } from 'rxjs/operators';
import { CommonService } from '@app/core/common.service';
import { environment } from '@env/environment';
import { AuthenticationService } from '@app/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import * as Sentry from '@sentry/browser';
import { DashboardPreferenceService } from '@app/core/dashboard-preference.service';
import { UserCredentials } from '@app/core/services/current-user.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { Observable, throwError } from 'rxjs';
import posthog from 'posthog-js';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  version: string = environment.version;
  project: string = environment.project;
  error: string;
  remember = false;
  baseQuestions;
  level;
  isPro = false;
  isCIQUser = false;
  loginForm: FormGroup;
  freeOrganization = false;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    private authenticationService: AuthenticationService,
    private http: ApiRequestService,
    private dashboardPreferenceService: DashboardPreferenceService,
    private storyblokService: StoryblokService,
    private localStorageService: LocalStorageService
  ) {}

  login(data: any, project?: string) {
    this.commonService.isPro = false;
    this.commonService.isLoggingIn.next(true);
    this.authenticationService
      .login(data)
      .pipe(
        finalize(() => {
          // this.loginForm.markAsPristine();
          this.commonService.isLoggingIn.next(false);
        })
      )
      .subscribe(
        (credentials) => {
          Sentry.setUser({ id: credentials['userId'] });
          if (this.project === 'CTI' && !credentials['tfaRequired']) {
            this.getQuestionList();
          }
          if (credentials && credentials['organisation'] && credentials['organisation']['licenseType']) {
            this.freeOrganization = credentials['organisation']['licenseType'] === 'Free';
          }
          if (credentials['tfaRequired']) {
            this.router.navigate([`/tfa/${credentials.userId}`], { replaceUrl: true });
          } else {
            this.loginSuccess(credentials, project);
          }
        },
        (error) => {
          // login error
          this.snackBar.open(error.error.message, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
          this.router.navigate(['/login']);
          this.commonService.isLoggingIn.next(false);
          this.error = error;
        }
      );
  }
  getLanguage() {
    this.http.callService(new Method(environment.services.organisationLanguage(), '', 'get')).subscribe({
      next: async (res) => {
        const orgLang = res['language'] ? res['language'] : 'en';
        const localLang = String(localStorage.getItem('lang'));
        if (orgLang !== localLang) {
          localStorage.setItem('lang', orgLang);
          location.reload();
        }
      },
      error: (error) => {
        // If language fetch fails, continue with default language
        console.error('Failed to load organization language:', error);
      },
    });
  }

  loginSuccess(credentials: any, project?: string) {
    this.setPosthogUser(credentials);
    if (credentials && credentials['organisation'] && credentials['organisation'].features) {
      credentials['organisation'].features.forEach((element) => {
        if (element === 'e5') {
          this.isCIQUser = true;
        }
      });
    }
    this.route.queryParams.subscribe((params) => {
      this.http.callService(new Method(environment.services.isvalidateEmail(), '', 'get')).subscribe({
        next: (res) => {
          sessionStorage.setItem('isvalidateEmail', JSON.stringify(res['valid']));
        },
        error: (error) => {
          // If email validation check fails, continue with default behavior
          console.error('Failed to validate email:', error);
          sessionStorage.setItem('isvalidateEmail', JSON.stringify(true));
        },
      });

      if (environment.project === 'CTI') {
        this.http.callService(new Method(environment.services.ctiGuidance(), '', 'get')).subscribe({
          next: (res) => {
            if (res['newUser']) {
              this.router.navigate(['/cti/guide/new-user'], { replaceUrl: true });
            } else {
              if (credentials['memberships'] && credentials['memberships'].length === 1) {
                this.selectOrg(credentials['memberships'][0]);
              } else {
                this.router.navigate(['/cti/select-organisation'], { replaceUrl: true });
              }
            }
          },
          error: (error) => {
            // If guidance check fails, proceed with organization selection
            console.error('Failed to load CTI guidance:', error);
            if (credentials['memberships'] && credentials['memberships'].length === 1) {
              this.selectOrg(credentials['memberships'][0]);
            } else {
              this.router.navigate(['/cti/select-organisation'], { replaceUrl: true });
            }
          },
        });
      } else if (environment.project === 'CIQ') {
        if (this.isCIQUser) {
          this.updateUserNameandLastname();
          if (credentials['memberships'] && credentials['memberships'].length === 1) {
            window.location.assign('/e5');
          } else {
            this.router.navigate(['/ciq/select-organisation'], { replaceUrl: true });
          }
        } else {
          this.router.navigate(['/wrong-credentials'], { replaceUrl: true });
        }
      }
    });
    if (credentials && credentials['organisation'] && credentials['organisation'].features) {
      credentials['organisation'].features.forEach((element) => {
        if (element === 'unlimited_unit') {
          this.isPro = true;
          this.commonService.isPro = true;
        }
      });
    }
  }
  updateUserNameandLastname() {
    if (this.commonService.updateUserNameandLastname) {
      this.http
        .callService(
          new Method(environment.services.currentUser(), this.commonService.updateUserNameandLastname, 'put')
        )
        .subscribe({
          next: () => {
            // User name updated successfully
          },
          error: (error) => {
            console.error('Failed to update user name:', error);
          },
        });
    }
  }

  private setPosthogUser(credentials: any) {
    const distinctId = credentials?.userId || credentials?.id;
    if (!distinctId) {
      return;
    }

    posthog.identify(distinctId, {
      email: credentials?.email,
      name: credentials?.name,
      organisationId: credentials?.organisation?.id,
      organisationName: credentials?.organisation?.name,
      licenseType: credentials?.organisation?.licenseType,
      project: environment.project,
    });
  }

  async selectOrg(org: any) {
    if (!org || !org.organisation || !org.organisation.id) {
      return;
    }
    await this.http
      .callService(
        new Method(environment.services.loginOrganisation(), { organisationId: org.organisation.id }, 'post')
      )
      .pipe(
        switchMap((res: UserCredentials) => {
          sessionStorage.setItem('credentials', JSON.stringify(res));

          // Update authentication service credentials
          this.authenticationService.updateCredentials(res);
          this.dashboardPreferenceService.setShowBLDashboard(res['showBLDashboard'] ?? null);
          this.setPosthogUser(res);

          // Chain the getUser() call to ensure it completes before proceeding
          return this.getUser().pipe(
            tap(() => {
              // getUser() completed successfully, now proceed with other operations
              this.http.callService(new Method(environment.services.ctiGuidance(), '', 'get')).subscribe({
                next: (ctiGuidanceData) => {
                  sessionStorage.setItem('ctiGuidance', JSON.stringify(ctiGuidanceData));
                  sessionStorage.setItem('onboardingAlwaysOn', JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']));
                  this.commonService.onboardingAlwaysOn = JSON.stringify(ctiGuidanceData['onboardingAlwaysOn']);
                },
                error: (error) => {
                  // If guidance data fails to load, continue without it
                  console.error('Failed to load CTI guidance:', error);
                },
              });

              if (environment.project === 'CTI') {
                if (this.freeOrganization) {
                  this.router.navigate(['/cti/materials'], { replaceUrl: true });
                  this.getLanguage();
                } else {
                  // this.getLanguage();
                  // tslint:disable-next-line:no-shadowed-variable
                  if (this.isPro) {
                    this.router.navigate(['/cti/pro-label']).then(() => {
                      location.reload();
                    });
                  } else {
                    this.http.callService(new Method(environment.services.listBusinessLevels(), '', 'get')).subscribe({
                      next: (level) => {
                        this.level = level;
                        if (this.isPro) {
                          if (res['showBLDashboard']) {
                            this.router.navigate(['/cti/pro-business']).then(() => {
                              location.reload();
                            });
                          } else {
                            this.router.navigate(['/cti/pro-label']).then(() => {
                              location.reload();
                            });
                          }
                          this.getLanguage();
                        } else {
                          if (this.level.length > 0) {
                            this.http
                              .callService(
                                new Method(
                                  environment.services.ctiUnitGuidance(this.level[0]?.assessments[0]?.unitId),
                                  '',
                                  'get'
                                )
                              )
                              .subscribe({
                                next: (step) => {
                                  sessionStorage.setItem('ctiUnitGuidance', JSON.stringify(step));
                                  if (!this.level[0].assessments[0].unitId) {
                                    Sentry.captureMessage('Redirect user to step1 with no unitId after login.', {
                                      level: 'error',
                                    });
                                  }
                                  this.router
                                    .navigate([`/cti/${this.level[0].assessments[0].unitId}/assessment/step1`])
                                    .then(() => {
                                      location.reload();
                                    });
                                  this.getLanguage();
                                },
                                error: (error) => {
                                  console.error('Failed to load unit guidance:', error);
                                  // Try to navigate anyway if we have unitId
                                  if (this.level[0]?.assessments[0]?.unitId) {
                                    this.router
                                      .navigate([`/cti/${this.level[0].assessments[0].unitId}/assessment/step1`])
                                      .then(() => {
                                        location.reload();
                                      });
                                  }
                                  this.getLanguage();
                                },
                              });
                          } else {
                            this.snackBar.open(this.commonService.storyblok.no_business_level, '', {
                              duration: 5000,
                              panelClass: ['error-snackBar'],
                            });
                          }
                        }
                      },
                    });
                  }
                }
              }
              if (environment.project === 'CIQ') {
                this.router.navigate(['/e5'], { replaceUrl: true }).then(() => {
                  location.reload();
                });
                this.getLanguage();
              }
              res['organisation'].features.forEach((element) => {
                if (element === 'unlimited_unit') {
                  this.isPro = true;
                  this.commonService.isPro = true;
                }
              });
            })
          );
        })
      )
      .subscribe({
        next: () => {
          // All operations completed successfully
        },
        error: (error) => {
          this.snackBar.open(error.error.message, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        },
      });
  }

  getUser(): Observable<any> {
    // Consider using pagination instead of a hardcoded size
    return this.http.callService(new Method(environment.services.user() + '?size=99', '', 'get')).pipe(
      tap((res) => {
        localStorage.setItem('userData', JSON.stringify(res['results']));
      }),
      catchError((error) => {
        return throwError(() => error);
      })
    );
  }
  getQuestionList() {
    this.http.callService(new Method(environment.services.questionList(), '', 'get')).subscribe({
      next: async (res) => {
        this.baseQuestions = res;
        await this.storyblokService.getStoryService().then((data) => {
          const story = data.filter((item) => item.slug === 'question-list');
          const questions = story[0].content.question_list.tbody;
          questions.forEach((question) => {
            this.baseQuestions.forEach((baseQuestion) => {
              if (question.body[0].value === baseQuestion.code) {
                baseQuestion.description.en = question.body[1].value;
              }
            });
          });
        });
        this.storyblokService.getStoryService().then((data) => {
          const answerStory = data.filter((item) => item.slug === 'select-answer-list');
          const answers = answerStory[0].content.select_answer_list.tbody;
          answers.forEach((answer) => {
            this.baseQuestions.forEach((baseQuestion) => {
              if (baseQuestion.code === answer.body[0].value) {
                const newValues = answer.body[1].value.split('&');
                const newOptions = baseQuestion.options.map(function (option: any, key: any) {
                  return { ...option, name: newValues[key] ?? 'xxxxx' };
                });
                baseQuestion.options = newOptions;
              }
            });
          });
          this.localStorageService.setCompressedSessionItem('questionList', this.baseQuestions);
        });
      },
      error: (error) => {
        console.error('Failed to load question list:', error);
        // If question list fails, continue without it (may cause issues but won't block login)
      },
    });
  }
}
