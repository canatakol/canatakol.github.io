import { Component, OnInit } from '@angular/core';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';

@Component({
  selector: 'app-ciq-login-faild-page',
  templateUrl: './ciq-login-faild-page.component.html',
  styleUrls: ['./ciq-login-faild-page.component.scss'],
  standalone: false,
})
export class CiqLoginFaildPageComponent implements OnInit {
  project: string = environment.project;
  storyblok;
  constructor(private storyblokService: StoryblokService) {}

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'ciq-wrong-credentials-page')[0].content;
      sessionStorage.removeItem('credentials');
    });
  }
}
