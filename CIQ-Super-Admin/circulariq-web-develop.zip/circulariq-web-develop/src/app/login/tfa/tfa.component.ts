import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '../../core/http/api-request.service';
import { finalize } from 'rxjs/operators';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../login.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-tfa',
  templateUrl: './tfa.component.html',
  styleUrls: ['./tfa.component.scss'],
  standalone: false,
})
export class TfaComponent implements OnInit {
  isLoading = false;
  quote: string;
  tfaForm: FormGroup;
  storyblok;
  userId = this.route.snapshot.params.userId;
  project: string = environment.project;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    private router: Router,
    private route: ActivatedRoute,
    private loginService: LoginService,
    private storyblokService: StoryblokService
  ) {
    this.createForm();
  }

  tfa() {
    this.isLoading = true;
    const data = { code: this.tfaForm.value.code, user_uuid: this.userId, project: this.project };
    this.http.callService(new Method(environment.services.authenticatetfa(), data, 'post')).subscribe(
      (res) => {
        sessionStorage.setItem('credentials', JSON.stringify(res));
        this.loginService.getQuestionList();
        this.loginService.loginSuccess(res);
        this.isLoading = false;
      },
      (error) => {
        this.isLoading = false;
        // Reset form code field to allow user to retry
        this.tfaForm.patchValue({ code: '' });
        this.tfaForm.get('code')?.markAsUntouched();
      }
    );
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'tfa');
      this.storyblok = story[0].content;
    });
  }
  private createForm() {
    this.tfaForm = this.formBuilder.group({
      code: ['', Validators.required],
    });
  }
}
