import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { LoginRoutingModule } from './login-routing.module';
import { LoginComponent } from './login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ForgotService } from './forgot-password/forgot.service';
import { SetPasswordComponent } from './set-password/set-password.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { SetPasswordService } from './set-password/set-password.service';
import { ResetPasswordService } from './reset-password/reset-password.service';
import { TfaComponent } from './tfa/tfa.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { MultiOrgListComponent } from './multi-org-list/multi-org-list.component';
import { SSOComponent } from './sso/sso.component';
import { E5SetPasswordComponent } from './e5-set-password/e5-set-password.component';
import { E5SetPasswordService } from './e5-set-password/e5-set-password.service';
import { CiqLoginFaildPageComponent } from './ciq-login-faild-page/ciq-login-faild-page.component';
import { SharedModule } from '@app/shared/shared.module';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgbModule,
    LoginRoutingModule,
    MatCheckboxModule,
    MatSnackBarModule,
    FormsModule,
    SharedModule,
    LoadingBarComponent,
  ],
  declarations: [
    LoginComponent,
    ForgotPasswordComponent,
    SetPasswordComponent,
    ResetPasswordComponent,
    E5SetPasswordComponent,
    TfaComponent,
    SSOComponent,
    MultiOrgListComponent,
    CiqLoginFaildPageComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [ForgotService, SetPasswordService, E5SetPasswordService, ResetPasswordService],
})
export class LoginModule {}
