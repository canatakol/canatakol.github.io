import { Component } from '@angular/core';
import { environment } from '@env/environment';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-sso',
  templateUrl: './sso.component.html',
  styleUrls: ['./sso.component.scss'],
  standalone: false,
})
export class SSOComponent {
  tokenValue;
  storyblok;
  pageShow = false;
  constructor(private route: ActivatedRoute, private router: Router, private snackBar: MatSnackBar) {
    this.tokenValue = this.route.snapshot.queryParams.token;
    try {
      this.postJSON(this.tokenValue);
    } catch (err) {
      this.snackBar.open(
        this.storyblok?.token_is_not_vaild_text ? this.storyblok?.token_is_not_vaild_text : 'token is not valid!',
        '',
        {
          duration: 5000,
          panelClass: ['error-snackBar'],
        }
      );
    }
  }
  async postJSON(token: any) {
    try {
      const response = await fetch(`${environment.serverUrl}/login`, {
        method: 'GET',
        headers: {
          'X-Auth-Token': token,
        },
      });
      const result = await response.json();
      await sessionStorage.setItem('credentials', JSON.stringify(result));

      if (result['showBLDashboard']) {
        window.location.href = '/cti/pro-label';
      } else {
        window.location.href = '/cti/pro-business';
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }
}
// erman+sso@circular-iq.com
