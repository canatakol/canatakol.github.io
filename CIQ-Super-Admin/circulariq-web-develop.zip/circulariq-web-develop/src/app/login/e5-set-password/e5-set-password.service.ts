import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { environment } from '../../../environments/environment';

export interface RandomQuoteContext {
  // The quote's category: 'dev', 'explicit'...
  category: string;
}

@Injectable()
export class E5SetPasswordService {
  constructor(private httpClient: HttpClient) {}

  checkToken(context: any) {
    return this.httpClient.request('get', environment.serverUrl + environment.services.token(context, 'set')).pipe(
      map((body: any) => body),
      catchError((body) => of(body?.error?.message))
    );
  }
  getToken(email: any) {
    return this.httpClient.request('get', environment.serverUrl + environment.services.getToken(email)).pipe(
      map((body: any) => body),
      catchError((body) => {
        if (body.error) {
          return of(body?.error?.message);
        } else {
          return of(null);
        }
      })
    );
  }
  reSend(data: any) {
    return this.httpClient
      .post(environment.serverUrl + environment.services.resendSingup(), data, {
        headers: { 'Content-Type': 'application/json' },
      })
      .pipe(
        map((body: any) => body),
        catchError((body) => of(body?.error?.message))
      );
  }
  setPassword(data: any) {
    return this.httpClient
      .post(environment.serverUrl + environment.services.setPassword(), data, {
        headers: { 'Content-Type': 'application/json' },
      })
      .pipe(
        map((body: any) => body),
        catchError((body) => of(body?.error?.message))
      );
  }
  passwordRegex(password: string, confirmedPassword: string, storyblok: any) {
    const errors = [];
    if (password) {
      if (password.length < 8) {
        errors.push(storyblok.password_error_text_size);
      }
      if (password.length > 20) {
        errors.push(storyblok.password_error_text_size);
      }
      if (password.search(/[a-z]/i) < 0) {
        errors.push(storyblok.password_error_text_one_letter);
      }
      if (password.search(/([A-Z]+)/g) < 0) {
        errors.push(storyblok.password_error_text_uppercase);
      }
      if (password.search(/[0-9]/) < 0) {
        errors.push(storyblok.password_error_text_one_digit);
      }
      this.isConfirmed(password, confirmedPassword);
      return errors;
    }
  }
  // tslint:disable-next-line:member-ordering
  isConfirmed(password: string, confirmedPassword: string) {
    let isConfirm = true;
    if (password === confirmedPassword) {
      isConfirm = true;
    } else {
      isConfirm = false;
    }
    return isConfirm;
  }
}
