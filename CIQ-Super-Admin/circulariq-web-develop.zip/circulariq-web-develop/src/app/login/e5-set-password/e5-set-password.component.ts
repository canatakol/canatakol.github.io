import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { E5SetPasswordService } from './e5-set-password.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoginService } from '../login.service';
import jwtDecode from 'jwt-decode';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';

@Component({
  selector: 'app-e5-set-password',
  templateUrl: './e5-set-password.component.html',
  styleUrls: ['./e5-set-password.component.scss'],
  standalone: false,
})
export class E5SetPasswordComponent implements OnInit {
  signUpForm: FormGroup;
  language;
  email;
  firstName;
  lastName;
  errors = [];
  isConfirm = true;
  agree = false;
  storyblok;
  loginStoryblok;
  tokenValue;
  pageShow = null;
  loginValue;
  password;
  submitted = false;
  type = 'password';
  isRegex = true;
  version: string = environment.version;
  project: string = environment.project;
  error: string;
  remember = false;
  loginForm: FormGroup;
  isLoading = false;
  freeOrganization = false;
  constructor(
    private route: ActivatedRoute,
    private setServise: E5SetPasswordService,
    private snackBar: MatSnackBar,
    private loginService: LoginService,
    private router: Router,
    private storyblokService: StoryblokService,
    private http: ApiRequestService,
    private commonService: CommonService
  ) {
    this.language = localStorage.getItem('language');
  }

  private initAfterStoryblok() {
    const givenToken = this.route.snapshot.queryParams.token;
    const givenEmail = this.route.snapshot.queryParams.email;
    this.firstName = this.route.snapshot.queryParams?.first;
    this.lastName = this.route.snapshot.queryParams?.last;
    this.email = this.route.snapshot.queryParams?.email;
    if (givenToken) {
      this.doTokenCheck(givenToken);
    } else if (givenEmail) {
      this.doEmailCheck(givenEmail);
    } else {
      this.snackBar.open(this.storyblok.invalid_token, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
      // No email or token given for activation
    }
  }

  private doTokenCheck(givenToken: any) {
    try {
      const decoded = jwtDecode(givenToken);
      this.email = decoded['email'];
    } catch (err) {
      this.snackBar.open(this.storyblok.token_is_not_vaild_text, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    }
    this.setServise.checkToken(givenToken).subscribe((res) => {
      if (!res) {
        this.tokenValue = givenToken;
        this.pageShow = true;
      } else {
        if (res === 'error.token.invalid.active.user') {
          this.router.navigate(['/login'], { replaceUrl: true });
        }
        this.pageShow = false;
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  private doEmailCheck(givenEmail: any) {
    this.setServise.getToken(givenEmail).subscribe((res) => {
      if (!res) {
        this.snackBar.open(this.storyblok.registration_failed, '', {
          duration: 10000,
          panelClass: ['error-snackBar'],
        });
        setTimeout(() => {
          this.router.navigate(['/login'], { replaceUrl: true });
        }, 10000);
      } else {
        this.tokenValue = res.token;
        this.email = givenEmail;
        this.pageShow = true;
      }
    });
  }

  onSubmit() {
    const data = { token: this.tokenValue, password: this.password, projectType: 'CIQ' };
    this.loginValue = { email: this.email, password: this.password, remember: false };

    this.updateUserNameandLastname();
    this.setServise.setPassword(data).subscribe((res) => {
      if (!res) {
        this.loginService.login(this.loginValue, 'e5');
      } else {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  updateUserNameandLastname() {
    const data = { firstName: this.firstName, middleName: null, lastName: this.lastName, email: this.email };
    this.commonService.updateUserNameandLastname = data;
    // this.http.callService(new Method(environment.services.currentUser(), data, 'put')).subscribe((res) => {});
  }

  passwordRegex(password: string, confirmedPassword: string) {
    this.errors = this.setServise.passwordRegex(password, confirmedPassword, this.storyblok);
  }

  isConfirmed(password: string, confirmedPassword: string) {
    this.isConfirm = this.setServise.isConfirmed(password, confirmedPassword);
  }

  ngOnInit() {
    this.createForm();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'signup');
      this.storyblok = story[0].content;
      const loginStory = data.filter((item) => item.slug === 'login');
      this.loginStoryblok = loginStory[0].content;

      this.initAfterStoryblok();
    });
    this.signUpForm.get('email')?.disable();
  }

  resend() {
    const data = { token: this.tokenValue };
    this.setServise.reSend(data).subscribe((res) => {
      if (res) {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  private createForm() {
    this.signUpForm = new FormGroup({
      accept: new FormControl(false),
      email: new FormControl(null, [Validators.required]),
      firstName: new FormControl(null, [Validators.required]),
      lastName: new FormControl(null, [Validators.required]),
      password: new FormControl(null, [Validators.required]),
      confirmedPassword: new FormControl(null, [Validators.required]),
    });
  }
}
