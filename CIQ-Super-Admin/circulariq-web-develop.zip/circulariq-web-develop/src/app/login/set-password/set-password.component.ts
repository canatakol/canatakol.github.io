import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { SetPasswordService } from './set-password.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { LoginService } from '../login.service';
import jwtDecode from 'jwt-decode';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-set-password',
  templateUrl: './set-password.component.html',
  styleUrls: ['./set-password.component.scss'],
  standalone: false,
})
export class SetPasswordComponent implements OnInit {
  signUpForm: FormGroup;
  language;
  email;
  errors = [];
  isConfirm = true;
  agree = false;
  storyblok;
  tokenValue;
  pageShow = null;
  loginValue;
  password;
  submitted = false;
  type = 'password';
  isRegex = true;
  version: string = environment.version;
  project: string = environment.project;
  error: string;
  remember = false;
  loginForm: FormGroup;
  isLoading = false;
  freeOrganization = false;
  constructor(
    private route: ActivatedRoute,
    private setServise: SetPasswordService,
    private snackBar: MatSnackBar,
    private loginService: LoginService,
    private router: Router,
    private storyblokService: StoryblokService
  ) {
    this.language = localStorage.getItem('language');
  }

  private initAfterStoryblok() {
    const givenToken = this.route.snapshot.queryParams.token;
    const givenEmail = this.route.snapshot.queryParams.email;
    if (givenToken) {
      this.doTokenCheck(givenToken);
    } else if (givenEmail) {
      this.doEmailCheck(givenEmail);
    } else {
      this.snackBar.open(this.storyblok.invalid_token, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    }
  }

  private doTokenCheck(givenToken: any) {
    try {
      const decoded = jwtDecode(givenToken);
      this.email = decoded['email'];
    } catch (err) {
      this.snackBar.open(this.storyblok.token_is_not_vaild_text, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    }
    this.setServise.checkToken(givenToken).subscribe((res) => {
      if (!res) {
        this.tokenValue = givenToken;
        this.pageShow = true;
      } else {
        if (res === 'error.token.invalid.active.user') {
          this.router.navigate(['/login'], { replaceUrl: true });
        }
        this.pageShow = false;
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  private doEmailCheck(givenEmail: any) {
    this.setServise.getToken(givenEmail).subscribe((res) => {
      if (!res) {
        this.snackBar.open(this.storyblok.registration_failed, '', {
          duration: 10000,
          panelClass: ['error-snackBar'],
        });
        setTimeout(() => {
          this.router.navigate(['/login'], { replaceUrl: true });
        }, 10000);
      } else {
        this.tokenValue = res.token;
        this.email = givenEmail;
        this.pageShow = true;
      }
    });
  }

  onSubmit() {
    const data = { token: this.tokenValue, password: this.password };
    this.loginValue = { email: this.email, password: this.password, remember: false };
    this.setServise.setPassword(data).subscribe((res) => {
      if (!res) {
        this.loginService.login(this.loginValue);
      } else {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  passwordRegex(password: string, confirmedPassword: string) {
    this.errors = this.setServise.passwordRegex(password, confirmedPassword, this.storyblok);
  }

  isConfirmed(password: string, confirmedPassword: string) {
    this.isConfirm = this.setServise.isConfirmed(password, confirmedPassword);
  }

  ngOnInit() {
    this.createForm();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'signup');
      this.storyblok = story[0].content;
      this.initAfterStoryblok();
    });
  }

  resend() {
    const data = { token: this.tokenValue };
    this.setServise.reSend(data).subscribe((res) => {
      if (res) {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  private createForm() {
    this.signUpForm = new FormGroup({
      accept: new FormControl(false),
      password: new FormControl(null, [Validators.required]),
      confirmedPassword: new FormControl(null, [Validators.required]),
    });
  }
}
