import { NgModule } from '@angular/core';

import { LoginComponent } from './login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { SetPasswordComponent } from './set-password/set-password.component';
import { TfaComponent } from './tfa/tfa.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { MultiOrgListComponent } from './multi-org-list/multi-org-list.component';
import { ErrorPageComponent } from '@app/error/error-page/error-page.component';
import { SSOComponent } from './sso/sso.component';
import { RouterModule, Routes, NavigationEnd, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { filter } from 'rxjs/operators';
import { E5SetPasswordComponent } from './e5-set-password/e5-set-password.component';
import { CiqLoginFaildPageComponent } from './ciq-login-faild-page/ciq-login-faild-page.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent, data: { title: 'CircularIQ - Login' } },
  { path: 'login/:token', component: LoginComponent, data: { title: 'CircularIQ - Login' } },
  { path: 'sso', component: SSOComponent, data: { title: 'CircularIQ - SSO' } },
  {
    path: 'forgot-password',
    component: ForgotPasswordComponent,
    data: { title: 'CircularIQ - Forgot Password' },
  },
  { path: 'signup', component: SetPasswordComponent, data: { title: 'CircularIQ - Signup' } },
  { path: 'e5-signup', component: E5SetPasswordComponent, data: { title: 'CircularIQ - Signup' } },
  { path: 'reset', component: ResetPasswordComponent, data: { title: 'CircularIQ - Reset Password' } },
  { path: 'tfa/:userId', component: TfaComponent, data: { title: 'CircularIQ - TFA' } },
  {
    path: 'wrong-credentials',
    component: CiqLoginFaildPageComponent,
    data: { title: 'CircularIQ - Wrong credentials' },
  },

  {
    path: 'cti/select-organisation',
    component: MultiOrgListComponent,
    data: { title: 'CircularIQ - Select Organisation' },
  },
  {
    path: 'ciq/select-organisation',
    component: MultiOrgListComponent,
    data: { title: 'CircularIQ - Select Organisation' },
  },
  {
    path: 'error-page',
    component: ErrorPageComponent,
    data: { title: 'CircularIQ - CTI Error page' },
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class LoginRoutingModule {
  constructor(private router: Router, private titleService: Title) {
    this.router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe(() => {
      const routeTitle = this.router.routerState.snapshot.root.firstChild?.data['title'];
      this.titleService.setTitle(routeTitle || 'Circular-IQ');
    });
  }
}
