import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { Logger } from '@app/core';
import { LoginService } from './login.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;
const log = new Logger('CircularIQ - Login');
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  standalone: false,
})
export class LoginComponent implements OnInit {
  version: string = environment.version;
  project: string = environment.project;
  environment = environment;
  error: string;
  selectedLanguage = localStorage.getItem('lang') ? localStorage.getItem('lang') : 'en';
  storyblok;
  remember = false;
  loginForm: FormGroup;
  freeOrganization = false;
  isLoading = false;
  selectedForm = 'login';
  constructor(
    private formBuilder: FormBuilder,
    private loginService: LoginService,
    private storyblokService: StoryblokService,
    private commonService: CommonService,
    private activatedRoute: ActivatedRoute,
    private http: ApiRequestService,
    private snackBar: MatSnackBar
  ) {
    this.createForm();
    $('html').addClass(this.project);

    this.activatedRoute.queryParams.subscribe((params: Params) => {
      if (params.token) {
        this.http
          .callService(new Method(environment.services.validateEmail(params.token), '', 'put'))
          .subscribe(async (res) => {
            if (res) {
              this.snackBar.open(this.commonService.storyblok?.success_message, '', {
                duration: 5000,
                panelClass: ['success-snackBar'],
              });
            }
          });
      }
    });
  }

  selectForm(form: string) {
    this.selectedForm = form;
  }

  sso(mail: string) {
    document.location.href = `${this.environment.serverUrl}/sso-service/user?email=${mail}`;
  }

  login() {
    this.isLoading = true;
    this.loginService.login(this.loginForm.value);
  }
  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'login');
      this.storyblok = story[0].content;
    });
    this.commonService.isLoggingIn.subscribe((data) => {
      this.isLoading = data;
    });
  }
  rememberme(val: any) {}
  changeLanguage() {
    localStorage.setItem('lang', this.selectedLanguage);
    const event = new CustomEvent('language.changed', {
      detail: {
        language: this.selectedLanguage,
      },
    });
    document.dispatchEvent(event);
    location.reload();
  }

  private createForm() {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      remember: false,
    });
  }
}
