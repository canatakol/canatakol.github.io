import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '../../core/http/api-request.service';
import { ResetPasswordService } from './reset-password.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import jwtDecode from 'jwt-decode';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { SetPasswordService } from '../set-password/set-password.service';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  standalone: false,
})
export class ResetPasswordComponent implements OnInit {
  signUpForm: FormGroup;
  email;
  errors = [];
  tokenValue;
  storyblok;
  pageShow = false;
  password;
  submitted = false;
  type = 'password';
  isRegex = true;
  isConfirm = true;

  constructor(
    private http: ApiRequestService,
    private route: ActivatedRoute,
    private router: Router,
    private setServise: ResetPasswordService,
    private setPasswordService: SetPasswordService,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService
  ) {
    this.tokenValue = this.route.snapshot.queryParams.token;
    try {
      const decoded = jwtDecode(this.tokenValue);
      this.email = decoded['email'];
    } catch (err) {
      this.snackBar.open(
        this.storyblok?.token_is_not_vaild_text ? this.storyblok?.token_is_not_vaild_text : 'token is not valid!',
        '',
        {
          duration: 5000,
          panelClass: ['error-snackBar'],
        }
      );
    }

    this.setServise.checkToken(this.tokenValue).subscribe((res) => {
      if (!res) {
        this.pageShow = true;
      } else {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  onSubmit() {
    const data = { token: this.tokenValue, password: this.password };
    this.setServise.setPassword(data).subscribe((res) => {
      if (!res) {
        this.router.navigate(['/login']);
      } else {
        this.snackBar.open(res, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  // tslint:disable-next-line:member-ordering
  passwordRegex(password: string, confirmedPassword: string) {
    this.errors = this.setPasswordService.passwordRegex(password, confirmedPassword, this.storyblok);
  }

  // tslint:disable-next-line:member-ordering
  isConfirmed(password: string, confirmedPassword: string) {
    this.isConfirm = this.setPasswordService.isConfirmed(password, confirmedPassword);
  }

  ngOnInit() {
    this.createForm();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'signup');
      this.storyblok = story[0].content;
    });
  }
  private createForm() {
    this.signUpForm = new FormGroup({
      password: new FormControl(null, [Validators.required]),
      confirmedPassword: new FormControl(null, [Validators.required]),
    });
  }
}
