import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '../../core/http/api-request.service';
import { ForgotService } from './forgot.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  standalone: false,
})
export class ForgotPasswordComponent implements OnInit {
  isLoading = false;
  project: string = environment.project;
  quote: string;
  storyblok;
  forgotPasswordForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    private service: ForgotService,
    private router: Router,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService
  ) {
    this.createForm();
  }

  forgotPassword() {
    fetch(environment.serverUrl + environment.services.forgottenPassword(), {
      headers: {
        'Content-Type': 'application/json',
      },
      method: 'POST',
      body: JSON.stringify({ email: this.forgotPasswordForm.value.email, project: this.project }),
    }).then((res) => {
      if (res.ok) {
        this.snackBar.open(this.storyblok.check_email, '', {
          duration: 5000,
          panelClass: ['info-snackBar'],
        });
        this.router.navigate(['/login'], { replaceUrl: true });
      }
    });
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'forgot-password');
      this.storyblok = story[0].content;
    });
  }
  private createForm() {
    this.forgotPasswordForm = this.formBuilder.group({
      email: [null, [Validators.required, Validators.email]],
    });
  }
}
