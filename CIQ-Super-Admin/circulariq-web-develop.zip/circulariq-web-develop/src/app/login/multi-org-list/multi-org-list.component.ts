import { Component, OnInit } from '@angular/core';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LoginService } from '../login.service';
import { environment } from '@env/environment';
declare var $: any;
@Component({
  selector: 'app-multi-org-list',
  templateUrl: './multi-org-list.component.html',
  styleUrls: ['./multi-org-list.component.scss'],
  standalone: false,
})
export class MultiOrgListComponent implements OnInit {
  memberships: any[] = [];
  storyblok;
  isLoading = false;
  project = environment.project;
  selectedOrgId: number | null = null;
  constructor(private loginService: LoginService, private storyblokService: StoryblokService) {
    const credentials = JSON.parse(sessionStorage.getItem('credentials'));
    this.memberships = credentials?.memberships || [];
  }
  selectOrg(org: any) {
    if (!org || !org.organisation || !org.organisation.id) {
      return;
    }
    this.selectedOrgId = org.organisation.id;
    this.isLoading = true;
    this.loginService.selectOrg(org).then((res) => {
      this.isLoading = true;
    });
  }
  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'select-organisation');
      this.storyblok = story[0].content;
    });
  }
}
