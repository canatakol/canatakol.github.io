import { Component } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MaterialsComponent } from '../../assessment-level/materials/materials.component';
import { ActivatedRoute, Router } from '@angular/router';
import { first } from 'rxjs/operators';

import { services } from '@env/services';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;
@Component({
  selector: 'app-critical-material',
  templateUrl: './critical-material.component.html',
  styleUrls: ['./critical-material.component.scss'],
  standalone: false,
})
export class CriticalMaterialComponent {
  unitId = this.route.snapshot.params.unitId;
  criticalMaterials;
  selectedCriticalGrup = 'all';
  selectedItems = [];
  criticalUSA = [];
  criticalEU = [];
  criticalAll = [];
  storyblok;
  constructor(
    private materialsComponent: MaterialsComponent,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    public storyblokService: StoryblokService,
    public router: Router,
    private route: ActivatedRoute,
    private commonService: CommonService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'critical-materials');
      this.storyblok = story[0].content;
      this.storyblok.critical_list_eu.tbody.forEach((element) => {
        this.criticalEU.push({ value: element.body[0].value, name: element.body[1].value });
      });
      this.storyblok.critical_list_all.tbody.forEach((element) => {
        this.criticalAll.push({ value: element.body[0].value, name: element.body[1].value });
      });
      this.storyblok.critical_list_usa.tbody.forEach((element) => {
        this.criticalUSA.push({ value: element.body[0].value, name: element.body[1].value });
      });
      if (this.unitId) {
        this.getCritical();
      }
    });
  }
  getCritical() {
    this.http.callService(new Method(environment.services.critical(this.unitId), '', 'get')).subscribe((res) => {
      this.criticalMaterials = res;
      this.criticalEU.forEach((element) => {
        this.criticalMaterials.forEach((item) => {
          if (element.name === item) {
            element['selected'] = true;
            this.selectedItems.push(element.name);
          }
        });
      });
      this.criticalUSA.forEach((element) => {
        this.criticalMaterials.forEach((item) => {
          if (element.name === item) {
            element['selected'] = true;
            this.selectedItems.push(element.name);
          }
        });
      });
      this.criticalAll.forEach((element) => {
        this.criticalMaterials.forEach((item) => {
          if (element.name === item) {
            element['selected'] = true;
            this.selectedItems.push(element.name);
          }
        });
      });
    });
  }
  selectItem(item: any) {
    const index = this.selectedItems.indexOf(item);
    if (index === -1) {
      this.selectedItems.push(item);
    } else {
      this.selectedItems.splice(index, 1);
    }
  }

  save() {
    this.http
      .callService(new Method(environment.services.critical(this.unitId), this.selectedItems, 'put'))
      .subscribe(async (res) => {
        this.materialsComponent.hideModal();
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        this.materialsComponent.getInflows(this.unitId, 'INFLOW', 1, 10, 'CREATION', 'ASCENDING');
      });
  }
  cancel() {
    this.materialsComponent.hideModal();
  }
}
