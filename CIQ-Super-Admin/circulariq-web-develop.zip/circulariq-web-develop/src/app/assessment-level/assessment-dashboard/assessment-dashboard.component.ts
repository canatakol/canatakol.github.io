import { Component } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
@Component({
  selector: 'app-assessment-dashboard',
  templateUrl: './assessment-dashboard.component.html',
  styleUrls: ['./assessment-dashboard.component.scss'],
  standalone: false,
})
export class AssessmentDashboardComponent {
  businessLevels = ['Select business level', 'Company level', 'Business unit', 'Product line', 'Site location'];
  scroll;
  data;
  recoveryTypeBarVersionShow = false;
  lifetimeExtension;
  isGHGShow;
  unitId = this.route.snapshot.params.unitId;
  energyBoxShow = [false, false, false, false, false, false, false, false];
  energyTooltip = false;
  waterTooltip = false;
  selectedTooltip;
  cmpBoxShow = false;
  environment = environment;
  storyblok;
  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    private router: Router,
    private route: ActivatedRoute,
    private storyblokService: StoryblokService
  ) {
    this.isGHGShow = this.commonService.isGHGShow;
    this.unitdetail();
    this.getLifetimeExtension();
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step4-dashboard');
      this.storyblok = story[0].content;
    });
  }
  unitdetail() {
    this.http.callService(new Method(environment.services.unitDetailed(this.unitId), '', 'get')).subscribe((res) => {
      this.data = res;
      this.recoveryTypeBarVersionShow = this.data['recoveryType'].breakdown.some(
        (element) => element.percentage === 100
      );
    });
  }

  getLifetimeExtension() {
    this.http
      .callService(new Method(environment.services.lifetimeExtension(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.lifetimeExtension = res;
      });
  }
  tooltipShow(idx: number) {
    this.energyBoxShow.forEach((e, i) => {
      if (i !== idx) {
        this.energyBoxShow[i] = false;
      } else {
        this.energyBoxShow[i] = true;
        setTimeout(() => {
          this.energyBoxShow[i] = false;
        }, 8 * 1000);
      }
    });
  }

  goToTheStep2(item: string) {
    this.router.navigateByUrl(`/cti/${this.unitId}/assessment/step2`, { state: { selectedProduct: item } });
  }
}
