import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, EmailValidator } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';

@Component({
  selector: 'app-new-organisation',
  templateUrl: './new-organisation.component.html',
  styleUrls: ['./new-organisation.component.scss'],
  standalone: false,
})
// tslint:disable-next-line: class-name
export class NewOrganisationComponent implements OnInit {
  isLoading = false;
  quote: string;
  credentials;
  storyblok;
  registerForm: FormGroup;
  industries = environment.services.industries;
  positions = environment.services.positions;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    public router: Router,
    private storyblokService: StoryblokService,
    private commonService: CommonService
  ) {
    this.credentials = JSON.parse(sessionStorage.getItem('credentials'));
    this.createForm();
  }

  register() {
    this.http
      .callService(new Method(environment.services.organisationDetails(), this.registerForm.value, 'put'))
      .subscribe((res) => {
        if (this.commonService.isPro) {
          if (this.credentials && this.credentials['showBLDashboard']) {
            this.router.navigate(['/cti/pro-business'], { replaceUrl: true });
          } else {
            this.router.navigate(['/cti/pro-label'], { replaceUrl: true });
          }
        } else {
          this.router.navigate(['/cti/none/assessment/step1'], { replaceUrl: true });
        }
      });
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'new-organisation');
      this.storyblok = story[0].content;
    });
  }
  private createForm() {
    const companyName =
      this.credentials && this.credentials['organisation'] && this.credentials['organisation']['name']
        ? this.credentials['organisation']['name']
        : '';
    this.registerForm = this.formBuilder.group({
      companyName: [companyName, Validators.required],
      industry: ['Agriculture, forestry and fishing', Validators.required],
      industryOther: [''],
      position: ['Materials extraction and agriculture', Validators.required],
      positionOther: [''],
      address: ['', Validators.required],
      revenue: [''],
      currenctType: ['€'],
    });
  }
}
