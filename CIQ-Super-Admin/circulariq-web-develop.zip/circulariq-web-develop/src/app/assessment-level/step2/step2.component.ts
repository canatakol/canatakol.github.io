import { Component, OnDestroy } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { Location } from '@angular/common';
import { ActivatedRoute, NavigationExtras, NavigationStart, Router, Event } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-step2',
  templateUrl: './step2.component.html',
  styleUrls: ['./step2.component.scss'],
  standalone: false,
})
export class Step2Component implements OnDestroy {
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  dirtyData;
  redirectUrl;
  data;
  unitId = this.route.snapshot.params.unitId;
  isGHGShow;
  storyblok;
  isDupplicateShow = false;
  isDuplicate;
  isPro = false;
  isUnderstand = false;
  ctiUnitGuidance;
  selectedProduct;
  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    public router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService
  ) {
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
    this.isPro = this.commonService.isPro;

    this.getIndicators();
    const local = this.location.getState();
    this.selectedProduct = local['selectedProduct'] || null;
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step2');
      this.storyblok = story[0].content;
    });
    const unit = this.commonService.selectedUnit;
    if (unit) {
      this.isDuplicate = unit.duplicate;
    }
    this.isGHGShow = this.commonService.isGHGShow;
    this.isPro = this.commonService.isPro;

    this.isUnderstand = JSON.parse(sessionStorage.getItem('ctiUnitGuidance')).step2;
    this.isDupplicateShow = !this.ctiUnitGuidance?.step2 && this.isDuplicate && !this.isUnderstand ? true : false;
  }
  changeData() {
    this.dirtyData = true;
  }
  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.saveStep2(this.data);
    } else {
      this.getIndicators();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
  }
  understandEvent() {
    this.isDupplicateShow = false;
    this.isUnderstand = true;
    this.saveStep2(this.data);
    this.router.navigate([`/cti/${this.unitId}/assessment/step3/materials`]);
  }
  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
  }
  async getIndicators() {
    await this.http
      .callService(new Method(environment.services.getIndicators(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.ctiUnitGuidance = JSON.parse(sessionStorage.getItem('ctiUnitGuidance'));
      });
  }
  saveStep2(data: any) {
    this.blockNavigation = false;
    this.dirtyData = false;
    this.http.callService(new Method(environment.services.getIndicators(this.unitId), data, 'put')).subscribe((res) => {
      sessionStorage.setItem('indicators', JSON.stringify(data));
      this.commonService.refreshUnitGuindance(this.unitId);
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
      // this.router.navigate([`/cti/${this.unitId}/assessment/step3`]);
    });
  }
}
