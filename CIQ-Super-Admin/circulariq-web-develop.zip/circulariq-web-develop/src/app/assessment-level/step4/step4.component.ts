import { Component, Input, OnInit } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { map } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';
declare var require: any;
@Component({
  selector: 'app-step4',
  templateUrl: './step4.component.html',
  styleUrls: ['./step4.component.scss'],
  standalone: false,
})
export class Step4Component {
  @Input() public storyblok: any;
  unitId = this.route.snapshot.params.unitId;
  authToken;
  data;
  fileUrl;
  reportData;
  constructor(
    private commonService: CommonService,
    private dialog: MatDialog,
    private https: ApiRequestService,
    private snackBar: MatSnackBar,
    public router: Router,
    private route: ActivatedRoute
  ) {
    this.data = this.commonService.selectedUnit;
    this.authToken = JSON.parse(sessionStorage.getItem('credentials')).authToken;
  }

  reportStatus() {
    window.open(`/cti/${this.unitId}/${this.authToken}/report`);
    // this.https.callService(new Method(environment.services.reportStatus(this.unitId), '', 'get')).subscribe((res) => {
    //   if (res['canDownload']) {
    //     if (res['warningMessage']) {
    //       const dialogRef = this.dialog.open(ReportStatusDialog, {
    //         width: '80%',
    //         maxWidth: '430px',
    //         panelClass: 'centered-dialog',
    //         data: {
    //           message: res['warningMessage'],
    //         },
    //       });
    //       dialogRef.afterClosed().subscribe(async (result) => {
    //         if (!result) {
    //           return;
    //         }
    //         try {
    //           window.open(`/cti/${this.unitId}/${this.authToken}/report`);
    //         } catch (error) {}
    //       });
    //     } else {
    //       window.open(`/cti/${this.unitId}/${this.authToken}/report`);
    //     }
    //   } else {
    //     this.snackBar.open(res['warningMessage'], '', {
    //       duration: 5000,
    //       panelClass: ['error-snackBar'],
    //     });
    //   }
    // });
  }

  exportCsv() {
    const token = JSON.parse(sessionStorage.getItem('credentials')).authToken;

    fetch(environment.serverUrl + environment.services.unitExport(this.unitId), {
      headers: {
        'x-auth-token': token,
      },
      method: 'GET',
    })
      .then((response) => {
        if (response.status !== 200) {
          throw response.json();
        }
        return response.arrayBuffer();
      })
      .then((buffer) => {
        const FileSaver = require('file-saver');
        const unit_name = this.data ? this.data['name'] : 'business level';
        const reportName = unit_name + ' export.csv';
        const file = new File([buffer], reportName, { type: 'text/csv' });
        FileSaver.saveAs(file);
      });
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.https.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
}
