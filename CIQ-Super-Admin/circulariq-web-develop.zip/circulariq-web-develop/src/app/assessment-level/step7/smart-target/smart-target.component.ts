import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { Step7DownloadReportDialog } from '@app/shared/dialog/step7-download-report/step7-download-report-dialog.component';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';

@Component({
  selector: 'app-smart-target',
  templateUrl: './smart-target.component.html',
  styleUrls: ['./smart-target.component.scss'],
  standalone: false,
})
export class SmartTargetComponent implements OnInit {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  isPatica = false;
  showData = false;
  data;
  pureData;
  authToken;
  unitId = this.route.snapshot.params.unitId;
  alphabet = 'abcdefghijklmnopqrstuvwxyz'.split('');
  mock = {
    text: '',
    what: [
      {
        whatItem: '',
      },
    ],
    when: [
      {
        whenItem: '',
      },
    ],
    who: [
      {
        whoItem: '',
      },
    ],
    departments: [
      {
        departmentItem: '',
      },
    ],
    others: [
      {
        otherItem: '',
      },
    ],
    considerations: [
      {
        considerationItem: '',
      },
    ],
  };
  smartTagetForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    public router: Router,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private route: ActivatedRoute
  ) {}
  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.onSubmit();
    } else {
      this.ngOnInit();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }
  ngOnInit(): void {
    this.smartTagetForm = this.fb.group({
      targets: this.fb.array([]),
    });
    setTimeout(() => {
      this.smartTagetForm.valueChanges.subscribe((res) => {
        this.dirtyData = true;
        this.tabSaveResponse.emit(true);
      });
    }, 1000);
    this.getData();
  }
  getData() {
    this.data = '';
    this.http
      .callService(new Method(environment.services.step7SamartTarget(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.showData = true;
        this.setTargets();
      });
    this.authToken = JSON.parse(sessionStorage.getItem('credentials')).authToken;
  }

  addNewTarget() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const control = <FormArray>this.smartTagetForm.controls.targets;
    control.push(
      this.fb.group({
        text: [''],
        what: this.setwhat(this.mock),
        when: this.setwhen(this.mock),
        who: this.setwho(this.mock),
        departments: this.setdepartment(this.mock),
        others: this.setother(this.mock),
        considerations: this.setconsideration(this.mock),
      })
    );
  }

  deleteTarget(index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const control = <FormArray>this.smartTagetForm.controls.targets;
    control.removeAt(index);
  }

  addNewWhat(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        whatItem: [''],
      })
    );
  }

  deleteWhat(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }

  addNewWhen(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        whenItem: [''],
      })
    );
  }
  deleteWhen(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }
  addNewWho(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        whoItem: [''],
      })
    );
  }
  deleteWho(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }

  addNewDepartment(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        departmentItem: [''],
      })
    );
  }

  deleteDepartment(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }

  addNewOther(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        otherItem: [''],
      })
    );
  }

  deleteOther(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }

  addNewConsideration(control: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.push(
      this.fb.group({
        considerationItem: [''],
      })
    );
  }

  deleteConsideration(control: any, index: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    control.removeAt(index);
  }

  setTargets() {
    const control = <FormArray>this.smartTagetForm.controls.targets;
    this.data.targets.forEach((x) => {
      control.push(
        this.fb.group({
          text: x.text,
          what: this.setwhat(x),
          when: this.setwhen(x),
          who: this.setwho(x),
          departments: this.setdepartment(x),
          others: this.setother(x),
          considerations: this.setconsideration(x),
        })
      );
    });
  }

  setwhen(x: any) {
    const arr = new FormArray([]);
    x.when.forEach((y) => {
      arr.push(
        this.fb.group({
          whenItem: y.whenItem,
        })
      );
    });
    return arr;
  }
  setwhat(x: any) {
    const arr = new FormArray([]);
    x.what.forEach((y) => {
      arr.push(
        this.fb.group({
          whatItem: y.whatItem,
        })
      );
    });
    return arr;
  }
  setwho(x: any) {
    const arr = new FormArray([]);
    x.who.forEach((y) => {
      arr.push(
        this.fb.group({
          whoItem: y.whoItem,
        })
      );
    });
    return arr;
  }

  setdepartment(x: any) {
    const arr = new FormArray([]);
    x.departments.forEach((y) => {
      arr.push(
        this.fb.group({
          departmentItem: y.departmentItem,
        })
      );
    });
    return arr;
  }
  setother(x: any) {
    const arr = new FormArray([]);
    x.others.forEach((y) => {
      arr.push(
        this.fb.group({
          otherItem: y.otherItem,
        })
      );
    });
    return arr;
  }
  setconsideration(x: any) {
    const arr = new FormArray([]);
    x.considerations.forEach((y) => {
      arr.push(
        this.fb.group({
          considerationItem: y.considerationItem,
        })
      );
    });
    return arr;
  }

  onSubmit() {
    this.http
      .callService(new Method(environment.services.step7SamartTarget(this.unitId), this.smartTagetForm.value, 'put'))
      .subscribe((res) => {
        this.flowComplate('CTI_STEP7_DONE');
        this.flowComplate('CTI_STEP7_TARGETS');
        const dialogRef = this.dialog.open(Step7DownloadReportDialog, {
          width: '80%',
          maxWidth: '600px',
          panelClass: 'centered-dialog',
          data: this.unitId,
        });
        dialogRef.afterClosed().subscribe(async (result) => {
          if (!result) {
            return;
          }
          try {
            this.reportStatus(this.unitId);
          } catch (error) {}
        });
      });
  }

  reportStatus(unitId: any) {
    this.http.callService(new Method(environment.services.reportStatus(unitId), '', 'get')).subscribe((res) => {
      if (res['canDownload']) {
        if (res['warningMessage']) {
          const dialogRef = this.dialog.open(ReportStatusDialog, {
            width: '80%',
            maxWidth: '430px',
            panelClass: 'centered-dialog',
            data: {
              message: res['warningMessage'],
            },
          });
          dialogRef.afterClosed().subscribe(async (result) => {
            if (!result) {
              return;
            }
            try {
              window.open(`/cti/${unitId}/${this.authToken}/report`);
            } catch (error) {}
          });
        } else {
          window.open(`/cti/${unitId}/${this.authToken}/report`);
        }
      } else {
        this.snackBar.open(res['warningMessage'], '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
}
