import { Component, OnDestroy } from '@angular/core';
import { NavigationExtras, NavigationStart, Router, Event } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-step7',
  templateUrl: './step7.component.html',
  styleUrls: ['./step7.component.scss'],
  standalone: false,
})
export class Step7Component implements OnDestroy {
  activeCase7 = 'smartTarget';
  isShowstep7Intro;
  storyblok;
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  dirtyData = false;
  redirectUrl;
  constructor(private commonService: CommonService, private storyblokService: StoryblokService, public router: Router) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step7');
      this.storyblok = story[0].content;
    });
    this.commonService.step7ActiveCase.next('smartTarget');
    this.isShowstep7Intro = localStorage.getItem('isShowstep7Intro');
    this.commonService.step7ActiveCase.subscribe((res) => {
      this.activeCase7 = res;
    });
    this.commonService.isShowstep7Intro.subscribe((res) => {
      this.isShowstep7Intro = res;
    });
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
  }
  async tabSaveResponse(value: boolean) {
    this.dirtyData = value;
  }
  tabClick(value: boolean) {
    this.blockNavigation = value;
  }
  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
  }
}
