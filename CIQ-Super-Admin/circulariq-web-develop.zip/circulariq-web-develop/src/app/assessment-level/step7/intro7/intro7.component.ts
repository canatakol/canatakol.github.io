import { Component, Input } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '@env/environment';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { storyblokInit, renderRichText } from '@storyblok/js';
@Component({
  selector: 'app-intro7',
  templateUrl: './intro7.component.html',
  styleUrls: ['./intro7.component.scss'],
  standalone: false,
})
export class Intro7Component {
  @Input() public storyblok: any;
  sanitizedContent: SafeHtml | null = null;
  remember: boolean | null = null;
  unitId = this.route.snapshot.params.unitId;
  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    public router: Router,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer
  ) {
    this.commonService.step7ActiveCase.next('step7Intro');
  }
  async ngOnChanges() {
    if (this.storyblok && this.storyblok.content) {
      try {
        const storyblokApi = storyblokInit();
        const htmlContent = renderRichText(this.storyblok.content);
        this.sanitizedContent = this.sanitizer.bypassSecurityTrustHtml(htmlContent);
      } catch (error) {
        console.error(error);
      }
    }
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
  nextStep() {
    this.flowComplate('CTI_STEP7_INTRO');
    localStorage.setItem('isShowstep7Intro', String(this.remember));
    this.commonService.isShowstep7Intro.next('true');
    this.commonService.step7ActiveCase.next('smartTarget');
  }
  rememberme(val: boolean) {
    this.remember = val;
  }
}
