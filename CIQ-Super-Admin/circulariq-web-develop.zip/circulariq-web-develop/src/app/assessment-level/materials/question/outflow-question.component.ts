import {
  Component,
  Input,
  OnChanges,
  SimpleChanges,
  AfterViewChecked,
  OnInit,
  EventEmitter,
  Output,
} from '@angular/core';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ActualRecoveryRatetDialog } from '@app/shared/dialog/actual-recovery-rate/actual-recovery-rate-dialog.component';
import { ChangeDetectorRef } from '@angular/core';
import { MaterialsComponent } from '../materials.component';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { AddAssessmentDialog } from '@app/shared/dialog/add-assessment/add-assessment.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
declare var $: any;

@Component({
  selector: 'app-outflow-question',
  templateUrl: './outflow-question.component.html',
  styleUrls: ['./question.component.scss'],
  standalone: false,
})
export class OutflowQuestionComponent implements OnChanges, AfterViewChecked, OnInit {
  @Input() public selectedFlow: string;
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() public showBoxResponse: EventEmitter<any> = new EventEmitter();
  @Output() setResponsibleUsers = new EventEmitter<any>();
  dirtyData = false;
  newRecoveryScenarioShow = false;
  totalMassArray = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  secondaryRecoveryShow = false;
  questions = [];
  technical = [];
  biological = [];
  foodAndFeed = [];
  possibleRecoveryTypes = [];
  isEmptyTI5;
  unitId = this.route.snapshot.params.unitId;
  storyblokGuidance;
  totalValue;
  indicators;
  isGHGShow;
  selectedPercentage;
  SelectApplication = 'Select Recovery rate source application';
  questionnaireId;
  controls;
  showForm = false;
  TI62SetingsShow = false;
  TI67SetingsShow = false;
  TI72SetingsShow = false;
  TI77SetingsShow = false;
  TI46Readonly = false;
  materialType;
  flowId;
  form: FormGroup;
  showTest;
  answers;
  nameAvailable = true;
  currentName;
  baseQuestionList = [];
  actualRecoveryRates = environment.services.actualRecoveryRates;
  isLoading = false;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private cdRef: ChangeDetectorRef,
    public storyblokService: StoryblokService,
    public materialsComponent: MaterialsComponent,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokGuidance = {
        name: data.filter((item) => item.uuid === '6dd82a43-54e6-4fb7-a5fa-a85b7195bb3e')[0].content,
        mass: data.filter((item) => item.uuid === '7cc9dc10-93f1-42f1-b143-cdf5af3f350e')[0].content,
        recoveryPotentia: data.filter((item) => item.uuid === 'cd0b107c-0fe0-473a-8c41-e5c32e24b37c')[0].content,
        flowType: data.filter((item) => item.uuid === 'bb75293e-2537-4326-a59e-b011df53eb7b')[0].content,
        actualRecovery: data.filter((item) => item.uuid === '4fcfe341-f256-4af3-aed2-78be7f89b663')[0].content,
        ghgOutflowImpact: data.filter((item) => item.uuid === '1908847c-617f-4350-80c6-b397b22fa10b')[0].content,
      };
    });
    this.credentials?.organisation?.features.forEach((element) => {
      if (element === 'secondary_recovery') {
        this.secondaryRecoveryShow = true;
      }
    });
  }
  changeData(value: boolean) {
    this.dirtyData = value;
    this.showBoxResponse.emit(value);
  }
  openGuidanceEvent(slug: any) {
    this.commonService.mainGuidanceData.next({ show: true, active: 'datapoint', slug: slug });
  }
  async reset() {
    this.changeData(false);
    await this.materialsComponent.closeDetail();
    await this.delay(1);
    await this.materialsComponent.showDetail(this.selectedFlow, 'OUTFLOW');
  }
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  baseQuestion() {
    const outflowQuestions = [
      'TI10',
      'M18',
      'TI4',
      'TI5',
      'TI6',
      'TI12',
      'TI19',
      'TI21',
      'TI20',
      'TI11',
      'TI24',
      'TI26',
      'TI30',
      'TI25',
      'TI38',
      'TI39',
      'TI40',
      'TI41',
      'TI42',
      'TI43',
      'TI44',
      'TI45',
      'TI46',
      'TI47',
      'TI48',
      'TI49',
      'TI50',
      'TI51',
      'TI52',
      'TI53',
      'TI54',
      'TI55',
      'TI56',
      'TI57',
      'TI58',
      'TI60',
      'TI61',
      'TI62',
      'TI63',
      'TI64',
      'TI65',
      'TI66',
      'TI67',
      'TI68',
      'TI69',
      'TI70',
      'TI71',
      'TI72',
      'TI73',
      'TI74',
      'TI75',
      'TI76',
      'TI77',
      'TI78',
      'TI79',
      'TI80',
      'TI81',
    ];
    const questionList = this.localStorageService.getCompressedSessionItem('questionList');
    questionList.forEach((question) => {
      outflowQuestions.forEach((code) => {
        if (question.code === code) {
          this.baseQuestionList.push(question);
        }
      });
    });
    this.baseQuestionList.forEach((element) => {
      if (element.code === 'TI11') {
        element.options.forEach((o) => {
          if (o.value === 'landfillMixed') {
            o.potential = ['0'];
          }
          if (o.value === 'nutrientAbsorption' || o.value === 'biogasRecovery') {
            o.potential = ['50'];
          }
          if (o.value === 'consumptionAlternative' || o.value === 'consumption') {
            o.potential = ['100'];
          }
          if (
            o.value === 'reUse' ||
            o.value === 'repairRefurbish' ||
            o.value === 'repurposeRemanufacture' ||
            o.value === 'recycle' ||
            o.value === 'incineration' ||
            o.value === 'landfillMixed'
          ) {
            this.technical.push(o);
          }
          if (
            o.value === 'reUse' ||
            o.value === 'repairRefurbish' ||
            o.value === 'repurposeRemanufacture' ||
            o.value === 'recycle' ||
            o.value === 'incineration' ||
            o.value === 'landfillMixed' ||
            o.value === 'nutrientAbsorption' ||
            o.value === 'biogasRecovery'
          ) {
            this.biological.push(o);
          }
          if (
            o.value === 'consumption' ||
            o.value === 'consumptionAlternative' ||
            o.value === 'incineration' ||
            o.value === 'landfillMixed' ||
            o.value === 'nutrientAbsorption' ||
            o.value === 'biogasRecovery'
          ) {
            this.foodAndFeed.push(o);
          }
        });
      }
    });
  }

  public ngOnChanges(changes: SimpleChanges) {
    if (changes.selectedFlow) {
      if (changes.selectedFlow.currentValue.flowId !== this.flowId) {
        this.unitdetail();
        this.showForm = false;
        const id = changes.selectedFlow.currentValue.id;
        this.flowId = changes.selectedFlow.currentValue.flowId;
        this.materialType = this.commonService.materialType;
        this.isGHGShow = this.commonService.isGHGShow;
        this.getSummary(this.flowId);
      }
    }
  }
  unitdetail() {
    this.http.callService(new Method(environment.services.getIndicators(this.unitId), '', 'get')).subscribe((res) => {
      this.indicators = res;
    });
  }
  getSummary(flowId: any) {
    this.http.callService(new Method(environment.services.getFlowDetail(flowId), '', 'get')).subscribe((res) => {
      this.questionnaireId = res['questionnaire']['questionnaireId'];
      this.getAnswers(this.questionnaireId);
      this.setResponsibleUsers.emit(res);
    });
  }

  getAnswers(id: string) {
    localStorage.setItem('questionId', id);
    this.http.callService(new Method(environment.services.answers(id), '', 'get')).subscribe((res) => {
      this.answers = [];
      this.answers = res;
      this.filterQuestion();
    });
  }
  ngAfterViewChecked() {
    this.cdRef.detectChanges();
  }

  ngOnInit(): void {
    this.baseQuestion();
  }

  setTI5Value(val: any) {
    if (val === 'landfillMixed' || val === 'incineration' || !val) {
      for (const [key, q] of Object.entries(this.questions)) {
        if (q.code === 'TI5') {
          q.value = ['0'];
        }
      }
    }
  }

  filterQuestion() {
    this.questions = [];
    this.controls = {};
    this.baseQuestionList.forEach((b) => {
      b.value = [''];
      b.evidenceFiles = [''];
      this.questions.push(b);
    });
    this.answers.forEach((a) => {
      this.questions.forEach((q) => {
        if (a.code === q.code) {
          q.value = a.value;
          q.evidenceFiles = a.evidenceFiles;
          if (q.evidenceFiles.length > 0) {
            if (q.evidenceFiles[0].fileName) {
              q.imgpath = `${environment.serverUrl}/assets/download/${q.evidenceFiles[0].fileName}`;
              q.fileType = q.evidenceFiles[0].fileName.split('.')[1];
            }
          }
        }
      });
    });
    this.questions = this.questions.reduce((acc, item) => {
      acc[item.code] = {
        ...item,
      };
      return acc;
    }, {});
    this.generateForm();
  }

  async generateForm() {
    this.calaculateTotalMass();
    this.showForm = false;
    for (const [key, q] of Object.entries(this.questions)) {
      this.currentName = this.questions['M18'].value[0];
      if (q.code === 'TI10') {
        this.questions['TI26'].isShow = this.indicators?.['actualLifetime'] && q.value[0] === 'product' ? true : false;
      }
      if (q.code === 'TI38') {
        this.newRecoveryScenarioShow = q.value[0] === 'Yes' ? true : false;
      }
      if (q.code === 'TI11') {
        this.questions['TI11'].isShow = this.indicators?.['recoveryType'] ? true : false;
        if (q.value[0] === '') {
          this.questions['TI5'].value = ['0'];
        }
      }
      if (q.code === 'TI12') {
        if (q.value[0] === 'technical' && this.isGHGShow && this.indicators?.['greenhouseGases']) {
          this.questions['TI30'].isShow = true;
        } else {
          this.questions['TI30'].isShow = false;
        }
      }
      if (q.code === 'TI21') {
        if (q.value[0] !== 'Yes') {
          q.realValue = false;
          this.questions['TI20'].isShow = false;
        } else {
          q.realValue = true;
          this.questions['TI20'].isShow = true;
        }
      }
      if (q.code === 'TI4') {
        q.value[0] = q.value[0] === '' ? null : q.value[0];
      }
      if (q.code === 'TI5') {
        q.value[0] = q.value[0] === '' ? null : q.value[0];
      }
      if (q.code === 'TI20') {
        this.selectedPercentage = q.value;
      }
      if (q.code === 'TI19') {
        if (q.value) {
          this.SelectApplication = q.value;
        } else {
          this.SelectApplication = 'Select Recovery rate source application';
        }
      }
      q.documentation = '';
      q.verification = '';
      if (q.evidenceFiles) {
        if (q.evidenceFiles.length > 0) {
          q.evidenceFiles.reverse().forEach((element) => {
            if (element.s3FileUuid) {
              q.documentation = element.s3FileUuid;
            }
            if (element.description) {
              q.verification = element.description;
            }
          });
        }
      }
      this.controls[q.code] = new FormControl(false);
    }
    this.form = this.fb.group({
      questionnaire: this.fb.group(this.controls),
    });
    for (const [key, element] of Object.entries(this.questions)) {
      if (element.code === 'TI12') {
        this.possibleRecoveryTypes = this.baseQuestionList.filter((item) => item.code === 'TI11')[0].options;
        switch (element.value[0]) {
          case 'technical':
            this.possibleRecoveryTypes = this.technical;
            break;
          case 'foodAndFeed':
            this.possibleRecoveryTypes = this.foodAndFeed;
            break;
          case 'biological':
            this.possibleRecoveryTypes = this.biological;
            break;
          default:
            break;
        }
      }
      if (element.code === 'TI11') {
        const setPercentage = element.options.filter((o) => o.value === element.value[0]);
      }
    }
    this.showForm = true;

    await setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        for (const [key, value] of Object.entries(res.questionnaire)) {
          if (key === 'TI10') {
            this.questions['TI26'].isShow = this.indicators?.['actualLifetime'] && value === 'product' ? true : false;
          }
          if (key === 'TI21') {
            this.questions['TI20'].isShow = value;
          }
        }
        this.dirtyData = true;
        this.showBoxResponse.emit(true);
      });
    }, 1000);
  }

  addCustomStrategy() {
    const dialogRef = this.dialog.open(AddAssessmentDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: this.storyblok.new_custom_strategy,
        description: this.storyblok.name_strategy,
        required: this.storyblok.name_required,
        placeholder: this.storyblok.custom_strategy_placeholder,
        button: this.storyblok.custom_strategy_button,

        type: 'customStrategy',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        if (this.questions['TI62'].value[0] === '' || this.questions['TI62'].value[0] === 'false') {
          this.form.value.questionnaire.TI62 = result;
          this.questions['TI62'].value[0] = result;
          return;
        }
        if (
          (this.questions['TI62'].value[0] !== '' || this.questions['TI62'].value[0] !== 'false') &&
          (this.questions['TI67'].value[0] === '' || this.questions['TI67'].value[0] === 'false')
        ) {
          this.form.value.questionnaire.TI67 = result;
          this.questions['TI67'].value[0] = result;
          return;
        }
        if (
          (this.questions['TI62'].value[0] !== '' || this.questions['TI62'].value[0] !== 'false') &&
          (this.questions['TI67'].value[0] !== '' || this.questions['TI67'].value[0] !== 'false') &&
          (this.questions['TI72'].value[0] === '' || this.questions['TI72'].value[0] === 'false')
        ) {
          this.form.value.questionnaire.TI72 = result;
          this.questions['TI72'].value[0] = result;
          return;
        }
        if (
          (this.questions['TI62'].value[0] !== '' || this.questions['TI62'].value[0] !== 'false') &&
          (this.questions['TI67'].value[0] !== '' || this.questions['TI67'].value[0] !== 'false') &&
          (this.questions['TI72'].value[0] !== '' || this.questions['TI72'].value[0] !== 'false') &&
          (this.questions['TI77'].value[0] === '' || this.questions['TI77'].value[0] === 'false')
        ) {
          this.form.value.questionnaire.TI77 = result;
          this.questions['TI77'].value[0] = result;
          return;
        }
        this.calaculateTotalMass();
      } catch (error) {}
    });
  }
  editStrategy(item: any) {
    this.TI62SetingsShow = false;
    this.TI67SetingsShow = false;
    this.TI72SetingsShow = false;
    this.TI77SetingsShow = false;
    const dialogRef = this.dialog.open(AddAssessmentDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: this.storyblok.edit_custom_strategy,
        description: this.storyblok.name_strategy,
        required: this.storyblok.name_required,
        placeholder: this.storyblok.custom_strategy_placeholder,
        button: this.storyblok.custom_strategy_edit_button,
        name: item.value[0],
        type: 'customStrategy',
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }
      try {
        this.changeData(true);
        if (item.code === 'TI62') {
          this.form.value.questionnaire.TI62 = result;
          this.questions['TI62'].value[0] = result;
        }
        if (item.code === 'TI67') {
          this.form.value.questionnaire.TI67 = result;
          this.questions['TI67'].value[0] = result;
        }
        if (item.code === 'TI72') {
          this.form.value.questionnaire.TI72 = result;
          this.questions['TI72'].value[0] = result;
        }
        if (item.code === 'TI77') {
          this.form.value.questionnaire.TI77 = result;
          this.questions['TI77'].value[0] = result;
        }
      } catch (error) {}
    });
  }

  deleteStrategy(item: any) {
    this.TI62SetingsShow = false;
    this.TI67SetingsShow = false;
    this.TI72SetingsShow = false;
    this.TI77SetingsShow = false;
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${this.storyblok.delete_strategy_modal_title}  ${item.value[0]}`,
        message: this.storyblok.delete_strategy_modal_message,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.changeData(true);
        if (item.code === 'TI62') {
          this.questions['TI62'].value[0] = '';
          this.questions['TI63'].value[0] = '';
          this.questions['TI64'].value[0] = '';
          this.questions['TI65'].value[0] = '';
          this.questions['TI66'].value[0] = '';
          this.form.value.questionnaire.TI62 = '';
          this.form.value.questionnaire.TI63 = '';
          this.form.value.questionnaire.TI64 = '';
          this.form.value.questionnaire.TI65 = '';
          this.form.value.questionnaire.TI66 = '';
        }
        if (item.code === 'TI67') {
          this.questions['TI67'].value[0] = '';
          this.questions['TI68'].value[0] = '';
          this.questions['TI69'].value[0] = '';
          this.questions['TI70'].value[0] = '';
          this.questions['TI71'].value[0] = '';
          this.form.value.questionnaire.TI67 = '';
          this.form.value.questionnaire.TI68 = '';
          this.form.value.questionnaire.TI69 = '';
          this.form.value.questionnaire.TI70 = '';
          this.form.value.questionnaire.TI71 = '';
        }
        if (item.code === 'TI72') {
          this.questions['TI72'].value[0] = '';
          this.questions['TI73'].value[0] = '';
          this.questions['TI74'].value[0] = '';
          this.questions['TI75'].value[0] = '';
          this.questions['TI76'].value[0] = '';
          this.form.value.questionnaire.TI72 = '';
          this.form.value.questionnaire.TI73 = '';
          this.form.value.questionnaire.TI74 = '';
          this.form.value.questionnaire.TI75 = '';
          this.form.value.questionnaire.TI76 = '';
        }
        if (item.code === 'TI77') {
          this.questions['TI77'].value[0] = '';
          this.questions['TI78'].value[0] = '';
          this.questions['TI79'].value[0] = '';
          this.questions['TI80'].value[0] = '';
          this.questions['TI81'].value[0] = '';
          this.form.value.questionnaire.TI77 = '';
          this.form.value.questionnaire.TI78 = '';
          this.form.value.questionnaire.TI79 = '';
          this.form.value.questionnaire.TI80 = '';
          this.form.value.questionnaire.TI81 = '';
        }

        this.calaculateTotalMass();
      } catch (error) {}
    });
  }
  openModel(item: string) {
    if (item === 'TI46' && this.TI46Readonly) {
      this.form.value.questionnaire.TI46 = '';
      this.questions['TI46'].value[0] = '';
      this.TI46Readonly = false;
      return;
    }
    const dialogRef = this.dialog.open(ActualRecoveryRatetDialog, {
      width: '80%',
      maxWidth: '700px',
      height: '500px',
      panelClass: 'centered-dialog',
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.changeData(true);
        this.selectedPercentage = result.percentage;
        for (const [key, q] of Object.entries(this.questions)) {
          if (item === 'TI5') {
            if (q.code === 'TI5') {
              q.value = [this.selectedPercentage];
            }
          }
          if (item === 'TI46') {
            if (q.code === 'TI46') {
              q.value = [this.selectedPercentage];
              this.TI46Readonly = true;
            }
          }
        }
        this.SelectApplication = result.name;
      } catch (error) {}
    });
  }

  calaculateTotalMass() {
    const calculateArray = [
      'TI39',
      'TI42',
      'TI45',
      'TI47',
      'TI50',
      'TI52',
      'TI54',
      'TI56',
      'TI58',
      'TI60',
      'TI63',
      'TI68',
    ];
    calculateArray.forEach((code, index) => {
      this.totalMassArray[index] = 0;
      const question = this.questions[code];
      if (question && question.value?.[0]) {
        this.totalMassArray[index] = Number(question.value[0]) || 0;
      }
    });

    calculateArray.forEach((element, index) => {
      this.maxValueWithTotal(this.questions[element], index, false);
    });
  }

  maxValueWithTotal(item: any, index: any, changeData: boolean) {
    this.totalMassArray[index] = Number(item.value[0] > 0 ? item.value[0] : 0);
    const totalSum: number = this.totalMassArray.reduce((a, b) => a + b, 0);
    const allowedPercentage = 100;
    if (totalSum > allowedPercentage) {
      this.totalMassArray[index] = allowedPercentage - (totalSum - this.totalMassArray[index]);
    }
    if (this.totalMassArray[index] < 0) {
      this.totalMassArray[index] = 0;
    }
    item.value[0] = this.totalMassArray[index];
    this.questions['TI61'].value[0] = 100 - totalSum < 0 ? 0 : 100 - totalSum;
    if (changeData) {
      this.changeData(true);
    }
  }
  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.flowNameCheck(this.unitId, 'OUTFLOW'), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
          this.nameAvailable =
            this.currentName.trim().toLowerCase() === name.trim().toLowerCase() ? true : this.nameAvailable;
          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }
  maxValue(item: any, max: any) {
    if (item.value[0] > max) {
      item.value[0] = max;
    }
    if (item.value[0] < 0) {
      item.value[0] = 0;
    }
    this.changeData(true);
  }

  maxValueFake(item: any, max: any) {
    if (item.massValue[1] > max) {
      item.massValue[1] = max;
    }
  }

  cycleTypeChangeEvent(q: any) {
    this.changeData(true);
    if (q.code === 'TI19') {
      this.questions.forEach((element) => {
        if (element.code === 'TI5') {
          element.value = [this.actualRecoveryRates[q.value]];
        }
      });
    }
    if (q.code === 'TI12') {
      this.questions['TI30'].isShow = false;
      switch (q.value[0]) {
        case 'technical':
          this.possibleRecoveryTypes = this.technical;
          if (this.isGHGShow && this.indicators?.['greenhouseGases']) {
            this.questions['TI30'].isShow = true;
          }
          break;
        case 'foodAndFeed':
          this.possibleRecoveryTypes = this.foodAndFeed;
          break;
        default:
          this.possibleRecoveryTypes = this.biological;

          break;
      }
      this.form.value.questionnaire.TI11 = '';
      this.questions['TI11'].value[0] = '';
      this.resetTableData();
      this.calaculateTotalMass();
    }
  }

  resetTableData() {
    const questionKeys = [
      'TI39',
      'TI40',
      'TI41',
      'TI42',
      'TI43',
      'TI44',
      'TI45',
      'TI46',
      'TI47',
      'TI48',
      'TI49',
      'TI50',
      'TI51',
      'TI52',
      'TI53',
      'TI54',
      'TI55',
      'TI56',
      'TI57',
      'TI58',
      'TI60',
      'TI63',
      'TI64',
      'TI65',
      'TI66',
      'TI68',
      'TI69',
      'TI70',
      'TI71',
      'TI72',
      'TI73',
      'TI74',
      'TI75',
      'TI76',
      'TI77',
      'TI78',
      'TI79',
      'TI80',
      'TI81',
    ];

    // Formdaki soru değerlerini sıfırla
    questionKeys.forEach((key) => {
      if (this.form.value.questionnaire[key] !== undefined) {
        this.form.value.questionnaire[key] = '';
      }
    });

    // Question değerlerini sıfırla
    questionKeys.forEach((key) => {
      if (this.questions[key]?.value?.[0] !== undefined) {
        this.questions[key].value[0] = '';
      }
    });
  }

  saveForm(isPublish: boolean) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const formatForService = (v: any): string => {
      if (v === undefined || v === null) {
        return '';
      }
      const str = String(v);
      // Remove thousand separators (commas) if present
      const noThousands = str.replace(/,/g, '');
      // If numeric or numeric with dot/comma decimals, keep dot as decimal (service side can parse)
      if (/^-?\d+([.,]\d+)?$/.test(noThousands)) {
        // normalize comma decimal to dot for numeric transport
        return noThousands.replace(',', '.');
      }
      return noThousands;
    };
    this.changeData(false);
    this.blockNavigation = false;
    const data = {};
    this.totalValue = null;

    for (const [key, value] of Object.entries(this.form.getRawValue().questionnaire)) {
      if (
        key.indexOf('verification') === -1 &&
        value !== undefined &&
        value !== 'false' &&
        value !== null &&
        value !== ''
      ) {
        if (key === 'TI21') {
          data[key] = [{ [key]: String(value ? 'Yes' : 'No') }];
        }
        if ($('#TI5').val() === '') {
          data['TI5'] = [{ ['TI5']: null }];
        }
        if ($('#TI4').val() === '') {
          data['TI4'] = [{ ['TI4']: null }];
        }

        if (key !== 'TI21') {
          data[key] = [{ [key]: formatForService(value) }];
        }
        if (key === 'TI30') {
          data[key] = [
            {
              [key]: String(
                this.form.value.questionnaire.TI12 === 'technical' ? this.form.value.questionnaire.TI30 : ''
              ),
            },
          ];
        }
      }
      if (key === 'TI38') {
        data[key] = [{ [key]: String(this.newRecoveryScenarioShow ? 'Yes' : 'No') }];
      }
      if (key === 'TI62') {
        data[key] = [{ [key]: String(this.questions['TI62'].value[0] ? this.questions['TI62'].value[0] : '') }];
      }
      if (key === 'TI67') {
        data[key] = [{ [key]: String(this.questions['TI67'].value[0] ? this.questions['TI67'].value[0] : '') }];
      }
      if (key === 'TI72') {
        data[key] = [{ [key]: String(this.questions['TI72'].value[0] ? this.questions['TI72'].value[0] : '') }];
      }
      if (key === 'TI77') {
        data[key] = [{ [key]: String(this.questions['TI77'].value[0] ? this.questions['TI77'].value[0] : '') }];
      }
      if (key === 'TI11') {
        data[key] = [{ [key]: String(this.questions['TI11'].value[0] ? this.questions['TI11'].value[0] : '') }];
      }
      if (key === 'TI6') {
        if (value === undefined || value === 'undefined') {
          data['TI6'] = [{ ['TI6']: '' }];
        }
      }

      if (
        key === 'TI39' ||
        key === 'TI40' ||
        key === 'TI41' ||
        key === 'TI42' ||
        key === 'TI43' ||
        key === 'TI44' ||
        key === 'TI45' ||
        key === 'TI46' ||
        key === 'TI47' ||
        key === 'TI48' ||
        key === 'TI49' ||
        key === 'TI50' ||
        key === 'TI51' ||
        key === 'TI52' ||
        key === 'TI53' ||
        key === 'TI54' ||
        key === 'TI55' ||
        key === 'TI56' ||
        key === 'TI57' ||
        key === 'TI58' ||
        key === 'TI59' ||
        key === 'TI60' ||
        key === 'TI61' ||
        key === 'TI63' ||
        key === 'TI64' ||
        key === 'TI65' ||
        key === 'TI66' ||
        key === 'TI68' ||
        key === 'TI69' ||
        key === 'TI70' ||
        key === 'TI71' ||
        key === 'TI73' ||
        key === 'TI74' ||
        key === 'TI75' ||
        key === 'TI76' ||
        key === 'TI78' ||
        key === 'TI79' ||
        key === 'TI80' ||
        key === 'TI81'
      ) {
        if (value === false) {
          delete data[key];
        }
      }
    }

    if (this.materialType === 'OUTFLOW') {
      data['TI19'] = [{ ['TI19']: String(this.SelectApplication) }];
      data['TI20'] = [{ ['TI20']: String(this.selectedPercentage) }];
    }
    if (this.form.controls.questionnaire.value.TI10 !== 'product') {
      delete data['TI24'];
      delete data['TI25'];
      delete data['TI26'];
    }
    this.http
      .callService(
        new Method(environment.services.ctiFlowQuestionsSave(this.flowId), { 'Product Details': data }, 'put')
      )
      .subscribe(async (res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        if (isPublish) {
          this.http
            .callService(
              new Method(
                environment.services.ctiQuestionsPublish(this.questionnaireId),
                { questionnaireId: this.questionnaireId },
                'post'
              )
            )
            .subscribe(async (res2) => {
              await this.materialsComponent.getUnitGuidance(this.unitId);
              await this.materialsComponent.initData(true);
              await this.materialsComponent.closeDetail();
              this.isLoading = false;
            });
        } else {
          await this.materialsComponent.initData();
        }
      });
  }

  saveAndPublishForm() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.isLoading = true;
    this.saveForm(true);
  }
}
