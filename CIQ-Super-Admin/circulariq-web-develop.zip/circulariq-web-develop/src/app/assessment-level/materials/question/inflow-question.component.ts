import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { environment } from '@env/environment';
import { Method, ApiRequestService } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MaterialsComponent } from '../materials.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { LocalStorageService } from '@app/core/services/local-storage.service';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
declare var $: any;

@Component({
  selector: 'app-inflow-question',
  templateUrl: './inflow-question.component.html',
  styleUrls: ['./question.component.scss'],
  standalone: false,
})
export class InflowQuestionComponent implements OnChanges {
  @Input() public selectedFlow: string;
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() public showBoxResponse: EventEmitter<any> = new EventEmitter();
  @Output() setResponsibleUsers = new EventEmitter<any>();
  dirtyData = false;
  unitId = this.route.snapshot.params.unitId;
  freeOrganization;
  showCriticalMaterial = true;
  totalCriticalMaterialValue = 0;
  totalCriticalMaterialArray = [0, 0, 0, 0];
  showTI32 = false;
  showTI34 = false;
  showTI36 = false;
  storyblokGuidance;
  selectedFlowId;
  totalValue;
  flowId;
  questionnaireId;
  controls;
  showForm = false;
  criticalBoxShow = false;
  materialType;
  maxPercentage;
  TI2ValidValue = 0;
  TI1ValidValue = 0;
  TI17ValidValue = 0;

  TI31ValidValue = 0;
  TI33ValidValue = 0;
  TI35ValidValue = 0;
  TI37ValidValue = 0;
  circularInflowbiggerMax = false;
  form: FormGroup;
  answers;
  baseQuestionList = [];
  indicators;
  isGHGShow;
  questions = [];
  displayGuidance = '';
  circularInflowSum = 0;
  isLoading = false;
  nameAvailable = true;
  currentName;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private fb: FormBuilder,
    public materialsComponent: MaterialsComponent,
    public storyblokService: StoryblokService,
    private cdr: ChangeDetectorRef,
    private route: ActivatedRoute,
    private localStorageService: LocalStorageService
  ) {
    // this.baseQuestionList = JSON.parse(sessionStorage.getItem('questionList'));
    const questionList = this.localStorageService.getCompressedSessionItem('questionList');
    const inflowQuestions = [
      'TI10',
      'TI1',
      'TI2',
      'TI22',
      'TI23',
      'TI27',
      'TI28',
      'TI29',
      'TI3',
      'TI7',
      'TI9',
      'TI17',
      'M18',
      'TI31',
      'TI32',
      'TI33',
      'TI34',
      'TI35',
      'TI36',
      'TI37',
    ];
    questionList.forEach((question) => {
      inflowQuestions.forEach((code) => {
        if (question.code === code) {
          this.baseQuestionList.push(question);
        }
      });
    });
    const user = JSON.parse(sessionStorage.getItem('credentials'));
    this.freeOrganization = user?.organisation?.licenseType === 'Free' || false;
    if (!this.freeOrganization) {
      const indicators = JSON.parse(sessionStorage.getItem('indicators'));
      this.criticalBoxShow = indicators?.criticalInflow;
    }
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokGuidance = {
        name: data.filter((item) => item.uuid === 'ca4d328c-0d1b-4fa5-85c3-d6f1579d0eb9')[0].content,
        mass: data.filter((item) => item.uuid === 'a32e7763-fb01-4926-b3e2-ec359e162f5c')[0].content,
        materialSourceType: data.filter((item) => item.uuid === '5886a6ac-4b5e-440c-b5ac-5bb3aeea8c53')[0].content,
        flowType: data.filter((item) => item.uuid === '8a09eeda-9dee-4304-8fe0-6629a12c5694')[0].content,
        criticalMaterial: data.filter((item) => item.uuid === 'dac529a4-d4ac-4385-aee9-ad7861871482')[0].content,
        ghgMaterialReference: data.filter((item) => item.uuid === '4542a983-faaf-436b-8045-9039b4af9758')[0].content,
      };
    });
  }
  openGuidanceEvent(slug: any) {
    this.commonService.mainGuidanceData.next({ show: true, active: 'datapoint', slug: slug });
  }
  changeData(value: boolean) {
    this.dirtyData = value;
    this.showBoxResponse.emit(value);
  }

  async reset() {
    this.changeData(false);
    await this.materialsComponent.closeDetail();
    await this.delay(1);
    await this.materialsComponent.showDetail(this.selectedFlow, 'INFLOW');
  }
  delay(ms: number) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  public ngOnChanges(changes: SimpleChanges) {
    if (changes.selectedFlow) {
      if (this.selectedFlowId !== changes.selectedFlow.currentValue.id) {
        this.isGHGShow = this.commonService.isGHGShow;
        this.showForm = false;
        const id = changes.selectedFlow.currentValue.id;
        this.flowId = changes.selectedFlow.currentValue.flowId;
        this.materialType = this.commonService.materialType;
        this.getSummary(this.flowId);
        if (!this.freeOrganization) {
          this.unitdetail();
        } else {
          this.flowIndicators(changes.selectedFlow.currentValue.flowId);
        }
      }
      this.selectedFlowId = changes.selectedFlow.currentValue.id;
    }
  }
  flowIndicators(flowId: any) {
    this.indicators = JSON.parse(sessionStorage.getItem('indicators'));
    this.criticalBoxShow = this.indicators.criticalInflow;
    if (!this.indicators) {
      this.http.callService(new Method(environment.services.flowIndicators(flowId), '', 'get')).subscribe((res) => {
        this.indicators = res;
        this.criticalBoxShow = this.indicators.criticalInflow;
        sessionStorage.setItem('indicators', JSON.stringify(this.indicators));
      });
    }
  }
  unitdetail() {
    this.indicators = JSON.parse(sessionStorage.getItem('indicators'));
    if (!this.indicators) {
      this.http.callService(new Method(environment.services.getIndicators(this.unitId), '', 'get')).subscribe((res) => {
        this.indicators = res;
        sessionStorage.setItem('indicators', JSON.stringify(this.indicators));
      });
    }
  }
  getSummary(flowId: any) {
    this.http.callService(new Method(environment.services.getFlowDetail(flowId), '', 'get')).subscribe((res) => {
      this.questionnaireId = res['questionnaire']['questionnaireId'];
      this.getAnswers(this.questionnaireId);
      this.setResponsibleUsers.emit(res);
    });
  }
  getAnswers(id: string) {
    localStorage.setItem('questionId', id);
    this.http.callService(new Method(environment.services.answers(id), '', 'get')).subscribe((res) => {
      this.answers = [];
      this.answers = res;
      this.filterQuestion();
    });
  }
  addCriticalMaterial(showTI32: boolean, showTI34: boolean) {
    if (showTI32) {
      this.showTI34 = true;
    }
    if (showTI34) {
      this.showTI36 = true;
    }
    this.showTI32 = true;
  }
  deleteCriticalMaterial(item: string) {
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: this.storyblok.delete_modal_title,
        message: this.storyblok.delete_modal_message,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.changeData(true);
        if (item === 'TI32') {
          this.showTI32 = false;
          this.questions['TI32'].value[0] = '';
          this.questions['TI33'].value[0] = '';
        }
        if (item === 'TI34') {
          this.showTI34 = false;
          this.questions['TI34'].value[0] = '';
          this.questions['TI35'].value[0] = '';
        }
        if (item === 'TI36') {
          this.showTI36 = false;
          this.questions['TI36'].value[0] = '';
          this.questions['TI37'].value[0] = '';
        }
        this.totalCriticalMaterialValue =
          Number(this.questions['TI37'].value[0]) +
          Number(this.questions['TI35'].value[0]) +
          Number(this.questions['TI33'].value[0]) +
          Number(this.questions['TI31'].value[0]);
      } catch (error) {}
    });
  }
  filterQuestion() {
    this.questions = [];
    this.controls = {};
    this.baseQuestionList.forEach((b) => {
      b.value = [''];
      b.evidenceFiles = [''];
      this.questions.push(b);
      if (b.code === 'TI29') {
        b.isShow = this.isGHGShow && this.indicators?.['greenhouseGases'] ? true : false;
      }
      if (b.code === 'TI7') {
        b.isShow = this.criticalBoxShow ? true : false;
      }
    });
    this.questions.forEach((q) => {
      if (q.code === 'TI10') {
        q.options.forEach((o, i) => {
          if (o.value === 'waste') {
            q.options.splice(i, 1);
          }
        });
      }
    });

    this.answers.forEach((a) => {
      this.questions.forEach((q) => {
        if (a.code === q.code) {
          q.value = a.value;
          q.evidenceFiles = a.evidenceFiles;
          if (q.evidenceFiles.length > 0) {
            if (q.evidenceFiles[0].fileName) {
              q.imgpath = `${environment.serverUrl}/assets/download/${q.evidenceFiles[0].fileName}`;
              q.fileType = q.evidenceFiles[0].fileName.split('.')[1];
            }
          }
        }
      });
    });
    this.questions = this.questions.reduce((acc, item) => {
      acc[item.code] = {
        ...item,
      };
      return acc;
    }, {});
    this.generateForm();
  }
  async generateForm() {
    this.showForm = false;
    this.controls['showCriticalMaterial'] = new FormControl();
    for (const [key, q] of Object.entries(this.questions)) {
      this.currentName = this.questions['M18'].value[0];
      this.showCriticalMaterial = this.questions['TI7'].value[0] === '' ? false : true;
      this.showTI32 =
        this.questions['TI32'].value[0] === '' || this.questions['TI32'].value[0] === 'undefined' ? false : true;
      this.showTI34 =
        this.questions['TI34'].value[0] === '' || this.questions['TI34'].value[0] === 'undefined' ? false : true;
      this.showTI36 =
        this.questions['TI36'].value[0] === '' || this.questions['TI36'].value[0] === 'undefined' ? false : true;
      this.totalCriticalMaterialValue =
        Number(this.questions['TI37'].value[0]) +
        Number(this.questions['TI35'].value[0]) +
        Number(this.questions['TI33'].value[0]) +
        Number(this.questions['TI31'].value[0]);
      if (q.code === 'TI29') {
        if (q.value[0] === 'Yes') {
          q.value[0] = true;
          this.questions['TI23'].isShow = true;
          this.questions['TI27'].value[0] = '';
          this.questions['TI28'].value[0] = '';
        } else {
          q.value[0] = false;
          this.questions['TI23'].isShow = false;
        }
      }
      q.documentation = '';
      q.verification = '';
      if (q.evidenceFiles) {
        if (q.evidenceFiles.length > 0) {
          q.evidenceFiles.reverse().forEach((element) => {
            if (element.s3FileUuid) {
              q.documentation = element.s3FileUuid;
            }
            if (element.description) {
              q.verification = element.description;
            }
          });
        }
      }
      if (q.code === 'TI17' || q.code === 'TI2' || q.code === 'TI1') {
        const totalValue =
          Number(this.questions['TI17'].value) +
          Number(this.questions['TI2'].value) +
          Number(this.questions['TI1'].value);
        if (totalValue === 0) {
          this.questions['TI9'].value[0] = 100;
        }
      }
      this.controls[q.code] = new FormControl();
    }
    this.form = this.fb.group({
      questionnaire: this.fb.group(this.controls),
    });
    this.showForm = true;
    await setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        for (const [key, value] of Object.entries(res.questionnaire)) {
          if (key === 'TI29') {
            this.questions['TI23'].isShow = value;
            if (value) {
              this.questions['TI27'].value[0] = '';
              this.questions['TI28'].value[0] = '';
            }
          }
        }
        this.dirtyData = true;
        this.showBoxResponse.emit(true);
      });
    }, 1000);
  }
  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.flowNameCheck(this.unitId, 'INFLOW'), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
          this.nameAvailable =
            this.currentName.trim().toLowerCase() === name.trim().toLowerCase() ? true : this.nameAvailable;
          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }

  calculateTotalCriticalMaterial(): void {
    this.totalCriticalMaterialValue =
      this.toSafeNumber(this.questions['TI31']?.value) +
      this.toSafeNumber(this.questions['TI33']?.value) +
      this.toSafeNumber(this.questions['TI35']?.value) +
      this.toSafeNumber(this.questions['TI37']?.value);
  }

  enforceLimit(field: string): void {
    if (!this.questions[field]) return;

    let value = this.toSafeNumber(this.questions[field].value);

    if (value > 100) {
      this.questions[field].value = 100; // Maksimum 100 olsun
    } else {
      this.questions[field].value = value; // Değer geçerliyse normal kaydet
    }

    this.calculateTotalCriticalMaterial(); // Toplamı güncelle
  }

  private getSafeNumber(value: any): number {
    const num = parseFloat(value);
    return isNaN(num) ? 0 : num;
  }

  private sanitizeValue(value: any, max: number = 100): number {
    let num = this.getSafeNumber(value);
    return Math.min(Math.max(num, 0), max); // Değeri 0 ile max arasında sınırla
  }

  materialSourceCalculate() {
    this.changeData(true);
    const sanitizeValue = (value: any, max: number = 100) => {
      let num = this.toSafeNumber(value);
      return Math.min(Math.max(num, 0), max);
    };
    for (const element of Object.values(this.questions)) {
      switch (element.code) {
        case 'TI17':
          this.TI17ValidValue = sanitizeValue(element.value);
          break;
        case 'TI2':
          this.TI2ValidValue = sanitizeValue(element.value);
          break;
        case 'TI1':
          this.TI1ValidValue = sanitizeValue(element.value);
          break;
        case 'TI9':
          element.value = sanitizeValue(100 - this.TI2ValidValue - this.TI1ValidValue - this.TI17ValidValue).toFixed(2);
          break;
      }
    }
    this.circularInflowSum = this.TI17ValidValue + this.TI2ValidValue + this.TI1ValidValue;
    this.circularInflowbiggerMax = this.circularInflowSum > 100;
  }

  private toSafeNumber(value: any): number {
    return isNaN(parseFloat(value?.toString().replace(',', '.'))) ? 0 : parseFloat(value.toString().replace(',', '.'));
  }

  saveForm(isPublish: boolean) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const formatForService = (v: any): string => {
      if (v === undefined || v === null) {
        return '';
      }
      const str = String(v);
      // Remove thousand separators (commas) if present
      const noThousands = str.replace(/,/g, '');
      // If numeric or numeric with dot/comma decimals, keep dot as decimal (service side can parse)
      if (/^-?\d+([.,]\d+)?$/.test(noThousands)) {
        // normalize comma decimal to dot for numeric transport
        return noThousands.replace(',', '.');
      }
      return noThousands;
    };
    this.changeData(false);
    this.blockNavigation = false;
    const data = {};
    this.totalValue = null;
    for (const [key, value] of Object.entries(this.form.getRawValue().questionnaire)) {
      if (
        key.indexOf('verification') === -1 &&
        value !== undefined &&
        value !== 'false' &&
        value !== null &&
        value !== ''
      ) {
        data[key] = [{ [key]: formatForService(value) }];
      }
      if (key === 'TI29') {
        data[key] = [{ [key]: String(value ? 'Yes' : 'No') }];
      }
      if (key === 'TI23') {
        data[key] = [{ [key]: String(this.form.value.questionnaire.TI29 ? this.form.value.questionnaire.TI23 : '') }];
      }

      if (!this.showCriticalMaterial) {
        if (key === 'TI7') {
          data[key] = [{ [key]: '' }];
        }
        if (key === 'TI31') {
          data[key] = [{ [key]: '' }];
        }
      }
      if (!this.showTI32) {
        if (key === 'TI32') {
          data[key] = [{ [key]: '' }];
        }
        if (key === 'TI33') {
          data[key] = [{ [key]: '' }];
        }
      }
      if (!this.showTI34) {
        if (key === 'TI34') {
          data[key] = [{ [key]: '' }];
        }
        if (key === 'TI35') {
          data[key] = [{ [key]: '' }];
        }
      }
      if (!this.showTI36) {
        if (key === 'TI36') {
          data[key] = [{ [key]: '' }];
        }
        if (key === 'TI37') {
          data[key] = [{ [key]: '' }];
        }
      }
      if (key === 'TI7') {
        if (value === undefined || value === 'undefined') {
          data['TI7'] = [{ ['TI7']: '' }];
        }
      }
      if (key === 'TI32') {
        if (value === undefined || value === 'undefined') {
          data['TI32'] = [{ ['TI32']: '' }];
        }
      }
      if (key === 'TI34' || value === 'undefined') {
        if (value === undefined) {
          data['TI34'] = [{ ['TI34']: '' }];
        }
      }
      if (key === 'TI36' || value === 'undefined') {
        if (value === undefined) {
          data['TI36'] = [{ ['TI36']: '' }];
        }
      }
      if (key === 'TI3') {
        if (value === undefined || value === 'undefined') {
          data['TI3'] = [{ ['TI3']: '' }];
        }
      }
    }
    delete data['showCriticalMaterial'];
    this.http
      .callService(
        new Method(environment.services.ctiFlowQuestionsSave(this.flowId), { 'Product Details': data }, 'put')
      )
      .subscribe(async (res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        if (isPublish) {
          this.http
            .callService(
              new Method(
                environment.services.ctiQuestionsPublish(this.questionnaireId),
                { questionnaireId: this.questionnaireId },
                'post'
              )
            )
            .subscribe(async (res2) => {
              await this.materialsComponent.getUnitGuidance(this.unitId);
              await this.materialsComponent.initData(true);
              await this.materialsComponent.closeDetail();
              this.isLoading = false;
            });
        } else {
          await this.materialsComponent.initData();
        }
      });
  }

  saveAndPublishForm() {
    console.log('saveAndPublishForm');

    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.isLoading = true;
    this.saveForm(true);
  }
  setProof(event: any) {
    this.getSummary(this.flowId);
  }

  toggleDisplayGuidance(code: string) {
    if (this.displayGuidance === code) {
      this.displayGuidance = null;
    } else {
      this.displayGuidance = code;
    }
  }
}
