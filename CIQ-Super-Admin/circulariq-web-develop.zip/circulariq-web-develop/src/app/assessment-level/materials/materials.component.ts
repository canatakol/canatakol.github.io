import { Component, OnInit, EventEmitter, Output, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { environment } from '@env/environment';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { NavigationExtras, NavigationStart, ActivatedRoute, Router, Event } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';
import { InviteColleagueDialog } from '@app/shared/dialog/invite-colleague/invite-colleague.component';
import { LabelManagmentDialog } from '@app/shared/dialog/label-managment/label-managment.component';
declare var $: any;
@Component({
  selector: 'app-materials',
  templateUrl: './materials.component.html',
  styleUrls: ['./materials.component.scss'],
  standalone: false,
})
export class MaterialsComponent implements OnInit, OnDestroy {
  @Output() public myOutput = new EventEmitter();
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  redirectUrl;
  dirtyData = false;
  storyblok;
  E5storyblok;
  productDetailData;
  proStoryblok;
  isAdvanced = false;
  category;
  criticalBoxShow = false;
  energyBoxShow = false;
  isShowPatica = false;
  inflows;
  inflowResults;
  supplierResults = [];
  inflowRemoveFlowList = [];
  outflowRemoveFlowList = [];
  labelList: any[] = [];
  labelListPureData: any[] = [];
  environment = environment;
  questions;
  showModal = false;
  showCriticalMaterial = false;
  showFileUpload = false;
  labels;
  steps;
  showAddFlow;
  outflows;
  outflowResults;
  invitedFlows;
  activePageDetail = false;
  unitId = this.route.snapshot.params.unitId;
  selectedMaterial = {
    id: '0',
    tradeName: '',
    type: '',
    responsibleSupplierInitals: '',
    responsibleSupplierInitalsFull: '',
    responsibleSupplierInitalsEmail: '',
    displayName: '',
    tradeNumber: '',
    status: '',
    owner: '',
    transitionDate: '',
    weight: null,
    responsibleUsers: [
      {
        email: '',
        organisation: {
          licenseType: '',
          name: '',
          id: '',
        },
        fullName: '',
        id: '0',
      },
    ],
    draft: null,
    critical: null,
    priority: null,
    buyer: {
      licenseType: '',
      name: '',
      id: '0',
    },
    virginNonRenewablePercentage: null,
    actualRecovery: null,
    potentialRecovery: null,
    wip: null,
    flowId: null,
    responsibleOwnerInitalsFull: '',
    responsibleOwnerInitalsEmail: '',
    responsibleOwnerInitals: '',
  };
  pageInfoInflowValue = 'CREATIONDESCENDING';
  pageInfoOutflowValue = 'CREATIONDESCENDING';
  pageInfoInvitedFlowValue = 'CREATIONDESCENDING';
  pageInfoInflow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  pageInfoOutflow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  pageInfoInvitedFlow = { pageIndex: 0, pageSize: 10, sort: 'CREATION', order: 'DESCENDING' };
  materiaNavShow = false;
  lastCreateMaterial = {};
  user;
  freeOrganization;
  pondOptions;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute,
    public router: Router,
    private storyblokService: StoryblokService,
    private cdr: ChangeDetectorRef
  ) {
    this.user = JSON.parse(sessionStorage.getItem('credentials'));
    this.freeOrganization = this.user?.organisation?.licenseType === 'Free' || false;
    setTimeout(() => {
      if (this.unitId) {
        this.getUnitGuidance(this.unitId);
      }
    }, 1000);
    this.criticalBoxShow = JSON.parse(sessionStorage.getItem('indicators'))
      ? JSON.parse(sessionStorage.getItem('indicators')).criticalInflow
      : false;
    this.energyBoxShow = JSON.parse(sessionStorage.getItem('indicators'))
      ? JSON.parse(sessionStorage.getItem('indicators')).renewableEnergy
      : false;
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
  }

  addRemoveList(value: any, id: any, type: string) {
    if (type === 'inflow') {
      if (value) {
        this.inflowRemoveFlowList.push(id);
      } else {
        this.inflowRemoveFlowList = this.inflowRemoveFlowList.filter((item) => item !== id);
      }
    } else {
      if (value) {
        this.outflowRemoveFlowList.push(id);
      } else {
        this.outflowRemoveFlowList = this.outflowRemoveFlowList.filter((item) => item !== id);
      }
    }
  }

  removeFlow() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    if (this.inflowRemoveFlowList.length) {
      this.http
        .callService(
          new Method(
            environment.services.removeFlow(this.unitId, 'INFLOW'),
            { productIds: this.inflowRemoveFlowList },
            'put'
          )
        )
        .subscribe((res) => {
          if (!this.outflowRemoveFlowList.length) {
            this.initData(true);
            this.close();
          }
        });
    }
    if (this.outflowRemoveFlowList.length) {
      this.http
        .callService(
          new Method(
            environment.services.removeFlow(this.unitId, 'OUTFLOW'),
            { productIds: this.outflowRemoveFlowList },
            'put'
          )
        )
        .subscribe((res) => {
          this.initData(true);
          this.close();
        });
    }
  }
  getAssmentLabel() {
    this.http.callService(new Method(environment.services.assementLabel(this.unitId), '', 'get')).subscribe((res) => {
      this.labels = res;
    });
  }
  isLastPath(label: any, index: number): boolean {
    return label.path.length === index + 1;
  }

  async labelManagment(): Promise<void> {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }

    await this.labelList.forEach((label) => {
      label.selected = false;
    });
    const selectedAssessments = [{ unitId: this.unitId, labels: this.labels }];
    const commonLabels = this.findCommonLabels(selectedAssessments);
    await this.labelList.forEach((label) => {
      label.selected = commonLabels.includes(label.id);
    });
    await this.labelList.sort(this.sortBySelected);
    const dialogRef = this.dialog.open(LabelManagmentDialog, {
      width: '80%',
      maxWidth: '700px',
      panelClass: 'centered-dialog',
      data: { selectAssetList: [this.unitId], labelList: this.labelList },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (result) {
        await this.getAssmentLabel();
      }
    });
  }

  setLabel(): void {
    this.http
      .callService(new Method(environment.services.labelSearch(), { keyword: '' }, 'put'))
      .subscribe(async (res: any[]) => {
        this.labelList = res.map((label) => ({
          ...label,
          selected: false,
          labelPahtWithTrim: label.path.join('').toLowerCase().replace(/\s/g, ''),
        }));
        this.labelListPureData = this.labelList;
        await this.labelList.sort((a, b) => a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim));
        await this.labelManagment();
      });
  }

  private findCommonLabels(assessments: any): string[] {
    const labelIds = assessments.flatMap((assessment) => assessment.labels.map((label) => label.id));
    const size = assessments.length;

    return labelIds.filter((id) => labelIds.filter((labelId) => labelId === id).length === size);
  }

  private sortBySelected(a: any, b: any): number {
    return a.selected === b.selected ? 0 : a.selected ? -1 : 1;
  }

  findSameAssessment(selectAssetList: any[], relatedLabelData: any[]): any[] {
    return relatedLabelData.filter((element) => selectAssetList.includes(element.unitId));
  }

  getProductLineDetails() {
    this.http
      .callService(new Method(environment.services.productLineDetails(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.productDetailData = res;
        this.productDetailData.amount = res['amount'] ? res['amount'] : 1;
      });
  }
  setProductLineDetails() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const data = { amount: this.productDetailData.amount };
    this.http
      .callService(new Method(environment.services.productLineDetails(this.unitId), data, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }
  deleteLabel(label: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const result = label.path.join(' / ');
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${result}`,
        message: this.E5storyblok.delete_label_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (result) {
        this.http
          .callService(
            new Method(environment.services.labelDrop(), { labelIds: [label.id], unitIds: [this.unitId] }, 'put')
          )
          .subscribe((res) => {
            this.getAssmentLabel();
          });
      }
    });
  }
  setSelectedFlow() {
    this.inflows?.results?.forEach((item) => {
      const isInRemoveList = this.inflowRemoveFlowList.some((removeItem) => removeItem === item.id);
      if (isInRemoveList) {
        item.selected = true;
      }
    });
    this.outflows?.results?.forEach((item) => {
      const isInRemoveList = this.outflowRemoveFlowList.some((removeItem) => removeItem === item.id);
      if (isInRemoveList) {
        item.selected = true;
      }
    });
  }

  close() {
    this.inflowRemoveFlowList = [];
    this.outflowRemoveFlowList = [];
    this.inflows.results.forEach((item) => {
      if (item.selected) {
        item.selected = false;
      }
    });
    this.outflows.results.forEach((item) => {
      if (item.selected) {
        item.selected = false;
      }
    });
  }

  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
    $('#main-content').removeClass('step3');
  }

  sortChange(selectedOption: string, flow: string) {
    this.lastCreateMaterial = {};
    this.inflows = [];
    this.outflows = [];
    if (flow === 'INFLOW') {
      switch (selectedOption) {
        case 'NAMEASCENDING':
          this.pageInfoInflow.sort = 'NAME';
          this.pageInfoInflow.order = 'ASCENDING';
          break;
        case 'NAMEDESCENDING':
          this.pageInfoInflow.sort = 'NAME';
          this.pageInfoInflow.order = 'DESCENDING';
          break;
        case 'WEIGHTASCENDING':
          this.pageInfoInflow.sort = 'WEIGHT';
          this.pageInfoInflow.order = 'ASCENDING';
          break;
        case 'WEIGHTDESCENDING':
          this.pageInfoInflow.sort = 'WEIGHT';
          this.pageInfoInflow.order = 'DESCENDING';
          break;
        case 'UPDATEDESCENDING':
          this.pageInfoInflow.sort = 'UPDATE';
          this.pageInfoInflow.order = 'DESCENDING';
          break;
        case 'UPDATEASCENDING':
          this.pageInfoInflow.sort = 'UPDATE';
          this.pageInfoInflow.order = 'ASCENDING';
          break;
        case 'CREATIONASCENDING':
          this.pageInfoInflow.sort = 'CREATION';
          this.pageInfoInflow.order = 'ASCENDING';
          break;
        default:
          this.pageInfoInflow.sort = 'CREATION';
          this.pageInfoInflow.order = 'DESCENDING';
          break;
      }
      this.getInflows(
        this.unitId,
        'INFLOW',
        1,
        this.pageInfoInflow.pageSize,
        this.pageInfoInflow.sort,
        this.pageInfoInflow.order
      );
    } else {
      switch (selectedOption) {
        case 'NAMEASCENDING':
          this.pageInfoOutflow.sort = 'NAME';
          this.pageInfoOutflow.order = 'ASCENDING';
          break;
        case 'NAMEDESCENDING':
          this.pageInfoOutflow.sort = 'NAME';
          this.pageInfoOutflow.order = 'DESCENDING';
          break;
        case 'WEIGHTASCENDING':
          this.pageInfoOutflow.sort = 'WEIGHT';
          this.pageInfoOutflow.order = 'ASCENDING';
          break;
        case 'WEIGHTDESCENDING':
          this.pageInfoOutflow.sort = 'WEIGHT';
          this.pageInfoOutflow.order = 'DESCENDING';
          break;
        case 'UPDATEDESCENDING':
          this.pageInfoOutflow.sort = 'UPDATE';
          this.pageInfoOutflow.order = 'DESCENDING';
          break;
        case 'UPDATEASCENDING':
          this.pageInfoOutflow.sort = 'UPDATE';
          this.pageInfoOutflow.order = 'ASCENDING';
          break;
        case 'CREATIONASCENDING':
          this.pageInfoOutflow.sort = 'CREATION';
          this.pageInfoOutflow.order = 'ASCENDING';
          break;
        default:
          this.pageInfoOutflow.sort = 'CREATION';
          this.pageInfoOutflow.order = 'DESCENDING';
          break;
      }
      this.getOutflows(
        this.unitId,
        'OUTFLOW',
        1,
        this.pageInfoOutflow.pageSize,
        this.pageInfoOutflow.sort,
        this.pageInfoOutflow.order
      );
    }
  }

  getUnitGuidance(id: string) {
    this.http.callService(new Method(environment.services.ctiUnitGuidance(id), '', 'get')).subscribe((res) => {
      this.steps = res;
      this.commonService.stepsData.next(res);
    });
  }
  selectEvent(item: any, category?: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.showModal = true;
    switch (item) {
      case 'INFLOW':
        this.showAddFlow = true;
        this.commonService.addmaterialType = 'INFLOW';
        break;
      case 'OUTFLOW':
        this.showAddFlow = true;
        this.commonService.addmaterialType = 'OUTFLOW';
        break;
      case 'critical':
        this.showCriticalMaterial = true;
        break;
      case 'fileUpload':
        this.showFileUpload = true;
        this.category = category;
        break;
      default:
        return;
        break;
    }
  }

  public hideModal() {
    this.showModal = false;
    this.showCriticalMaterial = false;
    this.showAddFlow = false;
    this.showFileUpload = false;
    this.lastCreateMaterial = this.commonService.lastCreateMaterial;
    this.initData();
  }

  ngOnInit() {
    $('#main-content').addClass('step3');
    this.getAssmentLabel();
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'step3')[0].content;
      this.E5storyblok = data.filter((item) => item.slug === 'material-page')[0].content;
      this.proStoryblok = data.filter((item) => item.slug === 'pro-dashboard')[0].content;
    });
    this.getProductLineDetails();
    this.initData();
  }

  public initData(dontOpen?: boolean) {
    if (this.unitId) {
      this.getInflows(
        this.unitId,
        'INFLOW',
        this.pageInfoInflow.pageIndex + 1,
        this.pageInfoInflow.pageSize,
        this.pageInfoInflow.sort,
        this.pageInfoInflow.order,
        dontOpen ? dontOpen : false
      );
      this.getOutflows(
        this.unitId,
        'OUTFLOW',
        this.pageInfoOutflow.pageIndex + 1,
        this.pageInfoOutflow.pageSize,
        this.pageInfoOutflow.sort,
        this.pageInfoOutflow.order,
        dontOpen ? dontOpen : false
      );
    } else {
      this.getInvitedFlows(this.pageInfoInvitedFlow.pageIndex + 1, this.pageInfoInvitedFlow.pageSize);
    }
  }
  pageEventInflow(pageInfo: any) {
    this.pageInfoInflow.pageIndex = pageInfo.pageIndex;
    this.pageInfoInflow.pageSize = pageInfo.pageSize;
    this.getInflows(
      this.unitId,
      'INFLOW',
      pageInfo.pageIndex + 1,
      pageInfo.pageSize,
      this.pageInfoInflow.sort,
      this.pageInfoInflow.order
    );
  }
  getInflows(
    unitId: string,
    type: string,
    page: number,
    size: number,
    order: string,
    sort: string,
    dontOpen?: boolean
  ) {
    this.http
      .callService(
        new Method(environment.services.inflowsandOutflofListLight(unitId, type, page, size, order, sort), '', 'get')
      )
      .subscribe((res) => {
        this.inflows = res;
        this.inflowResults = this.inflows.results;

        this.inflows.results.forEach((element) => {
          // element.class = element.type;
          if (!Array.isArray(element.listOfTypes)) {
            element.listOfTypes = [];
          }
          if (!element.listOfTypes.includes(element.type)) {
            if (element.type === 'product' || element.type === 'packaging') {
              element.listOfTypes.push({ class: element.type, name: element.type });
            }
            if (element.priority) {
              element.listOfTypes.push({
                class: 'priority',
                name: this.storyblok?.focus_flow_label ? this.storyblok?.focus_flow_label : 'Focus Flow',
              });
            }
            if (element.critical) {
              element.listOfTypes.push({
                class: 'critical',
                name: this.storyblok?.critical_label ? this.storyblok?.critical_label : 'Critical',
              });
            }
            if (element.draft) {
              element.listOfTypes.push({
                class: 'draft',
                name: this.storyblok?.darft_label ? this.storyblok?.darft_label : 'Draft',
              });
            }
            if (element.waste) {
              element.listOfTypes.push({
                class: 'waste',
                name: this.storyblok?.waste ? this.storyblok?.waste : 'Waste',
              });
            }
            if (element.id === this.lastCreateMaterial['id']) {
              if (dontOpen !== true) {
                this.showDetail(element, 'INFLOW');
              }
            }
          }
        });

        this.setSelectedFlow();
      });
  }
  pageEventOutflow(pageInfo: any) {
    this.pageInfoOutflow.pageIndex = pageInfo.pageIndex;
    this.pageInfoOutflow.pageSize = pageInfo.pageSize;
    this.getOutflows(
      this.unitId,
      'OUTFLOW',
      pageInfo.pageIndex + 1,
      pageInfo.pageSize,
      this.pageInfoOutflow.sort,
      this.pageInfoOutflow.order
    );
  }
  getOutflows(
    unitId: string,
    type: string,
    page: number,
    size: number,
    order: string,
    sort: string,
    dontOpen?: boolean
  ) {
    this.http
      .callService(
        new Method(environment.services.inflowsandOutflofListLight(unitId, type, page, size, order, sort), '', 'get')
      )
      .subscribe((res) => {
        this.outflows = res;
        this.outflowResults = this.outflows.results;

        this.outflowResults.forEach((element) => {
          if (!Array.isArray(element.listOfTypes)) {
            element.listOfTypes = [];
          }
          if (!element.listOfTypes.includes(element.type)) {
            if (element.type === 'product' || element.type === 'packaging') {
              element.listOfTypes.push({ class: element.type, name: element.type });
            }
            if (element.priority) {
              element.listOfTypes.push({
                class: 'priority',
                name: this.storyblok?.focus_flow_label ? this.storyblok?.focus_flow_label : 'Focus Flow',
              });
            }
            if (element.critical) {
              element.listOfTypes.push({
                class: 'critical',
                name: this.storyblok?.critical_label ? this.storyblok?.critical_label : 'Critical',
              });
            }
            if (element.draft) {
              element.listOfTypes.push({
                class: 'draft',
                name: this.storyblok?.darft_label ? this.storyblok?.darft_label : 'Draft',
              });
            }
            if (element.waste) {
              element.listOfTypes.push({
                class: 'waste',
                name: this.storyblok?.waste ? this.storyblok?.waste : 'Waste',
              });
            }
          }
          if (element.id === this.lastCreateMaterial['id']) {
            if (dontOpen !== true) {
              this.showDetail(element, 'OUTFLOW');
            }
          }
        });
        this.setSelectedFlow();
      });
  }
  pageEventInvitedFlow(pageInfo: any) {
    this.pageInfoInvitedFlow = pageInfo;
    this.getInvitedFlows(pageInfo.pageIndex + 1, pageInfo.pageSize);
  }
  getInvitedFlows(page: number, size: number) {
    this.http.callService(new Method(environment.services.invitedFlowList(page, size), '', 'get')).subscribe((res) => {
      this.invitedFlows = res;
      this.invitedFlows['results'].forEach((element) => {
        element.class = element.type;
        if (element.id === this.lastCreateMaterial['id']) {
          this.showDetail(element, 'OUTFLOW');
        }
      });
    });
  }

  setResponsibleUsers(flowItem: object) {
    if (!flowItem['responsibleUsers'] || !Array.isArray(flowItem['responsibleUsers'])) {
      return;
    }

    flowItem['responsibleUsers'].forEach((user) => {
      if (user.organisation?.id === flowItem['buyer']?.id) {
        flowItem['responsibleOwnerInitalsFull'] = user.fullName;
        flowItem['responsibleOwnerInitalsEmail'] = user.email;
        flowItem['responsibleOwnerInitals'] = user.fullName
          ? this.getNameInitials(user.fullName)
          : user.email.substring(0, 3);
      } else {
        flowItem['responsibleSupplierInitalsFull'] = user.fullName;
        flowItem['responsibleSupplierInitalsEmail'] = user.email;
        flowItem['responsibleSupplierInitals'] = user.fullName
          ? this.getNameInitials(user.fullName)
          : user.email.substring(0, 3);
      }
    });

    // Update selectedMaterial with the processed data
    if (this.selectedMaterial && flowItem['id'] === this.selectedMaterial['id']) {
      this.selectedMaterial['responsibleOwnerInitalsFull'] = flowItem['responsibleOwnerInitalsFull'];
      this.selectedMaterial['responsibleOwnerInitalsEmail'] = flowItem['responsibleOwnerInitalsEmail'];
      this.selectedMaterial['responsibleOwnerInitals'] = flowItem['responsibleOwnerInitals'];
      this.selectedMaterial['responsibleSupplierInitalsFull'] = flowItem['responsibleSupplierInitalsFull'];
      this.selectedMaterial['responsibleSupplierInitalsEmail'] = flowItem['responsibleSupplierInitalsEmail'];
      this.selectedMaterial['responsibleSupplierInitals'] = flowItem['responsibleSupplierInitals'];
    }

    // Trigger change detection to ensure the view updates
    this.cdr.detectChanges();
  }

  getNameInitials(fullName: string) {
    const a = fullName.split(' ').slice(0, -1).join(' ').charAt(0).toUpperCase();
    const b = fullName.split(' ').slice(-1).join(' ').charAt(0).toUpperCase();
    return a + b;
  }

  showDetail(material: any, type: string) {
    this.blockNavigation = this.dirtyData;
    if (!this.blockNavigation) {
      this.materiaNavShow = false;
      this.selectedMaterial = material;
      this.selectedMaterial['type'] = type;
      this.commonService.materialType = type;
      this.myOutput.emit(material.id);
      this.activePageDetail = true;
    }
  }

  showBoxResponse(value: boolean) {
    this.dirtyData = value;
  }
  closeDetail() {
    this.blockNavigation = this.dirtyData;
    if (!this.blockNavigation) {
      this.activePageDetail = false;
    }
  }
  flowComplate(value: boolean, flow: string) {
    const data = [{ question: flow, value: value, entityId: this.unitId }];
    if (this.criticalBoxShow && flow === 'CTI_INFLOW_DONE' && value) {
      const dialogRef = this.dialog.open(ReportStatusDialog, {
        width: '80%',
        maxWidth: '430px',
        panelClass: 'centered-dialog',
        data: {
          title: `Critical Materials`,
          message: 'You have selected Optimize the loop in Step 2. Did you add critical materials to your inflow?',
        },
      });
      dialogRef.afterClosed().subscribe(async (result) => {
        if (!result) {
          this.selectEvent('critical');
          this.getInflows(
            this.unitId,
            'INFLOW',
            1,
            this.pageInfoInflow.pageSize,
            this.pageInfoInflow.sort,
            this.pageInfoInflow.order
          );
        }
        try {
          this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
            this.getUnitGuidance(this.unitId);
          });
        } catch (error) {}
      });
    } else {
      this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
        this.getUnitGuidance(this.unitId);
      });
    }
  }

  removeMaterial(selectedMaterial: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${this.selectedMaterial['tradeName']}`,
        message: this.storyblok.delete_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(
            new Method(
              environment.services.removeMaterial(
                (this.unitId =
                  this.selectedMaterial['type'] === 'supplier'
                    ? this.selectedMaterial['organisationUnitUuid']
                    : this.unitId),
                this.selectedMaterial['type'],
                this.selectedMaterial['id']
              ),
              '',
              'delete'
            )
          )
          .subscribe((res) => {
            this.closeDetail();
            if (this.selectedMaterial['type'] === 'INFLOW') {
              this.getInflows(
                this.unitId,
                'INFLOW',
                1,
                this.pageInfoInflow.pageSize,
                this.pageInfoInflow.sort,
                this.pageInfoInflow.order
              );
            } else if (this.selectedMaterial['type'] === 'supplier') {
              this.getInvitedFlows(this.pageInfoInvitedFlow.pageIndex + 1, this.pageInfoInvitedFlow.pageSize);
            } else {
              this.getOutflows(
                this.unitId,
                'OUTFLOW',
                1,
                this.pageInfoOutflow.pageSize,
                this.pageInfoOutflow.sort,
                this.pageInfoOutflow.order
              );
            }
          });
      } catch (error) {}
    });
  }

  inviteColleague() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(InviteColleagueDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: this.selectedMaterial,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        if (this.selectedMaterial['type'] === 'INFLOW') {
          this.getInflows(
            this.unitId,
            'INFLOW',
            1,
            this.pageInfoInflow.pageSize,
            this.pageInfoInflow.sort,
            this.pageInfoInflow.order
          );
        } else if (this.selectedMaterial['type'] === 'supplier') {
          this.getInvitedFlows(this.pageInfoInvitedFlow.pageIndex + 1, this.pageInfoInvitedFlow.pageSize);
        } else {
          this.getOutflows(
            this.unitId,
            'OUTFLOW',
            1,
            this.pageInfoOutflow.pageSize,
            this.pageInfoOutflow.sort,
            this.pageInfoOutflow.order
          );
        }
      } catch (error) {}
    });
  }

  goToCriticalMaterials() {
    this.router.navigate([`/cti/${this.unitId}/assessment/critical-material`]);
  }
}
