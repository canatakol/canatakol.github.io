import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute, NavigationStart, NavigationExtras, Event } from '@angular/router';
import { Subscription } from 'rxjs';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';

@Component({
  selector: 'app-step1',
  templateUrl: './step1.component.html',
  styleUrls: ['./step1.component.scss'],
  standalone: false,
})
export class Step1Component implements OnInit, OnDestroy {
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  dirtyData = false;
  redirectUrl;
  businessLevels = environment.services.businessLevels;
  countries = environment.services.countries;
  mounthList = environment.services.mounthList;
  startMounth;
  endMounth;
  yearList = Array.from({ length: 20 }, (v, i) => new Date().getFullYear() - 10 + i + 1);
  startYear;
  endYear;
  businessLevelData;
  unitScope;
  unitProductLineData;
  ctiUnitGuidance;
  isDupplicateShow = false;
  data;
  baseName;
  storyblok;
  isUnderstand = false;
  isPro = false;
  unitId = this.route.snapshot.params.unitId;
  supplierList;
  nameAvailable = true;
  currentName;
  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    public router: Router,
    public route: ActivatedRoute,
    private storyblokService: StoryblokService
  ) {
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        const regex = /\/cti\/([0-9a-f-]+)\/assessment\/step1/;
        const match = event.url.match(regex);
        const isStep1Route = match && match.length > 1;
        const currentUrl = this.router.url;
        const isNavigatingAway = !isStep1Route || (isStep1Route && event.url !== currentUrl);

        if (isStep1Route) {
          // Sadece unitId değiştiyse verileri yeniden yükle
          const newId = match[1];
          if (this.unitId !== newId) {
            this.unitScope = null;
            this.ctiUnitGuidance = null;
            this.data = null;
            this.unitId = newId;
            this.loadStep1Data();
          }
        }

        // blockNavigation kontrolünü sadece step1 route'undan çıkış yapılırken yap
        // Aynı route içinde navigation'ı engelleme (sonsuz döngüyü önle)
        if (this.dirtyData && isNavigatingAway) {
          // Navigation'ı iptal etmek için history API kullan
          window.history.pushState(null, '', currentUrl);
          // Kullanıcıya uyarı göster
          if (this.storyblok?.unsaved_changes_alert) {
            this.snackBar.open(this.storyblok.unsaved_changes_alert, '', {
              duration: 5000,
              panelClass: ['error-snackBar'],
            });
          }
          // Navigation'ı durdur
          return;
        }

        this.blockNavigation = this.dirtyData && isNavigatingAway;
        this.redirectUrl = event.url;
      }
    });

    const unit = this.commonService.selectedUnit;
    if (unit && unit.id !== this.unitId) {
      this.unitId = unit.unitId;
      this.data = unit;
      this.baseName = unit.name;
    }
  }

  changeData() {
    this.dirtyData = true;
  }
  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.assessmentNameCheck(), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];
          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }
  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.saveStep1(this.unitScope, this.businessLevelData);
    } else {
      if (this.data) {
        this.data.name = this.baseName;
      }
      this.getScope(this.unitId);
    }
    this.blockNavigation = false;
    this.dirtyData = false;
  }

  unitWithUnit(unitId: string) {
    this.http.callService(new Method(environment.services.unitWithUnitId(unitId), '', 'get')).subscribe(async (res) => {
      this.data = res;
      this.baseName = res['name'];
      console.log('baseName 2', this.baseName);
    });
  }

  ngOnInit(): void {
    if (this.route.snapshot.params.unitId === 'none') {
      this.loadDefaultUnit();
    } else if (this.unitId) {
      this.loadStep1Data();
    }
  }

  private loadDefaultUnit(): void {
    this.http.callService(new Method(environment.services.listBusinessLevels(), '', 'get')).subscribe(async (level) => {
      this.unitId = level[0]?.assessments[0]?.unitId;
      await this.http
        .callService(new Method(environment.services.unitWithUnitId(this.unitId), '', 'get'))
        .subscribe(async (unit) => {
          await this.getScope(this.unitId);
          await this.router.navigate([`/cti/${this.unitId}/assessment/step1`], { replaceUrl: true });
        });
    });
  }

  private loadStep1Data(): void {
    // Paralel API çağrıları
    this.loadUnitData();
    this.loadScopeData();
    this.loadStoryblokData();
  }

  private loadUnitData(): void {
    this.unitWithUnit(this.unitId);
  }

  private loadScopeData(): void {
    this.getScope(this.unitId);
  }

  private loadStoryblokData(): void {
    // Storyblok verisi cache'den alınabilir
    const cachedStoryblok = sessionStorage.getItem('storyblok_step1');
    if (cachedStoryblok) {
      this.storyblok = JSON.parse(cachedStoryblok);
    } else {
      this.storyblokService.getStoryService().then((data) => {
        const story = data.filter((item) => item.slug === 'step1');
        this.storyblok = story[0]?.content;
        if (this.storyblok) {
          sessionStorage.setItem('storyblok_step1', JSON.stringify(this.storyblok));
        }
      });
    }
  }
  async getSupplierNames() {
    if (this.unitId) {
      await this.http.callService(new Method(environment.services.supplierNames(), '', 'get')).subscribe((res) => {
        this.supplierList = res;
      });
      await this.http
        .callService(new Method(environment.services.productLineDetails(this.unitId), '', 'get'))
        .subscribe((unit) => {
          this.unitProductLineData = unit;
        });
    }
  }
  addProduct() {
    this.unitProductLineData?.supplierName === 'new'
      ? (this.unitProductLineData.supplierName = this.unitProductLineData.supplierOtherName)
      : (this.unitProductLineData.supplierName = this.unitProductLineData.supplierName);
    delete this.unitProductLineData.supplierOtherName;
    this.http.callService(
      new Method(environment.services.productLineDetails(this.unitId), this.unitProductLineData, 'put')
    );
  }
  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
  }

  getScope(unitId: string) {
    // Paralel API çağrıları
    const businessLevelCall = this.http.callService(
      new Method(environment.services.getUnitBusinessLevel(unitId), '', 'get')
    );
    const scopeCall = this.http.callService(new Method(environment.services.scope(unitId), '', 'get'));

    businessLevelCall.subscribe((res) => {
      this.businessLevelData = res;
      this.getSupplierNames();
    });

    scopeCall.subscribe((res) => {
      this.unitScope = res;
      this.processDateData();
      this.loadGuidanceData();
    });

    this.isPro = this.commonService.isPro;
  }

  private processDateData(): void {
    if (this.unitScope?.startDate && this.unitScope?.endDate) {
      const startDate = new Date(this.unitScope.startDate);
      const startMounth = startDate.getMonth() + 1;
      this.startMounth = String(startMounth < 10 ? '0' + startMounth : startMounth);
      this.startYear = startDate.getUTCFullYear();

      const endDate = new Date(this.unitScope.endDate);
      const endMounth = endDate.getMonth() + 1;
      this.endMounth = String(endMounth < 10 ? '0' + endMounth : endMounth);
      this.endYear = endDate.getUTCFullYear();
    }
  }

  private loadGuidanceData(): void {
    const guidanceData = sessionStorage.getItem('ctiUnitGuidance');
    if (guidanceData) {
      this.ctiUnitGuidance = JSON.parse(guidanceData);
      this.isUnderstand = this.ctiUnitGuidance?.step1 || false;
      this.isDupplicateShow = !this.ctiUnitGuidance?.step1 && this.data?.duplicate && !this.isUnderstand;
    }
  }
  understandEvent() {
    this.isDupplicateShow = false;
    this.isUnderstand = true;
    this.saveStep1(this.unitScope, this.businessLevelData);
    this.router.navigate([`/cti/${this.unitId}/assessment/step2`]);
  }
  async saveStep1(item: any, businessData: any) {
    this.blockNavigation = false;
    this.dirtyData = false;

    if (this.baseName !== this.data.name && this.nameAvailable) {
      await this.http
        .callService(new Method(environment.services.unitWithUnitId(this.unitId), { name: this.data.name }, 'put'))
        .subscribe((res) => {
          if (typeof res === 'object') {
            this.commonService.refreshUnitGuindance(this.unitId);
          }
        });
    }
    this.addProduct();

    if (!this.isPro) {
      const data = {
        type: businessData.type,
        name: businessData.name,
        otherType: businessData.otherType,
      };
      await this.http.callService(new Method(environment.services.editBusinessLevel(businessData['id']), data, 'put'));
    }
    if (this.startMounth && this.startYear && this.endMounth && this.endYear) {
      if (this.startYear > this.endYear) {
        this.snackBar.open(this.storyblok.date_allert, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
        return;
      }
      if (this.startYear === this.endYear) {
        if (this.startMounth > this.endMounth) {
          this.snackBar.open(this.storyblok.date_allert, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
          return;
        }
      }
      item.startDate = `${this.startYear}-${this.startMounth}-02T00:00:00`;
      item.endDate = `${this.endYear}-${this.endMounth}-28T00:00:00`;
    }
    item['supplyLevel'] = businessData.type;
    await this.http.callService(new Method(environment.services.scope(this.unitId), item, 'put')).subscribe(() => {
      this.commonService.refreshUnitGuindance(this.unitId);
      if (this.isPro && this.data) {
        this.commonService.getbusinessLevelList.next({
          businessLevel: JSON.parse(localStorage.getItem('selectedBusiness')),
          assessmentUnitId: this.data['id'],
          goToStep1: false,
        });
      }
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
    });
  }
}
