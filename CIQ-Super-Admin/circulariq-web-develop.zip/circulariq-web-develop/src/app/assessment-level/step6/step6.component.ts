import { Component, OnDestroy } from '@angular/core';
import { NavigationExtras, NavigationStart, Router, Event } from '@angular/router';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-step6',
  templateUrl: './step6.component.html',
  styleUrls: ['./step6.component.scss'],
  standalone: false,
})
export class Step6Component implements OnDestroy {
  activeCase6 = 'inflow6';
  isShowstep6Intro;
  storyblok;
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  dirtyData = false;
  redirectUrl;
  constructor(private commonService: CommonService, private storyblokService: StoryblokService, public router: Router) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step6');
      this.storyblok = story[0].content;
    });
    this.commonService.step6ActiveCase.next('inflow6');
    this.isShowstep6Intro = localStorage.getItem('isShowstep6Intro');
    this.commonService.step6ActiveCase.subscribe((res) => {
      this.activeCase6 = res;
    });
    this.commonService.isShowstep6Intro.subscribe((res) => {
      this.isShowstep6Intro = res;
    });
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
  }
  async tabSaveResponse(value: boolean) {
    this.dirtyData = value;
  }
  tabClick(value: boolean) {
    this.blockNavigation = value;
  }
  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
    this.commonService.step5ActiveCase.next('inflow-question');
  }
}
