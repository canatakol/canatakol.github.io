import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import deepEqual from 'deep-equal';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-step6-critical-material',
  templateUrl: './critical-materials.component.html',
  styleUrls: ['./critical-materials.component.scss'],
  standalone: false,
})
export class Step6CriticalMaterialComponent implements OnInit {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();

  dirtyData = false;
  businessForm;
  isShow = false;
  isPatica = false;
  flowItems;
  unitId = this.route.snapshot.params.unitId;
  businessCase;
  data;
  controls;
  form: FormGroup;
  constructor(
    private commonService: CommonService,
    public router: Router,
    private fb: FormBuilder,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {}
  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.next2();
    } else {
      this.isShow = false;
      this.ngOnInit();
    }

    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }

  ngOnInit() {
    this.controls = {};
    this.http
      .callService(new Method(environment.services.step6Question(this.unitId, 'CRITICAL'), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.generateForm2();
      });
  }

  generateForm2() {
    for (const [key, value] of Object.entries(this.data)) {
      this.controls[key] = new FormControl(false);
    }
    this.form = this.fb.group({
      question: this.fb.group(this.controls),
    });
    setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        if (!deepEqual(res.question, this.data)) {
          this.dirtyData = true;
          this.tabSaveResponse.emit(true);
        }
      });
    }, 1000);
    this.isShow = true;
  }

  next2() {
    this.http
      .callService(new Method(environment.services.step6Question(this.unitId, 'CRITICAL'), this.data, 'put'))
      .subscribe((res) => {
        this.data = this.form.value.question;
        this.flowComplate('CTI_STEP6_BUSINESS');
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }

  uncheck(name: string, value: number, oldValue: number) {
    if (value === oldValue) {
      setTimeout(() => {
        this.data[`${name}`] = null;
      }, 50);
    }
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
}
