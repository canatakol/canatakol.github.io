import { Component, EventEmitter, Input, Output, ChangeDetectorRef, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-bubble-chart',
  templateUrl: './bubble-chart.component.html',
  styleUrls: ['./bubble-chart.component.scss'],
  standalone: true,
  imports: [CommonModule],
})
export class BubbleChartComponent implements OnChanges {
  @Input() public data: any;
  @Input() public isReport: boolean = false;
  rows = Array(7).fill(0);
  columns = Array(7).fill(0);
  groupedThreats: any[] = [];
  threats;
  constructor(private cd: ChangeDetectorRef) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes['data'] && changes['data'].currentValue) {
      this.processData();
      // Remove manual change detection to prevent unnecessary re-renders
      // this.cd.detectChanges();
    }
  }

  processData() {
    this.groupedThreats = this.groupThreats();
  }

  groupThreats() {
    this.threats = [
      {
        key: 'Ma',
        threatValue: Number(this.data.marketThreat),
        vulnerabilityValue: Number(this.data.marketVulnerability),
      },
      {
        key: 'Op',
        threatValue: Number(this.data.operationalThreat),
        vulnerabilityValue: Number(this.data.operationalVulnerability),
      },
      {
        key: 'Bu',
        threatValue: Number(this.data.businessThreat),
        vulnerabilityValue: Number(this.data.businessVulnerability),
      },
      {
        key: 'Le',
        threatValue: Number(this.data.legalThreat),
        vulnerabilityValue: Number(this.data.legalVulnerability),
      },
    ].filter((threat) => threat.threatValue && threat.vulnerabilityValue);

    const grouped: {
      key: string;
      threatValue: number;
      vulnerabilityValue: number;
      left: string;
      bottom: string;
      groupClass: string;
      overlapClass: string;
    }[] = [];

    const positionMap = new Map<string, string[]>();

    this.threats.forEach((threat) => {
      const left = `${threat.vulnerabilityValue * 100}px`;
      const bottom = `${threat.threatValue * 50}px`;

      const positionKey = `${left}-${bottom}`;
      if (!positionMap.has(positionKey)) {
        positionMap.set(positionKey, []);
      }
      positionMap.get(positionKey)!.push(threat.key);

      grouped.push({
        ...threat,
        left,
        bottom,
        groupClass: '',
        overlapClass: '',
      });
    });
    positionMap.forEach((keys, position) => {
      const groupClass = `group-${keys.length}`;

      keys.forEach((key, index) => {
        const overlapClass = `overlap-${index + 1}`;
        const threatIndex = grouped.findIndex((threat) => threat.key === key);
        if (threatIndex !== -1) {
          grouped[threatIndex].groupClass = groupClass;
          grouped[threatIndex].overlapClass = overlapClass;
        }
      });
    });

    return grouped;
  }
}
