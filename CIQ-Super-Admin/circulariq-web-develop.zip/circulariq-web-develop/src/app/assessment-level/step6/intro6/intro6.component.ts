import { Component, Input, OnChanges } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '@env/environment';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { storyblokInit, renderRichText } from '@storyblok/js';
@Component({
  selector: 'app-intro6',
  templateUrl: './intro6.component.html',
  styleUrls: ['./intro6.component.scss'],
  standalone: false,
})
export class Intro6Component {
  @Input() public storyblok: any;
  sanitizedContent: SafeHtml | null = null;
  remember: boolean | null = null;
  unitId = this.route.snapshot.params.unitId;

  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    public router: Router,
    private route: ActivatedRoute,
    private sanitizer: DomSanitizer
  ) {}
  async ngOnChanges() {
    if (this.storyblok && this.storyblok.content) {
      try {
        const storyblokApi = storyblokInit();
        const htmlContent = renderRichText(this.storyblok.content);
        this.sanitizedContent = this.sanitizer.bypassSecurityTrustHtml(htmlContent);
      } catch (error) {
        console.error(error);
      }
    }
  }
  rememberme(val: boolean) {
    this.remember = val;
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
  nextStep() {
    this.flowComplate('CTI_STEP6_INTRO');
    localStorage.setItem('isShowstep6Intro', String(this.remember));
    this.commonService.isShowstep6Intro.next('true');
    this.commonService.step6ActiveCase.next('inflow6');
  }
}
