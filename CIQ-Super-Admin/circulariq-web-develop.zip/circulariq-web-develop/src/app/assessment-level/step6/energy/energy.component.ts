import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { ReportStatusDialog } from '@app/shared/dialog/report-status/report-status-dialog.component';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import deepEqual from 'deep-equal';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-step6-energy',
  templateUrl: './energy.component.html',
  styleUrls: ['./energy.component.scss'],
  standalone: false,
})
export class Step6EnergyComponent implements OnInit {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();

  dirtyData = false;
  isShow = false;
  isPatica = false;
  authToken;
  flowOpportunityOtherUuid;
  flowRisOtherkUuid;
  flowSolutionOtherUuid;
  flowList = [];
  risks = [];
  opportunities = [];
  solutions = [];
  questionList;
  unitId = this.route.snapshot.params.unitId;
  data;
  response;
  controls;
  form: FormGroup;
  constructor(
    private commonService: CommonService,
    private http: ApiRequestService,
    public router: Router,
    private fb: FormBuilder,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private route: ActivatedRoute
  ) {}
  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.next2();
    } else {
      this.isShow = false;
      this.ngOnInit();
    }

    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
    this.authToken = JSON.parse(sessionStorage.getItem('credentials')).authToken;
  }
  ngOnInit() {
    this.controls = {};
    this.http
      .callService(new Method(environment.services.step6Question(this.unitId, 'ENERGY'), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.generateForm2();
      });
  }
  generateForm2() {
    for (const [key, value] of Object.entries(this.data)) {
      this.controls[key] = new FormControl(false);
    }
    this.form = this.fb.group({
      question: this.fb.group(this.controls),
    });
    setTimeout(() => {
      this.form.valueChanges.subscribe((res) => {
        if (!deepEqual(res.question, this.data)) {
          this.dirtyData = true;
          this.tabSaveResponse.emit(true);
        }
      });
    }, 1000);
    this.isShow = true;
  }

  next2() {
    this.goNext();
  }

  goNext() {
    this.http
      .callService(new Method(environment.services.step6Question(this.unitId, 'ENERGY'), this.data, 'put'))
      .subscribe((res) => {
        this.data = this.form.value.question;
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        this.flowComplate('CTI_STEP6_STRATEGY');
      });
  }

  saveComplate() {
    this.http
      .callService(new Method(environment.services.step6Question(this.unitId, 'ENERGY'), this.data, 'put'))
      .subscribe((res) => {
        this.flowComplate('CTI_STEP6_DONE');
        this.flowComplate('CTI_STEP6_BUSINESS');
      });
  }
  reportStatus(unitId: any) {
    this.http.callService(new Method(environment.services.reportStatus(unitId), '', 'get')).subscribe((res) => {
      if (res['canDownload']) {
        if (res['warningMessage']) {
          const dialogRef = this.dialog.open(ReportStatusDialog, {
            width: '80%',
            maxWidth: '430px',
            panelClass: 'centered-dialog',
            data: {
              message: res['warningMessage'],
            },
          });
          dialogRef.afterClosed().subscribe(async (result) => {
            if (!result) {
              return;
            }
            try {
              window.open(`/cti/${unitId}/${this.authToken}/report`);
            } catch (error) {}
          });
        } else {
          window.open(`/cti/${unitId}/${this.authToken}/report`);
        }
      } else {
        this.snackBar.open(res['warningMessage'], '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
      }
    });
  }

  uncheck(name: string, value: number, oldValue: number) {
    if (value === oldValue) {
      setTimeout(() => {
        this.data[`${name}`] = null;
      }, 50);
    }
  }

  generateForm() {
    this.flowList.forEach((element) => {
      this.controls[element.organisationUnitFlowUuid + 'risks'] = new FormControl(false);
      this.controls[element.organisationUnitFlowUuid + 'opportunities'] = new FormControl(false);
      this.controls[element.organisationUnitFlowUuid + 'solutions'] = new FormControl(false);
      this.controls[element.organisationUnitFlowUuid + 'flowRiskOtherName'] = new FormControl(false);
      this.controls[element.organisationUnitFlowUuid + 'flowOpportunityOtherName'] = new FormControl(false);
      this.controls[element.organisationUnitFlowUuid + 'flowSolutionOtherName'] = new FormControl(false);
      element.opportunities.forEach((o) => {
        if (o.text === 'OTHER') {
          this.flowOpportunityOtherUuid = o.uuid;
        }
      });
      element.risks.forEach((o) => {
        if (o.text === 'OTHER') {
          this.flowRisOtherkUuid = o.uuid;
        }
      });
      element.solutions.forEach((o) => {
        if (o.text === 'OTHER') {
          this.flowSolutionOtherUuid = o.uuid;
        }
      });
    });
    this.form = this.fb.group({
      question: this.fb.group(this.controls),
    });
    this.isShow = true;
  }

  next() {
    const list = [];
    this.flowList.forEach((element) => {
      const item = {
        flowImprovementUuid: element.flowImprovementUuid,
        flowSolutionUuid: element.flowSolutionUuid === '0' ? ' ' : element.flowSolutionUuid,
        flowSolutionOtherText:
          element.flowSolutionUuid !== '62cf7bd9-4248-41af-aef7-7c52c92db9fe' ? ' ' : element.flowSolutionOtherName,
      };
      list.push(item);
    });
    const data = {
      flowSolutionRequests: list,
    };
    this.http
      .callService(new Method(environment.services.saveFlowSolution(this.unitId), data, 'put'))
      .subscribe((res) => {
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
        this.flowComplate('CTI_STEP6_STRATEGY');
      });
  }
}
