import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, EmailValidator } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { CommonService } from '@app/core/common.service';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  standalone: false,
})
// tslint:disable-next-line: class-name
export class NewUserComponent implements OnInit {
  isLoading = false;
  user;
  storyblok;
  freeOrganization;
  quote: string;
  registerForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    public router: Router,
    private commonService: CommonService,
    private storyblokService: StoryblokService
  ) {
    this.http.callService(new Method(environment.services.currentUser(), '', 'get')).subscribe((res) => {
      this.user = res;
      this.freeOrganization = this.user?.organisation?.licenseType === 'Free' || false;
      this.createForm();
    });
  }

  register() {
    const data = [{ question: 'CTI_KNOWLEDGE', value: this.registerForm.value.CTI_KNOWLEDGE }];
    this.updateUserNameandLastname(this.registerForm.value);
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      if (this.freeOrganization) {
        this.router.navigate(['/cti/materials'], { replaceUrl: true });
      } else {
        this.http.callService(new Method(environment.services.ctiGuidance(), '', 'get')).subscribe((response) => {
          if (this.commonService.isPro) {
            if (JSON.parse(sessionStorage.getItem('credentials'))['showBLDashboard']) {
              this.router.navigate(['/cti/pro-business'], { replaceUrl: true });
            } else {
              this.router.navigate(['/cti/pro-label'], { replaceUrl: true });
            }
          } else {
            this.router.navigate(['/cti/none/assessment/step1'], { replaceUrl: true });
          }
          setTimeout(() => {
            location.reload();
          }, 2000);
        });
      }
    });
  }

  updateUserNameandLastname(value: any) {
    const data = { firstName: value.firstname, middleName: null, lastName: value.lastname, email: this.user.email };
    this.http.callService(new Method(environment.services.currentUser(), data, 'put')).subscribe((res) => {});
  }

  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'new-user');
      this.storyblok = story[0].content;
    });
  }
  private createForm() {
    this.registerForm = this.formBuilder.group({
      firstname: [this.user ? this.user.firstname : '', Validators.required],
      lastname: [this.user ? this.user.lastname : '', Validators.required],
      email: [this.user.email, [Validators.required, Validators.email]],
    });
  }
}
