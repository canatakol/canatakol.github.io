import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;

@Component({
  selector: 'app-outflow',
  templateUrl: './outflow.component.html',
  styleUrls: ['./outflow.component.scss'],
  standalone: false,
})
export class OutflowComponent {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  fileUrl;
  unitId = this.route.snapshot.params.unitId;
  organizationGoal;
  isEnabledCTIGoal;
  environment = environment;
  reportData;
  outflowCircularPercentage;
  selectedArray = [];
  selectedOperation;
  diffrent = null;
  itemList;
  active;
  rightItems;
  sortNameDirection = null;
  sortWeightDirection = null;
  sortPotentialDirection = null;
  sortActualDirection = null;
  sortOutflowDirection = null;
  weightChangeValue;
  actualRecoveryChangeValue;
  potentialRecoveryChangeValue;
  indicators = JSON.parse(sessionStorage.getItem('indicators'));
  constructor(
    private dialog: MatDialog,
    public router: Router,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    private route: ActivatedRoute
  ) {
    this.organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
    this.isEnabledCTIGoal = JSON.parse(localStorage.getItem('isEnabledCTIGoal'));
    this.onReady();
  }

  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit(true);
    } else {
      this.onReady();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }
  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }

  onReady() {
    this.http
      .callService(new Method(environment.services.improvementList(this.unitId, 'OUTFLOW'), '', 'get'))
      .subscribe((res2) => {
        this.itemList = res2;
        this.http
          .callService(new Method(environment.services.improvement(this.unitId, 'OUTFLOW'), '', 'get'))
          .subscribe((res) => {
            this.rightItems = res;
            res['materials'].forEach((element) => {
              element.selected = true;
              this.itemList.forEach((left) => {
                if (left.flowId === element.id) {
                  left.selected = true;
                }
              });
            });
            this.selectedArray = res['materials'];
            this.http.callService(new Method(environment.services.graph(this.unitId), '', 'get')).subscribe((res3) => {
              this.outflowCircularPercentage = res3['outflowCircularPercentage'];
            });
          });
      });
  }
  addItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const index = this.selectedArray.findIndex((x) => x.id === item.flowId);
    if (index === -1) {
      item.id = item.flowId;
      this.selectedArray.push(item);
      this.selectedArray.sort((a, b) => {
        return b.weight - a.weight;
      });
      this.itemList.forEach((element) => {
        if (element.flowId === item.flowId) {
          element.selected = true;
        }
      });
      this.submit(false);
    }
  }
  removeItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${item['name']}`,
        message: this.storyblok.delete_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const index = this.selectedArray.findIndex((x) => x.id === item.id);
        this.selectedArray.splice(index, 1);
        this.selectedArray.sort((a, b) => {
          return b.weight - a.weight;
        });
        this.itemList.forEach((element) => {
          if (element.flowId === item.id) {
            element.selected = false;
          }
          if (element.id === item.id) {
            element.selected = false;
          }
        });
        this.submit(false);
      } catch (error) {}
    });
  }
  openCalculete(item: any, type: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedOperation = false;
    this.diffrent = null;
    this.selectedArray.forEach((element) => {
      if (element.id === item.id) {
        if (type === 'weight') {
          element.weightChange = !element.weightChange;
          element.potentialRecoveryChange = false;
          element.actualRecoveryChange = false;
          if (element.weightDiff) {
            this.selectedOperation = element.weightDiff < 0 ? '-' : '+';
            this.diffrent = Math.abs(element.weightDiff);
          }
        } else if (type === 'potentialRecovery') {
          element.potentialRecoveryChange = !element.potentialRecoveryChange;
          element.weightChange = false;
          element.actualRecoveryChange = false;
          if (element.potentialRecoveryDiff) {
            this.selectedOperation = element.potentialRecoveryDiff < 0 ? '-' : '+';
            this.diffrent = Math.abs(element.potentialRecoveryDiff);
          }
        } else if (type === 'actualRecovery') {
          element.actualRecoveryChange = !element.actualRecoveryChange;
          element.weightChange = false;
          element.potentialRecoveryChange = false;
          if (element.actualRecoveryDiff) {
            this.selectedOperation = element.actualRecoveryDiff < 0 ? '-' : '+';
            this.diffrent = Math.abs(element.actualRecoveryDiff);
          }
        }
      } else {
        element.weightChange = false;
        element.potentialRecoveryChange = false;
        element.actualRecoveryChange = false;
      }
    });
  }
  calculateDone() {
    const materials = [];
    this.selectedArray.forEach((element) => {
      const piese = {
        id: element.id,
        targetWeight:
          element.weightChangeValue !== null && element.weightChangeValue !== undefined
            ? element.weightChangeValue
            : element.targetWeight,
        targetPotentialRecovery:
          element.potentialRecoveryChangeValue !== null && element.potentialRecoveryChangeValue !== undefined
            ? element.potentialRecoveryChangeValue
            : element.targetPotentialRecovery,
        targetActualRecovery:
          element.actualRecoveryChangeValue !== null && element.actualRecoveryChangeValue !== undefined
            ? element.actualRecoveryChangeValue
            : element.targetActualRecovery,
      };
      materials.push(piese);
    });
    this.http
      .callService(new Method(environment.services.calculateImprovement(this.unitId, 'OUTFLOW'), { materials }, 'put'))
      .subscribe((res) => {
        this.rightItems = res;
        this.selectedArray = this.rightItems['materials'];
      });
    this.changeData();
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
  submit(nextpage: boolean) {
    const materials = [];
    this.selectedArray.forEach((element) => {
      const piese = {
        id: element.id,
        targetWeight:
          element.weightChangeValue !== null && element.weightChangeValue !== undefined
            ? element.weightChangeValue
            : element.targetWeight,
        targetPotentialRecovery:
          element.potentialRecoveryChangeValue !== null && element.potentialRecoveryChangeValue !== undefined
            ? element.potentialRecoveryChangeValue
            : element.targetPotentialRecovery,
        targetActualRecovery:
          element.actualRecoveryChangeValue !== null && element.actualRecoveryChangeValue !== undefined
            ? element.actualRecoveryChangeValue
            : element.targetActualRecovery,
      };
      materials.push(piese);
    });
    const data = {
      materials,
      totalChange: 0,
    };
    this.http
      .callService(new Method(environment.services.improvement(this.unitId, 'OUTFLOW'), data, 'put'))
      .subscribe((res) => {
        if (nextpage) {
          this.flowComplate('CTI_STEP5_OUTFLOW');
          this.snackBar.open(this.commonService.storyblok?.success_message, '', {
            duration: 5000,
            panelClass: ['success-snackBar'],
          });
        } else {
          this.onReady();
        }
      });
  }

  setValue(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }
  setOperation(set: string, value: number, dif: number, target: string) {
    this.selectedOperation = set;
    this.calculate(value, dif, target);
  }

  calculate(item: number, dif: number, target: string) {
    if (target === 'weight') {
      if (this.selectedOperation === '-') {
        item['weightChangeValue'] = item['oldWeight'] - dif;
      } else if (this.selectedOperation === '+') {
        item['weightChangeValue'] = item['oldWeight'] + dif;
      } else if (this.selectedOperation === '-%') {
        item['weightChangeValue'] = item['oldWeight'] - item['oldWeight'] * (dif / 100);
      } else if (this.selectedOperation === '+%') {
        item['weightChangeValue'] = item['oldWeight'] + item['oldWeight'] * (dif / 100);
      }
    }
    if (target === 'potentialRecovery') {
      if (this.selectedOperation === '-') {
        item['potentialRecoveryChangeValue'] = item['oldPotentialRecovery'] - dif;
      } else if (this.selectedOperation === '+') {
        item['potentialRecoveryChangeValue'] = item['oldPotentialRecovery'] + dif;
      } else if (this.selectedOperation === '-%') {
        item['potentialRecoveryChangeValue'] =
          item['oldPotentialRecovery'] - item['oldPotentialRecovery'] * (dif / 100);
      } else if (this.selectedOperation === '+%') {
        item['potentialRecoveryChangeValue'] =
          item['oldPotentialRecovery'] + item['oldPotentialRecovery'] * (dif / 100);
      }
    }
    if (target === 'actualRecovery') {
      if (this.selectedOperation === '-') {
        item['actualRecoveryChangeValue'] = item['oldActualRecovery'] - dif;
      } else if (this.selectedOperation === '+') {
        item['actualRecoveryChangeValue'] = item['oldActualRecovery'] + dif;
      } else if (this.selectedOperation === '-%') {
        item['actualRecoveryChangeValue'] = item['oldActualRecovery'] - item['oldActualRecovery'] * (dif / 100);
      } else if (this.selectedOperation === '+%') {
        item['actualRecoveryChangeValue'] = item['oldActualRecovery'] + item['oldActualRecovery'] * (dif / 100);
      }
    }
  }
  sortName() {
    if (this.sortNameDirection) {
      this.sortNameDirection = false;
      // tslint:disable-next-line:typedef
      this.itemList.sort(function (b, a) {
        if (a.tradeName < b.tradeName) {
          return -1;
        }
        if (a.tradeName > b.tradeName) {
          return 1;
        }
        return 0;
      });
    } else {
      this.sortNameDirection = true;
      // tslint:disable-next-line:typedef
      this.itemList.sort(function (a, b) {
        if (a.tradeName < b.tradeName) {
          return -1;
        }
        if (a.tradeName > b.tradeName) {
          return 1;
        }
        return 0;
      });
    }
    this.sortWeightDirection = null;
    this.sortPotentialDirection = null;
    this.sortActualDirection = null;
    this.sortOutflowDirection = null;
  }

  sortMass() {
    if (this.sortWeightDirection) {
      this.sortWeightDirection = false;
      this.itemList.sort((a, b) => {
        return a.weight - b.weight;
      });
    } else {
      this.sortWeightDirection = true;
      this.itemList.sort((a, b) => {
        return b.weight - a.weight;
      });
    }
    this.sortNameDirection = null;
    this.sortPotentialDirection = null;
    this.sortActualDirection = null;
    this.sortOutflowDirection = null;
  }

  sortPotential() {
    if (this.sortPotentialDirection) {
      this.sortPotentialDirection = false;
      this.itemList.sort((a, b) => {
        return a.potentialRecovery - b.potentialRecovery;
      });
    } else {
      this.sortPotentialDirection = true;
      this.itemList.sort((a, b) => {
        return b.potentialRecovery - a.potentialRecovery;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortActualDirection = null;
    this.sortOutflowDirection = null;
  }
  sortActual() {
    if (this.sortActualDirection) {
      this.sortActualDirection = false;
      this.itemList.sort((a, b) => {
        return a.actualRecovery - b.actualRecovery;
      });
    } else {
      this.sortActualDirection = true;
      this.itemList.sort((a, b) => {
        return b.actualRecovery - a.actualRecovery;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortPotentialDirection = null;
    this.sortOutflowDirection = null;
  }
  sortOutflow() {
    if (this.sortOutflowDirection) {
      this.sortOutflowDirection = false;
      this.itemList.sort((a, b) => {
        return a.wip - b.wip;
      });
    } else {
      this.sortOutflowDirection = true;
      this.itemList.sort((a, b) => {
        return b.wip - a.wip;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortPotentialDirection = null;
    this.sortActualDirection = null;
  }
}
