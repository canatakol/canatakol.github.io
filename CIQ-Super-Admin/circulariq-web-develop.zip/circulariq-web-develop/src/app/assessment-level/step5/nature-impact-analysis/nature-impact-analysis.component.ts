import { AfterContentChecked, Component, Input, OnInit } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { ActivatedRoute } from '@angular/router';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { FormArray, FormBuilder, FormGroup } from '@angular/forms';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-natureimpact-analysis',
  templateUrl: './nature-impact-analysis.component.html',
  styleUrls: ['./nature-impact-analysis.component.scss'],
  standalone: false,
})
export class NatureImpactStep5Component implements OnInit, AfterContentChecked {
  @Input() public blockNavigation: boolean;
  storyblok;
  alphabet = 'ABCD'.split('');
  res;
  cmpBoxShow = false;
  searchText = '';
  showNav;
  showReason;
  inflowListShow = false;
  environment = environment;
  selectedUnitDetails;
  selectedUnit;
  inflows;
  unitId = this.route.snapshot.params.unitId;
  selectedInflow;
  extentValue;
  conditiontValue;
  significanValue;
  extentScore;
  conditionScore;
  significanScore;
  selectedExtent;
  selectedCondition;
  selectedSignifican;
  currentExtent;
  currentCondition;
  currentSignifican;
  data;
  niData;
  addButtonShow = true;
  alternativesForm: FormGroup;
  natureImpactExtentList = environment.services.natureImpactExtentList;
  natureImpactConditionList = environment.services.natureImpactConditionList;
  natureImpactSignificancenList = environment.services.natureImpactSignificancenList;
  constructor(
    private http: ApiRequestService,
    private route: ActivatedRoute,
    private storyblokService: StoryblokService,
    private dialog: MatDialog,
    private fb: FormBuilder,
    private commonService: CommonService,
    private snackBar: MatSnackBar
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step-3-top-boxes');
      this.storyblok = story[0].content;
    });
    this.selectedUnitDetails = JSON.parse(localStorage.getItem('selectedUnit'));
    if (this.unitId) {
      this.getNatureImpact();
    }
  }

  ngOnInit(): void {
    this.alternativesForm = this.fb.group({
      alternatives: this.fb.array([]),
    });
    this.getData();
  }

  getData() {
    this.data = '';
    this.http
      .callService(new Method(environment.services.natureImpactImprovement(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.alternativesForm = this.fb.group({
          alternatives: this.fb.array([]),
        });
        this.setAlternatives();
      });
  }

  deleteAlternative(comp: any, index: number) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: comp.value.flowName,
        message: this.storyblok.delete_confirm_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const control = <FormArray>this.alternativesForm.controls.alternatives;
        control.removeAt(index);
        this.save();
        this.showNav = '';
      } catch (error) {}
    });
  }

  setAlternatives() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const control = <FormArray>this.alternativesForm.controls.alternatives;
    this.data.alternatives.forEach((x) => {
      control.push(
        this.fb.group({
          flowName: x.flowName,
          extendDimension: x.extendDimension,
          conditionDimension: x.conditionDimension,
          significanceDimension: x.significanceDimension,
          natureImpact: x.natureImpact,
          reasonDescription: x.reasonDescription,
        })
      );
    });
  }
  saveReason() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.showReason = '';
    this.addButtonShow = false;
  }
  editAlternative() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.addButtonShow = false;
    this.showNav = '';
  }
  addNewAlternative(size: number) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    if (size > 2) {
      this.snackBar.open(this.storyblok.error_message, '', {
        duration: 5000,
        panelClass: ['error-snackBar'],
      });
    } else {
      const control = <FormArray>this.alternativesForm.controls.alternatives;
      control.push(
        this.fb.group({
          flowName: null,
          extendDimension: null,
          conditionDimension: null,
          significanceDimension: null,
          natureImpact: null,
          reasonDescription: null,
        })
      );
    }
    this.addButtonShow = false;
  }

  getNatureImpact() {
    this.http.callService(new Method(environment.services.natureImpact(this.unitId), '', 'get')).subscribe((res) => {
      this.niData = res;
      if (res['extendDimension']) {
        this.extentValue = res['extendDimension'];
        this.natureImpactExtentList.forEach((element) => {
          if (this.extentValue === element.extendDimension) {
            this.currentExtent = element;
          }
        });
      }
      if (res['conditionDimension']) {
        this.conditiontValue = res['conditionDimension'];
        this.natureImpactConditionList.forEach((element) => {
          if (this.conditiontValue === element.conditionDimension) {
            this.currentCondition = element;
          }
        });
      }
      if (res['significanceDimension']) {
        this.significanValue = res['significanceDimension'];
        this.natureImpactSignificancenList.forEach((element) => {
          if (this.significanValue === element.significanceDimension) {
            this.currentSignifican = element;
          }
        });
      }
      this.selectedInflow = {
        displayName: res['flowName'],
        weight: res['flowMass'],
      };
    });
  }
  ngAfterContentChecked() {
    this.alternativesForm.valueChanges.subscribe((val) => {
      val.alternatives.forEach((element, idx) => {
        let extentScore = null;
        let conditionScore = null;
        let significanScore = null;
        this.natureImpactExtentList.forEach((item) => {
          if (element.extendDimension === item.extendDimension) {
            extentScore = item.score;
          }
        });
        this.natureImpactConditionList.forEach((item) => {
          if (element.conditionDimension === item.conditionDimension) {
            conditionScore = item.score;
          }
        });
        this.natureImpactSignificancenList.forEach((item) => {
          if (element.significanceDimension === item.significanceDimension) {
            significanScore = item.score;
          }
        });
        if (extentScore && conditionScore && significanScore) {
          this.alternativesForm.controls.alternatives.value[idx].natureImpact =
            extentScore * conditionScore * significanScore;
        }
      });
    });
  }

  changeExtent(event: any, idx: number) {
    this.natureImpactExtentList.forEach((element) => {
      if (event === element.extendDimension) {
        this.selectedExtent = element;
        this.extentScore = element.score;
      }
    });
  }
  changeCondition(event: any, idx: number) {
    this.natureImpactConditionList.forEach((element) => {
      if (event === element.conditionDimension) {
        this.selectedCondition = element;
        this.conditionScore = element.score;
      }
    });
  }
  changeSignificancen(event: any, idx: number) {
    this.natureImpactSignificancenList.forEach((element) => {
      if (event === element.significanceDimension) {
        this.selectedSignifican = element;
        this.significanScore = element.score;
      }
    });
  }

  save() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    let isSave = true;
    this.alternativesForm.controls.alternatives.value.forEach((element) => {
      if (!element.flowName) {
        this.snackBar.open(this.storyblok.error_message_2, '', {
          duration: 5000,
          panelClass: ['error-snackBar'],
        });
        isSave = false;
        return;
      }
    });
    if (isSave) {
      this.http
        .callService(
          new Method(
            environment.services.natureImpactImprovement(this.unitId),
            { alternatives: this.alternativesForm.controls.alternatives.value },
            'put'
          )
        )
        .subscribe((res) => {
          this.addButtonShow = true;
          this.getData();
          this.snackBar.open(this.commonService.storyblok?.success_message, '', {
            duration: 5000,
            panelClass: ['success-snackBar'],
          });
        });
    }
  }
}
