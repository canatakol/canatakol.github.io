import { Pipe, PipeTransform } from '@angular/core';
import { environment } from '@env/environment';

@Pipe({
  name: 'convertScore',
  standalone: false,
})
export class ScorePipe implements PipeTransform {
  environment = environment;
  score;
  transform(value: unknown, type: string, ...args: unknown[]): unknown {
    if (type === 'extend') {
      environment.services.natureImpactExtentList.forEach((element) => {
        if (element.extendDimension === value) {
          this.score = element.score;
        }
      });
    }
    if (type === 'condition') {
      environment.services.natureImpactConditionList.forEach((element) => {
        if (element.conditionDimension === value) {
          this.score = element.score;
        }
      });
    }
    if (type === 'significance') {
      environment.services.natureImpactSignificancenList.forEach((element) => {
        if (element.significanceDimension === value) {
          this.score = element.score;
        }
      });
    }
    return this.score;
  }
}
