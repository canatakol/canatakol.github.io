import { Component, OnDestroy } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { NavigationExtras, NavigationStart, Router, Event } from '@angular/router';
import { Subscription } from 'rxjs';
declare var $: any;
@Component({
  selector: 'app-step5',
  templateUrl: './step5.component.html',
  styleUrls: ['./step5.component.scss'],
  standalone: false,
})
export class Step5Component implements OnDestroy {
  activeCase = 'inflow-question';
  isShowstep5Intro;
  storyblok;
  routerEventsSubscription: Subscription;
  blockNavigation = false;
  dirtyData = false;
  redirectUrl;
  constructor(private commonService: CommonService, private storyblokService: StoryblokService, public router: Router) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step5');
      this.storyblok = story[0].content;
    });
    this.isShowstep5Intro = localStorage.getItem('isShowstep5Intro');
    this.commonService.step5ActiveCase.subscribe((res) => {
      this.activeCase = res;
    });
    this.commonService.isShowstep5Intro.subscribe((res) => {
      this.isShowstep5Intro = res;
    });
    this.routerEventsSubscription = this.router.events.subscribe(async (event: Event) => {
      if (event instanceof NavigationStart) {
        this.blockNavigation = this.dirtyData;
        this.redirectUrl = event.url;
        if (this.blockNavigation) {
          const navigationExtras: NavigationExtras = {
            skipLocationChange: false,
          };
          this.router.navigate([this.router.url], navigationExtras);
        }
      }
    });
  }
  async tabSaveResponse(value: boolean) {
    this.dirtyData = value;
  }
  tabClick(value: boolean) {
    this.blockNavigation = value;
  }
  ngOnDestroy() {
    this.routerEventsSubscription.unsubscribe();
    this.commonService.step5ActiveCase.next('inflow-question');
  }
}
