import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;
@Component({
  selector: 'app-inflow-questions',
  templateUrl: './inflow-questions.component.html',
  styleUrls: ['./inflow-questions.component.scss'],
  standalone: false,
})
export class InflowQuestionsComponent implements OnInit {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  registerForm: FormGroup;
  rightItems;
  inflowCircularPercentage;
  unitId = this.route.snapshot.params.unitId;
  constructor(
    private formBuilder: FormBuilder,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private commonService: CommonService,
    private route: ActivatedRoute
  ) {}

  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit();
    } else {
      this.ngOnInit();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }

  ngOnInit() {
    this.http
      .callService(new Method(environment.services.improvement(this.unitId, 'INFLOW'), '', 'get'))
      .subscribe((res) => {
        this.rightItems = res;
        this.createForm();
      });
    this.http.callService(new Method(environment.services.graph(this.unitId), '', 'get')).subscribe((res) => {
      this.inflowCircularPercentage = res['inflowCircularPercentage'];
    });
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
  submit() {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const data = {
      why: this.registerForm.value.why,
      expect: this.registerForm.value.expect,
      whyExpect: this.registerForm.value.whyExpect,
      focus: this.registerForm.value.focus,
      whyFocus: this.registerForm.value.whyFocus,
      limitations: this.registerForm.value.limitations,
      whyLimitations: this.registerForm.value.whyLimitations,
    };
    this.http
      .callService(new Method(environment.services.improvementQuestiont(this.unitId, 'INFLOW'), data, 'put'))
      .subscribe((res) => {
        this.flowComplate('CTI_STEP5_INFLOW_QUESTIONS');
        this.snackBar.open(this.commonService.storyblok?.success_message, '', {
          duration: 5000,
          panelClass: ['success-snackBar'],
        });
      });
  }
  private createForm() {
    this.registerForm = this.formBuilder.group({
      why: [this.rightItems ? this.rightItems.why : '', Validators.required],
      expect: [this.rightItems ? this.rightItems.expect : ''],
      whyExpect: [this.rightItems ? this.rightItems.whyExpect : ''],
      focus: [this.rightItems ? this.rightItems.focus : ''],
      whyFocus: [this.rightItems ? this.rightItems.whyFocus : ''],
      limitations: [this.rightItems ? this.rightItems.limitations : ''],
      whyLimitations: [this.rightItems ? this.rightItems.whyLimitations : ''],
    });
  }
}
