import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;
@Component({
  selector: 'app-energy-analysis',
  templateUrl: './energy-analysis.component.html',
  styleUrls: ['./energy-analysis.component.scss'],
  standalone: false,
})
export class EnergyAnalysisComponent {
  data;
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  renewableOperation;
  totalOperation;
  unitId = this.route.snapshot.params.unitId;
  environment = environment;
  selectedOperation;
  renewableChange = false;
  totalChange = false;
  diffrent = null;
  renewableEnergyConsumption = null;
  totalEnergyConsumption = null;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {
    this.onReady();
  }
  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit();
    } else {
      this.onReady();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }
  onReady() {
    this.http
      .callService(new Method(environment.services.energyImprovement(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.renewableOperation = this.data.renewableEnergyConsumptionDelta < 0 ? false : true;
        this.totalOperation = this.data.totalEnergyConsumptionDelta < 0 ? false : true;
        this.data.renewableChangeValue = this.data.targetRenewableEnergyConsumption;
        this.data.totalChangeValue = this.data.targetTotalEnergyConsumption;
        this.renewableEnergyConsumption = this.data.renewableEnergyConsumptionDelta;
        this.totalEnergyConsumption = this.data.totalEnergyConsumptionDelta;
      });
  }

  openCalculete(type: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedOperation = false;
    this.diffrent = null;
    this.data.renewableChangeValue = this.data.targetRenewableEnergyConsumption;
    this.data.totalChangeValue = this.data.targetTotalEnergyConsumption;
    if (type === 'renewableChange') {
      this.renewableChange = !this.renewableChange;
      this.totalChange = false;
      if (this.data.renewableEnergyConsumptionDelta !== '0') {
        this.selectedOperation = this.data.renewableEnergyConsumptionDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.renewableEnergyConsumptionDelta);
      }
    } else if (type === 'totalChange') {
      this.totalChange = !this.totalChange;
      this.renewableChange = false;
      if (this.data.totalEnergyConsumptionDelta !== '0') {
        this.selectedOperation = this.data.totalEnergyConsumptionDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.totalEnergyConsumptionDelta);
      }
    }
  }
  calculateDone(value: number, target: string) {
    if (target === 'renewable') {
      this.data.renewableEnergyConsumptionDelta = value;
      this.data.renewableEnergyConsumptionIncrease = this.renewableOperation;
      this.data.renewableEnergyConsumptionDecrease = !this.renewableOperation;
    }
    if (target === 'total') {
      this.data.totalEnergyConsumptionDelta = value;
      this.data.totalEnergyConsumptionIncrease = this.totalOperation;
      this.data.totalEnergyConsumptionDecrease = !this.totalOperation;
    }
    this.changeData();
    this.renewableChange = false;
    this.totalChange = false;
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }

  submit() {
    const pure = {
      renewableEnergyConsumptionDelta: this.renewableEnergyConsumption,
      totalEnergyConsumptionDelta: this.totalEnergyConsumption,
    };
    this.http
      .callService(new Method(environment.services.energyImprovement(this.unitId), pure, 'put'))
      .subscribe((res) => {
        this.data = res;
        this.data['renewableChangeValue'] = this.data['currentRenewableEnergyConsumption'];
        this.data['totalChangeValue'] = this.data['currentTotalEnergyConsumption'];
      });
    this.flowComplate('CTI_STEP5_ENERGY');
    this.snackBar.open(this.commonService.storyblok?.success_message, '', {
      duration: 5000,
      panelClass: ['success-snackBar'],
    });
  }

  setRenewable(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }
  setTotal(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }
  setOperation(set: string, value: number, dif: number, target: string) {
    if (target === 'renewableChange') {
      this.renewableOperation = set === '+' ? true : false;
    }
    if (target === 'totalChange') {
      this.totalOperation = set === '+' ? true : false;
    }
    this.selectedOperation = set;
    this.calculate(value, dif, target);
  }

  calculate(value: number, dif: number, target: string) {
    if (target === 'renewableChange') {
      if (this.selectedOperation === '-') {
        this.data['renewableChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['renewableChangeValue'] = Number(value) + Number(dif);
      }
      this.renewableEnergyConsumption = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
    if (target === 'totalChange') {
      if (this.selectedOperation === '-') {
        this.data['totalChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['totalChangeValue'] = Number(value) + Number(dif);
      }
      this.totalEnergyConsumption = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
  }
}
