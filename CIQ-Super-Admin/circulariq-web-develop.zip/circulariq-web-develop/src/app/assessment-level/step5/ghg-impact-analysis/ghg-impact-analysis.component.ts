import { Component, EventEmitter, Input, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;

@Component({
  selector: 'app-ghg-impact-analysis',
  templateUrl: './ghg-impact-analysis.component.html',
  styleUrls: ['./ghg-impact-analysis.component.scss'],
  standalone: false,
})
export class GHGImpactAnalysisComponent {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  inflowCircularPercentage;
  environment = environment;
  diffrent = null;
  itemList;
  active;
  unitId = this.route.snapshot.params.unitId;
  rightItems;
  sortNameDirection = null;
  sortWeightDirection = null;
  sortVirginDirection = null;
  sortGHGpotentialDirection = null;
  circularityChangeValue;

  constructor(
    private dialog: MatDialog,
    private http: ApiRequestService,
    private commonService: CommonService,
    public router: Router,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {
    this.getData({}, true);
  }
  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit();
    } else {
      this.getData({}, false, true);
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }

  calculateDone(item: any) {
    const data = {
      flowImprovements: [],
    };
    this.itemList.improvedMaterials.forEach((element) => {
      element.virginPercentageChange = false;
      let targetPercentageImprovementValue = 0;
      if (element.diffrent !== undefined) {
        if (element.diffrent > element.virginPercentage) {
          targetPercentageImprovementValue = element.virginPercentage;
        } else {
          targetPercentageImprovementValue = element.diffrent;
        }
      } else {
        targetPercentageImprovementValue = element.targetPercentageReduction;
      }
      data.flowImprovements.push({
        productUuid: element.flowUuid,
        targetPercentageRecoveredSourceIncrease: Math.abs(targetPercentageImprovementValue),
      });
    });
    this.changeData();
    this.getData(data, false);
  }

  getData(data: any, save: boolean, reset?: boolean) {
    if (reset) {
      this.itemList = null;
    }
    this.http
      .callService(new Method(environment.services.ghgImprovement(this.unitId, 'INFLOW', save), data, 'put'))
      .subscribe((res) => {
        this.itemList = res;
        this.calcPercentage(this.itemList);
      });
  }

  calcPercentage(data: any) {
    if (data.improvedMaterials?.length > 0) {
      const largestImprovedMaterials = Math.max.apply(
        Math,
        data.improvedMaterials.map(function (o: any) {
          return o.potentialGhgSavings;
        })
      );

      data.potentialImprovementResult = Number(
        data.improvedMaterials.reduce((n, { potentialGhgSavings }) => n + potentialGhgSavings, 0)
      );
      data.scenarioResult = Number(
        data.improvedMaterials.reduce((n, { scenarioGhgSavings }) => n + scenarioGhgSavings, 0)
      );
      data.sumScenarioPercentage = (data.scenarioResult / data.potentialImprovementResult) * 100;
      data.improvedMaterials.forEach((item) => {
        item.percentage = (item.potentialGhgSavings / largestImprovedMaterials) * 100;
        item.scenarioPercentage = (item.scenarioGhgSavings / item.potentialGhgSavings) * 100;
      });
    }
  }

  addItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const index = this.itemList.unimprovedMaterials.findIndex((x) => x.flowUuid === item.flowUuid);
    this.itemList.improvedMaterials.push(item);
    this.itemList.unimprovedMaterials.splice(index, 1);
    this.goToService();
  }
  removeItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${item['name']}`,
        message: this.storyblok.delete_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const index = this.itemList.improvedMaterials.findIndex((x) => x.flowUuid === item.flowUuid);
        this.itemList.unimprovedMaterials.push(item);
        this.itemList.improvedMaterials.splice(index, 1);
        this.http
          .callService(new Method(environment.services.deleteGHGMaterial(this.unitId, item.flowUuid), {}, 'delete'))
          .subscribe((res) => {
            this.goToService();
          });
      } catch (error) {}
    });
  }

  openCalculate(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.diffrent = null;
    this.itemList.improvedMaterials.forEach((element) => {
      if (element.flowUuid === item.flowUuid) {
        element.virginPercentageChange = !element.virginPercentageChange;
        element.circularityChange = false;
      } else {
        element.virginPercentageChange = false;
      }
    });
  }

  goToService() {
    const data = {
      flowImprovements: [],
    };
    this.itemList.improvedMaterials.forEach((element) => {
      let targetPercentageImprovementValue = 0;
      if (element.diffrent !== undefined) {
        if (element.diffrent > element.virginPercentage) {
          targetPercentageImprovementValue = element.virginPercentage;
        } else {
          targetPercentageImprovementValue = element.diffrent;
        }
      } else {
        targetPercentageImprovementValue = element.targetPercentageReduction;
      }
      data.flowImprovements.push({
        productUuid: element.flowUuid,
        targetPercentageRecoveredSourceIncrease: Math.abs(targetPercentageImprovementValue),
      });
    });
    this.getData(data, true);
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }

  submit() {
    this.goToService();
    this.snackBar.open(this.commonService.storyblok?.success_message, '', {
      duration: 5000,
      panelClass: ['success-snackBar'],
    });
    this.flowComplate('CTI_STEP5_GHG');
  }

  calculate(item: any, dif: number) {
    if (dif > item.virginPercentage) {
      this.diffrent = item.virginPercentage;
      item['virginPercentageChangeValue'] = item['nonVirginPercentage'];
      item['targetPercentageReduction'] = item['nonVirginPercentage'];
    } else {
      item['virginPercentageChangeValue'] = item['nonVirginPercentage'] + dif;
      item['targetPercentageReduction'] = dif;
    }
    item.diffrent = dif;
  }

  sortName() {
    if (this.sortNameDirection) {
      this.sortNameDirection = false;
      // tslint:disable-next-line:typedef
      this.itemList.unimprovedMaterials.sort(function (b, a) {
        if (a.name < b.name) {
          return -1;
        }
        if (a.name > b.name) {
          return 1;
        }
        return 0;
      });
    } else {
      this.sortNameDirection = true;
      // tslint:disable-next-line:typedef
      this.itemList.unimprovedMaterials.sort(function (a, b) {
        if (a.name < b.name) {
          return -1;
        }
        if (a.name > b.name) {
          return 1;
        }
        return 0;
      });
    }
    this.sortWeightDirection = null;
    this.sortVirginDirection = null;
    this.sortGHGpotentialDirection = null;
  }
  sortMass() {
    if (this.sortWeightDirection) {
      this.sortWeightDirection = false;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return a.weight - b.weight;
      });
    } else {
      this.sortWeightDirection = true;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return b.weight - a.weight;
      });
    }
    this.sortNameDirection = null;
    this.sortVirginDirection = null;
    this.sortGHGpotentialDirection = null;
  }

  sortVirgincontent() {
    if (this.sortVirginDirection) {
      this.sortVirginDirection = false;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return a.virginPercentage - b.virginPercentage;
      });
    } else {
      this.sortVirginDirection = true;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return b.virginPercentage - a.virginPercentage;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortGHGpotentialDirection = null;
  }

  sortGHGpotential() {
    if (this.sortGHGpotentialDirection) {
      this.sortGHGpotentialDirection = false;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return a.potentialGhgSavings - b.potentialGhgSavings;
      });
    } else {
      this.sortGHGpotentialDirection = true;
      this.itemList.unimprovedMaterials.sort((a, b) => {
        return b.potentialGhgSavings - a.potentialGhgSavings;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortVirginDirection = null;
  }
}
