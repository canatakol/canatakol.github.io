import { Component, EventEmitter, Input, Output, Inject, LOCALE_ID } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { SetOrganisationGoalAssessmentDialog } from '@app/shared/dialog/set-organisation-goal/set_organisation_goal_dialog.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-inflow',
  templateUrl: './inflow.component.html',
  styleUrls: ['./inflow.component.scss'],
  standalone: false,
})
export class InflowComponent {
  @Input() public storyblok: any;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  selectedArray = [];
  inflowCircularPercentage;
  environment = environment;
  selectedOperation;
  organizationGoal;
  isEnabledCTIGoal;
  diffrent = null;
  itemList;
  indicators = JSON.parse(sessionStorage.getItem('indicators'));
  active;
  unitId = this.route.snapshot.params.unitId;
  rightItems;
  sortNameDirection = null;
  sortWeightDirection = null;
  sortLinearDirection = null;
  sortMassLinearDirection = null;
  weightChangeValue;
  circularityChangeValue;

  constructor(
    private dialog: MatDialog,
    private snackBar: MatSnackBar,
    private http: ApiRequestService,
    private commonService: CommonService,
    private route: ActivatedRoute,
    @Inject(LOCALE_ID) public locale: string
  ) {
    this.onReady();
    this.organizationGoal = JSON.parse(localStorage.getItem('organizationGoal'));
    this.isEnabledCTIGoal = JSON.parse(localStorage.getItem('isEnabledCTIGoal'));
  }

  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit(true);
    } else {
      this.onReady();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }

  async setOrganisationGoal(target: any) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const dialogRef = this.dialog.open(SetOrganisationGoalAssessmentDialog, {
      width: '80%',
      maxWidth: '1200px',
      panelClass: 'centered-dialog',
      data: this.organizationGoal,
    });

    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        this.http
          .callService(new Method(environment.services.setOrganisationGoal(), result, 'put'))
          .subscribe(async (res) => {
            this.snackBar.open(this.commonService.storyblok?.success_message, '', {
              duration: 5000,
              panelClass: ['success-snackBar'],
            });
            this.getOrganizationGoal();
          });
      } catch (error) {}
    });
  }
  getOrganizationGoal() {
    this.http.callService(new Method(environment.services.setOrganisationGoal(), '', 'get')).subscribe((res) => {
      this.organizationGoal = res;
      localStorage.setItem('organizationGoal', JSON.stringify(this.organizationGoal));
    });
  }

  onReady() {
    this.http
      .callService(new Method(environment.services.improvementList(this.unitId, 'INFLOW'), '', 'get'))
      .subscribe((res2) => {
        this.itemList = res2;
        this.http
          .callService(new Method(environment.services.improvement(this.unitId, 'INFLOW'), '', 'get'))
          .subscribe((res) => {
            this.rightItems = res;
            this.selectedArray = this.rightItems['materials'];
            this.selectedArray.forEach((element) => {
              element.selected = true;
              this.itemList.forEach((left) => {
                if (left.flowId === element.id) {
                  left.selected = true;
                }
              });
            });
            this.http.callService(new Method(environment.services.graph(this.unitId), '', 'get')).subscribe((res3) => {
              this.inflowCircularPercentage = res3['inflowCircularPercentage'];
            });
          });
      });
  }
  addItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const index = this.selectedArray.findIndex((x) => x.id === item.flowId);
    if (index === -1) {
      item.id = item.flowId;
      this.selectedArray.push(item);
      this.itemList.forEach((element) => {
        if (element.flowId === item.flowId) {
          element.selected = true;
        }
      });
    }
    this.submit(false);
  }
  removeItem(item: any) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    const dialogRef = this.dialog.open(DeleteConfirmDialog, {
      width: '80%',
      maxWidth: '600px',
      panelClass: 'centered-dialog',
      data: {
        title: `${item['name']}`,
        message: this.storyblok.delete_modal_text,
      },
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      if (!result) {
        return;
      }
      try {
        const index = this.selectedArray.findIndex((x) => x.id === item.id);
        this.selectedArray.splice(index, 1);
        this.itemList.forEach((element) => {
          if (element.flowId === item.id) {
            element.selected = false;
          }
          if (element.id === item.id) {
            element.selected = false;
          }
        });
        this.submit(false);
      } catch (error) {}
    });
  }

  openCalculete(item: any, type: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedOperation = false;
    this.diffrent = null;
    this.selectedArray.forEach((element) => {
      if (element.id === item.id) {
        if (type === 'weight') {
          element.weightChange = !element.weightChange;
          element.circularityChange = false;
          if (element.weightDiff) {
            this.selectedOperation = element.weightDiff < 0 ? '-' : '+';
            this.diffrent = Math.abs(element.weightDiff);
          }
        } else if (type === 'circularity') {
          element.circularityChange = !element.circularityChange;
          element.weightChange = false;
          if (element.inflowCircularityDiff) {
            this.selectedOperation = element.inflowCircularityDiff < 0 ? '-' : '+';
            this.diffrent = Math.abs(element.inflowCircularityDiff);
          }
        }
      } else {
        element.weightChange = false;
        element.circularityChange = false;
      }
    });
  }
  calculateDone() {
    const materials = [];
    this.selectedArray.forEach((element) => {
      const piese = {
        id: element.id,
        targetWeight:
          element.weightChangeValue !== null && element.weightChangeValue !== undefined
            ? element.weightChangeValue
            : element.targetWeight,
        targetInflowCircularity:
          element.circularityChangeValue !== null && element.circularityChangeValue !== undefined
            ? element.circularityChangeValue
            : element.targetInflowCircularity,
      };
      materials.push(piese);
    });
    this.http
      .callService(new Method(environment.services.calculateImprovement(this.unitId, 'INFLOW'), { materials }, 'put'))
      .subscribe((res) => {
        this.rightItems = res;
        this.selectedArray = this.rightItems['materials'];
      });
    this.changeData();
  }
  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }
  submit(nextpage: boolean) {
    const materials = [];
    this.selectedArray.forEach((element) => {
      const piese = {
        id: element.id,
        targetWeight:
          element.weightChangeValue !== null && element.weightChangeValue !== undefined
            ? element.weightChangeValue
            : element.targetWeight,
        targetInflowCircularity:
          element.circularityChangeValue !== null && element.circularityChangeValue !== undefined
            ? element.circularityChangeValue
            : element.targetInflowCircularity,
      };
      materials.push(piese);
    });
    const data = {
      materials,
      totalChange: 0,
    };
    this.http
      .callService(new Method(environment.services.improvement(this.unitId, 'INFLOW'), data, 'put'))
      .subscribe((res) => {
        if (nextpage) {
          this.flowComplate('CTI_STEP5_INFLOW');
          this.snackBar.open(this.commonService.storyblok?.success_message, '', {
            duration: 5000,
            panelClass: ['success-snackBar'],
          });
        } else {
          this.onReady();
        }
      });
  }

  setWeight(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }

  setPotential(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }
  setOperation(set: string, value: number, dif: number, target: string) {
    this.selectedOperation = set;
    this.calculate(value, dif, target);
  }

  calculate(item: number, dif: number, target: string) {
    if (target === 'weight') {
      if (this.selectedOperation === '-') {
        item['weightChangeValue'] = item['oldWeight'] - dif;
      } else if (this.selectedOperation === '+') {
        item['weightChangeValue'] = item['oldWeight'] + dif;
      } else if (this.selectedOperation === '-%') {
        item['weightChangeValue'] = item['oldWeight'] - item['oldWeight'] * (dif / 100);
      } else if (this.selectedOperation === '+%') {
        item['weightChangeValue'] = item['oldWeight'] + item['oldWeight'] * (dif / 100);
      }
    }
    if (target === 'circularity') {
      if (this.selectedOperation === '-') {
        item['circularityChangeValue'] = item['oldInflowCircularity'] - dif;
      } else if (this.selectedOperation === '+') {
        item['circularityChangeValue'] = item['oldInflowCircularity'] + dif;
      } else if (this.selectedOperation === '-%') {
        item['circularityChangeValue'] = item['oldInflowCircularity'] - item['oldInflowCircularity'] * (dif / 100);
      } else if (this.selectedOperation === '+%') {
        item['circularityChangeValue'] = item['oldInflowCircularity'] + item['oldInflowCircularity'] * (dif / 100);
      }
    }
  }
  sortName() {
    if (this.sortNameDirection) {
      this.sortNameDirection = false;
      // tslint:disable-next-line:typedef
      this.itemList.sort(function (b, a) {
        if (a.tradeName < b.tradeName) {
          return -1;
        }
        if (a.tradeName > b.tradeName) {
          return 1;
        }
        return 0;
      });
    } else {
      this.sortNameDirection = true;
      // tslint:disable-next-line:typedef
      this.itemList.sort(function (a, b) {
        if (a.tradeName < b.tradeName) {
          return -1;
        }
        if (a.tradeName > b.tradeName) {
          return 1;
        }
        return 0;
      });
    }
    this.sortWeightDirection = null;
    this.sortLinearDirection = null;
    this.sortMassLinearDirection = null;
  }
  sortMass() {
    if (this.sortWeightDirection) {
      this.sortWeightDirection = false;
      this.itemList.sort((a, b) => {
        return a.weight - b.weight;
      });
    } else {
      this.sortWeightDirection = true;
      this.itemList.sort((a, b) => {
        return b.weight - a.weight;
      });
    }
    this.sortNameDirection = null;
    this.sortLinearDirection = null;
    this.sortMassLinearDirection = null;
  }

  sortLinearInflow() {
    if (this.sortLinearDirection) {
      this.sortLinearDirection = false;
      this.itemList.sort((a, b) => {
        return a.circularPercentage - b.circularPercentage;
      });
    } else {
      this.sortLinearDirection = true;
      this.itemList.sort((a, b) => {
        return b.circularPercentage - a.circularPercentage;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortMassLinearDirection = null;
  }

  sortMassLinear() {
    if (this.sortMassLinearDirection) {
      this.sortMassLinearDirection = false;
      this.itemList.sort((a, b) => {
        return a.wip - b.wip;
      });
    } else {
      this.sortMassLinearDirection = true;
      this.itemList.sort((a, b) => {
        return b.wip - a.wip;
      });
    }
    this.sortNameDirection = null;
    this.sortWeightDirection = null;
    this.sortLinearDirection = null;
  }
}
