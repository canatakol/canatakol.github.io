import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CommonService } from '@app/core/common.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
declare var $: any;

@Component({
  selector: 'app-water-analysis',
  templateUrl: './water-analysis.component.html',
  styleUrls: ['./water-analysis.component.scss'],
  standalone: false,
})
export class WaterAnalysisComponent {
  @Input() public storyblok: any;
  data;
  @Input() public blockNavigation: boolean;
  @Output() tabSaveResponse: EventEmitter<any> = new EventEmitter();
  dirtyData = false;
  onSiteWaterCirculation;
  isGHGShow;
  unitId = this.route.snapshot.params.unitId;
  environment = environment;
  selectedOperation;
  waterInflowOperation;
  waterOutflowOperation;
  waterUseOperation;
  totalWaterOperation;
  withdrawalChange = false;
  dischargeChange = false;
  waterChange = false;
  totalWaterChange = false;
  diffrent = null;
  circularWaterWithdrawal = null;
  circularWaterDischarge = null;
  currentWater = null;
  currentTotalWater = null;
  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    public router: Router,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute
  ) {
    this.isGHGShow = this.commonService.isGHGShow;
    this.onReady();
  }
  changeData() {
    this.dirtyData = true;
    this.tabSaveResponse.emit(true);
  }

  async saveBoxResponse(value: boolean) {
    if (value) {
      await this.submit();
    } else {
      this.onReady();
    }
    this.blockNavigation = false;
    this.dirtyData = false;
    this.tabSaveResponse.emit(false);
  }
  onReady() {
    this.http
      .callService(new Method(environment.services.waterImprovement(this.unitId), '', 'get'))
      .subscribe((res) => {
        this.data = res;
        this.waterInflowOperation = this.data.circularWaterWithdrawalDelta < 0 ? false : true;
        this.waterOutflowOperation = this.data.circularWaterDischargeDelta < 0 ? false : true;
        this.waterUseOperation = this.data.totalWaterUseDelta < 0 ? false : true;
        this.totalWaterOperation = this.data.totalWaterWithdrawalDelta < 0 ? false : true;
        this.data.withdrawalChangeValue = this.data.targetCircularWaterWithdrawal;
        this.data.dischargeChangeValue = this.data.targetCircularWaterDischarge;
        this.data.waterChangeValue = this.data.targetWaterUse;
        this.data.totalWaterChangeValue = this.data.targetTotalWaterWithdrawal;
        this.circularWaterWithdrawal = this.data.circularWaterWithdrawalDelta;
        this.circularWaterDischarge = this.data.circularWaterDischargeDelta;
        this.currentWater = this.data.totalWaterUseDelta;
        this.currentTotalWater = this.data.totalWaterWithdrawalDelta;
      });

    this.http.callService(new Method(environment.services.getIndicators(this.unitId), '', 'get')).subscribe((res) => {
      this.onSiteWaterCirculation = res['onSiteWaterCirculation'];
    });
  }

  openCalculete(type: string) {
    if (!this.commonService.userRoleValidation(['Admin', 'Member'])) {
      return;
    }
    this.selectedOperation = false;
    this.diffrent = null;
    this.data.withdrawalChangeValue = this.data.targetCircularWaterWithdrawal;
    this.data.dischargeChangeValue = this.data.targetCircularWaterDischarge;
    this.data.waterChangeValue = this.data.targetWaterUse;
    this.data.totalWaterChangeValue = this.data.targetTotalWaterWithdrawal;
    if (type === 'withdrawalChange') {
      this.withdrawalChange = !this.withdrawalChange;
      this.dischargeChange = false;
      this.waterChange = false;
      this.totalWaterChange = false;
      if (this.data.circularWaterWithdrawalDelta !== '0') {
        this.selectedOperation = this.data.circularWaterWithdrawalDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.circularWaterWithdrawalDelta);
      }
    } else if (type === 'dischargeChange') {
      this.dischargeChange = !this.dischargeChange;
      this.withdrawalChange = false;
      this.waterChange = false;
      this.totalWaterChange = false;
      if (this.data.circularWaterDischargeDelta !== '0') {
        this.selectedOperation = this.data.circularWaterDischargeDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.circularWaterDischargeDelta);
      }
    } else if (type === 'waterChange') {
      this.waterChange = !this.waterChange;
      this.withdrawalChange = false;
      this.dischargeChange = false;
      this.totalWaterChange = false;
      if (this.data.totalWaterUseDelta !== '0') {
        this.selectedOperation = this.data.totalWaterUseDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.totalWaterUseDelta);
      }
    } else if (type === 'totalWaterChange') {
      this.totalWaterChange = !this.totalWaterChange;
      this.withdrawalChange = false;
      this.dischargeChange = false;
      this.waterChange = false;
      if (this.data.totalWaterWithdrawalDelta !== '0') {
        this.selectedOperation = this.data.totalWaterWithdrawalDelta < 0 ? '-' : '+';
        this.diffrent = Math.abs(this.data.totalWaterWithdrawalDelta);
      }
    }
  }
  calculateDone(value: number, target: string) {
    this.changeData();
    this.withdrawalChange = false;
    this.dischargeChange = false;
    this.waterChange = false;
    this.totalWaterChange = false;
    if (target === 'waterInflow') {
      this.data.circularWaterWithdrawalDelta = value;
      this.data.circularWaterWithdrawalIncrease = this.waterInflowOperation;
      this.data.circularWaterWithdrawalDecrease = !this.waterInflowOperation;
    }
    if (target === 'waterOutflow') {
      this.data.circularWaterDischargeDelta = value;
      this.data.circularWaterDischargeIncrease = this.waterOutflowOperation;
      this.data.circularWaterDischargeDecrease = !this.waterOutflowOperation;
    }
    if (target === 'waterUse') {
      this.data.totalWaterUseDelta = value;
      this.data.totalWaterUseIncrease = this.waterUseOperation;
      this.data.totalWaterUseDecrease = !this.waterUseOperation;
    }
    if (target === 'waterWithdrawal') {
      this.data.totalWaterWithdrawalDelta = value;
      this.data.totalWaterWithdrawalIncrease = this.totalWaterOperation;
      this.data.totalWaterWithdrawalDecrease = !this.totalWaterOperation;
    }
  }
  setOperation(set: string, value: number, dif: number, target: string) {
    if (target === 'withdrawalChange') {
      this.waterInflowOperation = set === '+' ? true : false;
    }
    if (target === 'dischargeChange') {
      this.waterOutflowOperation = set === '+' ? true : false;
    }
    if (target === 'waterChange') {
      this.waterUseOperation = set === '+' ? true : false;
    }
    if (target === 'totalWaterChange') {
      this.totalWaterOperation = set === '+' ? true : false;
    }
    this.selectedOperation = set;
    this.calculate(value, dif, target);
  }

  flowComplate(flow: string) {
    const data = [{ question: flow, value: true, entityId: this.unitId }];
    this.http.callService(new Method(environment.services.guidance(), data, 'put')).subscribe((res) => {
      this.commonService.refreshUnitGuindance(this.unitId);
    });
  }

  submit() {
    const pure = {
      circularWaterWithdrawalDelta: this.circularWaterWithdrawal,
      circularWaterDischargeDelta: this.circularWaterDischarge,
      totalWaterUseDelta: this.currentWater,
      totalWaterWithdrawalDelta: this.currentTotalWater,
    };
    this.http
      .callService(new Method(environment.services.waterImprovement(this.unitId), pure, 'put'))
      .subscribe((res) => {
        this.data = res;
        this.data['withdrawalChangeValue'] = this.data['currentCircularWaterWithdrawal'];
        this.data['dischargeChangeValue'] = this.data['currentCircularWaterDischarge'];
        this.data['waterChangeValue'] = this.data['currentWaterUse'];
        this.data['totalWaterChange'] = this.data['currentTotalWaterWithdrawal'];
      });
    this.flowComplate('CTI_STEP5_WATER');
    if (this.isGHGShow) {
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
    } else {
      this.router.navigate([`/cti/${this.unitId}/assessment/step6`]);
    }
  }

  setRenewable(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }
  setTotal(value: number, dif: number, target: string) {
    this.calculate(value, dif, target);
  }

  calculate(value: number, dif: number, target: string) {
    if (target === 'withdrawalChange') {
      if (this.selectedOperation === '-') {
        this.data['withdrawalChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['withdrawalChangeValue'] = Number(value) + Number(dif);
      }
      this.circularWaterWithdrawal = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
    if (target === 'dischargeChange') {
      if (this.selectedOperation === '-') {
        this.data['dischargeChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['dischargeChangeValue'] = Number(value) + Number(dif);
      }
      this.circularWaterDischarge = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
    if (target === 'waterChange') {
      if (this.selectedOperation === '-') {
        this.data['waterChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['waterChangeValue'] = Number(value) + Number(dif);
      }
      this.currentWater = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
    if (target === 'totalWaterChange') {
      if (this.selectedOperation === '-') {
        this.data['totalWaterChangeValue'] = Number(value) - Number(dif);
      } else if (this.selectedOperation === '+') {
        this.data['totalWaterChangeValue'] = Number(value) + Number(dif);
      }
      this.currentTotalWater = this.selectedOperation === '-' ? Number(-dif) : Number(dif);
    }
  }
}
