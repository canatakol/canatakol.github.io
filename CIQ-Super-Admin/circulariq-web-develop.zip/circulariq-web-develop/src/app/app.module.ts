import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { ServiceWorkerModule } from '@angular/service-worker';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { CommonModule, DecimalPipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { environment } from '@env/environment';
import { CoreModule } from '@app/core';
import { SharedModule } from '../app/shared/shared.module';
import { ShellModule } from '../app/shell/shell.module';
import { LoginModule } from './login/login.module';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { CiqNumberPipe } from '@app/pipes/CIQNumberPipe';
import { TruncatePipe } from '@app/pipes/truncate-text';

// Material Modules
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatDialogModule } from '@angular/material/dialog';
import { MAT_FORM_FIELD_DEFAULT_OPTIONS, MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatTabsModule } from '@angular/material/tabs';
import { MatButtonModule } from '@angular/material/button';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatStepperModule } from '@angular/material/stepper';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTreeModule } from '@angular/material/tree';
import { MatProgressBarModule } from '@angular/material/progress-bar';

// Other Modules
import { ClipboardModule } from '@angular/cdk/clipboard';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { AutosizeModule } from 'ngx-autosize';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { AngularEditorModule } from '@kolkov/angular-editor';
import { FilePondModule, registerPlugin } from 'ngx-filepond';
import FilePondPluginFilePoster from 'filepond-plugin-file-poster';
import FilepondPluginImagePreview from 'filepond-plugin-image-preview';
import FilePondPluginFileValidateType from 'filepond-plugin-file-validate-type';

// Register FilePond plugins
registerPlugin(FilePondPluginFilePoster);
registerPlugin(FilepondPluginImagePreview);
registerPlugin(FilePondPluginFileValidateType);

// Locale
import { registerLocaleData } from '@angular/common';
import { LOCALE_ID } from '@angular/core';
import localeNl from '@angular/common/locales/nl';
registerLocaleData(localeNl);

// Sentry
import * as Sentry from '@sentry/browser';
import { ErrorHandler, Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';

// Regular Components
import { OrganizationComponent } from './organization/organization.component';
import { MaterialsComponent } from './assessment-level/materials/materials.component';
import { Step1Component } from './assessment-level/step1/step1.component';
import { NewUserComponent } from './assessment-level/new-user/new-user.component';
import { Step2Component } from './assessment-level/step2/step2.component';
import { NewOrganisationComponent } from './assessment-level/new-organisation/new-organisation.component';
import { AddMaterialComponent } from './shared-components/add-material/add-material.component';
import { StepperComponent } from './shared-components/stepper/stepper.component';
import { CriticalMaterialComponent } from './assessment-level/critical-material/critical-material.component';
import { FileUploadComponent } from './shared-components/file-upload/file-upload.component';
import { Step4Component } from './assessment-level/step4/step4.component';
import { UserComponent } from './user/user.component';
import { Step5Component } from './assessment-level/step5/step5.component';
import { InflowComponent } from './assessment-level/step5/inflow/inflow.component';
import { OutflowComponent } from './assessment-level/step5/outflow/outflow.component';
import { IntroComponent } from './assessment-level/step5/intro/intro.component';
import { Step6Component } from './assessment-level/step6/step6.component';
import { Intro6Component } from './assessment-level/step6/intro6/intro6.component';
import { Inflow6Component } from './assessment-level/step6/inflow6/inflow6.component';
import { Outflow6Component } from './assessment-level/step6/outflow6/outflow6.component';
import { WaterComponent } from './assessment-level/step6/water/water.component';
import { Step7Component } from './assessment-level/step7/step7.component';
import { Intro7Component } from './assessment-level/step7/intro7/intro7.component';
import { SmartTargetComponent } from './assessment-level/step7/smart-target/smart-target.component';
import { InflowQuestionsComponent } from './assessment-level/step5/inflow-questions/inflow-questions.component';
import { OutflowQuestionsComponent } from './assessment-level/step5/outflow-questions/outflow-questions.component';
import { ProofComponent } from './assessment-level/materials/question/proof/proof.component';
import { BoxesComponent } from './shared-components/boxes/boxes.component';
import { EnergyConfirm } from './shared-components/boxes/energy-confirm/energy-confirm.component';
import { WaterConfirm } from './shared-components/boxes/water-confirm/water-confirm.component';
import { OnSiteWaterConfirm } from './shared-components/boxes/onSiteWater-confirm/onSiteWater-confirm.component';
import { ProductivityConfirm } from './shared-components/boxes/productivity-confirm/productivity-confirm.component';
import { RevenueConfirm } from './shared-components/boxes/revenue-confirm/revenue-confirm.component';

import { EnergyAnalysisComponent } from './assessment-level/step5/energy-analysis/energy-analysis.component';
import { WaterAnalysisComponent } from './assessment-level/step5/water-analysis/water-analysis.component';
import { DownloadReportComponent } from './shared-components/download-report/download-report.component';
import { Step6CriticalMaterialComponent } from './assessment-level/step6/critical-materials/critical-materials.component';
import { Step6EnergyComponent } from './assessment-level/step6/energy/energy.component';
import { CompareComponent } from './pro/compare/compare.component';
import { CompareCloseComponent } from './pro/compare/close/close.component';
import { CompareValueComponent } from './pro/compare/value/value.component';
import { CompareOptimizeComponent } from './pro/compare/optimize/optimize.component';

import { SuppliersComponent } from './suppliers/suppliers.component';
import { IsImgPipe } from '@app/pipes/is-img.pipe';
import { GHGImpactAnalysisComponent } from './assessment-level/step5/ghg-impact-analysis/ghg-impact-analysis.component';
import { GHGImpactComponent } from './assessment-level/step6/ghg-impact/ghg-impact.component';
// ReportComponent is now standalone - imported directly in routing
import { GuidanceComponent } from './shared-components/guidance/guidance';
import { CompareReportComponent } from './shared-components/compare-report/compare-report.component';
import { AggregateReportComponent } from './shared-components/aggregate-report/aggregate-report.component';
import { ErrorPageComponent } from './error/error-page/error-page.component';

import { OrganizationGoalComponent } from './pro/organization-goal/organization-goal.component';
import { AddProductComponent } from './pro/add-product/add-product.component';

import { TfaComponent } from './shared-components/tfa/tfa.component';
import { AutoSaveComponent } from './shared-components/auto-save/auto-save.component';

import { WorkspaceGuidanceComponent } from './guidance/workspace/workspace.component';
import { GHGImpactOutflowAnalysisComponent } from './assessment-level/step5/ghg-impact-outflow-analysis/ghg-impact-outflow-analysis.component';
import { NatureImpactConfirm } from './shared-components/boxes/natureImpact-confirm/natureImpact-confirm.component';
import { FilterPipe } from '@app/pipes/FilterPipe';
import { NatureImpactStep5Component } from './assessment-level/step5/nature-impact-analysis/nature-impact-analysis.component';
import { ScorePipe } from './assessment-level/step5/nature-impact-analysis/score.pipe';
import { MainGuidanceComponent } from './guidance/main-guidance/main-guidance.component';
import { InflowQuestionComponent } from './assessment-level/materials/question/inflow-question.component';
import { OutflowQuestionComponent } from './assessment-level/materials/question/outflow-question.component';
import { GuidanceAssessmentLevelComponent } from './guidance/assessment-level/assessment-level.component';
import { GuidanceIndicatorLevelComponent } from './guidance/indicator-level/indicator-level.component';
import { GuidanceDatapointLevelComponent } from './guidance/datapoint-level/datapoint-level.component';
import { GuidanceGlossaryComponent } from './guidance/glossary/glossary.component';
import { GuidanceFAQComponent } from './guidance/faq/faq.component';
import { GuidanceContactSupportComponent } from './guidance/contact-support/contact-support.component';
import { GuidanceGettingStartedComponent } from './guidance/getting-started/getting-started.component';
import { LabelBaseComponent } from './pro/label-base/label-base.component';

import { E5Component } from './e5/e5.component';
import { E5LabelBaseComponent } from './e5/label-base/label-base.component';
import { E5ReportComponent } from './e5/e5-report/e5-report.component';
import { E5PDFReportComponent } from './shared-components/e5-report/e5-report.component';
import { E5MaterialsComponent } from './e5/e5-materials/e5-materials.component';
import { E5OutflowQuestionComponent } from './e5/e5-materials/question/e5-outflow-question.component';
import { E5InflowQuestionComponent } from './e5/e5-materials/question/e5-inflow-question.component';
import { E5AddMaterialComponent } from './shared-components/e5-add-material/e5-add-material.component';
import { ManageHazardousComponent } from './e5/manage-hazardous/manage-hazardous.component';
import { FlexDecimalModule } from './directives/flex-decimal.module';

import { ProComponent } from './pro/pro.component';
import { MissingDataComponent } from './pro/aggregate/missing-data/missing-data.component';
import { GuidanceLabelViewComponent } from './guidance/label-view/label-view.component';
import { TermsComponent } from './terms/terms.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AssessmentDashboardComponent } from './assessment-level/assessment-dashboard/assessment-dashboard.component';
import { SustainabilityTabComponent } from './dashboard/sustainability-tab/sustainability-tab.component';
import { DesignTabComponent } from './dashboard/design-tab/design-tab.component';
import { ProcurementTabComponent } from './dashboard/procurement-tab/procurement-tab.component';
import { LabelLogicDisplayComponent } from './shared-components/label-logic-display/label-logic-display.component';
import { SankeyInfoComponent } from './shared-components/sankey-info/sankey-info.component';
import { GHGComponent } from './shared-components/ghg/ghg.component';
import { CriticalInflowComponent } from './shared-components/critical-inflow/critical-inflow.component';
import { CommentCenterComponent } from './shared-components/comment-center/comment-center.component';
import { RecoveryBreakdownBarComponent } from './shared-components/recovery-breakdown-bar/recovery-breakdown-bar.component';
import { RecoveryBreakdownComponent } from './shared-components/recovery-breakdown/recovery-breakdown.component';
import { PackagingComponent } from './shared-components/packaging/packaging.component';
import { CommentBadgeComponent } from './shared-components/comment-badge/comment-badge.component';
import { HeaderCommentCenterComponent } from './shared-components/header-comment-center/header-comment-center.component';
import { DashboardMetricsComponent } from './dashboard/dashboard-metrics/dashboard-metrics.component';
import { MostLinearInflowComponent } from './shared-components/most-linear-inflow/most-linear-inflow.component';
import { CurrencyMaskModule } from 'ng2-currency-mask';
import { DialogModule } from './shared/dialog/dialog.module';
import { ActualLifetimeComponent } from './shared-components/actual-lifetime/actual-lifetime.component';
import { NatureImpactComponent } from './shared-components/nature-impact/nature-impact.component';
import { BubbleChartComponent } from './assessment-level/step6/bubble-chart/bubble-chart.component';
import { LoadingBarComponent } from './shared-components/loading-bar/loading-bar.component';
import { DashboardFlowsComponent } from './shared-components/dashboard-flows/dashboard-flows.component';
import { FlowAnalysisSankeyComponent } from './shared-components/flow-analysis-sankey/flow-analysis-sankey.component';
import { DashboardFlowsGroupComponent } from './shared-components/dashboard-flows-group/dashboard-flows-group.component';

registerPlugin(FilePondPluginFileValidateType, FilePondPluginFilePoster, FilepondPluginImagePreview);
if (environment.production) {
  Sentry.init({
    environment: environment.name,
    dsn: 'https://33dd795a42984214bc6867cb874270db@o403400.ingest.sentry.io/5265974',
    integrations: [
      new Sentry.Integrations.TryCatch({
        setTimeout: true,
        setInterval: true,
        requestAnimationFrame: true,
        XMLHttpRequest: false,
        eventTarget: true,
      }),
    ],
  });
}

registerLocaleData(localeNl);

@Injectable()
export class SentryErrorHandler implements ErrorHandler {
  constructor() {}

  extractError(error: any) {
    if (error && error.ngOriginalError) {
      error = error.ngOriginalError;
    }

    if (error instanceof HttpErrorResponse) {
      if (error.error instanceof Error) {
        return error.error;
      }
      if (error.error instanceof ErrorEvent) {
        return error.error.message;
      }
      if (typeof error.error === 'string') {
        return `Server returned code ${error.status} with body "${error.error}"`;
      }
      return error.message;
    }

    if (error instanceof Error) {
      return error.message;
    }

    if (typeof error === 'string') {
      return error;
    }

    return null;
  }

  handleError(error: any) {
    const extractedError = this.extractError(error) || 'Handled unknown error';
    const eventId = Sentry.captureException(extractedError);
    if (!environment.production) {
      console.error(extractedError);
    }
  }
}

@NgModule({
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    MatTableModule,
    NgbModule,
    CoreModule,
    ClipboardModule,
    MatSortModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    LoginModule,
    MatButtonModule,
    MatRadioModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatStepperModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    AngularEditorModule,
    AppRoutingModule,
    SharedModule,
    ShellModule,
    FilePondModule,
    NoopAnimationsModule,
    MatDialogModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatTabsModule,
    MatTooltipModule,
    ScrollingModule,
    AutosizeModule,
    MatTreeModule,
    MatProgressBarModule,
    RouterModule.forRoot([]),
    ServiceWorkerModule.register('./ngsw-worker.js', { enabled: environment.production }),
    ReactiveFormsModule.withConfig({ warnOnNgModelWithFormControl: 'never' }),
    CiqNumberPipe,
    TruncatePipe,
    CurrencyMaskModule,
    DialogModule,
    FlexDecimalModule,
    // Standalone components
    MissingDataComponent,
    LabelLogicDisplayComponent,
    SankeyInfoComponent,
    CriticalInflowComponent,
    GHGComponent,
    CommentCenterComponent,
    RecoveryBreakdownBarComponent,
    RecoveryBreakdownComponent,
    PackagingComponent,
    CommentBadgeComponent,
    HeaderCommentCenterComponent,
    DesignTabComponent,
    SustainabilityTabComponent,
    DashboardMetricsComponent,
    ProcurementTabComponent,
    MostLinearInflowComponent,
    DashboardFlowsComponent,
    DashboardFlowsGroupComponent,
    FlowAnalysisSankeyComponent,
    CompareReportComponent,
    E5PDFReportComponent,
    GuidanceComponent,
    ActualLifetimeComponent,
    NatureImpactComponent,
    BubbleChartComponent,
    LoadingBarComponent,
  ],
  declarations: [
    AppComponent,
    // Regular Components
    OrganizationComponent,
    MaterialsComponent,
    E5MaterialsComponent,
    SuppliersComponent,
    InflowQuestionComponent,
    E5InflowQuestionComponent,
    OutflowQuestionComponent,
    E5OutflowQuestionComponent,
    Step1Component,
    NewUserComponent,
    Step2Component,
    NewOrganisationComponent,
    AddMaterialComponent,
    E5AddMaterialComponent,
    CriticalMaterialComponent,
    StepperComponent,
    FileUploadComponent,
    Step4Component,
    UserComponent,
    Step5Component,
    NatureImpactStep5Component,
    ScorePipe,
    InflowComponent,
    OutflowComponent,
    IntroComponent,
    Step6Component,
    Intro6Component,
    Inflow6Component,
    GHGImpactComponent,
    Outflow6Component,
    Step6EnergyComponent,
    WaterComponent,
    Step6CriticalMaterialComponent,
    Step7Component,
    Intro7Component,
    SmartTargetComponent,
    InflowQuestionsComponent,
    OutflowQuestionsComponent,
    ProofComponent,
    BoxesComponent,
    EnergyConfirm,
    WaterConfirm,
    OnSiteWaterConfirm,
    NatureImpactConfirm,
    ProductivityConfirm,
    RevenueConfirm,

    EnergyAnalysisComponent,
    WaterAnalysisComponent,
    DownloadReportComponent,
    CompareComponent,
    CompareCloseComponent,
    CompareValueComponent,
    CompareOptimizeComponent,

    IsImgPipe,
    GHGImpactAnalysisComponent,
    AggregateReportComponent,
    ErrorPageComponent,
    OrganizationGoalComponent,
    AddProductComponent,
    TfaComponent,
    AutoSaveComponent,

    WorkspaceGuidanceComponent,
    GHGImpactOutflowAnalysisComponent,
    FilterPipe,
    MainGuidanceComponent,
    GuidanceAssessmentLevelComponent,
    GuidanceIndicatorLevelComponent,
    GuidanceDatapointLevelComponent,
    GuidanceGlossaryComponent,
    GuidanceFAQComponent,
    GuidanceContactSupportComponent,
    GuidanceGettingStartedComponent,
    LabelBaseComponent,
    E5Component,
    E5LabelBaseComponent,
    E5ReportComponent,
    ManageHazardousComponent,
    ProComponent,
    GuidanceLabelViewComponent,
    TermsComponent,
    AssessmentDashboardComponent,
  ],
  providers: [
    { provide: LOCALE_ID, useValue: 'nl-NL' },
    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'outline' } },
    { provide: ErrorHandler, useClass: SentryErrorHandler },
    DecimalPipe,
    TruncatePipe,
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
