import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '@env/environment';
import Storyblok from 'storyblok-js-client';
declare var $: any;

@Component({
  selector: 'app-datapoint-level-guidance',
  templateUrl: './datapoint-level.component.html',
  styleUrls: ['./datapoint-level.component.scss'],
  standalone: false,
})
export class GuidanceDatapointLevelComponent implements OnInit, OnDestroy {
  @Input() public data: any;
  @Input() public mainGuidanceData: any;
  @Output() openReturn: EventEmitter<any> = new EventEmitter();
  public fakeData;
  public activeItem;
  public detailShow = false;
  public relatedContentShow = false;
  public activeSubPage = false;
  public isLoad = 0;
  public breadcrumb = [];
  toggleData = [];
  pageData = [];
  activeChild = 0;
  public storyblokClient;
  constructor(private sanitizer: DomSanitizer) {
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });
  }
  ngOnDestroy(): void {
    this.toggleData = [];
    this.pageData = [];
    this.isLoad = 0;
  }

  ngOnInit() {
    this.fakeData = this.data;
    this.breadcrumb.push({ description: this.data.description, slug: this.data.slug });
    if (this.mainGuidanceData.slug) {
      this.goBack(this.mainGuidanceData.slug);
    }
  }

  goBack(slug: string) {
    this.toggleData = [];
    this.pageData = [];
    this.isLoad = 0;
    this.relatedContentShow = false;
    if (this.activeSubPage) {
      this.openSub(this.breadcrumb[this.breadcrumb.length - 2].slug);
      this.breadcrumb.splice(this.breadcrumb.length - 2, this.breadcrumb.length);
      this.activeSubPage = false;
    } else {
      if (slug === 'guidance/assessment-level/step-3/data-level') {
        this.fakeData = this.data;
        this.detailShow = false;
        this.activeItem = null;
        this.breadcrumb = [{ description: this.data.description, slug: this.data.slug }];
      } else {
        this.data.content.forEach((item) => {
          if (slug === item.slug) {
            this.activeItem = item;
            if (item.content.length > 1) {
              this.fakeData = item;
              this.detailShow = false;
              this.breadcrumb.splice(2, this.breadcrumb.length);
            } else {
              this.detailShow = true;
              this.breadcrumb = [{ description: this.data.description, slug: this.data.slug }];
            }
          } else {
            if (item.content.length > 0) {
              item.content.forEach((subItem) => {
                if (slug === subItem.slug) {
                  this.activeItem = subItem;
                  if (subItem.content.length > 1) {
                    this.fakeData = subItem;
                    this.detailShow = false;
                    this.breadcrumb.splice(3, this.breadcrumb.length);
                  } else {
                    this.detailShow = true;
                    this.breadcrumb = [{ description: this.data.description, slug: this.data.slug }];
                  }
                } else {
                  if (subItem.content.length > 0) {
                    subItem.content.forEach((childItem) => {
                      if (slug === childItem.slug) {
                        this.activeItem = childItem;
                        if (item.content.length > 1) {
                          this.fakeData = childItem;
                          this.detailShow = false;
                          this.breadcrumb.splice(4, this.breadcrumb.length);
                        } else {
                          this.detailShow = true;
                          this.breadcrumb = [{ description: this.data.description, slug: this.data.slug }];
                        }
                      }
                    });
                  }
                }
              });
            }
          }
        });
      }
    }
  }

  openSub(slug: string) {
    this.toggleData = [];
    this.pageData = [];
    this.isLoad = 0;
    this.activeSubPage = false;
    this.fakeData.content.forEach((item) => {
      if (slug === item.slug) {
        if (!this.relatedContentShow) {
          this.breadcrumb.push(item);
        }
        this.activeItem = item;
        if (item.content.length > 1) {
          this.fakeData = item;
          this.detailShow = false;
        } else {
          this.breadcrumb[this.breadcrumb.length - 1] = item;
          if (this.breadcrumb.length > 2) {
            this.relatedContentShow = true;
          }
          this.detailShow = true;
        }
      }
    });
  }

  pageOpen(item: any) {
    this.toggleData = [];
    this.pageData = [];
    this.isLoad = 0;
    if (this.breadcrumb.length < 3) {
      this.breadcrumb.push({ description: item.title, slug: item.title });
      this.detailShow = false;
      this.relatedContentShow = false;
      this.activeSubPage = item;
    } else {
      this.breadcrumb.splice(3, this.breadcrumb.length);
      this.breadcrumb.push({ description: item.title, slug: item.title });
      this.detailShow = false;
      this.relatedContentShow = false;
      this.activeSubPage = item;
    }
  }

  renderRichText(content: any) {
    return this.getRichTextResolver().render(content);
  }

  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
  getRichTextResolver() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        case 'toggle':
          if (this.isLoad < 2) {
            this.toggleData.push(blok);
          }
          return '';
        case 'page':
          if (this.isLoad < 2) {
            this.pageData.push({ blok, description: blok.title, slug: blok.title });
          }
          return '';
        default:
          return blok;
      }
    });
    this.isLoad++;
    return this.storyblokClient.richTextResolver;
  }
  renderRichTextChild(content: any) {
    return this.getRichTextResolverChild().render(content);
  }
  getRichTextResolverChild() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });
    return this.storyblokClient.richTextResolver;
  }
}
