import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatDialog } from '@angular/material/dialog';
import { WatchvideoConfirmDialog } from '@app/shared/dialog/watch-video/watch-video-dialog.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { DomSanitizer } from '@angular/platform-browser';
import Storyblok from 'storyblok-js-client';
declare var $: any;

@Component({
  selector: 'app-getting-started',
  templateUrl: './getting-started.component.html',
  styleUrls: ['./getting-started.component.scss'],
  standalone: false,
})
export class GuidanceGettingStartedComponent implements OnInit, OnDestroy {
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  sampleVideosSeen = true;
  permanentlyHide = false;
  storyblok;
  isPro = false;
  useCasesList;
  onboardingAlwaysOn;
  fakeData;
  activeItem;
  detailShow = false;
  isLoading = false;
  relatedContentShow = false;
  environment = environment;
  alertShow = true;
  storyblokMainGuidanceShell;
  public storyblokClient;

  constructor(
    private dialog: MatDialog,
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService,
    private sanitizer: DomSanitizer
  ) {
    if (this.credentials && this.credentials['organisation'] && this.credentials['organisation'].features) {
      this.credentials['organisation'].features.forEach((element) => {
        if (element === 'unlimited_unit') {
          this.isPro = true;
        }
      });
    }
    this.http.callService(new Method(environment.services.userJourneyCTI(), '', 'get')).subscribe((res) => {
      this.sampleVideosSeen = res['sampleVideosSeen'];
    });
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });
    this.http.callService(new Method(environment.services.onboarding(), '', 'get')).subscribe(async (res) => {
      const data = res['text'];
    });
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokMainGuidanceShell = data.filter(
        (item) => item.uuid === '666f7c59-2976-409c-94a9-e2a11ced230c'
      )[0].content;
      this.storyblok = data.filter((item) => item.uuid === '265ed70e-b05c-4a9b-9fba-99c9f85c1de8')[0].content;
      this.useCasesList = {
        description: this.storyblok.title,
        slug: 'guidance/getting-started/getting-started',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: [
          {
            description: this.storyblok.title,
            slug: 'guidance/getting-started/getting-started',
            content: data.filter((item) => item.uuid === '265ed70e-b05c-4a9b-9fba-99c9f85c1de8'),
          },
          {
            description: this.storyblok.use_case_item1,
            slug: 'guidance/getting-started/packaging',
            content: data.filter((item) => item.uuid === 'f991e6bb-8e97-4dbd-b2ba-6db275af5c97'),
          },
          {
            description: this.storyblok.use_case_item2,
            slug: 'guidance/getting-started/complex-product',
            content: data.filter((item) => item.uuid === '16051af6-91ca-43d3-b8f2-1a396e4af460'),
          },
          {
            description: this.storyblok.use_case_item3,
            slug: 'guidance/getting-started/product-category-management',
            content: data.filter((item) => item.uuid === '7dc0f6ce-6e37-4e2c-aef1-9a81b67a5b92'),
          },
        ],
      };
      this.fakeData = this.useCasesList;
      this.openSub('guidance/getting-started/getting-started');
    });
  }
  openSub(slug: string) {
    this.fakeData.content.forEach((item) => {
      if (slug === item.slug) {
        this.activeItem = item;
        if (item.content.length > 1) {
          this.fakeData = item;
          this.detailShow = false;
        } else {
          this.relatedContentShow = true;
          this.detailShow = true;
        }
      }
    });
  }
  watchVideo(item: any) {
    const dialogRef = this.dialog.open(WatchvideoConfirmDialog, {
      minWidth: '980px',
      width: '75%',
      panelClass: 'centered-dialog',
      data: item,
    });
    dialogRef.afterClosed().subscribe(async (result) => {
      try {
        if (item?.refresh) {
          this.isLoading = false;
        }
      } catch (error) {}
    });
  }

  ngOnInit(): void {
    this.onboardingAlwaysOn =
      this.commonService.onboardingAlwaysOn === false
        ? false
        : JSON.parse(sessionStorage.getItem('onboardingAlwaysOn'));
  }
  ngOnDestroy(): void {
    this.commonService.onboardingAlwaysOn = false;
  }

  crateSample(item: string) {
    if (!this.commonService.userRoleValidation(['Admin'])) {
      return;
    }
    const videoData = {
      name: item[0]['value'] + ' (2/2)',
      video: item[2]['value'],
      refresh: true,
    };
    this.watchVideo(videoData);
    this.http.callService(new Method(environment.services.sampleAssessment(item[5]['value']), {}, 'post'));
    const data = [
      {
        question: 'SAMPLE_VIDEOS_SEEN',
        value: true,
      },
    ];
    this.http.callService(new Method(environment.services.userJourney(), data, 'put')).subscribe(async () => {
      this.sampleVideosSeen = true;
    });
  }

  renderRichText(content: any) {
    return this.getRichTextResolver().render(content);
  }
  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
  getRichTextResolver() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });
    return this.storyblokClient.richTextResolver;
  }

  neverShowAgain() {
    const data = [
      {
        question: 'SAMPLE_VIDEOS_SEEN',
        value: this.permanentlyHide,
      },
    ];
    this.http.callService(new Method(environment.services.userJourney(), data, 'put'));
  }
}
