import { Component, OnInit } from '@angular/core';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
declare var $: any;
@Component({
  selector: 'app-main-guidance',
  templateUrl: './main-guidance.component.html',
  styleUrls: ['./main-guidance.component.scss'],
  standalone: false,
})
export class MainGuidanceComponent implements OnInit {
  mainGuidanceData;
  storyblokDatapointLevel;
  storyblokDataLevelData;
  storyblokStep5;
  storyblokGlossary;
  storyblokFAQ;
  stroyblokLabel;
  sampleVideosSeen = true;
  storyblokGlossaryContent = [];
  storyblokFAQContent = [];
  stroyblokLabelContent = [];
  storyblokMainGuidanceShell;
  storyblokIndicators;
  storyblokStepper;
  activeTab = 1;
  constructor(
    public commonService: CommonService,
    private storyblokService: StoryblokService,
    private http: ApiRequestService
  ) {
    this.commonService.mainGuidanceData.subscribe((res) => {
      this.mainGuidanceData = res;
    });
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokMainGuidanceShell = data.filter(
        (item) => item.uuid === '666f7c59-2976-409c-94a9-e2a11ced230c'
      )[0].content;
      this.storyblokStep5 = data.filter((item) => item.slug === 'step5')[0].content;
      this.storyblokIndicators = data.filter((item) => item.slug === 'step2')[0].content;
      this.storyblokStepper = data.filter((item) => item.slug === 'stepper')[0].content;
      data.forEach((item) => {
        const isGlossary = item.full_slug.indexOf('guidance/glossary');
        if (isGlossary > -1) {
          this.storyblokGlossaryContent.push({
            description: item.name,
            slug: item.full_slug,
            content: item,
          });
        }
        const isFAQ = item.full_slug.indexOf('guidance/faq/');
        if (isFAQ > -1) {
          this.storyblokFAQContent.push({
            description: item.name,
            slug: item.full_slug,
            content: item,
          });
        }
        const isLabel = item.full_slug.indexOf('guidance/label-view/');
        if (isLabel > -1) {
          this.stroyblokLabelContent.push({
            description: item.name,
            slug: item.full_slug,
            content: item,
          });
        }
      });
    });

    this.storyblokService.getStoryService().then((data) => {
      this.storyblokDataLevelData = data.filter((item) => item.slug === 'step3')[0].content;
      this.storyblokDatapointLevel = {
        description: this.storyblokMainGuidanceShell.data_level,
        slug: 'guidance/assessment-level/step-3/data-level',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: [
          {
            description: this.storyblokMainGuidanceShell.inflow,
            slug: 'guidance/assessment-level/step-3/data-level/inflow',
            content: [
              {
                description: this.storyblokStep5.name,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/name',
                content: [data.filter((item) => item.uuid === 'ca4d328c-0d1b-4fa5-85c3-d6f1579d0eb9')],
              },
              {
                description: this.storyblokDataLevelData.mass,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/mass',
                content: [data.filter((item) => item.uuid === 'a32e7763-fb01-4926-b3e2-ec359e162f5c')],
              },
              {
                description: this.storyblokDataLevelData.material_source_type,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/material-source-type',
                content: [data.filter((item) => item.uuid === '5886a6ac-4b5e-440c-b5ac-5bb3aeea8c53')],
              },
              {
                description: this.storyblokDataLevelData.flow_type,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/flow-type',
                content: [data.filter((item) => item.uuid === '8a09eeda-9dee-4304-8fe0-6629a12c5694')],
              },
              {
                description: this.storyblokDataLevelData.critical_material,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/critical-material',
                content: [data.filter((item) => item.uuid === 'dac529a4-d4ac-4385-aee9-ad7861871482')],
              },
              {
                description: this.storyblokDataLevelData.ghg_material_reference,
                slug: 'guidance/assessment-level/step-3/data-level/inflow/ghg-material-reference',
                content: [data.filter((item) => item.uuid === '4542a983-faaf-436b-8045-9039b4af9758')],
              },
            ],
          },
          {
            description: this.storyblokMainGuidanceShell.outflow,
            slug: 'guidance/assessment-level/step-3/data-level/outflow',
            content: [
              {
                description: this.storyblokStep5.name,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/name',
                content: [data.filter((item) => item.uuid === '6dd82a43-54e6-4fb7-a5fa-a85b7195bb3e')],
              },
              {
                description: this.storyblokDataLevelData.mass,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/mass',
                content: [data.filter((item) => item.uuid === '7cc9dc10-93f1-42f1-b143-cdf5af3f350e')],
              },
              {
                description: this.storyblokDataLevelData.flow_type,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/flow-type',
                content: [data.filter((item) => item.uuid === 'bb75293e-2537-4326-a59e-b011df53eb7b')],
              },
              {
                description: this.storyblokDataLevelData.recovery_potential,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/recovery-potential',
                content: [data.filter((item) => item.uuid === 'cd0b107c-0fe0-473a-8c41-e5c32e24b37c')],
              },
              {
                description: this.storyblokDataLevelData.actual_recovery,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/actual-recovery',
                content: [data.filter((item) => item.uuid === '4fcfe341-f256-4af3-aed2-78be7f89b663')],
              },
              {
                description: this.storyblokDataLevelData.ghg_outflow_impact,
                slug: 'guidance/assessment-level/step-3/data-level/outflow/ghg-outflow-impact',
                content: [data.filter((item) => item.uuid === '1908847c-617f-4350-80c6-b397b22fa10b')],
              },

              // {
              //   description: 'Test Recovery potential',
              //   slug: 'guidance/assessment-level/step-3/data-level/outflow/test',
              //   content: [data.filter((item) => item.uuid === 'ea4227f0-d439-4627-b8a5-58d2c24aca70')],
              // },
            ],
          },
        ],
      };

      this.storyblokGlossary = {
        description: this.storyblokMainGuidanceShell.glossary,
        slug: 'guidance/glossary',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: this.storyblokGlossaryContent,
      };
      this.storyblokFAQ = {
        description: this.storyblokMainGuidanceShell.faq,
        slug: 'guidance/faq',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: this.storyblokFAQContent,
      };
      this.stroyblokLabel = {
        description: this.storyblokMainGuidanceShell.label,
        slug: 'guidance/label',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: this.stroyblokLabelContent,
      };
    });
  }
  ngOnInit(): void {
    this.http.callService(new Method(environment.services.userJourneyCTI(), '', 'get')).subscribe((res) => {
      this.sampleVideosSeen = res['sampleVideosSeen'];
    });
  }

  openGuidanceEvent(slug: any) {
    this.commonService.mainGuidanceData.next({ show: true, active: 'datapoint', slug: slug });
  }
}
