import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import Storyblok from 'storyblok-js-client';
declare var $: any;

@Component({
  selector: 'app-assessment-level-guidance',
  templateUrl: './assessment-level.component.html',
  styleUrls: ['./assessment-level.component.scss'],
  standalone: false,
})
export class GuidanceAssessmentLevelComponent implements OnInit {
  @Output() openReturn: EventEmitter<any> = new EventEmitter();
  @Input() public page: string;
  public fakeData;
  public activeItem;
  public storyblokMainGuidanceShell;
  public storyblokIndicators;
  public detailShow = false;
  public relatedContentShow = false;
  public storyblokAssessmentLevel;
  public storyblokDataLevelData;
  public storyblokStep5;
  public storyblokStepper;
  public breadcrumb = [];
  public storyblokClient;
  private renderedContentCache = new Map<string, string>();
  public currentRenderedContent: string = '';
  public currentSanitizedContent: any = '';
  constructor(private sanitizer: DomSanitizer, private storyblokService: StoryblokService) {
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });
  }
  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokMainGuidanceShell = data.filter(
        (item) => item.uuid === '666f7c59-2976-409c-94a9-e2a11ced230c'
      )[0].content;
      this.storyblokDataLevelData = data.filter((item) => item.slug === 'step3')[0].content;
      this.storyblokIndicators = data.filter((item) => item.slug === 'step2')[0].content;
      this.storyblokStepper = data.filter((item) => item.slug === 'stepper')[0].content;
      this.storyblokStep5 = data.filter((item) => item.slug === 'step5')[0].content;

      this.storyblokAssessmentLevel = {
        description: this.storyblokMainGuidanceShell.assessment,
        slug: 'guidance/assessment-level',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: [
          {
            name: this.storyblokStepper.step_1_title,
            description: this.storyblokStepper.step_1_description,
            relatedText: this.storyblokStepper.step_1_title,
            slug: 'guidance/assessment-level/step-1',
            content: data.filter((item) => item.uuid === '230bed10-0023-4c3e-93f2-85aab4418b10'),
          },
          {
            name: this.storyblokStepper.step_2_title,
            description: this.storyblokStepper.step_2_description,
            relatedText: this.storyblokStepper.step_2_title,
            slug: 'guidance/assessment-level/step-2',
            content: [
              {
                description: this.storyblokMainGuidanceShell.getting_started,
                slug: 'guidance/assessment-level/step-2/getting-started-with-step-2',
                content: data.filter((item) => item.uuid === '5956c138-e685-4757-99a6-030ac9f4437a'),
              },
              {
                description: this.storyblokMainGuidanceShell.indicators,
                slug: 'guidance/assessment-level/step-2/indicators',
                content: [
                  {
                    description: this.storyblokIndicators.material_circularity,
                    slug: 'guidance/assessment-level/step-2/indicators/material-circularity',
                    content: data.filter((item) => item.uuid === '77a3228e-59a8-483b-89b6-bd2ef48b39d9'),
                  },
                  {
                    description: this.storyblokIndicators.water_circularity,
                    slug: 'guidance/assessment-level/step-2/indicators/water-circularity',
                    content: data.filter((item) => item.uuid === '4db89ace-3989-4331-a4f6-b0006c85f4cf'),
                  },
                  {
                    description: this.storyblokIndicators.renewable_energy,
                    slug: 'guidance/assessment-level/step-2/indicators/renewable-energy',
                    content: data.filter((item) => item.uuid === '514dd98a-bc75-4370-bc34-c9a9cff6620b'),
                  },
                  {
                    description: this.storyblokIndicators.critical_inflow,
                    slug: 'guidance/assessment-level/step-2/indicators/critical-inflow',
                    content: data.filter((item) => item.uuid === 'e7d76922-cdd3-4568-917b-173dfc840a13'),
                  },
                  {
                    description: this.storyblokIndicators.recovery_type,
                    slug: 'guidance/assessment-level/step-2/indicators/recovery-type',
                    content: data.filter((item) => item.uuid === 'b25e7606-1940-4f77-b617-eee0654e0c6d'),
                  },
                  {
                    description: this.storyblokIndicators.onsite_water_circulation,
                    slug: 'guidance/assessment-level/step-2/indicators/onsite-water-circulation',
                    content: data.filter((item) => item.uuid === '99dc3076-5111-46a3-a970-270326d47ea5'),
                  },
                  {
                    description: this.storyblokIndicators.actual_lifetime,
                    slug: 'guidance/assessment-level/step-2/indicators/actual-lifetime',
                    content: data.filter((item) => item.uuid === '0a13ccc8-3038-4231-afc5-380f6866411d'),
                  },
                  {
                    description: this.storyblokIndicators.circular_material_productivity,
                    slug: 'guidance/assessment-level/step-2/indicators/circular-material-productivity',
                    content: data.filter((item) => item.uuid === '825a5b1c-59ee-408a-9643-023996c5fbff'),
                  },
                  {
                    description: this.storyblokIndicators.cti_revenue,
                    slug: 'guidance/assessment-level/step-2/indicators/cti-revenue',
                    content: data.filter((item) => item.uuid === '02dfa8c5-7b9c-4fa5-8196-98041ca1f077'),
                  },
                  {
                    description: this.storyblokIndicators.ghg_Impact,
                    slug: 'guidance/assessment-level/step-2/indicators/ghg-impact',
                    content: data.filter((item) => item.uuid === 'f017071f-baed-46fc-b183-e1b64379646e'),
                  },
                  {
                    description: this.storyblokIndicators.nature_impact,
                    slug: 'guidance/assessment-level/step-2/indicators/nature-impact',
                    content: data.filter((item) => item.uuid === '00acaa3c-284c-414b-b9eb-0ed08608fdc4'),
                  },
                ],
              },
              {
                description: this.storyblokMainGuidanceShell.examples,
                slug: 'guidance/assessment-level/step-2/examples',
                content: data.filter((item) => item.uuid === '96da47fe-a90f-496b-bbdb-1c98089dcd8a'),
              },
            ],
          },
          {
            name: this.storyblokStepper.step_3_title,
            description: this.storyblokStepper.step_3_description,
            relatedText: this.storyblokStepper.step_3_title,
            slug: 'guidance/assessment-level/step-3',
            content: [
              {
                description: this.storyblokMainGuidanceShell.intro,
                slug: 'guidance/assessment-level/step-3/intro',
                content: [
                  {
                    description: this.storyblokMainGuidanceShell.getting_started_with_step_3,
                    slug: 'guidance/assessment-level/step-3/intro/getting-started-with-step-3',
                    content: data.filter((item) => item.uuid === 'a77b9d17-2b27-4066-a2f7-4b30350b472c'),
                  },
                  {
                    description: this.storyblokDataLevelData.add_inflow,
                    slug: 'guidance/assessment-level/step-3/intro/add-inflow',
                    content: data.filter((item) => item.uuid === '9aab0b5f-b357-490c-91cf-41501d44bc36'),
                  },
                  {
                    description: this.storyblokDataLevelData.add_outflow,
                    slug: 'guidance/assessment-level/step-3/intro/add-outflow',
                    content: data.filter((item) => item.uuid === '00b058a9-f35c-4643-8d86-9dc261b02972'),
                  },
                  {
                    description: this.storyblokDataLevelData.import_data,
                    slug: 'guidance/assessment-level/step-3/intro/import-data',
                    content: data.filter((item) => item.uuid === 'f3827acd-470d-4698-910b-929c9717b9fd'),
                  },
                ],
              },
              {
                description: this.storyblokMainGuidanceShell.data_level,
                slug: 'guidance/assessment-level/step-3/data-level',
                content: [
                  {
                    description: this.storyblokMainGuidanceShell.inflow,
                    slug: 'guidance/assessment-level/step-3/data-level/inflow',
                    content: [
                      {
                        description: this.storyblokStep5.name,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/name',
                        content: [data.filter((item) => item.uuid === 'ca4d328c-0d1b-4fa5-85c3-d6f1579d0eb9')],
                      },
                      {
                        description: this.storyblokDataLevelData.mass,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/mass',
                        content: [data.filter((item) => item.uuid === 'a32e7763-fb01-4926-b3e2-ec359e162f5c')],
                      },
                      {
                        description: this.storyblokDataLevelData.material_source_type,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/material-source-type',
                        content: [data.filter((item) => item.uuid === '5886a6ac-4b5e-440c-b5ac-5bb3aeea8c53')],
                      },
                      {
                        description: this.storyblokDataLevelData.flow_type,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/flow-type',
                        content: [data.filter((item) => item.uuid === '8a09eeda-9dee-4304-8fe0-6629a12c5694')],
                      },
                      {
                        description: this.storyblokDataLevelData.critical_material,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/critical-material',
                        content: [data.filter((item) => item.uuid === 'dac529a4-d4ac-4385-aee9-ad7861871482')],
                      },
                      {
                        description: this.storyblokDataLevelData.ghg_material_reference,
                        slug: 'guidance/assessment-level/step-3/data-level/inflow/ghg-material-reference',
                        content: [data.filter((item) => item.uuid === '4542a983-faaf-436b-8045-9039b4af9758')],
                      },
                    ],
                  },
                  {
                    description: this.storyblokMainGuidanceShell.outflow,
                    slug: 'guidance/assessment-level/step-3/data-level/outflow',
                    content: [
                      {
                        description: this.storyblokStep5.name,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/name',
                        content: [data.filter((item) => item.uuid === '6dd82a43-54e6-4fb7-a5fa-a85b7195bb3e')],
                      },
                      {
                        description: this.storyblokDataLevelData.mass,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/mass',
                        content: [data.filter((item) => item.uuid === '7cc9dc10-93f1-42f1-b143-cdf5af3f350e')],
                      },
                      {
                        description: this.storyblokDataLevelData.flow_type,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/flow-type',
                        content: [data.filter((item) => item.uuid === 'bb75293e-2537-4326-a59e-b011df53eb7b')],
                      },
                      {
                        description: this.storyblokDataLevelData.recovery_potential,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/recovery-potential',
                        content: [data.filter((item) => item.uuid === 'cd0b107c-0fe0-473a-8c41-e5c32e24b37c')],
                      },
                      {
                        description: this.storyblokDataLevelData.actual_recovery,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/actual-recovery',
                        content: [data.filter((item) => item.uuid === '4fcfe341-f256-4af3-aed2-78be7f89b663')],
                      },
                      {
                        description: this.storyblokDataLevelData.ghg_outflow_impact,
                        slug: 'guidance/assessment-level/step-3/data-level/outflow/ghg-outflow-impact',
                        content: [data.filter((item) => item.uuid === '1908847c-617f-4350-80c6-b397b22fa10b')],
                      },
                    ],
                  },
                ],
              },
              {
                description: this.storyblokMainGuidanceShell.indicators,
                slug: 'guidance/assessment-level/step-3/indicators',
                content: [
                  {
                    description: this.storyblokIndicators.material_circularity,
                    slug: 'guidance/assessment-level/step-3/indicators/material-circularity',
                    content: data.filter((item) => item.uuid === 'e18230a9-682d-457c-b923-ede4c2e4df29'),
                  },
                  {
                    description: this.storyblokIndicators.water_circularity,
                    slug: 'guidance/assessment-level/step-3/indicators/water-circularity',
                    content: data.filter((item) => item.uuid === 'cbc12866-b8c6-4887-8942-b42b5eb8b8e5'),
                  },
                  {
                    description: this.storyblokIndicators.renewable_energy,
                    slug: 'guidance/assessment-level/step-3/indicators/renewable-energy',
                    content: data.filter((item) => item.uuid === 'e01e111b-1b94-4f0c-bfd6-d80b21966780'),
                  },
                  {
                    description: this.storyblokIndicators.critical_inflow,
                    slug: 'guidance/assessment-level/step-3/indicators/critical-inflow',
                    content: data.filter((item) => item.uuid === 'c8b00f75-a2b5-4473-9b80-5cc14757e213'),
                  },
                  {
                    description: this.storyblokIndicators.recovery_type,
                    slug: 'guidance/assessment-level/step-3/indicators/recovery-type',
                    content: data.filter((item) => item.uuid === '63d6d0d3-1d40-4275-ab80-9443d164115f'),
                  },
                  {
                    description: this.storyblokIndicators.onsite_water_circulation,
                    slug: 'guidance/assessment-level/step-3/indicators/onsite-water-circulation',
                    content: data.filter((item) => item.uuid === '7fdea4eb-e12f-4f56-99de-a63dc2a71463'),
                  },
                  {
                    description: this.storyblokIndicators.actual_lifetime,
                    slug: 'guidance/assessment-level/step-3/indicators/actual-lifetime',
                    content: data.filter((item) => item.uuid === 'cb3c6d67-c061-4c10-b885-d5fd70fcd987'),
                  },
                  {
                    description: this.storyblokIndicators.circular_material_productivity,
                    slug: 'guidance/assessment-level/step-3/indicators/circular-material-productivity',
                    content: data.filter((item) => item.uuid === '38878a4e-79ac-45c1-9d29-f34863a36e87'),
                  },
                  {
                    description: this.storyblokIndicators.cti_revenue,
                    slug: 'guidance/assessment-level/step-3/indicators/cti-revenue',
                    content: data.filter((item) => item.uuid === 'a65c3083-0728-4b8d-b08d-7318395718a3'),
                  },
                  {
                    description: this.storyblokIndicators.ghg_Impact,
                    slug: 'guidance/assessment-level/step-3/indicators/ghg-impact',
                    content: data.filter((item) => item.uuid === 'bebc2892-c384-47e5-8501-1ff0b7275dbf'),
                  },
                  {
                    description: this.storyblokIndicators.nature_impact,
                    slug: 'guidance/assessment-level/step-3/indicators/nature-impact',
                    content: data.filter((item) => item.uuid === '2234b039-3abf-4855-8478-78edd1dd2ded'),
                  },
                ],
              },
            ],
          },

          {
            name: this.storyblokStepper.step_4_title,
            description: this.storyblokStepper.step_4_description,
            relatedText: this.storyblokStepper.step_4_title,
            slug: 'guidance/assessment-level/step-4/getting-started-with-step-4',
            content: data.filter(
              (item) => item.uuid === 'guidance/assessment-level/step-4/getting-started-with-step-4'
            ),
          },
          {
            name: this.storyblokStepper.step_5_title,
            description: this.storyblokStepper.step_5_description,
            relatedText: this.storyblokStepper.step_5_title,
            slug: 'guidance/assessment-level/step-5',
            content: [
              {
                description: this.storyblokMainGuidanceShell.getting_started_with_step_5,
                slug: 'guidance/assessment-level/step-5/getting-started-with-step-5',
                content: data.filter((item) => item.uuid === '83f1d0dd-2268-4ac9-b7e1-893f65298183'),
              },
              {
                description: this.storyblokStep5.inflow_questions,
                slug: 'guidance/assessment-level/step-5/inflow-questions',
                content: data.filter((item) => item.uuid === '700fb6a5-b770-4b9c-b5af-4354539534ba'),
              },
              {
                description: this.storyblokStep5.inflow_analysis,
                slug: 'guidance/assessment-level/step-5/inflow-analysis',
                content: data.filter((item) => item.uuid === '01e6ec82-a527-4e7d-bc48-ce6676c6cb65'),
              },
              {
                description: this.storyblokStep5.outflow_questions,
                slug: 'guidance/assessment-level/step-5/outflow-questions',
                content: data.filter((item) => item.uuid === 'c3c47313-99fe-4a98-a263-c37b36c1d6db'),
              },
              {
                description: this.storyblokStep5.outflow_analysis,
                slug: 'guidance/assessment-level/step-5/outflow-analysis',
                content: data.filter((item) => item.uuid === '39cdb5af-0359-4150-8b11-23220244af02'),
              },
              {
                description: this.storyblokStep5.energy_analysis,
                slug: 'guidance/assessment-level/step-5/energy-analysis',
                content: data.filter((item) => item.uuid === '597e93f4-08b3-429c-96a7-43a4ebe2d527'),
              },
              {
                description: this.storyblokStep5.water_analysis,
                slug: 'guidance/assessment-level/step-5/water-analysis',
                content: data.filter((item) => item.uuid === '09142de6-5f38-40ae-9564-be074564c348'),
              },
              {
                description: this.storyblokStep5.nature_impact_analysis,
                slug: 'guidance/assessment-level/step-5/nature-impact-analysis',
                content: data.filter((item) => item.uuid === '330bcec4-4643-4b74-b387-81e8d400da8e'),
              },
              {
                description: this.storyblokStep5.ghg_impact_analysis,
                slug: 'guidance/assessment-level/step-5/ghg-analysis',
                content: data.filter((item) => item.uuid === 'fd48e367-c4f9-445a-80e9-8b31add826e9'),
              },
              {
                description: this.storyblokStep5.cti_revenue,
                slug: 'guidance/assessment-level/step-5/cti-revenue',
                content: data.filter((item) => item.uuid === '5fb1c97b-ff32-4251-87a8-722c8bc027ac'),
              },
              {
                description: this.storyblokStep5.circular_material_productivity,
                slug: 'guidance/assessment-level/step-5/circular-material-productivity',
                content: data.filter((item) => item.uuid === '93b4e066-d081-4f76-9d45-2fe4a13914c8'),
              },
            ],
          },
          {
            name: this.storyblokStepper.step_6_title,
            description: this.storyblokStepper.step_6_description,
            relatedText: this.storyblokStepper.step_6_title,
            slug: 'guidance/assessment-level/step-6/step-6-info',
            content: data.filter((item) => item.uuid === '7444f504-57a9-4827-a086-f79b19d301d1'),
          },
          {
            name: this.storyblokStepper.step_7_title,
            description: this.storyblokStepper.step_7_description,
            relatedText: this.storyblokStepper.step_7_title,
            slug: 'guidance/assessment-level/step-7/step-7-info',
            content: data.filter((item) => item.uuid === '3d8486e4-f785-43c5-9bd1-197d50205abf'),
          },
        ],
      };

      this.fakeData = this.storyblokAssessmentLevel;
      this.breadcrumb.push({
        description: this.storyblokAssessmentLevel?.description,
        slug: this.storyblokAssessmentLevel?.slug,
      });
      if (this.page) {
        this.goBack(this.page);
      }
    });
  }

  goBack(slug: string) {
    this.relatedContentShow = false;
    // Clear cache when navigating back
    this.clearRenderCache();
    if (slug === 'guidance/assessment-level') {
      this.fakeData = this.storyblokAssessmentLevel;
      this.detailShow = false;
      this.activeItem = null;
      this.breadcrumb = [
        { description: this.storyblokAssessmentLevel.description, slug: this.storyblokAssessmentLevel.slug },
      ];
    } else {
      this.storyblokAssessmentLevel.content.forEach((item) => {
        if (slug === item.slug) {
          this.activeItem = item;
          if (item.content.length > 1) {
            this.fakeData = item;
            this.detailShow = false;
            this.breadcrumb.splice(2, this.breadcrumb.length);
          } else {
            this.detailShow = true;
            this.breadcrumb = [
              { description: this.storyblokAssessmentLevel.description, slug: this.storyblokAssessmentLevel.slug },
            ];
            this.updateCurrentRenderedContent();
          }
        } else {
          if (item.content.length > 0) {
            item.content.forEach((subItem) => {
              if (slug === subItem.slug) {
                this.activeItem = subItem;
                if (subItem.content.length > 1) {
                  this.fakeData = subItem;
                  this.detailShow = false;
                  this.breadcrumb.splice(3, this.breadcrumb.length);
                } else {
                  this.detailShow = true;
                  this.breadcrumb = [
                    {
                      description: this.storyblokAssessmentLevel.description,
                      slug: this.storyblokAssessmentLevel.slug,
                    },
                  ];
                  this.updateCurrentRenderedContent();
                }
              } else {
                if (subItem.content.length > 0) {
                  subItem.content.forEach((childItem) => {
                    if (slug === childItem.slug) {
                      this.activeItem = childItem;
                      if (childItem.content.length > 1) {
                        this.fakeData = childItem;
                        this.detailShow = false;
                        this.breadcrumb.splice(4, this.breadcrumb.length);
                      } else {
                        this.detailShow = true;
                        this.breadcrumb = [
                          {
                            description: this.storyblokAssessmentLevel.description,
                            slug: this.storyblokAssessmentLevel.slug,
                          },
                        ];
                        this.updateCurrentRenderedContent();
                      }
                    }
                  });
                }
              }
            });
          }
        }
      });
    }
  }
  openSub(slug: string) {
    this.fakeData.content.forEach((item) => {
      if (slug === item.slug) {
        if (!this.relatedContentShow) {
          this.breadcrumb.push(item);
        }
        this.activeItem = item;
        // Clear cache when activeItem changes to prevent memory leaks
        this.clearRenderCache();
        if (item.content.length > 1) {
          this.fakeData = item;
          this.detailShow = false;
        } else {
          this.breadcrumb[this.breadcrumb.length - 1] = item;
          if (this.breadcrumb.length > 2) {
            this.relatedContentShow = true;
          }
          this.detailShow = true;
          // Update rendered content when showing detail
          this.updateCurrentRenderedContent();
        }
      }
    });
  }

  renderRichText(content: any) {
    console.log('renderRichText');
    return this.getRichTextResolver().render(content);
  }

  getCachedRenderedContent(content: any): string {
    const contentKey = JSON.stringify(content);

    if (this.renderedContentCache.has(contentKey)) {
      return this.renderedContentCache.get(contentKey)!;
    }

    const renderedContent = this.getRichTextResolver().render(content);
    this.renderedContentCache.set(contentKey, renderedContent);
    return renderedContent;
  }

  clearRenderCache(): void {
    this.renderedContentCache.clear();
  }

  private updateCurrentRenderedContent(): void {
    if (this.activeItem && this.detailShow) {
      const content = this.activeItem?.content[0][0]
        ? this.activeItem.content[0][0].content.content
        : this.activeItem?.content[0]?.content?.content;

      if (content) {
        this.currentRenderedContent = this.getCachedRenderedContent(content);
        this.currentSanitizedContent = this.bypassHtmlSecurity(this.currentRenderedContent);
      }
    }
  }
  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
  getRichTextResolver() {
    console.log('getRichTextResolver');
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });
    return this.storyblokClient.richTextResolver;
  }
}
