import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import Storyblok from 'storyblok-js-client';
declare var $: any;

@Component({
  selector: 'app-indicator-level-guidance',
  templateUrl: './indicator-level.component.html',
  styleUrls: ['./indicator-level.component.scss'],
  standalone: false,
})
export class GuidanceIndicatorLevelComponent implements OnInit {
  @Output() openReturn: EventEmitter<any> = new EventEmitter();
  @Input() public page: string;
  public fakeData;
  public activeItem;
  public storyblokMainGuidanceShell;
  public storyblokIndicators;
  public storyblokIndicatorLevel;
  public detailShow = false;
  public relatedContentShow = false;
  public breadcrumb = [];
  public storyblokClient;
  constructor(private sanitizer: DomSanitizer, private storyblokService: StoryblokService) {
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });
  }
  ngOnInit() {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblokMainGuidanceShell = data.filter(
        (item) => item.uuid === '666f7c59-2976-409c-94a9-e2a11ced230c'
      )[0].content;
      this.storyblokIndicators = data.filter((item) => item.slug === 'step2')[0].content;
      this.storyblokIndicatorLevel = {
        description: this.storyblokMainGuidanceShell.indicators,
        slug: 'guidance/assessment-level/step-2/indicators',
        otherTopics: this.storyblokMainGuidanceShell.other_topics,
        content: [
          {
            description: this.storyblokIndicators.material_circularity,
            slug: 'guidance/assessment-level/step-2/indicators/material-circularity',
            content: data.filter((item) => item.uuid === '77a3228e-59a8-483b-89b6-bd2ef48b39d9'),
          },
          {
            description: this.storyblokIndicators.water_circularity,
            slug: 'guidance/assessment-level/step-2/indicators/water-circularity',
            content: data.filter((item) => item.uuid === '4db89ace-3989-4331-a4f6-b0006c85f4cf'),
          },
          {
            description: this.storyblokIndicators.renewable_energy,
            slug: 'guidance/assessment-level/step-2/indicators/renewable-energy',
            content: data.filter((item) => item.uuid === '514dd98a-bc75-4370-bc34-c9a9cff6620b'),
          },
          {
            description: this.storyblokIndicators.critical_inflow,
            slug: 'guidance/assessment-level/step-2/indicators/critical-inflow',
            content: data.filter((item) => item.uuid === 'e7d76922-cdd3-4568-917b-173dfc840a13'),
          },
          {
            description: this.storyblokIndicators.recovery_type,
            slug: 'guidance/assessment-level/step-2/indicators/recovery-type',
            content: data.filter((item) => item.uuid === 'b25e7606-1940-4f77-b617-eee0654e0c6d'),
          },
          {
            description: this.storyblokIndicators.onsite_water_circulation,
            slug: 'guidance/assessment-level/step-2/indicators/onsite-water-circulation',
            content: data.filter((item) => item.uuid === '99dc3076-5111-46a3-a970-270326d47ea5'),
          },
          {
            description: this.storyblokIndicators.actual_lifetime,
            slug: 'guidance/assessment-level/step-2/indicators/actual-lifetime',
            content: data.filter((item) => item.uuid === '0a13ccc8-3038-4231-afc5-380f6866411d'),
          },
          {
            description: this.storyblokIndicators.circular_material_productivity,
            slug: 'guidance/assessment-level/step-2/indicators/circular-material-productivity',
            content: data.filter((item) => item.uuid === '825a5b1c-59ee-408a-9643-023996c5fbff'),
          },
          {
            description: this.storyblokIndicators.cti_revenue,
            slug: 'guidance/assessment-level/step-2/indicators/cti-revenue',
            content: data.filter((item) => item.uuid === '02dfa8c5-7b9c-4fa5-8196-98041ca1f077'),
          },
          {
            description: this.storyblokIndicators.ghg_Impact,
            slug: 'guidance/assessment-level/step-2/indicators/ghg-impact',
            content: data.filter((item) => item.uuid === 'f017071f-baed-46fc-b183-e1b64379646e'),
          },
          {
            description: this.storyblokIndicators.nature_impact,
            slug: 'guidance/assessment-level/step-2/indicators/nature-impact',
            content: data.filter((item) => item.uuid === '00acaa3c-284c-414b-b9eb-0ed08608fdc4'),
          },
        ],
      };
      this.fakeData = this.storyblokIndicatorLevel;
      this.breadcrumb.push({
        description: this.storyblokIndicatorLevel?.description,
        slug: this.storyblokIndicatorLevel?.slug,
      });
      if (this.page === 'step2') {
        setTimeout(() => {
          this.storyblokIndicatorLevel.content.unshift({
            description: this.storyblokMainGuidanceShell.getting_started,
            slug: 'guidance/assessment-level/step-2/getting-started-with-step-2',
            content: data.filter((item) => item.uuid === '5956c138-e685-4757-99a6-030ac9f4437a'),
          });
          this.openSub('guidance/assessment-level/step-2/getting-started-with-step-2');
        }, 100);
      } else {
        this.openSub(this.page);
      }
    });
  }

  goBack(slug: string) {
    this.relatedContentShow = false;
    if (slug === 'guidance/assessment-level/step-2/indicators') {
      this.fakeData = this.storyblokIndicatorLevel;
      this.detailShow = false;
      this.activeItem = null;
      this.breadcrumb = [
        { description: this.storyblokIndicatorLevel.description, slug: this.storyblokIndicatorLevel.slug },
      ];
    }
  }

  openSub(slug: string) {
    this.fakeData.content.forEach((item) => {
      if (slug === item.slug) {
        if (!this.relatedContentShow) {
          this.breadcrumb.push(item);
        }
        this.activeItem = item;
        if (item.content.length > 1) {
          this.fakeData = item;
          this.detailShow = false;
        } else {
          this.breadcrumb[this.breadcrumb.length - 1] = item;
          this.relatedContentShow = true;
          this.detailShow = true;
        }
      }
    });
  }

  renderRichText(content: any) {
    return this.getRichTextResolver().render(content);
  }
  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
  getRichTextResolver() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });
    return this.storyblokClient.richTextResolver;
  }
}
