import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { environment } from '@env/environment';
import Storyblok from 'storyblok-js-client';
declare var $: any;

@Component({
  selector: 'app-label-view-guidance',
  templateUrl: './label-view.component.html',
  styleUrls: ['./label-view.component.scss'],
  standalone: false,
})
export class GuidanceLabelViewComponent implements OnInit {
  @Input() public data: any;
  @Output() openReturn: EventEmitter<any> = new EventEmitter();
  public fakeData;
  public activeItem;
  public detailShow = false;
  public relatedContentShow = false;
  public breadcrumb = [];
  public storyblokClient;
  constructor(private sanitizer: DomSanitizer) {
    this.storyblokClient = new Storyblok({
      accessToken: environment.storyblokToken,
    });
  }
  ngOnInit() {
    this.fakeData = this.data;
    this.breadcrumb.push({ description: this.data.description, slug: this.data.slug });
  }

  goBack(slug: string) {
    this.relatedContentShow = false;
    if (slug === 'guidance/label') {
      this.fakeData = this.data;
      this.detailShow = false;
      this.activeItem = null;
      this.breadcrumb = [{ description: this.data.description, slug: this.data.slug }];
    }
  }
  openSub(slug: string) {
    this.fakeData.content.forEach((item) => {
      if (slug === item.slug) {
        if (!this.relatedContentShow) {
          this.breadcrumb.push(item);
        }
        this.activeItem = item;

        if (item.content.length > 1) {
          this.fakeData = item;
          this.detailShow = false;
        } else {
          this.breadcrumb[this.breadcrumb.length - 1] = item;
          this.relatedContentShow = true;
          this.detailShow = true;
        }
      }
    });
  }

  renderRichText(content: any) {
    return this.getRichTextResolver().render(content);
  }
  bypassHtmlSecurity(html: string) {
    return this.sanitizer.bypassSecurityTrustHtml(html);
  }
  getRichTextResolver() {
    this.storyblokClient.setComponentResolver((component: string, blok: any) => {
      switch (component) {
        case 'VimeoVideo':
          return `<div class='VimeoVideo'>${blok.iframe}</div>`;
        default:
          return blok;
      }
    });
    return this.storyblokClient.richTextResolver;
  }
}
