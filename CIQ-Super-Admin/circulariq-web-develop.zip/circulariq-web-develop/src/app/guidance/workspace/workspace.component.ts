import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import editorConfig from '@app/core/DefaultEditorConfig';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { MatDialog } from '@angular/material/dialog';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
declare var $: any;

@Component({
  selector: 'app-workspace-guidance',
  templateUrl: './workspace.component.html',
  styleUrls: ['./workspace.component.scss'],
  standalone: false,
})
export class WorkspaceGuidanceComponent implements OnInit, OnDestroy {
  credentials = JSON.parse(sessionStorage.getItem('credentials'));
  dirtyData = false;
  blockNavigation = false;
  htmlContent;
  storyblok;
  pureHtmlContent;
  onboardingAlwaysOn;
  isLoading = false;
  environment = environment;
  editorConfig = editorConfig;
  isSettingsVisible = false;
  isShowEditor = false;
  alertShow = true;
  sampleVideosSeen = true;
  constructor(
    private dialog: MatDialog,
    private http: ApiRequestService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private storyblokService: StoryblokService
  ) {
    this.editorConfig.minHeight = $(window).height() - 410 + 'px';
    this.http.callService(new Method(environment.services.onboarding(), '', 'get')).subscribe(async (res) => {
      const data = res['text'];
      this.htmlContent = data;
      this.pureHtmlContent = data;
      if (this.htmlContent === '') {
        this.isShowEditor = true;
      }
    });
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.uuid === '6781fa8d-c7ed-424e-b88e-7543b58cfa44')[0].content;
    });
  }

  ngOnInit(): void {
    this.onboardingAlwaysOn =
      this.commonService.onboardingAlwaysOn === false
        ? false
        : JSON.parse(sessionStorage.getItem('onboardingAlwaysOn'));
    this.openSettings();
  }
  ngOnDestroy(): void {
    this.commonService.onboardingAlwaysOn = false;
  }
  openEditor() {
    this.isShowEditor = true;
    this.isSettingsVisible = false;
  }
  openSettings() {
    if (this.onboardingAlwaysOn) {
      $('.sticky').css('bottom', '0');
      this.dirtyData = false;
      this.blockNavigation = false;
    }
  }
  changeData() {
    if (this.htmlContent.length > 0) {
      $('.sticky').css('width', '775px');
      $('.sticky').css('bottom', '14px');
      this.dirtyData = true;
    }
  }

  saveBoxResponse(value: boolean) {
    $('.sticky').css('bottom', '-140px');
    if (value) {
      this.http
        .callService(new Method(environment.services.onboarding(), { text: this.htmlContent }, 'put'))
        .subscribe(async (res) => {
          this.isShowEditor = false;
          this.pureHtmlContent = this.htmlContent;
          this.snackBar.open(this.commonService.storyblok?.success_message, '', {
            duration: 5000,
            panelClass: ['success-snackBar'],
          });
        });
    } else {
      this.isShowEditor = false;
      this.htmlContent = this.pureHtmlContent;
    }
    this.dirtyData = false;
    this.blockNavigation = false;
  }
}
