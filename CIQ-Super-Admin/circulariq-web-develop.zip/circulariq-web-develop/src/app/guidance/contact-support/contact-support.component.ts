import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { CommonService } from '@app/core/common.service';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';

@Component({
  selector: 'app-contact-support-guidance',
  templateUrl: './contact-support.component.html',
  styleUrls: ['./contact-support.component.scss'],
  standalone: false,
})
export class GuidanceContactSupportComponent {
  storyblok;
  selectedItem;
  category = 'other';
  message;
  placeholder;
  constructor(
    private storyblokService: StoryblokService,
    private http: ApiRequestService,
    private snackBar: MatSnackBar,
    private commonService: CommonService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.uuid === '85f60626-dc48-4129-8ba3-a9e878436869')[0].content;
      this.placeholder = this.storyblok.option4placeholder;
    });
  }

  selectedItemEvent(selected: string) {
    switch (selected) {
      case 'option1':
        this.placeholder = this.storyblok.option1placeholder;
        this.category = 'Implementing CTI Framework';
        break;
      case 'option2':
        this.placeholder = this.storyblok.option2placeholder;
        this.category = 'Using CTI Tool';
        break;
      case 'option3':
        this.placeholder = this.storyblok.option3placeholder;
        this.category = 'Report a bug/issue';
        break;
      default:
        this.placeholder = this.storyblok.option4placeholder;
        this.category = 'other';
        break;
    }
    this.selectedItem = selected;
  }

  sendMesseage() {
    const data = {
      category: this.category,
      question: this.message,
    };
    this.http.callService(new Method(environment.services.contact(), data, 'post')).subscribe(async (res) => {
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
      this.selectedItem = null;
      this.message = '';
    });
  }
}
