import { NgModule } from '@angular/core';
import { Shell } from './shell/shell.service';
import { OrganizationComponent } from './organization/organization.component';
import { AssessmentDashboardComponent } from './assessment-level/assessment-dashboard/assessment-dashboard.component';
import { NewUserComponent } from './assessment-level/new-user/new-user.component';
import { Step1Component } from './assessment-level/step1/step1.component';
import { Step2Component } from './assessment-level/step2/step2.component';
import { NewOrganisationComponent } from './assessment-level/new-organisation/new-organisation.component';
import { CriticalMaterialComponent } from './assessment-level/critical-material/critical-material.component';
import { UserComponent } from './user/user.component';
import { Step5Component } from './assessment-level/step5/step5.component';
import { Step6Component } from './assessment-level/step6/step6.component';
import { Step7Component } from './assessment-level/step7/step7.component';
import { CompareComponent } from './pro/compare/compare.component';
import { AggregateComponent } from './pro/aggregate/aggregate.component';
import { ReportComponent } from './shared-components/report/report.component';
import { AggregateReportComponent } from './shared-components/aggregate-report/aggregate-report.component';
import { CompareReportComponent } from './shared-components/compare-report/compare-report.component';
import { RouterModule, Routes, NavigationEnd, Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { filter, map, mergeMap } from 'rxjs/operators';
import { E5Component } from './e5/e5.component';
import { E5ReportComponent } from './e5/e5-report/e5-report.component';
import { E5PDFReportComponent } from './shared-components/e5-report/e5-report.component';
import { E5MaterialsComponent } from './e5/e5-materials/e5-materials.component';
import { e5GuardGuard } from './core/e5-guard.guard';
import { MaterialsComponent } from './assessment-level/materials/materials.component';
import { ProComponent } from './pro/pro.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DashboardFlowsUnsavedGuard } from './core/guards/dashboard-flows-unsaved.guard';

const routes: Routes = [
  Shell.childRoutes([
    { path: 'cti', redirectTo: 'cti/:unitId/dashboard', pathMatch: 'full' },
    {
      path: 'organisation',
      component: OrganizationComponent,
      data: { title: 'CircularIQ - CTI Organisation' },
    },
    { path: 'user', component: UserComponent, data: { title: 'CircularIQ - CTI User Profile' } },
    {
      path: 'cti/dashboard',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - Dashboard' },
    },
    {
      path: 'cti/dashboard/:dashboardId',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - Dashboard' },
    },
    {
      path: 'cti/dashboard/:dashboardId/:tab',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - Dashboard' },
    },
    {
      path: 'cti/new-dashboard',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - New Dashboard' },
    },
    {
      path: 'cti/edit-dashboard/:dashboardId',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - Edit Dashboard' },
    },
    {
      path: 'cti/pro-label',
      component: E5Component,
      data: { title: 'CircularIQ - CTI PRO' },
    },
    {
      path: 'cti/pro',
      component: ProComponent,
      data: { title: 'CircularIQ - CTI PRO' },
    },
    {
      path: 'cti/pro-business',
      component: ProComponent,
      data: { title: 'CircularIQ - CTI PRO' },
    },
    {
      path: 'cti/pro/compare',
      component: CompareComponent,
      data: { title: 'CircularIQ - CTI PRO COMPARE' },
    },
    {
      path: 'cti/pro/aggregate',
      component: AggregateComponent,
      data: { title: 'CircularIQ - CTI PRO AGGREGATE' },
    },

    {
      path: 'cti/:unitId/materials',
      component: MaterialsComponent,
      data: { title: 'CircularIQ - CTI Materials' },
    },
    {
      path: 'cti/:unitId/dashboard',
      component: DashboardComponent,
      canDeactivate: [DashboardFlowsUnsavedGuard],
      data: { title: 'CircularIQ - CTI Dashboard' },
    },
    {
      path: 'cti/:unitId/assessment/step1',
      component: Step1Component,
      data: { title: 'CircularIQ - CTI Step 1' },
    },
    {
      path: 'cti/:unitId/assessment/step2',
      component: Step2Component,
      data: { title: 'CircularIQ - CTI Step 2', selectedProduct: '' },
    },
    {
      path: 'cti/:unitId/assessment/step3/materials',
      component: MaterialsComponent,
      data: { title: 'CircularIQ - CTI Materials' },
    },
    {
      path: 'cti/:unitId/assessment/step4',
      component: AssessmentDashboardComponent,
      data: { title: 'CircularIQ - CTI Step4 ' },
    },
    {
      path: 'cti/:unitId/assessment/step5',
      component: Step5Component,
      data: { title: 'CircularIQ - CTI Step 5' },
    },
    {
      path: 'cti/:unitId/assessment/step6',
      component: Step6Component,
      data: { title: 'CircularIQ - CTI Step 6' },
    },
    {
      path: 'cti/:unitId/assessment/step7',
      component: Step7Component,
      data: { title: 'CircularIQ - CTI Step 7' },
    },

    {
      path: 'cti/:unitId/assessment/critical-material',
      component: CriticalMaterialComponent,
      data: { title: 'CircularIQ - Critical Material' },
    },
    {
      path: 'e5',
      component: E5Component,
      canActivate: [e5GuardGuard],
      data: { title: 'CircularIQ - CTI E5' },
    },
    {
      path: 'e5/:reportId/e5-report',
      component: E5ReportComponent,
      canActivate: [e5GuardGuard],
      data: { title: 'CircularIQ - E5 Report' },
    },
    {
      path: 'e5/:unitId/e5-materials/:iseditable',
      component: E5MaterialsComponent,
      canActivate: [e5GuardGuard],
      data: { title: 'CircularIQ - CTI Materials' },
    },
  ]),
  {
    path: 'cti/guide/new-user',
    component: NewUserComponent,
    data: { title: 'CircularIQ - CTI New User' },
  },
  {
    path: 'cti/guide/new-organisation',
    component: NewOrganisationComponent,
    data: { title: 'CircularIQ - CTI New Organisation' },
  },
  {
    path: 'cti/:unitId/:authToken/report',
    component: ReportComponent,
    data: { title: 'CircularIQ - CTI Report' },
  },
  {
    path: 'cti/compare-report',
    component: CompareReportComponent,
    data: { title: 'CircularIQ - CTI Compare Report' },
  },
  {
    path: 'cti/aggregate-report',
    component: AggregateReportComponent,
    data: { title: 'CircularIQ - CTI Aggregate Report' },
  },
  {
    path: 'e5/:reportId/report',
    component: E5PDFReportComponent,
    canActivate: [e5GuardGuard],
    data: { title: 'CircularIQ - E5 Report' },
  },

  { path: '**', redirectTo: '/error-page', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {
  constructor(private router: Router, private titleService: Title) {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        map(() => this.router.routerState.snapshot.root),
        map((root) => {
          while (root.firstChild) {
            root = root.firstChild;
          }
          return root;
        }),
        mergeMap(async (route) => route.data)
      )
      .subscribe((data) => {
        this.titleService.setTitle(data['title'] || 'Circular-IQ');
      });
  }
}
