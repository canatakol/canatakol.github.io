import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { SankeyInfoComponent } from '@app/shared-components/sankey-info/sankey-info.component';
import { PackagingComponent } from '@app/shared-components/packaging/packaging.component';
import { MostLinearInflowComponent } from '@app/shared-components/most-linear-inflow/most-linear-inflow.component';
import { CriticalInflowComponent } from '@app/shared-components/critical-inflow/critical-inflow.component';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { GHGComponent } from '@app/shared-components/ghg/ghg.component';
import { CiqNumberPipe } from '@app/pipes';
import { CommentCenterComponent } from '@app/shared-components/comment-center/comment-center.component';
import { DashboardMetricsComponent } from '../dashboard-metrics/dashboard-metrics.component';
import { CommonService } from '@app/core/common.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-design-tab',
  templateUrl: './design-tab.component.html',
  styleUrls: ['./design-tab.component.scss'],
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    MatProgressBarModule,
    SankeyInfoComponent,
    PackagingComponent,
    MostLinearInflowComponent,
    CriticalInflowComponent,
    GHGComponent,
    CiqNumberPipe,
    CommentCenterComponent,
    DashboardMetricsComponent,
  ],
})
export class DesignTabComponent implements OnInit, OnDestroy {
  data: any;
  storyblok: any;
  @Input() set dashboardData(value: any) {
    this._dashboardData = value;
  }
  get dashboardData(): any {
    return this._dashboardData;
  }
  @Input() selectedLabels: any[] = [];
  @Input() aggregateData: any;
  @Input() loadingAggregate: boolean;
  @Input() organisationGoal: any;
  @Input() storyblokDashoard: any;
  private _dashboardData: any = null;

  // Reactive data from CommonService
  reactiveDashboardData: any = null;
  reactiveAggregateData: any = null;
  reactiveOrganisationGoal: any = null;
  reactiveLoadingState: boolean = false;

  private subscriptions: Subscription[] = [];

  constructor(
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private commonService: CommonService
  ) {
    this.storyblokService.getStoryService().then((data) => {
      const story = data.filter((item) => item.slug === 'step4-dashboard');
      this.storyblok = story[0].content;
    });
  }

  ngOnInit(): void {
    // Subscribe to reactive data from CommonService
    this.subscriptions.push(
      this.commonService.selectedDashboard.subscribe((data) => {
        this.reactiveDashboardData = data;
      }),

      this.commonService.dashboardAggregateData.subscribe((data) => {
        if (data && data.tab === 'DESIGN') {
          this.reactiveAggregateData = data.data;
          this.reactiveLoadingState = data.loading;
        }
      }),

      this.commonService.organisationGoalData.subscribe((data) => {
        this.reactiveOrganisationGoal = data;
      }),

      this.commonService.dashboardLoadingState.subscribe((state) => {
        if (state.tab === 'DESIGN' || state.tab === 'all') {
          this.reactiveLoadingState = state.loading;
        }
      })
    );
  }

  ngOnDestroy(): void {
    // Clean up subscriptions
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }
}
