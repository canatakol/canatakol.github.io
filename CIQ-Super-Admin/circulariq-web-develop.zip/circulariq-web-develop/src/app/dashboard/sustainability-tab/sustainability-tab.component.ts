import { Component, Input, OnInit, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { AggregateComponent } from '@app/pro/aggregate/aggregate.component';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { environment } from '@env/environment';
import { CiqNumberPipe } from '@app/pipes';
import { CommentCenterComponent } from '@app/shared-components/comment-center/comment-center.component';
import { DashboardMetricsComponent } from '../dashboard-metrics/dashboard-metrics.component';
import { CommonService } from '@app/core/common.service';
import { Subscription } from 'rxjs';
import { LocalStorageService } from '@app/core/services/local-storage.service';

@Component({
  selector: 'app-sustainability-tab',
  templateUrl: './sustainability-tab.component.html',
  styleUrls: ['./sustainability-tab.component.scss'],
  standalone: true,
  imports: [
    FormsModule,
    CommonModule,
    MatProgressBarModule,
    AggregateComponent,
    CiqNumberPipe,
    CommentCenterComponent,
    DashboardMetricsComponent,
  ],
})
export class SustainabilityTabComponent implements OnInit, OnDestroy {
  @Input() set dashboardData(value: any) {
    this._dashboardData = value;
    if (value && value.id) {
      this.updateAggregateData();
    }
  }
  get dashboardData(): any {
    return this._dashboardData;
  }
  @Input() set aggregateData(value: any) {
    this._aggregateData = value;
    this.updateAggregateData();
  }
  get aggregateData(): any {
    return this._aggregateData;
  }
  @Input() loadingAggregate: boolean = false;
  @Input() selectedLabels: any[] = [];
  @Input() organisationGoal: any;
  @Input() storyblokDashoard: any;
  private _dashboardData: any = null;
  private _aggregateData: any = null;

  // Reactive data from CommonService
  reactiveDashboardData: any = null;
  reactiveAggregateData: any = null;
  reactiveOrganisationGoal: any = null;
  reactiveLoadingState: boolean = false;

  private subscriptions: Subscription[] = [];

  constructor(
    private http: ApiRequestService,
    private commonService: CommonService,
    private localStorageService: LocalStorageService
  ) {}

  ngOnInit(): void {
    this.updateAggregateData();

    // Subscribe to reactive data from CommonService
    this.subscriptions.push(
      this.commonService.selectedDashboard.subscribe((data) => {
        this.reactiveDashboardData = data;
      }),

      this.commonService.dashboardAggregateData.subscribe((data) => {
        if (data && data.tab === 'SUSTANABILITY') {
          this.reactiveAggregateData = data.data;
          this.reactiveLoadingState = data.loading;
          this.updateAggregateData();
        }
      }),

      this.commonService.organisationGoalData.subscribe((data) => {
        this.reactiveOrganisationGoal = data;
      }),

      this.commonService.dashboardLoadingState.subscribe((state) => {
        if (state.tab === 'SUSTANABILITY' || state.tab === 'all') {
          this.reactiveLoadingState = state.loading;
        }
      })
    );
  }

  ngOnDestroy(): void {
    // Clean up subscriptions
    this.subscriptions.forEach((sub) => sub.unsubscribe());
  }

  private updateAggregateData(): void {
    // Use reactive data if available, otherwise fall back to input data
    const dataToUse = this.reactiveAggregateData || this._aggregateData;
    if (dataToUse) {
      this.localStorageService.setCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY, dataToUse);
    }
  }
}
