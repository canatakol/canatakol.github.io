import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiRequestService, Method } from '@app/core/http/api-request.service';
import { StoryblokService } from '@app/core/storyblok/storyblok.service';
import { environment } from '@env/environment';
import { Label } from '@app/shared-components/label-logic-display/label-logic-display.component';
import { CommonService } from '@app/core/common.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { SustainabilityTabComponent } from './sustainability-tab/sustainability-tab.component';
import { ProcurementTabComponent } from './procurement-tab/procurement-tab.component';
import { DesignTabComponent } from './design-tab/design-tab.component';
import { LabelLogicDisplayComponent } from '@app/shared-components/label-logic-display/label-logic-display.component';
import { LabelManagmentComponent } from '@app/pro/label-managment/label-managment.component';
import { DeleteConfirmDialog } from '@app/shared/dialog/delete-confirm/delete-confirm-dialog.component';
import { DashboardStateService } from '@app/core/services/dashboard-state.service';
import { AggregateDataService } from '@app/core/services/aggregate-data.service';
import { LoadingBarComponent } from '@app/shared-components/loading-bar/loading-bar.component';
import { LocalStorageService } from '@app/core/services/local-storage.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatSnackBarModule,
    SustainabilityTabComponent,
    ProcurementTabComponent,
    DesignTabComponent,
    LabelLogicDisplayComponent,
    LabelManagmentComponent,
    LoadingBarComponent,
  ],
})
export class DashboardComponent implements OnInit {
  dashboardName: string = '';
  nameAvailable: any;
  dirtyData: boolean;
  storyblok: any;
  labelList: any[] = [];
  labelListPureData: any[] = [];
  showLabelManagment: boolean = false;
  selectedLabels: Label[] = [];
  dashboardData: any = [];
  selectedDashboard: any = null;
  showCreateDashboard: boolean = false;
  showEditDashboard: boolean = false;
  editingDashboardId: string | null = null;
  originalDashboardName: string = '';
  selectedTab: string = 'PROCUREMENT';
  isDeletingDashboard: boolean = false;
  aggregateData: any = null;
  loadingAggregate: boolean = false;
  showDashboardContent: boolean = false;
  aggregateDataProcurement: any = null;
  loadingAggregateProcurement: boolean = false;
  aggregateDataSustanability: any = null;
  loadingAggregateSustanability: boolean = false;
  aggregateDataDesign: any = null;
  loadingAggregateDesign: boolean = false;
  organisationGoal: any = null;
  isNavigating: boolean = false; // Add flag to prevent infinite loops
  showSelectedLabelsDisplay: boolean = false; // Add property to control selected labels display visibility
  assessmentsLength: number = 1;
  labelCount: number = 1;
  getAssessmentaccordingToLabelCount: number = null;
  constructor(
    private http: ApiRequestService,
    private storyblokService: StoryblokService,
    private commonService: CommonService,
    private snackBar: MatSnackBar,
    private dialog: MatDialog,
    private route: ActivatedRoute,
    private router: Router,
    private dashboardStateService: DashboardStateService,
    private aggregateDataService: AggregateDataService,
    private localStorageService: LocalStorageService
  ) {
    this.setLabel();
  }

  getLabelCount(): void {
    this.http.callService(new Method(environment.services.label(), {}, 'get')).subscribe((res: any) => {
      this.labelCount = res.length || 0;
    });
    this.aggregateData = this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY) || {};
    this.assessmentsLength = this.aggregateData?.assessments?.length || 0;
  }

  ngOnInit(): void {
    this.getLabelCount();
    this.storyblokService.getStoryService().then((data) => {
      this.storyblok = data.filter((item) => item.slug === 'dashboard')[0].content;
    });

    this.route.params.subscribe((params) => {
      // Prevent infinite loops by checking if we're already navigating
      if (this.isNavigating) {
        return;
      }

      const dashboardId = params['dashboardId'];
      const tab = params['tab'];

      if (this.router.url === '/cti/new-dashboard') {
        this.showCreateDashboard = true;
        this.getDashboardData();
        this.showDashboardContent = true;
        return;
      }
      if (this.router.url.startsWith('/cti/edit-dashboard/')) {
        if (dashboardId) {
          this.showEditDashboard = true;
          this.editingDashboardId = dashboardId;
          this.getDashboardData();
          this.loadDashboardForEdit(dashboardId);
        }
        this.showDashboardContent = true;
        return;
      }

      // Normal dashboard view - show loading until all data is ready
      this.loadAllDashboardData(dashboardId, tab)
        .then(() => {
          this.showDashboardContent = true;
        })
        .catch(() => {
          // Even if there's an error, show the content
          this.showDashboardContent = true;
        });
    });
  }

  gOrganisationGoal(): Promise<void> {
    return new Promise((resolve) => {
      this.http.callService(new Method(environment.services.setOrganisationGoal(), {}, 'get')).subscribe((res) => {
        this.organisationGoal = res;
        // Update CommonService for reactive sharing
        this.commonService.organisationGoalData.next(res);
        resolve();
      });
    });
  }

  private async loadAllDashboardData(dashboardId: string, tab: string): Promise<void> {
    try {
      // Load dashboard list
      await this.getDashboardDataAsync();

      // Load organisation goal
      await this.gOrganisationGoal();

      // Select dashboard and load its details
      if (dashboardId) {
        await this.selectDashboard(dashboardId);
      } else if (this.dashboardData.length > 0 && !this.selectedDashboard) {
        await this.selectDashboard(this.dashboardData[0].id);
      }

      // Set tab and load aggregate data
      if (tab) {
        const tabUpper = tab.toUpperCase();
        // Only call selectTabs if the tab is different from current
        if (this.selectedTab !== tabUpper) {
          await this.selectTabs(tabUpper);
        } else {
          // Just load aggregate data for the current tab
          if (this.selectedDashboard) {
            await this.loadDashboardAggregate(this.selectedTab);
          }
        }
      } else if (!this.selectedDashboard) {
        this.selectedTab = this.getLastSelectedTab();
        // Update dashboard state service with the default tab
        this.dashboardStateService.updateState({
          selectedTab: this.selectedTab,
          dashboardId: this.selectedDashboard?.id || '',
        });
        // Load aggregate data for the default tab
        if (this.selectedDashboard) {
          await this.loadDashboardAggregate(this.selectedTab);
        }
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
      throw error;
    }
  }

  newDashboard(): void {
    this.showCreateDashboard = true;
    this.selectedDashboard = null;
    this.router.navigate(['cti/new-dashboard']);
  }

  showSelectedLabels(): void {
    this.showSelectedLabelsDisplay = !this.showSelectedLabelsDisplay;
  }

  setLabel(): Promise<void> {
    return new Promise((resolve) => {
      this.http
        .callService(new Method(environment.services.labelSearch(), { keyword: '' }, 'put'))
        .subscribe((res: any[]) => {
          this.labelList = res.map((label) => ({
            ...label,
            selected: false,
            labelPahtWithTrim: label.path.join('').toLowerCase().replace(/\s/g, ''),
          }));
          this.labelListPureData = this.labelList;
          this.labelList.sort((a, b) => a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim));
          resolve();
        });
    });
  }

  ckeckName(name: string): void {
    if (name.length >= 3) {
      this.http
        .callService(new Method(environment.services.assessmentNameCheck(), { name: name }, 'put'))
        .subscribe((res) => {
          this.nameAvailable = res['available'];

          if (this.showEditDashboard && this.originalDashboardName.trim().toLowerCase() === name.trim().toLowerCase()) {
            this.nameAvailable = true;
          } else {
            this.nameAvailable =
              this.dashboardName.trim().toLowerCase() === name.trim().toLowerCase() ? true : this.nameAvailable;
          }

          this.dirtyData = true;
        });
    } else {
      this.nameAvailable = false;
      this.dirtyData = false;
    }
  }

  setSelectedLabelArray(selectedData: any): void {
    this.selectedLabels = selectedData;
    const labelIds = this.selectedLabels.map((label) => label.id);
    this.getAssessmentaccordingToLabel(labelIds);
    this.labelList.forEach((label) => {
      label.selected = this.selectedLabels.some((selectedLabel) => selectedLabel.id === label.id);
    });

    this.labelList.sort((a, b) => {
      if (a.selected && !b.selected) return -1;
      if (!a.selected && b.selected) return 1;

      return a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim);
    });

    this.showLabelManagment = false;
  }

  getAssessmentaccordingToLabel(labelIds: any) {
    const data = { labelIds: labelIds, keyword: '', noLabel: false };

    this.http
      .callService(
        new Method(
          environment.services.getAssessmentaccordingToLabel(),
          { labelIds: labelIds, keyword: '', noLabel: false },
          'put'
        )
      )
      .subscribe((res: any) => {
        this.getAssessmentaccordingToLabelCount = res.assessments.length | 0;
      });
  }

  onLabelRemoved(label: Label): void {
    this.selectedLabels = this.selectedLabels.filter((l) => l.id !== label.id);
    const labelIds = this.selectedLabels.map((label) => label.id);
    this.getAssessmentaccordingToLabel(labelIds);
    const labelInList = this.labelList.find((l) => l.id === label.id);
    if (labelInList) {
      labelInList.selected = false;
    }

    this.labelList.sort((a, b) => {
      if (a.selected && !b.selected) return -1;
      if (!a.selected && b.selected) return 1;

      return a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim);
    });
  }

  getDashboardData(): void {
    this.http.callService(new Method(environment.services.dashboard(), {}, 'get')).subscribe({
      next: (res) => {
        this.dashboardData = res;
        if (this.router.url.startsWith('/cti/edit-dashboard/')) {
          this.nameAvailable = true;
        }
        if (this.router.url === '/cti/new-dashboard' || this.router.url.startsWith('/cti/edit-dashboard/')) {
          return;
        }

        if (this.dashboardData.length === 0) {
          this.showCreateDashboard = true;
          this.router.navigate(['cti/new-dashboard']);
          return;
        }

        if (this.selectedDashboard && !this.dashboardData.find((d) => d.id === this.selectedDashboard.id)) {
          this.selectedDashboard = null;
        }

        if (
          !this.selectedDashboard &&
          this.dashboardData.length > 0 &&
          !this.router.url.startsWith('/cti/edit-dashboard/')
        ) {
          const lastSelectedDashboardId = this.getLastSelectedDashboardId();
          if (lastSelectedDashboardId && this.dashboardData.find((d) => d.id === lastSelectedDashboardId)) {
            this.selectDashboard(lastSelectedDashboardId);
          } else {
            this.selectDashboard(this.dashboardData[0].id);
          }
        }
      },
      error: (error) => {
        this.dashboardData = [];
        this.selectedDashboard = null;
      },
    });
  }

  getDashboardDataAsync(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.http.callService(new Method(environment.services.dashboard(), {}, 'get')).subscribe({
        next: (res) => {
          this.dashboardData = res;
          resolve();
        },
        error: (error) => {
          this.dashboardData = [];
          this.selectedDashboard = null;
          reject(error);
        },
      });
    });
  }

  getDashboardDetailAsync(dashboardId: string | number): Promise<any> {
    return new Promise((resolve, reject) => {
      this.http
        .callService(new Method(environment.services.dashboardDetail(dashboardId.toString()), {}, 'get'))
        .subscribe({
          next: (res) => {
            this.selectedDashboard = res || {};

            this.saveLastSelectedDashboardId(dashboardId);

            this.selectedTab = this.getLastSelectedTab();

            resolve(this.selectedDashboard);
          },
          error: (error) => {
            const dashboard = this.dashboardData.find((d) => d.id === dashboardId);
            if (dashboard) {
              this.selectedDashboard = dashboard;
              this.saveLastSelectedDashboardId(dashboardId);
              this.selectedTab = this.getLastSelectedTab();
              resolve(this.selectedDashboard);
            } else {
              reject(error);
            }
          },
        });
    });
  }

  getDashboardDetail(dashboardId: string | number): void {
    this.http
      .callService(new Method(environment.services.dashboardDetail(dashboardId.toString()), {}, 'get'))
      .subscribe({
        next: (res) => {
          this.selectedDashboard = res || {};

          this.saveLastSelectedDashboardId(dashboardId);

          this.selectedTab = this.getLastSelectedTab();
        },
        error: (error) => {
          const dashboard = this.dashboardData.find((d) => d.id === dashboardId);
          if (dashboard) {
            this.selectedDashboard = dashboard;
            this.saveLastSelectedDashboardId(dashboardId);
            this.selectedTab = this.getLastSelectedTab();
          }
        },
      });
  }

  createDashboard(): void {
    const newDashboard = {
      name: this.dashboardName,
      labelIds: this.selectedLabels.map((label) => label.id),
    };

    this.http.callService(new Method(environment.services.dashboard(), newDashboard, 'post')).subscribe((res) => {
      this.snackBar.open(this.commonService.storyblok?.success_message, '', {
        duration: 5000,
        panelClass: ['success-snackBar'],
      });
      this.showCreateDashboard = false;
      const newDashboardId = res['id'];
      this.saveLastSelectedDashboardId(newDashboardId);
      const tabToUse = this.getLastSelectedTab();
      this.selectedTab = tabToUse;
      this.router.navigate(['cti/dashboard', newDashboardId, tabToUse.toLowerCase()]);
    });
  }

  updateDashboard(): void {
    if (!this.editingDashboardId) {
      this.snackBar.open('No dashboard selected for updating', '', {
        duration: 3000,
        panelClass: ['error-snackBar'],
      });
      return;
    }

    const updatedDashboard = {
      name: this.dashboardName,
      labelIds: this.selectedLabels.map((label) => label.id),
    };

    this.http
      .callService(new Method(environment.services.updateDashboard(this.editingDashboardId), updatedDashboard, 'put'))
      .subscribe({
        next: (res) => {
          this.snackBar.open('Dashboard updated successfully', '', {
            duration: 3000,
            panelClass: ['success-snackBar'],
          });

          this.showEditDashboard = false;
          this.editingDashboardId = null;
          this.originalDashboardName = '';

          this.getDashboardData();

          const tabToUse = this.getLastSelectedTab();
          this.selectedTab = tabToUse;
          this.router.navigate(['cti/dashboard', res['id'] || this.editingDashboardId, tabToUse.toLowerCase()]);
        },
        error: (error) => {
          let errorMessage = 'Failed to update dashboard. Please try again.';

          if (error.status === 404) {
            errorMessage = 'Dashboard not found.';
          } else if (error.status === 403) {
            errorMessage = 'You do not have permission to update this dashboard.';
          } else if (error.status === 400) {
            errorMessage = 'Invalid dashboard data. Please check your inputs.';
          } else if (error.status === 500) {
            errorMessage = 'Server error occurred. Please try again later.';
          }

          this.snackBar.open(errorMessage, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        },
      });
  }

  async loadDashboardForEdit(dashboardId: string): Promise<void> {
    if (this.labelList.length === 0) {
      await this.setLabel();
    }

    this.http.callService(new Method(environment.services.dashboardDetail(dashboardId), {}, 'get')).subscribe({
      next: (res: any) => {
        this.dashboardName = res.name || '';
        this.originalDashboardName = this.dashboardName;

        if (res.labels && Array.isArray(res.labels)) {
          this.selectedLabels = res.labels.map((label: any) => ({
            ...label,
            selected: true,
          }));

          this.labelList.forEach((label) => {
            label.selected = this.selectedLabels.some((selectedLabel) => selectedLabel.id === label.id);
          });

          this.labelList.sort((a, b) => {
            if (a.selected && !b.selected) return -1;
            if (!a.selected && b.selected) return 1;

            return a.labelPahtWithTrim.localeCompare(b.labelPahtWithTrim);
          });
        } else {
          this.selectedLabels = [];
        }

        this.selectedDashboard = res;
      },
      error: (error) => {
        this.snackBar.open('Failed to load dashboard details. Please try again.', '', {
          duration: 3000,
          panelClass: ['error-snackBar'],
        });

        this.router.navigate(['cti/dashboard']);
      },
    });
  }

  async selectDashboard(id: number | string): Promise<void> {
    this.aggregateData = this.localStorageService.getCompressedItem(this.localStorageService.AGGREGATE_DATA_KEY) || {};
    this.assessmentsLength = this.aggregateData?.assessments?.length || 0;
    if (this.selectedDashboard && this.selectedDashboard.id == id) {
      return;
    }

    // Check if we're switching to a different dashboard
    const isDifferentDashboard = this.selectedDashboard && this.selectedDashboard.id !== id;

    // Reset all aggregate data and loading states when switching dashboards
    this.aggregateDataProcurement = null;
    this.aggregateDataSustanability = null;
    this.aggregateDataDesign = null;
    this.loadingAggregateProcurement = false;
    this.loadingAggregateSustanability = false;
    this.loadingAggregateDesign = false;

    // Clear aggregate data from localStorage if switching to a different dashboard
    if (isDifferentDashboard) {
      this.clearAggregateData();
    }

    // Update CommonService loading state
    this.commonService.dashboardLoadingState.next({ tab: 'all', loading: true });

    const dashboardId = id;

    if (!this.dashboardData || this.dashboardData.length === 0) {
      try {
        await this.getDashboardDataAsync();
      } catch (e) {
        return;
      }
    }

    if (dashboardId) {
      const dashboard = this.dashboardData.find((dashboard: any) => dashboard.id === dashboardId);
      if (dashboard) {
        this.selectedDashboard = dashboard;
        // Update CommonService for reactive sharing
        this.commonService.selectedDashboard.next(dashboard);

        // Update dashboard state service
        this.dashboardStateService.updateState({
          selectedTab: this.selectedTab,
          dashboardId: dashboardId.toString(),
        });

        try {
          await this.getDashboardDetailAsync(dashboardId);
        } catch (e) {}

        await this.loadDashboardAggregate(this.selectedTab);

        if (!this.router.url.startsWith('/cti/edit-dashboard/')) {
          // Set navigation flag to prevent infinite loops
          this.isNavigating = true;

          const currentTab = this.selectedTab.toLowerCase();
          const currentUrl = this.router.url;
          const desiredUrl = `/cti/dashboard/${dashboardId}/${currentTab}`;

          if (currentUrl !== desiredUrl) {
            this.router.navigate(['cti/dashboard', dashboardId, currentTab]);
          }

          // Reset navigation flag after a short delay
          setTimeout(() => {
            this.isNavigating = false;
          }, 100);
        }
      } else {
        if (this.dashboardData.length > 0) {
          this.selectDashboard(this.dashboardData[0].id);
        }
      }
    } else {
      this.selectedDashboard = null;
      this.router.navigate(['cti/dashboard']);
    }
  }

  async selectTabs(tab: string): Promise<void> {
    // Don't reload if already on the same tab
    if (this.selectedTab === tab) {
      return;
    }

    let navigationSucceeded = true;

    if (this.selectedDashboard) {
      const commands: any[] = ['cti/dashboard', this.selectedDashboard.id, tab.toLowerCase()];
      const desiredUrl = `/${commands.join('/')}`;

      if (this.router.url !== desiredUrl) {
        this.isNavigating = true;
        try {
          navigationSucceeded = await this.router.navigate(commands);
        } catch (error) {
          navigationSucceeded = false;
        } finally {
          setTimeout(() => {
            this.isNavigating = false;
          }, 100);
        }
      }
    }

    if (!navigationSucceeded) {
      return;
    }

    this.selectedTab = tab;
    this.saveLastSelectedTab(tab);

    // Update dashboard state service
    this.dashboardStateService.updateState({
      selectedTab: tab,
      dashboardId: this.selectedDashboard?.id || '',
    });

    if (!this.selectedDashboard && this.dashboardData.length > 0) {
      await this.selectDashboard(this.dashboardData[0].id);
    }

    if (this.selectedDashboard) {
      await this.loadDashboardAggregate(tab);
    }
  }

  private saveLastSelectedDashboardId(dashboardId: string | number): void {
    localStorage.setItem('lastSelectedDashboardId', dashboardId.toString());
  }

  private getLastSelectedDashboardId(): string | null {
    return localStorage.getItem('lastSelectedDashboardId');
  }

  private saveLastSelectedTab(tab: string): void {
    localStorage.setItem('lastSelectedTab', tab);
  }

  private getLastSelectedTab(): string {
    return localStorage.getItem('lastSelectedTab') || 'PROCUREMENT';
  }

  downloadDashboard(): void {
    window.open('/cti/aggregate-report', '_blank');
  }

  closeEditDashboard(): void {
    this.showEditDashboard = false;
    this.editingDashboardId = null;
    this.originalDashboardName = '';
    this.dashboardName = '';
    this.selectedLabels = [];
    this.selectedDashboard = null;

    this.labelList.forEach((label) => {
      label.selected = false;
    });
    const lastSelectedDashboardId = this.getLastSelectedDashboardId();
    if (lastSelectedDashboardId && this.dashboardData.length > 0) {
      const dashboard = this.dashboardData.find((d) => d.id === lastSelectedDashboardId);
      if (dashboard) {
        const tabToUse = this.getLastSelectedTab();
        this.router.navigate(['cti/dashboard', lastSelectedDashboardId, tabToUse.toLowerCase()]);
      } else {
        if (this.dashboardData.length > 0) {
          const tabToUse = this.getLastSelectedTab();
          this.router.navigate(['cti/dashboard', this.dashboardData[0].id, tabToUse.toLowerCase()]);
        } else {
          this.router.navigate(['cti/dashboard']);
        }
      }
    } else {
      this.router.navigate(['cti/dashboard']);
    }
  }

  editDashboard(): void {
    if (!this.selectedDashboard) {
      this.snackBar.open('No dashboard selected for editing', '', {
        duration: 3000,
        panelClass: ['error-snackBar'],
      });
      return;
    }

    this.router.navigate(['cti/edit-dashboard', this.selectedDashboard.id]);
  }

  deleteDashboard(): void {
    if (this.isDeletingDashboard) {
      return;
    }

    if (!this.selectedDashboard) {
      this.snackBar.open('No dashboard selected for deletion', '', {
        duration: 3000,
        panelClass: ['error-snackBar'],
      });
      return;
    }

    this.isDeletingDashboard = true;

    this.ensureDashboardDetailsLoaded()
      .then(() => {
        this.openDeleteDialog();
      })
      .catch((error) => {
        this.snackBar.open('Error loading dashboard details. Please try again.', '', {
          duration: 3000,
          panelClass: ['error-snackBar'],
        });
      })
      .finally(() => {
        this.isDeletingDashboard = false;
      });
  }

  private async ensureDashboardDetailsLoaded(): Promise<void> {
    if (this.selectedDashboard && (!this.selectedDashboard.labels || !this.selectedDashboard.name)) {
      return new Promise((resolve, reject) => {
        this.getDashboardDetail(this.selectedDashboard.id);

        const checkInterval = setInterval(() => {
          if (this.selectedDashboard && this.selectedDashboard.name) {
            clearInterval(checkInterval);
            resolve();
          }
        }, 100);

        setTimeout(() => {
          clearInterval(checkInterval);
          reject(new Error('Timeout waiting for dashboard details'));
        }, 5000);
      });
    }

    return Promise.resolve();
  }

  private openDeleteDialog(): void {
    const dashboardName = this.selectedDashboard?.name || 'this dashboard';

    try {
      const dialogRef = this.dialog.open(DeleteConfirmDialog, {
        width: '650px',
        disableClose: false,
        data: {
          title: 'Delete Dashboard',
          message: `Are you sure you want to delete "${dashboardName}"? This action cannot be undone.`,
          yesButtonText: 'DELETE',
        },
      });

      dialogRef.afterClosed().subscribe((result) => {
        if (result === true) {
          this.performDeleteDashboard();
        }
      });
    } catch (error) {
      this.snackBar.open('Error opening delete dialog. Please try again.', '', {
        duration: 3000,
        panelClass: ['error-snackBar'],
      });
    }
  }

  private performDeleteDashboard(): void {
    if (!this.selectedDashboard?.id) {
      this.snackBar.open('No dashboard selected for deletion', '', {
        duration: 3000,
        panelClass: ['error-snackBar'],
      });
      return;
    }

    this.isDeletingDashboard = true;

    this.snackBar.open('Deleting dashboard...', '', {
      duration: 2000,
      panelClass: ['info-snackBar'],
    });

    this.http
      .callService(new Method(environment.services.deleteDashboard(this.selectedDashboard.id), {}, 'delete'))
      .subscribe({
        next: (res) => {
          this.snackBar.open('Dashboard deleted successfully', '', {
            duration: 3000,
            panelClass: ['success-snackBar'],
          });

          this.dashboardData = this.dashboardData.filter((d) => d.id !== this.selectedDashboard.id);

          this.selectedDashboard = null;

          localStorage.removeItem('lastSelectedDashboardId');

          if (this.dashboardData.length === 0) {
            this.showCreateDashboard = true;
            this.router.navigate(['cti/new-dashboard']);
          } else {
            this.selectDashboard(this.dashboardData[0].id);
          }
        },
        error: (error) => {
          let errorMessage = 'Failed to delete dashboard. Please try again.';

          if (error.status === 404) {
            errorMessage = 'Dashboard not found or already deleted.';
          } else if (error.status === 403) {
            errorMessage = 'You do not have permission to delete this dashboard.';
          } else if (error.status === 500) {
            errorMessage = 'Server error occurred. Please try again later.';
          }

          this.snackBar.open(errorMessage, '', {
            duration: 5000,
            panelClass: ['error-snackBar'],
          });
        },
        complete: () => {
          this.isDeletingDashboard = false;
        },
      });
  }

  loadDashboardAggregate(tabName: string): Promise<void> {
    return new Promise(async (resolve) => {
      if (this.selectedDashboard && this.selectedDashboard.id) {
        // Always set loading to true first
        this.setAggregateState(tabName, null, true);

        try {
          // Use the aggregate data service to get data
          const data = await this.aggregateDataService.getAggregateDataForDashboard(
            this.selectedDashboard.id.toString()
          );
          this.setAggregateState(tabName, data, false);

          // Update assessmentsLength when aggregate data is loaded
          if (data && data.assessments) {
            this.assessmentsLength = data.assessments.length || 0;
          }
        } catch (error) {
          this.setAggregateState(tabName, null, false);
        }
      }
      resolve();
    });
  }

  private setAggregateState(tabName: string, data: any, loading: boolean) {
    if (tabName === 'PROCUREMENT') {
      this.aggregateDataProcurement = data;
      this.loadingAggregateProcurement = loading;
    } else if (tabName === 'SUSTAINABILITY') {
      this.aggregateDataSustanability = data;
      this.loadingAggregateSustanability = loading;
    } else if (tabName === 'DESIGN') {
      this.aggregateDataDesign = data;
      this.loadingAggregateDesign = loading;
    }

    // Update assessmentsLength when data is set (not when loading)
    if (!loading && data && data.assessments) {
      this.assessmentsLength = data.assessments.length || 0;
    }

    // Update CommonService for reactive sharing
    this.commonService.dashboardAggregateData.next({
      tab: tabName,
      data: data,
      loading: loading,
    });
    this.commonService.dashboardLoadingState.next({ tab: tabName, loading: loading });
  }

  private clearAggregateData(): void {
    // Use the aggregate data service to clear data
    this.aggregateDataService.clearAggregateData();

    // Clear all aggregate data properties
    this.aggregateDataProcurement = null;
    this.aggregateDataSustanability = null;
    this.aggregateDataDesign = null;

    // Reset loading states
    this.loadingAggregateProcurement = false;
    this.loadingAggregateSustanability = false;
    this.loadingAggregateDesign = false;

    // Reset assessmentsLength when clearing data
    this.assessmentsLength = 0;

    // Update CommonService to clear reactive data
    this.commonService.dashboardAggregateData.next(null);
    this.commonService.dashboardLoadingState.next({ tab: 'all', loading: false });
  }

  /**
   * Unified loading state method that combines all loading conditions
   */
  isAnyLoading(): boolean {
    // Main dashboard loading
    if (!this.showDashboardContent) {
      return true;
    }

    // Tab-specific loading states
    if (this.selectedTab === 'SUSTAINABILITY' && this.loadingAggregateSustanability) {
      return true;
    }

    if (this.selectedTab === 'PROCUREMENT' && this.loadingAggregateProcurement) {
      return true;
    }

    if (this.selectedTab === 'DESIGN' && this.loadingAggregateDesign) {
      return true;
    }

    // No assessments loading state
    if (
      this.selectedDashboard &&
      !this.showCreateDashboard &&
      !this.showEditDashboard &&
      this.assessmentsLength === 0
    ) {
      return true;
    }

    return false;
  }
}
