import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CiqNumberPipe } from '@app/pipes';

@Component({
  selector: 'app-dashboard-metrics',
  templateUrl: './dashboard-metrics.component.html',
  styleUrls: ['./dashboard-metrics.component.scss'],
  standalone: true,
  imports: [CommonModule, CiqNumberPipe],
})
export class DashboardMetricsComponent {
  @Input() aggregateData: any;
  @Input() loadingAggregate: boolean = false;
  @Input() organisationGoal: any;
  @Input() storyblok: any;
}
