export const services = {
  login() {
    return '/login';
  },
  forgottenPassword() {
    return '/forgottenPassword';
  },
  authenticatetfa() {
    return '/authenticatetfa';
  },
  currentUser() {
    return '/user/current';
  },
  inflowsandOutflofList(id: string, type: string, page: number, size: number, sort: string, order: string) {
    return `/unit/${id}/category/${type}/list?page=${page}&size=${size}&sort=${sort}&order=${order}`;
  },
  inflowsandOutflofListLight(id: string, type: string, page: number, size: number, sort: string, order: string) {
    return `/unit/${id}/category/${type}/listLight?page=${page}&size=${size}&sort=${sort}&order=${order}`;
  },
  getFlowDetail(flowId: string) {
    return `/cti/flow/${flowId}/light`;
  },

  esrsInflowsandOutflofList(
    reportId: string,
    unitId: string,
    type: string,
    page: number,
    size: number,
    sort: string,
    order: string
  ) {
    return `/esrs/e5/report/${reportId}/assessment/${unitId}/category/${type}?page=${page}&size=${size}&sort=${sort}&order=${order}`;
  },

  esrsQuestionData(reportId: string, unitId: string, productId: string) {
    return `/esrs/e5/report/${reportId}/assessment/${unitId}/product/${productId}`;
  },

  invitedFlowList(page: number, size: number) {
    return `/cti/material/listInvited?page=${page}&size=${size}`;
  },
  energy(id: string) {
    return `/cti/unit/${id}/energyUsage`;
  },
  flowSummary(flaowId: any) {
    return `/cti/flow/${flaowId}`;
  },
  productDetail(id: any, summary: any) {
    return `/product/${id}?summary=${summary}`;
  },
  ctiQuestion(id: string) {
    return `/questionnaire/${id}/categories/Product%20Details?dynamic=true`;
  },
  ctiFlowQuestionsSave(id: string) {
    return `/cti/material/${id}/saveFlow`;
  },
  ctiQuestionsPublish(id: string) {
    return `/cti/material/${id}/authorize`;
  },
  unitWithUnitId(unitId: string) {
    return `/unit/${unitId}`;
  },
  unitDetail(id: string) {
    return `/unit/${id}/details`;
  },
  unitEdit(id: string) {
    return `/unit/${id}`;
  },
  loopEdit(id: string) {
    return `/cti/unit/${id}/loop`;
  },
  addMaterial(unitId: string, type: string) {
    return `/cti/unit/${unitId}/category/${type}/add`;
  },
  suppliers(page: any) {
    return `/suppliers?page=${page}`;
  },
  addSuppliers(unitId: string, type: string) {
    return `/cti/unit/${unitId}/category/${type}/addSupplier`;
  },
  guidance() {
    return `/guidance`;
  },
  ctiGuidance() {
    return `/cti/guidance`;
  },
  ctiUnitGuidance(unitId: string) {
    return `/cti/unit/${unitId}/guidance`;
  },
  companyAdmin() {
    return `/user/role/Company%20admin`;
  },
  productManager() {
    return `/user/role/Product%20manager`;
  },
  dataEntryUser() {
    return `/user/role/Data%20entry%20user`;
  },
  responsible(materialId: string) {
    return `/cti/material/${materialId}/responsible`;
  },
  organisation() {
    return `/organisation`;
  },
  organisationDetails() {
    return `/organisation/details`;
  },
  removeMaterial(unitId: string, type: string, productId: any) {
    return `/unit/${unitId}/category/${(type = type === 'supplier' ? 'INFLOW' : type)}/product/${productId}`;
  },
  emailCheck(email: string) {
    return `/user/${email}`;
  },
  emailCheckForSupplier(email: string) {
    return `/suppliers/user/${email}`;
  },
  newSupplier(unitId: string, type: string) {
    return `/cti/unit/${unitId}/category/${type}/addSupplier`;
  },
  productivity(unitId: string) {
    return `/cti/unit/${unitId}/productivity`;
  },
  graph(unitId: string) {
    return `/cti/unit/${unitId}/graph`;
  },
  critical(unitId: string) {
    return `/cti/unit/${unitId}/critical`;
  },
  upload() {
    return `/assets/upload`;
  },
  importUnitProduct(unitId: string) {
    return `/import/unit/${unitId}/product`;
  },
  excelUploadFlow() {
    return `/parsing-service/assessment/excel/flow`;
  },
  token(token: string, reason: string) {
    return `/token/${token}?reason=${reason}`;
  },
  getToken(email: string) {
    return `/token/activation/${email}`;
  },
  setPassword() {
    return `/setPassword`;
  },
  unitReport(unitId: string) {
    return `/cti/unit/${unitId}/report`;
  },
  unitExport(unitId: string) {
    return `/export/unit/${unitId}/products`;
  },
  uploadEveidance() {
    return `/assets/uploadPermanent?folder=evidence`;
  },
  questionnaireWithEvidence(id: string) {
    return `/cti/material/${id}/saveEvidence`;
  },
  improvementList(unitId: string, type: string) {
    return `/unit/${unitId}/category/${type}/improvementList`;
  },
  calculateImprovement(unitId: string, category: string) {
    return `/cti/unit/${unitId}/category/${category}/calculateImprovement`;
  },
  improvement(unitId: string, category: string) {
    return `/cti/unit/${unitId}/category/${category}/improvement`;
  },
  step6AllFlowProperties() {
    return `/cti/getAllFlowProperties`;
  },
  getFlowStrategies(unitId: string) {
    return `/cti/getFlowStrategies/unit/${unitId}`;
  },
  saveFlowStrategies(unitId: string) {
    return `/cti/saveFlowStrategies/unit/${unitId}`;
  },
  saveFlowSolution(unitId: string) {
    return `/cti/saveFlowSolution/unit/${unitId}`;
  },
  saveBusinessCase(unitId: string) {
    return `/cti/saveBusinessCase/unit/${unitId}`;
  },
  resendSingup() {
    return `/signup/resend`;
  },
  getStrategyChecklist(unitId: string) {
    return `/cti/getStrategyChecklist/unit/${unitId}`;
  },
  saveStrategyChecklist(unitId: string) {
    return `/cti/saveStrategyChecklist/unit/${unitId}`;
  },
  productsList(pageIndex: Number, pageSize: Number, direction: String, active: String) {
    if (direction === null || active === null) {
      return `/product?page=${pageIndex}&pageSize=${pageSize}`;
    } else {
      return `/product?order=${direction}&page=${pageIndex}&sort=${active}`;
    }
  },

  addProduct() {
    return `/product`;
  },
  addProductCSV() {
    return `/assets/upload`;
  },
  uploadCSV() {
    return `/import/product`;
  },
  productNameList() {
    return `/product?onlyName=true`;
  },
  cloneProduct(id: any) {
    return `/product/${id}`;
  },

  suppliersList(pageIndex?: Number, pageSize?: Number, direction?: String, active?: String) {
    return `/suppliers`;
  },
  supplierDetail(id: any) {
    return `/suppliers/${id}`;
  },
  usersOfSupplier(id: any) {
    return `/suppliers/${id}/users`;
  },
  userDetail(email: any) {
    return `/user/${email}`;
  },
  createSuppliers(id: any, isNewUser: boolean) {
    return `/invitations/product/${id}?isNewUser=${isNewUser}`;
  },
  questionnaireForm(id: any, cat: any) {
    return `/questionnaire/${id}/categories/${cat}?dynamic=true`;
  },
  putQuestionnaireForm(id: any) {
    return `/questionnaire/${id}?dynamic=true`;
  },
  filter() {
    return `/filter`;
  },
  users(page: any) {
    return `/user?page=${page}`;
  },
  user() {
    return `/user`;
  },
  userRole(email: any) {
    return `/user/${email}/role`;
  },
  bomList(pageIndex?: Number, pageSize?: Number, direction?: String, id?: any) {
    return `/product/${id}/bom`;
  },
  deleteBom(productId: string, bomId: string) {
    return `/product/${productId}/bom/${bomId}/remove`;
  },
  editBom(productId: string, bomId: string) {
    return `/product/${productId}/bom/${bomId}`;
  },
  updateBomProperties(productId: string, bomId: string) {
    return `/product/${productId}/bom/properties/${bomId}`;
  },
  createBom(productId: string, isGenericMaterial: string) {
    return `/product/${productId}/bom/${isGenericMaterial}`;
  },
  createBomComponent(productId: string) {
    return `/product/${productId}/bom`;
  },
  bomListOther(productId: string) {
    return `/product/${productId}/bom/listOther`;
  },
  assetsUpload() {
    return `/assets/upload`;
  },
  imageDownload(fileName: any) {
    return `/assets/download/${fileName}`;
  },
  productPermissions(productId: string) {
    return `/product/${productId}/permissions`;
  },
  invitationsProduct(productId: string, isNewUser: boolean) {
    return `/invitations/product/${productId}?isNewUser=${isNewUser}`;
  },
  checkEmail(email: string) {
    return `/suppliers/user/${email}`;
  },
  delegate(productId: string) {
    return `/invitations/product/${productId}/delegate`;
  },
  featuresOrganisation(orgId: string) {
    return `/features/organisation/${orgId}`;
  },
  adminSettings(orgId: string, feature: any, status: string) {
    return `/admin/organisation/${orgId}/feature/${feature}/status/${status}`;
  },
  reportStatus(unitId: string) {
    return `/cti/unit/${unitId}/reportStatus`;
  },
  password() {
    return `/user/password`;
  },
  columns(lens: string) {
    return `/question-service/question/columns/${lens}`;
  },
  spreadsheet(productId: string) {
    return `/product-service/product/spreadsheet/${productId}`;
  },
  getSpreadsheet(spreadsheetUuid: string) {
    return `/csvimport-service/spreadsheet/${spreadsheetUuid}`;
  },
  spreadsheetRowEdit() {
    return `/csvimport-service/spreadsheet/row`;
  },
  spreadsheetCreate() {
    return `/csvimport-service/spreadsheet`;
  },
  spreadsheetInsertingNewRow(spreadsheetUuid: string) {
    return `/csvimport-service/spreadsheet/row/${spreadsheetUuid}`;
  },
  lenses() {
    return `/question-repository/lenses`;
  },
  spreadsheetId(productUuid: string) {
    return `/csvimport-service/spreadsheet/product/${productUuid}`;
  },
  ecocost(productUuid: string) {
    return `/calculation-service/circularity/product/${productUuid}/ecocost`;
  },
  improvementQuestiont(unitId: string, category: string) {
    return `/cti/unit/${unitId}/category/${category}/improvementQuestion`;
  },

  step6Question(unitId: string, category: string) {
    return `/cti/unit/${unitId}/category/${category}/step6`;
  },
  step7SamartTarget(unitId: string) {
    return `/cti/unit/${unitId}/step7`;
  },
  questionList() {
    return `/question-service/question/list`;
  },
  answers(questionnaireuUuid: string) {
    return `/questionnaire/${questionnaireuUuid}/answers`;
  },
  publishSpreasheet(spreadsheetUuid: string) {
    return `/csvimport-service/spreadsheet/authorize/${spreadsheetUuid}`;
  },
  authorizeProduct(productUuid: string) {
    return `/product-service/product/authorize/product/${productUuid}`;
  },
  adminOrganisation() {
    return `/admin/organisation`;
  },
  isReadySpreadsheet(spreadsheetUuid: string) {
    return `/csvimport-service/spreadsheet/isReady/spreadsheet/${spreadsheetUuid}`;
  },
  removeProject(productUuid: any) {
    return `/product/${productUuid}`;
  },
  getIndicators(unitId: string) {
    return `/cti/unit/${unitId}/indicators`;
  },
  unitDetailed(unitId: string) {
    return `/cti/unit/${unitId}/detailed`;
  },
  unitWater(unitId: string) {
    return `/cti/unit/${unitId}/water`;
  },
  unitOnsiteWater(unitId: string) {
    return `/cti/unit/${unitId}/onsiteWater`;
  },
  unitGraph(unitId: string) {
    return `/cti/unit/${unitId}/graph`;
  },
  energyImprovement(unitId: string) {
    return `/cti/unit/${unitId}/energyImprovement`;
  },
  waterImprovement(unitId: string) {
    return `/cti/unit/${unitId}/waterImprovement`;
  },
  ctiReport(unitId: string) {
    return `/cti/unit/${unitId}/reportData`;
  },
  ctiReportGenerate() {
    return `/pdf/generate`;
  },
  listBusinessLevels() {
    return `/businessLevel`;
  },
  addAssessment(businessLevelID: string) {
    return `/businessLevel/${businessLevelID}/assessment`;
  },
  getAssessment(assessmentId: string) {
    return `/businessLevel/assessment/${assessmentId}`;
  },
  getCTIProDashboard() {
    return `/businessLevel/dashboard`;
  },
  deleteBusinessLevel(businessLevelID: string) {
    return `/businessLevel/${businessLevelID}`;
  },
  editBusinessLevel(businessLevelID: string) {
    return `/businessLevel/${businessLevelID}`;
  },
  getUnitBusinessLevel(unitId: string) {
    return `/businessLevel/byUnit/${unitId}`;
  },
  BusinessLevelsOfuser(userId: string) {
    return `/businessLevel/user/${userId}`;
  },
  membersOfBusinessLevel(businessLevelID: string) {
    return `/businessLevel/${businessLevelID}/member`;
  },
  removeMembersOfBusinessLevel(businessLevelID: string, userId: string) {
    return `/businessLevel/${businessLevelID}/member/${userId}`;
  },
  compareBusiness() {
    return `/businessLevel/compare`;
  },
  aggregateBusiness() {
    return `/businessLevel/aggregate`;
  },
  listInvited() {
    return `/cti/material/listInvited`;
  },
  deleteGHGMaterial(unitId: string, flowId: string) {
    return `/cti/deleteGHGMaterial/unit/${unitId}/flow/${flowId}`;
  },
  lifetimeExtension(unitId: string) {
    return `/cti/unit/${unitId}/lifetimeExtension`;
  },
  revenueCompanyLevel() {
    return `/cti/revenueCompanyLevel`;
  },
  duplicateAssessment(assessmentId: string) {
    return `/businessLevel/assessment/${assessmentId}/duplicate`;
  },
  checkduplicateAssessmentStatus(assessmentId: string) {
    return `/businessLevel/duplicateAssessment/${assessmentId}`;
  },
  flowIndicators(flowId: string) {
    return `/cti/flow/${flowId}/indicators`;
  },
  duplicateAssessmentNonSuccessful() {
    return `/businessLevel/duplicateAssessment/status/nonSuccessful`;
  },
  duplicateAssessmentDelete(duplicateAssessmentId: string) {
    return `/businessLevel/duplicateAssessment/${duplicateAssessmentId}`;
  },
  uploadPermanent() {
    return `/assets/uploadPermanent?folder=assessments/imports`;
  },
  parsingServiceJSON() {
    return `/parsing-service/assessment/json`;
  },
  parsingServiceExcel() {
    return `/parsing-service/assessment/excel`;
  },
  assessmentImport() {
    return `/assessmentImport`;
  },
  deleteFailedAssessment(assessmentId: string) {
    return `/assessmentImport/${assessmentId}`;
  },
  assessmentImportErrorDetail(assessmentId: string) {
    return `/assessmentImport/${assessmentId}/errors`;
  },
  organizationGoal() {
    return `/cti/material/listInvited`;
  },
  setOrganisationGoal() {
    return `/organisation/ctiGoal`;
  },
  isEnabledCTIGoal() {
    return `/organisation/ctiGoal/enabled`;
  },
  membership(organisationId: string) {
    return `/membership/organization/${organisationId}`;
  },
  loginOrganisation() {
    return `/loginOrganisation`;
  },
  organisationLanguage() {
    return `/organisation/language`;
  },
  deleteMembership(userId: string) {
    return `/membership/user/${userId}/drop`;
  },
  organisationName() {
    return `/organisation/name`;
  },
  assessmentSnapshot() {
    return `/assessmentSnapshot`;
  },

  assessmentSnapshotEdit(snapshotId: string) {
    return `/assessmentSnapshot/${snapshotId}/name`;
  },
  assessmentSnapshotRemove(snapshotId: string) {
    return `/assessmentSnapshot/${snapshotId}`;
  },
  moveAssessments(businessLevelId: string) {
    return `/businessLevel/${businessLevelId}/moveAssessments`;
  },
  supplierNames() {
    return `/unit/supplierNames`;
  },
  productLineDetails(unitId: string) {
    return `/unit/${unitId}/productLineDetails`;
  },
  scope(unitId: string) {
    return `/unit/${unitId}/scope`;
  },
  onboarding() {
    return `/organisation/onboarding`;
  },
  userJourney() {
    return `/user/journey`;
  },
  userJourneyCTI() {
    return `/user/journey/cti`;
  },
  memberPreferences() {
    return `/member/preferences`;
  },
  update2FABannerPreference() {
    return `/member/preference/2fa-banner`;
  },
  validateEmail(token: string) {
    return `/email/validate/${token}`;
  },
  isvalidateEmail() {
    return `/email/validate`;
  },
  sampleAssessment(sampleName: string) {
    return `/parsing-service/assessment/json/sample/${sampleName}`;
  },
  ghgImprovement(unitId: string, category: string, save: boolean) {
    return `/cti/unit/${unitId}/category/${category}/ghgImprovement?save=${save}`;
  },
  natureImpact(unitId: string) {
    return `/cti/unit/${unitId}/natureImpact`;
  },

  natureImpactImprovement(unitId: string) {
    return `/cti/unit/${unitId}/natureImpactImprovement`;
  },
  membershipSupport() {
    return `/membership/support`;
  },
  contact() {
    return `/cti/contact`;
  },
  label() {
    return `/label`;
  },
  getAssessmentaccordingToLabel() {
    return `/businessLevel/dashboard/label `;
  },
  labelSearch() {
    return `/label/search`;
  },
  labelAttach() {
    return `/label/attach`;
  },
  labelDrop() {
    return `/label/drop`;
  },
  labelaction(labelId: string) {
    return `/label/${labelId}`;
  },
  assementLabel(unitId: string) {
    return `/label/unit/${unitId}`;
  },

  createESRSReport() {
    return `/esrs/e5/report`;
  },
  getESRSReport() {
    return `/esrs/e5/report`;
  },
  getESRSReportDetail(uuid: string) {
    return `/esrs/e5/report/${uuid}`;
  },

  addAssessmentDefault() {
    return `/businessLevel/default/assessment`;
  },
  getESRSPDFReportDetail(report: string) {
    return `/esrs/e5/report/${report}/detail`;
  },

  getHazardous() {
    return `/esrs/e5/materials/hazardous`;
  },
  setHazardous() {
    return `/esrs/e5/materials/setHazardous`;
  },
  deleteReport(reportId: string) {
    return `/esrs/e5/report/${reportId}`;
  },
  updateReport(reportId: string) {
    return `/esrs/e5/report/${reportId}`;
  },

  removeFlow(unitId: string, category: string) {
    return `/unit/${unitId}/category/${category}/product/remove`;
  },
  flowNameCheck(unitId: string, category: string) {
    return `/unit/${unitId}/category/${category}/name/check`;
  },
  assessmentNameCheck() {
    return `/unit/name/check`;
  },

  bulkDelete() {
    return `/businessLevel/assessment/bulkDelete`;
  },
  dashboard() {
    return `/cti/dashboard`;
  },
  dashboardDetail(id: string) {
    return `/cti/dashboard/${id}`;
  },
  deleteDashboard(id: string) {
    return `/cti/dashboard/${id}`;
  },
  updateDashboard(id: string) {
    return `/cti/dashboard/${id}`;
  },
  dashboardAggregate(dashboardId: string) {
    return `/cti/dashboard/${dashboardId}/aggregate`;
  },

  dashboardFlows(
    dashboardId: string,
    category: string,
    page: number,
    size: number,
    sortParams?: {
      legacyField?: string;
      nodeField?: string;
      legacyDirection?: string;
      nodeDirection?: string;
    },
    scenarioId?: string
  ) {
    const resolvedSort = sortParams?.legacyField || 'NAME';
    const resolvedOrder = sortParams?.legacyDirection || 'ASCENDING';

    const queryParams = new URLSearchParams({
      category: category,
      page: page.toString(),
      size: size.toString(),
      sort: resolvedSort,
      order: resolvedOrder,
    });

    // Optional scenario selection (original scenario has no id)
    if (scenarioId) {
      queryParams.append('scenarioId', scenarioId);
    }

    if (sortParams?.nodeField) {
      queryParams.append('pageNumber', page.toString());
      queryParams.append('pageSize', size.toString());
      queryParams.append('sortField', sortParams.nodeField);
      queryParams.append('sortDirection', sortParams.nodeDirection || (resolvedOrder === 'ASCENDING' ? 'ASC' : 'DESC'));
    }

    return `/cti/dashboard/${encodeURIComponent(dashboardId.toString())}/groupedFlows?${queryParams.toString()}`;
  },

  dashboardGroups(
    baselineId: string,
    flowType: string[],
    flowCategory: string,
    sortBy: string = 'total_mass',
    scenarioId?: string
  ): string {
    const queryParams = new URLSearchParams();

    // API expects flow_type: product | packaging | waste (multiple params)
    const apiFlowTypes = flowType.map((ft) => {
      if (ft === 'products') return 'product';
      if (ft === 'plastics') return 'packaging';
      if (ft === 'waste') return 'waste';
      return ft;
    });
    apiFlowTypes.forEach((ft) => queryParams.append('flow_type', ft));

    // API expects flow_category: INFLOW | OUTFLOW (uppercase)
    queryParams.append('flow_category', (flowCategory || 'INFLOW').toUpperCase());
    queryParams.append('sort_by', sortBy);
    if (scenarioId) {
      queryParams.append('scenario_id', scenarioId);
    }

    return `/flow-analysis/baseline/${encodeURIComponent(baselineId)}/groups?${queryParams.toString()}`;
  },

  dashboardGroupsFlows(
    baselineId: string,
    options: {
      materialCategory?: string;
      subMaterialCategory?: string;
      flowType?: string[];
      flowCategory: string;
      sortBy?: string;
      scenarioId?: string;
      page?: number;
      pageSize?: number;
    }
  ): string {
    const {
      materialCategory,
      subMaterialCategory,
      flowType = [],
      flowCategory,
      sortBy = 'total_mass',
      scenarioId,
      page = 1,
      pageSize = 20,
    } = options;

    const queryParams = new URLSearchParams({
      flow_category: flowCategory,
      sort_by: sortBy,
      page: page.toString(),
      page_size: pageSize.toString(),
    });

    if (materialCategory) {
      queryParams.append('material_category', materialCategory);
    }
    if (subMaterialCategory) {
      queryParams.append('sub_material_category', subMaterialCategory);
    }
    if (flowType.length > 0) {
      const apiFlowTypes = flowType.map((ft) => {
        if (ft === 'products') return 'product';
        if (ft === 'plastics') return 'packaging';
        if (ft === 'waste') return 'waste';
        return ft;
      });
      apiFlowTypes.forEach((ft) => queryParams.append('flow_type', ft));
    }
    if (scenarioId) {
      queryParams.append('scenario_id', scenarioId);
    }

    return `/flow-analysis/baseline/${encodeURIComponent(baselineId)}/groups/flows?${queryParams.toString()}`;
  },

  dashboardComments(dashboardId: string) {
    return `/cti/dashboard/${dashboardId}/comment`;
  },
  markCommentRead(commentId: string) {
    return `/cti/dashboard/comment/${commentId}/mark-read`;
  },
  headersComments() {
    return `/cti/dashboard/comments`;
  },
  businessLevelStats() {
    return `/businessLevel/stats`;
  },
  dashboardScenarios(dashboardId: string, category: string) {
    return `/cti/dashboard/${dashboardId}/scenarios/${category}`;
  },

  improvementsDashboardScenario(scenarioId: string) {
    return `/cti/scenarios/${scenarioId}/improvements`;
  },

  dashboardScenarioImprovements(scenarioId: string) {
    return `/cti/scenarios/${scenarioId}/improvements`;
  },

  deleteDashboardScenario(scenarioId: string) {
    return `/cti/scenarios/${scenarioId}`;
  },
  reviewImprovements(dashboardId: string, category: string) {
    return `/cti/dashboard/${dashboardId}/preview-improvements/${category}`;
  },

  natureImpactExtentList: [
    {
      estimatedValue: '~0 ',
      extendDimension: 'NEGLIGIBLE',
      displayName: 'Negligible',
      score: '0.01',
    },
    {
      estimatedValue: '0 < 0.1 ',
      extendDimension: 'VERY_SMALL',
      displayName: 'Very small',
      score: '0.1',
    },
    {
      estimatedValue: '0.1 < 1 ',
      extendDimension: 'SMALL',
      displayName: 'Small',
      score: '1',
    },
    {
      estimatedValue: '1 < 10 ',
      extendDimension: 'SMALL_MEDIUM',
      displayName: 'Small - medium',
      score: '10',
    },
    {
      estimatedValue: '10 < 100 ',
      extendDimension: 'MEDIUM_LARGE',
      displayName: 'Medium - large',
      score: '100',
    },
    {
      estimatedValue: '100 < 1,000 ',
      extendDimension: 'LARGE',
      displayName: 'Large',
      score: '1000',
    },
    {
      estimatedValue: '1,000 < 10,000 ',
      extendDimension: 'VERY_LARGE',
      displayName: 'Very large',
      score: '10000',
    },
    {
      estimatedValue: '> 10,000 ',
      extendDimension: 'EXTREMELY_LARGE',
      displayName: 'Extremely large',
      score: '20000',
    },
  ],
  natureImpactConditionList: [
    {
      estimatedValue: '0 < 0.01 ',
      conditionDimension: 'VERY_SMALL',
      displayName: 'Very small',
      score: '0.01',
    },
    {
      estimatedValue: '0.01 < 0.1 ',
      conditionDimension: 'SMALL',
      displayName: 'Small',
      score: '0.1',
    },
    {
      estimatedValue: '0.1 < 0.3 ',
      conditionDimension: 'SMALL_MEDIUM',
      displayName: 'Small - medium',
      score: '0.3',
    },
    {
      estimatedValue: '0.3 < 0.5 ',
      conditionDimension: 'MEDIUM_LARGE',
      displayName: 'Medium - large',
      score: '0.5',
    },
    {
      estimatedValue: '0.5 < 0.7 ',
      conditionDimension: 'LARGE',
      displayName: 'Large',
      score: '0.7',
    },
    {
      estimatedValue: '> 0.7 ',
      conditionDimension: 'VERY_LARGE',
      displayName: 'Very large',
      score: '1',
    },
  ],
  natureImpactSignificancenList: [
    {
      estimatedValue: '0 < 10 ',
      significanceDimension: 'LOW',
      displayName: 'Low',
      score: '1',
    },
    {
      estimatedValue: '10 < 100 ',
      significanceDimension: 'MODERATE',
      displayName: 'Moderate',
      score: '2',
    },
    {
      estimatedValue: '100 < 1,000 ',
      significanceDimension: 'HIGH',
      displayName: 'High',
      score: '3',
    },
    {
      estimatedValue: '1,000 < 10,000 ',
      significanceDimension: 'VERY_HIGH',
      displayName: 'Very high',
      score: '4',
    },
    {
      estimatedValue: '10,000 < 100,000 ',
      significanceDimension: 'HIGHEST',
      displayName: 'Highest',
      score: '5',
    },
  ],
  mounthList: [
    { name: 'January', num: '01' },
    { name: 'February', num: '02' },
    { name: 'March', num: '03' },
    { name: 'April', num: '04' },
    { name: 'May', num: '05' },
    { name: 'June', num: '06' },
    { name: 'July', num: '07' },
    { name: 'August', num: '08' },
    { name: 'September', num: '09' },
    { name: 'October', num: '10' },
    { name: 'November', num: '11' },
    { name: 'December', num: '12' },
  ],
  industries: [
    'Agriculture, forestry and fishing',
    'Mining and quarrying',
    'Manufacturing',
    'Electricity, gas, steam and air conditioning supply',
    'Water supply; sewerage, waste management and remediation activities',
    'Construction',
    'Wholesale and retail trade; repair of motor vehicles and motorcycles',
    'Transportation and storage',
    'Accommodation and food service activities',
    'Information and communication',
    'Financial and insurance activities',
    'Real estate activities',
    'Professional, scientific and technical activities',
    'Administrative and support service activities',
    'Public administration and defence; compulsory social security',
    'Education',
    'Human health and social work activities',
    'Arts, entertainment and recreation',
    'Other service activities',
    'Activities of households as employers; undifferentiated goods- and services-producing activities of households for own use',
    'Activities of extraterritorial organizations and bodies',
    'Other',
  ],
  positions: [
    'Materials extraction and agriculture',
    'Upstream materials producer (chemicals, mining, metal…)',
    'Manufacturer of consumable goods (food, medicine…)',
    'Manufacturer of consumer goods and infrastructure (clothes, electronics, buildings..)',
    'Waste and waste water treatment',
    'Reverse cycle for products (refurbish and tighter)',
    'Retail of consumer goods and infrastructure',
    'Services using products (e.g., transportation)',
    'Purely services (e.g., consulting)',
    'Other',
  ],
  countries: [
    'Afghanistan',
    'Åland Islands',
    'Albania',
    'Algeria',
    'American Samoa',
    'Andorra',
    'Angola',
    'Anguilla',
    'Antarctica',
    'Antigua and Barbuda',
    'Argentina',
    'Armenia',
    'Aruba',
    'Australia',
    'Austria',
    'Azerbaijan',
    'Bahamas',
    'Bahrain',
    'Bangladesh',
    'Barbados',
    'Belarus',
    'Belgium',
    'Belize',
    'Benin',
    'Bermuda',
    'Bhutan',
    'Bolivia',
    'Bosnia and Herzegovina',
    'Botswana',
    'Bouvet Island',
    'Brazil',
    'British Indian Ocean Territory',
    'British Virgin Islands',
    'Brunei',
    'Bulgaria',
    'Burkina Faso',
    'Burundi',
    'Cambodia',
    'Cameroon',
    'Canada',
    'Cape Verde',
    'Cayman Islands',
    'Central African Republic',
    'Chad',
    'Chile',
    'China',
    'Christmas Island',
    'Cocos (Keeling) Islands',
    'Colombia',
    'Comoros',
    'Cook Islands',
    'Costa Rica',
    'Croatia',
    'Cuba',
    'Curaçao',
    'Cyprus',
    'Czech Republic',
    'Denmark',
    'Djibouti',
    'Dominica',
    'Dominican Republic',
    'DR Congo',
    'Ecuador',
    'Egypt',
    'El Salvador',
    'Equatorial Guinea',
    'Eritrea',
    'Estonia',
    'Ethiopia',
    'Falkland Islands',
    'Faroe Islands',
    'Fiji',
    'Finland',
    'France',
    'French Guiana',
    'French Polynesia',
    'French Southern and Antarctic Lands',
    'Gabon',
    'Gambia',
    'Georgia',
    'Germany',
    'Ghana',
    'Gibraltar',
    'Greece',
    'Greenland',
    'Grenada',
    'Guadeloupe',
    'Guam',
    'Guatemala',
    'Guernsey',
    'Guinea',
    'Guinea-Bissau',
    'Guyana',
    'Haiti',
    'Heard Island and McDonald Islands',
    'Honduras',
    'Hong Kong',
    'Hungary',
    'Iceland',
    'India',
    'Indonesia',
    'Iran',
    'Iraq',
    'Ireland',
    'Isle of Man',
    'Israel',
    'Italy',
    'Ivory Coast',
    'Jamaica',
    'Japan',
    'Jersey',
    'Jordan',
    'Kazakhstan',
    'Kenya',
    'Kiribati',
    'Kuwait',
    'Kyrgyzstan',
    'Laos',
    'Latvia',
    'Lebanon',
    'Lesotho',
    'Liberia',
    'Libya',
    'Liechtenstein',
    'Lithuania',
    'Luxembourg',
    'Macau',
    'Macedonia',
    'Madagascar',
    'Malawi',
    'Malaysia',
    'Maldives',
    'Mali',
    'Malta',
    'Marshall Islands',
    'Martinique',
    'Mauritania',
    'Mauritius',
    'Mayotte',
    'Mexico',
    'Micronesia',
    'Moldova',
    'Monaco',
    'Mongolia',
    'Montenegro',
    'Montserrat',
    'Morocco',
    'Mozambique',
    'Myanmar',
    'Namibia',
    'Nauru',
    'Nepal',
    'Netherlands',
    'New Caledonia',
    'New Zealand',
    'Nicaragua',
    'Niger',
    'Nigeria',
    'Niue',
    'Norfolk Island',
    'North Korea',
    'Northern Mariana Islands',
    'Norway',
    'Oman',
    'Pakistan',
    'Palau',
    'Palestine',
    'Panama',
    'Papua New Guinea',
    'Paraguay',
    'Peru',
    'Philippines',
    'Pitcairn Islands',
    'Poland',
    'Portugal',
    'Puerto Rico',
    'Qatar',
    'Republic of the Congo',
    'Reunion',
    'Romania',
    'Russia',
    'Rwanda',
    'Saint Barthélemy',
    'Saint Kitts and Nevis',
    'Saint Lucia',
    'Saint Martin',
    'Saint Pierre and Miquelon',
    'Saint Vincent and the Grenadines',
    'Samoa',
    'San Marino',
    'Sao Tome and Principe',
    'Saudi Arabia',
    'Senegal',
    'Serbia',
    'Seychelles',
    'Sierra Leone',
    'Singapore',
    'Sint Maarten',
    'Slovakia',
    'Slovenia',
    'Solomon Islands',
    'Somalia',
    'South Africa',
    'South Georgia',
    'South Korea',
    'South Sudan',
    'Spain',
    'Sri Lanka',
    'Sudan',
    'Suriname',
    'Svalbard and Jan Mayen',
    'Swaziland',
    'Sweden',
    'Switzerland',
    'Syria',
    'Taiwan',
    'Tajikistan',
    'Tanzania',
    'Thailand',
    'Timor-Leste',
    'Togo',
    'Tokelau',
    'Tonga',
    'Trinidad and Tobago',
    'Tunisia',
    'Turkey',
    'Turkmenistan',
    'Turks and Caicos Islands',
    'Tuvalu',
    'Uganda',
    'Ukraine',
    'United Arab Emirates',
    'United Kingdom',
    'United States',
    'United States Minor Outlying Islands',
    'United States Virgin Islands',
    'Uruguay',
    'Uzbekistan',
    'Vanuatu',
    'Vatican City',
    'Venezuela',
    'Vietnam',
    'Wallis and Futuna',
    'Western Sahara',
    'Yemen',
    'Zambia',
    'Zimbabwe',
  ],
  businessLevels: ['Select business level', 'Company level', 'Business unit', 'Product line', 'Site location', 'Other'],

  actualRecoveryRates: {
    'Metals - Steel - MATERIAL': '85',
    'Metals - Steel - building - sheet': '95',
    'Metals - Steel - packaging': '74',
    'Metals - Steel - steel hangers and screws': '95',
    'Metals - Aluminium - MATERIAL (unspcified)': '85',
    'Metals - Aluminium - automotive': '90',
    'Metals - Aluminium - building - sheet': '95',
    'Metals - Aluminium - building - e.g. doors, windows': '90',
    'Metals - Aluminium - appliances - sheet': '90',
    'Metals - Aluminium - packaging - cans, closures, trays': '69',
    'Metals - Copper - building - sheet': '95',
    'Metals - Copper - building - pipes': '95',
    'Metals - Copper - electronic applications': '80',
    'Metals - Copper - electrical applications (cables)': '95',
    'Metals - Copper - mechanical applications': '80',
    'Metals - Copper - building - water supply pipes': '95',
    'Metals - Copper alloys - building - water supply pipes': '95',
    'Metals - Lead - building - sheet': '95',
    'Paper - MATERIAL': '62',
    'Plastics - PET - packaging - bottle': '42',
    'Plastics - PE - PE-LD building and construction': '27.5',
    'Plastics - PE - PE-HD building and construction': '27.5',
    'Plastics - PP - building and construction': '18.3',
    'Plastics - PS - building and construction': '6.7',
    'Plastics - EPS - building and construction': '6.7',
    'Plastics - PVC - building and construction': '32.1',
    'Plastics - Polycarbonate PC - packaging - water': '29.',
    'Plastics - Generic plastics - packaging - generic': '29.',
    'Glass - MATERIAL': '66',
    'Wood - packaging - pallet': '30',
    'Textiles - t-shirts': '11',
  },
};
