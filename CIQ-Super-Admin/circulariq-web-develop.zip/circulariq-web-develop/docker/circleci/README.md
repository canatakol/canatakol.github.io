README.md
# CircleCI FE builder image

Image required to build frontend application of CIQ, test and deploy them to AWS EKS via CircleCI.



## Usage
docker build -t 920961825756.dkr.ecr.eu-central-1.amazonaws.com/fe-builder:latest .
